package javax.measure;

import org.p003jf.dexlib2.Opcode;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public enum BinaryPrefix implements Prefix {
    KIBI("Ki", 1),
    MEBI("Mi", 2),
    GIBI("Gi", 3),
    TEBI("Ti", 4),
    PEBI("Pi", 5),
    EXBI("Ei", 6),
    ZEBI("Zi", 7),
    YOBI("Yi", 8);

    private final int exponent;
    private final String symbol;

    BinaryPrefix(String str, int i) {
        this.symbol = str;
        this.exponent = i;
    }

    public static <Q extends Quantity<Q>> Unit<Q> EXBI(Unit<Q> unit) {
        return unit.prefix(EXBI);
    }

    public static <Q extends Quantity<Q>> Unit<Q> GIBI(Unit<Q> unit) {
        return unit.prefix(GIBI);
    }

    public static <Q extends Quantity<Q>> Unit<Q> KIBI(Unit<Q> unit) {
        return unit.prefix(KIBI);
    }

    public static <Q extends Quantity<Q>> Unit<Q> MEBI(Unit<Q> unit) {
        return unit.prefix(MEBI);
    }

    public static <Q extends Quantity<Q>> Unit<Q> PEBI(Unit<Q> unit) {
        return unit.prefix(PEBI);
    }

    public static <Q extends Quantity<Q>> Unit<Q> TEBI(Unit<Q> unit) {
        return unit.prefix(TEBI);
    }

    public static <Q extends Quantity<Q>> Unit<Q> YOBI(Unit<Q> unit) {
        return unit.prefix(YOBI);
    }

    public static <Q extends Quantity<Q>> Unit<Q> ZEBI(Unit<Q> unit) {
        return unit.prefix(ZEBI);
    }

    @Override // javax.measure.Prefix
    public int getExponent() {
        return this.exponent;
    }

    @Override // javax.measure.Prefix
    public String getName() {
        return name();
    }

    @Override // javax.measure.Prefix
    public String getSymbol() {
        return this.symbol;
    }

    @Override // javax.measure.Prefix
    public Integer getValue() {
        return Integer.valueOf(Opcode.CAN_INITIALIZE_REFERENCE);
    }
}
