package javax.measure;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class MeasurementException extends RuntimeException {
    private static final long serialVersionUID = 8959937033300443361L;

    public MeasurementException(String str) {
        super(str);
    }

    public MeasurementException(Throwable th) {
        super(th);
    }

    public MeasurementException(String str, Throwable th) {
        super(str, th);
    }

    public MeasurementException() {
    }
}
