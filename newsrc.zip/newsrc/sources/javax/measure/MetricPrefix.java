package javax.measure;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public enum MetricPrefix implements Prefix {
    QUETTA("Q", 30),
    RONNA("R", 27),
    YOTTA("Y", 24),
    ZETTA("Z", 21),
    EXA("E", 18),
    PETA("P", 15),
    TERA("T", 12),
    GIGA("G", 9),
    MEGA("M", 6),
    KILO("k", 3),
    HECTO("h", 2),
    DECA("da", 1),
    DECI("d", -1),
    CENTI("c", -2),
    MILLI("m", -3),
    MICRO("µ", -6),
    NANO("n", -9),
    PICO("p", -12),
    FEMTO("f", -15),
    ATTO("a", -18),
    ZEPTO("z", -21),
    YOCTO("y", -24),
    RONTO("r", -27),
    QUECTO("q", -30);

    private final int exponent;
    private final String symbol;

    MetricPrefix(String str, int i) {
        this.symbol = str;
        this.exponent = i;
    }

    public static <Q extends Quantity<Q>> Unit<Q> ATTO(Unit<Q> unit) {
        return unit.prefix(ATTO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> CENTI(Unit<Q> unit) {
        return unit.prefix(CENTI);
    }

    public static <Q extends Quantity<Q>> Unit<Q> DECA(Unit<Q> unit) {
        return unit.prefix(DECA);
    }

    public static <Q extends Quantity<Q>> Unit<Q> DECI(Unit<Q> unit) {
        return unit.prefix(DECI);
    }

    public static <Q extends Quantity<Q>> Unit<Q> DEKA(Unit<Q> unit) {
        return unit.prefix(DECA);
    }

    public static <Q extends Quantity<Q>> Unit<Q> EXA(Unit<Q> unit) {
        return unit.prefix(EXA);
    }

    public static <Q extends Quantity<Q>> Unit<Q> FEMTO(Unit<Q> unit) {
        return unit.prefix(FEMTO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> GIGA(Unit<Q> unit) {
        return unit.prefix(GIGA);
    }

    public static <Q extends Quantity<Q>> Unit<Q> HECTO(Unit<Q> unit) {
        return unit.prefix(HECTO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> KILO(Unit<Q> unit) {
        return unit.prefix(KILO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> MEGA(Unit<Q> unit) {
        return unit.prefix(MEGA);
    }

    public static <Q extends Quantity<Q>> Unit<Q> MICRO(Unit<Q> unit) {
        return unit.prefix(MICRO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> MILLI(Unit<Q> unit) {
        return unit.prefix(MILLI);
    }

    public static <Q extends Quantity<Q>> Unit<Q> NANO(Unit<Q> unit) {
        return unit.prefix(NANO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> PETA(Unit<Q> unit) {
        return unit.prefix(PETA);
    }

    public static <Q extends Quantity<Q>> Unit<Q> PICO(Unit<Q> unit) {
        return unit.prefix(PICO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> QUECTO(Unit<Q> unit) {
        return unit.prefix(QUECTO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> QUETTA(Unit<Q> unit) {
        return unit.prefix(QUETTA);
    }

    public static <Q extends Quantity<Q>> Unit<Q> RONNA(Unit<Q> unit) {
        return unit.prefix(RONNA);
    }

    public static <Q extends Quantity<Q>> Unit<Q> RONTO(Unit<Q> unit) {
        return unit.prefix(RONTO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> TERA(Unit<Q> unit) {
        return unit.prefix(TERA);
    }

    public static <Q extends Quantity<Q>> Unit<Q> YOCTO(Unit<Q> unit) {
        return unit.prefix(YOCTO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> YOTTA(Unit<Q> unit) {
        return unit.prefix(YOTTA);
    }

    public static <Q extends Quantity<Q>> Unit<Q> ZEPTO(Unit<Q> unit) {
        return unit.prefix(ZEPTO);
    }

    public static <Q extends Quantity<Q>> Unit<Q> ZETTA(Unit<Q> unit) {
        return unit.prefix(ZETTA);
    }

    @Override // javax.measure.Prefix
    public int getExponent() {
        return this.exponent;
    }

    @Override // javax.measure.Prefix
    public String getName() {
        return name();
    }

    @Override // javax.measure.Prefix
    public String getSymbol() {
        return this.symbol;
    }

    @Override // javax.measure.Prefix
    public Integer getValue() {
        return 10;
    }
}
