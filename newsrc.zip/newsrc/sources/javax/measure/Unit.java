package javax.measure;

import java.util.Map;
import javax.measure.Quantity;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public interface Unit<Q extends Quantity<Q>> {
    Unit<Q> alternate(String str);

    <T extends Quantity<T>> Unit<T> asType(Class<T> cls);

    Unit<Q> divide(double d);

    Unit<Q> divide(Number number);

    Unit<?> divide(Unit<?> unit);

    Map<? extends Unit<?>, Integer> getBaseUnits();

    UnitConverter getConverterTo(Unit<Q> unit);

    UnitConverter getConverterToAny(Unit<?> unit);

    Dimension getDimension();

    String getName();

    String getSymbol();

    Unit<Q> getSystemUnit();

    Unit<?> inverse();

    boolean isCompatible(Unit<?> unit);

    boolean isEquivalentTo(Unit<Q> unit);

    Unit<Q> multiply(double d);

    Unit<Q> multiply(Number number);

    Unit<?> multiply(Unit<?> unit);

    Unit<?> pow(int i);

    Unit<Q> prefix(Prefix prefix);

    Unit<?> root(int i);

    Unit<Q> shift(double d);

    Unit<Q> shift(Number number);

    String toString();

    Unit<Q> transform(UnitConverter unitConverter);
}
