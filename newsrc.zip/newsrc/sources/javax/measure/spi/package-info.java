package javax.measure.spi;

