package javax.measure.spi;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import javax.measure.Quantity;
import p000.C1521v3;
import p000.fg1;
import p000.z82;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public abstract class ServiceProvider {
    private static final String LEGACY_NAMED_ANNOTATION = "javax.inject.Named";
    private static final String LEGACY_PRIORITY_ANNOTATION = "javax.annotation.Priority";
    private static final String NAMED_ANNOTATION = "jakarta.inject.Named";
    private static final String PRIORITY_ANNOTATION = "jakarta.annotation.Priority";
    private static final AtomicReference<ServiceProvider> current = new AtomicReference<>();

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class Selector implements Predicate<ServiceProvider>, Comparator<ServiceProvider> {
        private final Method legacyNameGetter;
        private final Method legacyPriorityGetter;
        private final Method nameGetter;
        private final Method priorityGetter;
        private final String toSearch;

        public Selector(String str) {
            this.toSearch = str;
            try {
                if (str != null) {
                    this.nameGetter = getValueMethod(ServiceProvider.NAMED_ANNOTATION);
                    this.legacyNameGetter = getValueMethod(ServiceProvider.LEGACY_NAMED_ANNOTATION);
                } else {
                    this.nameGetter = null;
                    this.legacyNameGetter = null;
                }
                this.priorityGetter = getValueMethod(ServiceProvider.PRIORITY_ANNOTATION);
                this.legacyPriorityGetter = getValueMethod(ServiceProvider.LEGACY_PRIORITY_ANNOTATION);
            } catch (NoSuchMethodException e) {
                throw new ServiceConfigurationError("Cannot get annotation value", e);
            }
        }

        private static Object getValue(Class<?> cls, Method method, Method method2) {
            if (method == null) {
                method = method2;
                method2 = null;
            }
            while (method != null) {
                Annotation annotation = cls.getAnnotation(method.getDeclaringClass().asSubclass(Annotation.class));
                if (annotation != null) {
                    try {
                        return method.invoke(annotation, null);
                    } catch (IllegalAccessException | InvocationTargetException e) {
                        throw new ServiceConfigurationError("Cannot get annotation value", e);
                    }
                }
                method = method2;
                method2 = null;
            }
            return null;
        }

        private static Method getValueMethod(String str) {
            try {
                return Class.forName(str).getMethod("value", null);
            } catch (ClassNotFoundException unused) {
                return null;
            }
        }

        private int priority(ServiceProvider serviceProvider) {
            Object value = getValue(serviceProvider.getClass(), this.priorityGetter, this.legacyPriorityGetter);
            return value != null ? ((Integer) value).intValue() : serviceProvider.getPriority();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public Stream<ServiceProvider> stream() {
            Stream stream = StreamSupport.stream(ServiceLoader.load(ServiceProvider.class).spliterator(), false);
            if (this.toSearch != null) {
                stream = stream.filter(this);
            }
            return stream.sorted(this);
        }

        @Override // java.util.Comparator
        public int compare(ServiceProvider serviceProvider, ServiceProvider serviceProvider2) {
            return Integer.compare(priority(serviceProvider2), priority(serviceProvider));
        }

        @Override // java.util.function.Predicate
        public boolean test(ServiceProvider serviceProvider) {
            Object value = getValue(serviceProvider.getClass(), this.nameGetter, this.legacyNameGetter);
            if (value == null) {
                value = serviceProvider.toString();
            }
            return this.toSearch.equals(value);
        }
    }

    public static final List<ServiceProvider> available() {
        ArrayList arrayList = (ArrayList) new Selector(null).stream().collect(Collectors.toCollection(new fg1(5)));
        ServiceProvider serviceProvider = current.get();
        if (serviceProvider != null) {
            Class<?> cls = serviceProvider.getClass();
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                if (cls.equals(((ServiceProvider) arrayList.get(i)).getClass())) {
                    if (i != 0) {
                        arrayList.remove(i);
                        break;
                    }
                }
            }
            arrayList.add(0, serviceProvider);
        }
        return arrayList;
    }

    public static final ServiceProvider current() {
        ServiceProvider serviceProvider = current.get();
        if (serviceProvider != null) {
            return serviceProvider;
        }
        Optional optionalFindFirst = new Selector(null).stream().findFirst();
        if (optionalFindFirst.isPresent()) {
            return (ServiceProvider) optionalFindFirst.get();
        }
        C1521v3.m18909p("No Measurement ServiceProvider found.");
        return null;
    }

    /* JADX INFO: renamed from: of */
    public static ServiceProvider m11215of(String str) {
        Objects.requireNonNull(str);
        Selector selector = new Selector(str);
        ServiceProvider serviceProvider = current.get();
        if (serviceProvider != null && selector.test(serviceProvider)) {
            return serviceProvider;
        }
        Optional optionalFindFirst = selector.stream().findFirst();
        if (optionalFindFirst.isPresent()) {
            return (ServiceProvider) optionalFindFirst.get();
        }
        C1521v3.m18903j(z82.m21089v("No Measurement ServiceProvider ", str, " found ."));
        return null;
    }

    public static final ServiceProvider setCurrent(ServiceProvider serviceProvider) {
        Objects.requireNonNull(serviceProvider);
        ServiceProvider andSet = current.getAndSet(serviceProvider);
        if (andSet != serviceProvider) {
            Logger.getLogger("javax.measure.spi").log(Level.CONFIG, "Measurement ServiceProvider {1,choice,0#set to|1#replaced by} {0}.", new Object[]{serviceProvider.getClass().getName(), Integer.valueOf(andSet == null ? 0 : 1)});
        }
        return andSet;
    }

    public abstract FormatService getFormatService();

    public int getPriority() {
        return 0;
    }

    public abstract <Q extends Quantity<Q>> QuantityFactory<Q> getQuantityFactory(Class<Q> cls);

    public abstract SystemOfUnitsService getSystemOfUnitsService();
}
