package javax.measure.spi;

import java.util.Set;
import javax.measure.format.QuantityFormat;
import javax.measure.format.UnitFormat;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public interface FormatService {

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public enum FormatType {
        UNIT_FORMAT,
        QUANTITY_FORMAT
    }

    Set<String> getAvailableFormatNames(FormatType formatType);

    QuantityFormat getQuantityFormat();

    QuantityFormat getQuantityFormat(String str);

    UnitFormat getUnitFormat();

    UnitFormat getUnitFormat(String str);

    UnitFormat getUnitFormat(String str, String str2);
}
