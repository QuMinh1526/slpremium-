package javax.measure.spi;

import java.util.Collection;
import java.util.EnumSet;
import java.util.Set;
import javax.measure.Prefix;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public interface SystemOfUnitsService {
    Collection<SystemOfUnits> getAvailableSystemsOfUnits();

    default <P extends Prefix> Set<P> getPrefixes(Class<P> cls) {
        if (Prefix.class.isAssignableFrom(cls)) {
            return EnumSet.allOf(cls.asSubclass(Enum.class));
        }
        throw new ClassCastException(cls + " does not implement Prefix");
    }

    SystemOfUnits getSystemOfUnits();

    SystemOfUnits getSystemOfUnits(String str);
}
