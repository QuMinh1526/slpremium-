package javax.measure.spi;

import java.util.Set;
import javax.measure.Dimension;
import javax.measure.Quantity;
import javax.measure.Unit;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public interface SystemOfUnits {
    String getName();

    <Q extends Quantity<Q>> Unit<Q> getUnit(Class<Q> cls);

    Unit<?> getUnit(String str);

    Set<? extends Unit<?>> getUnits();

    Set<? extends Unit<?>> getUnits(Dimension dimension);
}
