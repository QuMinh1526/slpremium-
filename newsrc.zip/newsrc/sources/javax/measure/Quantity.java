package javax.measure;

import javax.measure.Quantity;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public interface Quantity<Q extends Quantity<Q>> {

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public enum Scale {
        ABSOLUTE,
        RELATIVE
    }

    Quantity<Q> add(Quantity<Q> quantity);

    <T extends Quantity<T>> Quantity<T> asType(Class<T> cls);

    Quantity<Q> divide(Number number);

    Quantity<?> divide(Quantity<?> quantity);

    Scale getScale();

    Unit<Q> getUnit();

    Number getValue();

    Quantity<?> inverse();

    boolean isEquivalentTo(Quantity<Q> quantity);

    Quantity<Q> multiply(Number number);

    Quantity<?> multiply(Quantity<?> quantity);

    Quantity<Q> negate();

    Quantity<Q> subtract(Quantity<Q> quantity);

    /* JADX INFO: renamed from: to */
    Quantity<Q> mo11214to(Unit<Q> unit);

    default Quantity<Q> toSystemUnit() {
        return mo11214to(getUnit().getSystemUnit());
    }
}
