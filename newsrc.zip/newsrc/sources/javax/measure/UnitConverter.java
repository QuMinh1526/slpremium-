package javax.measure;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public interface UnitConverter {
    UnitConverter concatenate(UnitConverter unitConverter);

    double convert(double d);

    Number convert(Number number);

    List<? extends UnitConverter> getConversionSteps();

    UnitConverter inverse();

    boolean isIdentity();

    boolean isLinear();
}
