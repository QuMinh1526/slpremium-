package javax.measure.format;

import javax.measure.MeasurementException;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class MeasurementParseException extends MeasurementException {
    private static final long serialVersionUID = 2727457045794254852L;
    private CharSequence data;
    private int position;

    public MeasurementParseException(String str, CharSequence charSequence, int i) {
        super(str);
        this.data = charSequence;
        this.position = i;
    }

    public String getParsedString() {
        CharSequence charSequence = this.data;
        if (charSequence == null) {
            return null;
        }
        return charSequence.toString();
    }

    public int getPosition() {
        return this.position;
    }

    public MeasurementParseException(CharSequence charSequence, int i) {
        this("Parse Error", charSequence, i);
    }

    public MeasurementParseException(Throwable th) {
        super(th);
    }

    public MeasurementParseException(String str) {
        super(str);
    }
}
