package javax.measure.format;

