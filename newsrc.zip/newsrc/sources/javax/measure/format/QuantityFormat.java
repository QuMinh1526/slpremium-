package javax.measure.format;

import java.text.ParsePosition;
import javax.measure.Quantity;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public interface QuantityFormat {
    Appendable format(Quantity<?> quantity, Appendable appendable);

    String format(Quantity<?> quantity);

    default boolean isLocaleSensitive() {
        return false;
    }

    Quantity<?> parse(CharSequence charSequence);

    Quantity<?> parse(CharSequence charSequence, ParsePosition parsePosition);
}
