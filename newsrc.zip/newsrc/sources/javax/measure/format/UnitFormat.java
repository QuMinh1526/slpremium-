package javax.measure.format;

import java.text.ParsePosition;
import javax.measure.Unit;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public interface UnitFormat {
    Appendable format(Unit<?> unit, Appendable appendable);

    String format(Unit<?> unit);

    default boolean isLocaleSensitive() {
        return false;
    }

    void label(Unit<?> unit, String str);

    Unit<?> parse(CharSequence charSequence);

    Unit<?> parse(CharSequence charSequence, ParsePosition parsePosition);
}
