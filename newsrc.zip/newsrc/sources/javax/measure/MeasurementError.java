package javax.measure;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class MeasurementError extends Error {
    private static final long serialVersionUID = -412360965273525777L;

    public MeasurementError() {
    }

    public MeasurementError(String str) {
        super(str);
    }

    public MeasurementError(Throwable th) {
        super(th);
    }

    public MeasurementError(String str, Throwable th) {
        super(str, th);
    }
}
