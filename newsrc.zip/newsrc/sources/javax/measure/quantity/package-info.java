package javax.measure.quantity;

