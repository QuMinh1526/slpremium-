package javax.measure.quantity;

import javax.measure.Quantity;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public interface SolidAngle extends Quantity<SolidAngle> {
}
