package android.support.v4.graphics.drawable;

import androidx.annotation.RestrictTo;
import androidx.core.graphics.drawable.IconCompat;
import p000.kab;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(kab kabVar) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(kabVar);
    }

    public static void write(IconCompat iconCompat, kab kabVar) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, kabVar);
    }
}
