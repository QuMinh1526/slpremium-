package android.support.v4.app;

import androidx.annotation.RestrictTo;
import androidx.core.app.RemoteActionCompat;
import p000.kab;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class RemoteActionCompatParcelizer extends androidx.core.app.RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(kab kabVar) {
        return androidx.core.app.RemoteActionCompatParcelizer.read(kabVar);
    }

    public static void write(RemoteActionCompat remoteActionCompat, kab kabVar) {
        androidx.core.app.RemoteActionCompatParcelizer.write(remoteActionCompat, kabVar);
    }
}
