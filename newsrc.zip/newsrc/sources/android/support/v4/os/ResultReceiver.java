package android.support.v4.os;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.RestrictTo;
import p000.f45;
import p000.hs7;
import p000.i19;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@SuppressLint({"BanParcelableUsage"})
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public class ResultReceiver implements Parcelable {
    public static final Parcelable.Creator<ResultReceiver> CREATOR = new hs7(5);

    /* JADX INFO: renamed from: e */
    public f45 f1109e;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        synchronized (this) {
            try {
                if (this.f1109e == null) {
                    i19 i19Var = new i19();
                    i19Var.attachInterface(i19Var, f45.f13640c);
                    this.f1109e = i19Var;
                }
                parcel.writeStrongBinder(this.f1109e.asBinder());
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
