package tech.units.indriya.internal.format;

import org.apiguardian.api.API;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
interface UnitTokenConstants {
    public static final int ASTERISK = 7;
    public static final int CARET = 10;
    public static final int CLOSE_PAREN = 13;
    public static final int COLON = 11;
    public static final int DEFAULT = 0;
    public static final int DIGIT = 1;

    /* JADX INFO: renamed from: E */
    public static final int f40121E = 19;
    public static final int EOF = 0;
    public static final int EXTENDED_CHAR = 4;
    public static final int FLOATING_POINT = 16;
    public static final String IMAGE_E = "e";
    public static final int INITIAL_CHAR = 3;
    public static final int INTEGER = 14;
    public static final int LOG = 17;
    public static final int MIDDLE_DOT = 8;
    public static final int MINUS = 6;
    public static final int NAT_LOG = 18;
    public static final int OPEN_PAREN = 12;
    public static final int PLUS = 5;
    public static final int SOLIDUS = 9;
    public static final int SUPERSCRIPT_DIGIT = 2;
    public static final int SUPERSCRIPT_INTEGER = 15;
    public static final int UNIT_IDENTIFIER = 20;
    public static final String[] tokenImage = {"<EOF>", "<DIGIT>", "<SUPERSCRIPT_DIGIT>", "<INITIAL_CHAR>", "<EXTENDED_CHAR>", "\"+\"", "\"-\"", "\"*\"", "\"\\u00b7\"", "\"/\"", "\"^\"", "\":\"", "\"(\"", "\")\"", "<INTEGER>", "<SUPERSCRIPT_INTEGER>", "<FLOATING_POINT>", "<LOG>", "<NAT_LOG>", "\"e\"", "<UNIT_IDENTIFIER>"};
}
