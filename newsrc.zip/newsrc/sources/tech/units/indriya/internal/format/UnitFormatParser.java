package tech.units.indriya.internal.format;

import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import javax.measure.Prefix;
import javax.measure.Unit;
import javax.measure.quantity.Dimensionless;
import org.apiguardian.api.API;
import org.p003jf.dexlib2.Opcode;
import p000.vf3;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.format.SymbolMap;
import tech.units.indriya.format.Token;
import tech.units.indriya.format.TokenException;
import tech.units.indriya.function.LogConverter;
import tech.units.indriya.function.MultiplyConverter;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
public final class UnitFormatParser implements UnitTokenConstants {
    private static int[] jj_la1_0;
    private final JJCalls[] jj_2_rtns;
    private int jj_endpos;
    private final List<int[]> jj_expentries;
    private int[] jj_expentry;
    private int jj_gc;
    private int jj_gen;
    private DefaultCharStream jj_input_stream;
    private int jj_kind;
    private int jj_la;
    private final int[] jj_la1;
    private Token jj_lastpos;
    private int[] jj_lasttokens;
    private final LookaheadSuccess jj_ls;
    private Token jj_nt;
    private int jj_ntk;
    private boolean jj_rescan;
    private Token jj_scanpos;
    private SymbolMap symbols;
    private Token token;
    private UnitTokenManager token_source;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class Exponent {
        final int pow;
        final int root;

        public Exponent(int i, int i2) {
            this.pow = i;
            this.root = i2;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class JJCalls {
        int arg;
        Token first;
        int gen;
        JJCalls next;
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class LookaheadSuccess extends Error {
        private static final long serialVersionUID = -8192240240676284081L;

        private LookaheadSuccess() {
        }
    }

    static {
        jj_la1_init_0();
    }

    public UnitFormatParser(InputStream inputStream, String str) {
        this.jj_la1 = new int[19];
        this.jj_2_rtns = new JJCalls[2];
        int i = 0;
        this.jj_rescan = false;
        this.jj_gc = 0;
        this.jj_ls = new LookaheadSuccess();
        this.jj_expentries = new ArrayList();
        this.jj_kind = -1;
        this.jj_lasttokens = new int[100];
        try {
            DefaultCharStream defaultCharStream = new DefaultCharStream(inputStream, str, 1, 1);
            this.jj_input_stream = defaultCharStream;
            this.token_source = new UnitTokenManager(defaultCharStream);
            this.token = new Token();
            this.jj_ntk = -1;
            this.jj_gen = 0;
            for (int i2 = 0; i2 < 19; i2++) {
                this.jj_la1[i2] = -1;
            }
            while (true) {
                JJCalls[] jJCallsArr = this.jj_2_rtns;
                if (i >= jJCallsArr.length) {
                    return;
                }
                jJCallsArr[i] = new JJCalls();
                i++;
            }
        } catch (UnsupportedEncodingException e) {
            vf3.m19093j(e);
            throw null;
        }
    }

    private boolean jj_2_1(int i) {
        this.jj_la = i;
        Token token = this.token;
        this.jj_scanpos = token;
        this.jj_lastpos = token;
        try {
            return true ^ jj_3_1();
        } catch (LookaheadSuccess unused) {
            return true;
        } finally {
            jj_save(0, i);
        }
    }

    private boolean jj_2_2(int i) {
        this.jj_la = i;
        Token token = this.token;
        this.jj_scanpos = token;
        this.jj_lastpos = token;
        try {
            return !jj_3_2();
        } catch (LookaheadSuccess unused) {
            return true;
        } finally {
            jj_save(1, i);
        }
    }

    private boolean jj_3R_3() {
        Token token = this.jj_scanpos;
        if (!jj_3R_5()) {
            return false;
        }
        this.jj_scanpos = token;
        return jj_3R_6();
    }

    private boolean jj_3R_4() {
        Token token = this.jj_scanpos;
        if (!jj_scan_token(5)) {
            return false;
        }
        this.jj_scanpos = token;
        return jj_scan_token(6);
    }

    private boolean jj_3R_5() {
        return jj_scan_token(14);
    }

    private boolean jj_3R_6() {
        return jj_scan_token(16);
    }

    private boolean jj_3_1() {
        return jj_3R_3() || jj_3R_4();
    }

    private boolean jj_3_2() {
        Token token = this.jj_scanpos;
        if (jj_scan_token(14)) {
            this.jj_scanpos = token;
            if (jj_scan_token(19)) {
                return true;
            }
        }
        return jj_scan_token(10);
    }

    private void jj_add_error_token(int i, int i2) {
        if (i2 >= 100) {
            return;
        }
        int i3 = this.jj_endpos;
        if (i2 == i3 + 1) {
            int[] iArr = this.jj_lasttokens;
            this.jj_endpos = i3 + 1;
            iArr[i3] = i;
            return;
        }
        if (i3 != 0) {
            int[] iArr2 = new int[i3];
            this.jj_expentry = iArr2;
            System.arraycopy(this.jj_lasttokens, 0, iArr2, 0, i3);
            loop0: for (int[] iArr3 : this.jj_expentries) {
                if (iArr3.length == this.jj_expentry.length) {
                    int i4 = 0;
                    while (true) {
                        int[] iArr4 = this.jj_expentry;
                        if (i4 >= iArr4.length) {
                            this.jj_expentries.add(iArr4);
                            break loop0;
                        } else if (iArr3[i4] != iArr4[i4]) {
                            break;
                        } else {
                            i4++;
                        }
                    }
                }
            }
            if (i2 != 0) {
                int[] iArr5 = this.jj_lasttokens;
                this.jj_endpos = i2;
                iArr5[i2 - 1] = i;
            }
        }
    }

    private Token jj_consume_token(int i) {
        Token token = this.token;
        Token token2 = token.next;
        if (token2 != null) {
            this.token = token2;
        } else {
            Token nextToken = this.token_source.getNextToken();
            token.next = nextToken;
            this.token = nextToken;
        }
        this.jj_ntk = -1;
        if (this.token.kind != i) {
            this.token = token;
            this.jj_kind = i;
            throw generateParseException();
        }
        this.jj_gen++;
        int i2 = this.jj_gc + 1;
        this.jj_gc = i2;
        if (i2 > 100) {
            int i3 = 0;
            this.jj_gc = 0;
            while (true) {
                JJCalls[] jJCallsArr = this.jj_2_rtns;
                if (i3 >= jJCallsArr.length) {
                    break;
                }
                for (JJCalls jJCalls = jJCallsArr[i3]; jJCalls != null; jJCalls = jJCalls.next) {
                    if (jJCalls.gen < this.jj_gen) {
                        jJCalls.first = null;
                    }
                }
                i3++;
            }
        }
        return this.token;
    }

    private static void jj_la1_init_0() {
        jj_la1_0 = new int[]{2048, 96, 896, 384, 896, 540672, 33792, 16384, 393216, 1527808, 1134592, 96, 81920, 96, 96, 96, Opcode.JUMBO_OPCODE, 20576, 33792};
    }

    private int jj_ntk() {
        Token token = this.token;
        Token token2 = token.next;
        this.jj_nt = token2;
        if (token2 != null) {
            int i = token2.kind;
            this.jj_ntk = i;
            return i;
        }
        Token nextToken = this.token_source.getNextToken();
        token.next = nextToken;
        int i2 = nextToken.kind;
        this.jj_ntk = i2;
        return i2;
    }

    private void jj_rescan_token() {
        this.jj_rescan = true;
        for (int i = 0; i < 2; i++) {
            try {
                JJCalls jJCalls = this.jj_2_rtns[i];
                do {
                    if (jJCalls.gen > this.jj_gen) {
                        this.jj_la = jJCalls.arg;
                        Token token = jJCalls.first;
                        this.jj_scanpos = token;
                        this.jj_lastpos = token;
                        if (i == 0) {
                            jj_3_1();
                        } else if (i == 1) {
                            jj_3_2();
                        }
                    }
                    jJCalls = jJCalls.next;
                } while (jJCalls != null);
            } catch (LookaheadSuccess unused) {
            }
        }
        this.jj_rescan = false;
    }

    private void jj_save(int i, int i2) {
        JJCalls jJCalls = this.jj_2_rtns[i];
        while (jJCalls.gen > this.jj_gen) {
            JJCalls jJCalls2 = jJCalls.next;
            if (jJCalls2 == null) {
                JJCalls jJCalls3 = new JJCalls();
                jJCalls.next = jJCalls3;
                jJCalls = jJCalls3;
                break;
            }
            jJCalls = jJCalls2;
        }
        jJCalls.gen = (this.jj_gen + i2) - this.jj_la;
        jJCalls.first = this.token;
        jJCalls.arg = i2;
    }

    private boolean jj_scan_token(int i) {
        Token token = this.jj_scanpos;
        if (token == this.jj_lastpos) {
            this.jj_la--;
            Token token2 = token.next;
            if (token2 == null) {
                Token nextToken = this.token_source.getNextToken();
                token.next = nextToken;
                this.jj_scanpos = nextToken;
                this.jj_lastpos = nextToken;
            } else {
                this.jj_scanpos = token2;
                this.jj_lastpos = token2;
            }
        } else {
            this.jj_scanpos = token.next;
        }
        if (this.jj_rescan) {
            Token token3 = this.token;
            int i2 = 0;
            while (token3 != null && token3 != this.jj_scanpos) {
                i2++;
                token3 = token3.next;
            }
            if (token3 != null) {
                jj_add_error_token(i, i2);
            }
        }
        Token token4 = this.jj_scanpos;
        if (token4.kind != i) {
            return true;
        }
        if (this.jj_la == 0 && token4 == this.jj_lastpos) {
            throw this.jj_ls;
        }
        return false;
    }

    public Unit<?> addExpr() {
        Number numberNumberExpr;
        Token tokenSign;
        Token token;
        Unit<Dimensionless> unit = AbstractUnit.ONE;
        Number numberNumberExpr2 = null;
        if (jj_2_1(Integer.MAX_VALUE)) {
            numberNumberExpr = numberExpr();
            tokenSign = sign();
        } else {
            numberNumberExpr = null;
            tokenSign = null;
        }
        Unit<?> unitMulExpr = mulExpr();
        int iJj_ntk = this.jj_ntk;
        if (iJj_ntk == -1) {
            iJj_ntk = jj_ntk();
        }
        if (iJj_ntk == 5 || iJj_ntk == 6) {
            Token tokenSign2 = sign();
            numberNumberExpr2 = numberExpr();
            token = tokenSign2;
        } else {
            this.jj_la1[1] = this.jj_gen;
            token = null;
        }
        if (numberNumberExpr != null) {
            if (tokenSign.image.equals("-")) {
                unitMulExpr = unitMulExpr.multiply(-1.0d);
            }
            unitMulExpr = unitMulExpr.shift(numberNumberExpr.doubleValue());
        }
        if (numberNumberExpr2 == null) {
            return unitMulExpr;
        }
        double dDoubleValue = numberNumberExpr2.doubleValue();
        if ("-".equals(token.image)) {
            dDoubleValue = -dDoubleValue;
        }
        return unitMulExpr.shift(dDoubleValue);
    }

    public Unit<?> atomicExpr() {
        Unit<Dimensionless> unit = AbstractUnit.ONE;
        int iJj_ntk = this.jj_ntk;
        if (iJj_ntk == -1) {
            iJj_ntk = jj_ntk();
        }
        if (iJj_ntk == 12) {
            jj_consume_token(12);
            Unit<?> unitAddExpr = addExpr();
            jj_consume_token(13);
            return unitAddExpr;
        }
        if (iJj_ntk == 14 || iJj_ntk == 16) {
            Number numberNumberExpr = numberExpr();
            return numberNumberExpr instanceof Integer ? unit.multiply(numberNumberExpr.intValue()) : unit.multiply(numberNumberExpr.doubleValue());
        }
        if (iJj_ntk != 20) {
            this.jj_la1[10] = this.jj_gen;
            jj_consume_token(-1);
            throw new TokenException();
        }
        Token tokenJj_consume_token = jj_consume_token(20);
        Unit<?> unit2 = this.symbols.getUnit(tokenJj_consume_token.image);
        if (unit2 != null) {
            return unit2;
        }
        Prefix prefix = this.symbols.getPrefix(tokenJj_consume_token.image);
        if (prefix != null) {
            Unit<?> unit3 = this.symbols.getUnit(tokenJj_consume_token.image.substring(this.symbols.getSymbol(prefix).length()));
            if (unit3 != null) {
                return unit3.transform(MultiplyConverter.ofPrefix(prefix));
            }
        }
        throw new TokenException();
    }

    public Exponent exp() {
        Token tokenSign;
        Token tokenJj_consume_token;
        int iJj_ntk = this.jj_ntk;
        if (iJj_ntk == -1) {
            iJj_ntk = jj_ntk();
        }
        int i = 1;
        if (iJj_ntk != 10) {
            if (iJj_ntk != 15) {
                this.jj_la1[18] = this.jj_gen;
                jj_consume_token(-1);
                throw new TokenException();
            }
            Token tokenJj_consume_token2 = jj_consume_token(15);
            int i2 = 0;
            for (int i3 = 0; i3 < tokenJj_consume_token2.image.length(); i3++) {
                i2 *= 10;
                char cCharAt = tokenJj_consume_token2.image.charAt(i3);
                if (cCharAt == 178) {
                    i2 += 2;
                } else if (cCharAt == 179) {
                    i2 += 3;
                } else if (cCharAt != 185) {
                    switch (cCharAt) {
                        case 8308:
                            i2 += 4;
                            break;
                        case 8309:
                            i2 += 5;
                            break;
                        case 8310:
                            i2 += 6;
                            break;
                        case 8311:
                            i2 += 7;
                            break;
                        case 8312:
                            i2 += 8;
                            break;
                        case 8313:
                            i2 += 9;
                            break;
                    }
                } else {
                    i2++;
                }
            }
            return new Exponent(i2, 1);
        }
        jj_consume_token(10);
        int iJj_ntk2 = this.jj_ntk;
        if (iJj_ntk2 == -1) {
            iJj_ntk2 = jj_ntk();
        }
        Token tokenSign2 = null;
        if (iJj_ntk2 != 5 && iJj_ntk2 != 6) {
            if (iJj_ntk2 == 12) {
                jj_consume_token(12);
                int iJj_ntk3 = this.jj_ntk;
                if (iJj_ntk3 == -1) {
                    iJj_ntk3 = jj_ntk();
                }
                if (iJj_ntk3 == 5 || iJj_ntk3 == 6) {
                    tokenSign = sign();
                } else {
                    this.jj_la1[14] = this.jj_gen;
                    tokenSign = null;
                }
                Token tokenJj_consume_token3 = jj_consume_token(14);
                int iJj_ntk4 = this.jj_ntk;
                if (iJj_ntk4 == -1) {
                    iJj_ntk4 = jj_ntk();
                }
                if (iJj_ntk4 != 9) {
                    this.jj_la1[16] = this.jj_gen;
                    tokenJj_consume_token = null;
                } else {
                    jj_consume_token(9);
                    int iJj_ntk5 = this.jj_ntk;
                    if (iJj_ntk5 == -1) {
                        iJj_ntk5 = jj_ntk();
                    }
                    if (iJj_ntk5 == 5 || iJj_ntk5 == 6) {
                        tokenSign2 = sign();
                    } else {
                        this.jj_la1[15] = this.jj_gen;
                    }
                    tokenJj_consume_token = jj_consume_token(14);
                }
                jj_consume_token(13);
                int i4 = Integer.parseInt(tokenJj_consume_token3.image);
                if (tokenSign != null && tokenSign.image.equals("-")) {
                    i4 = -i4;
                }
                if (tokenJj_consume_token != null) {
                    i = Integer.parseInt(tokenJj_consume_token.image);
                    if (tokenSign2 != null && tokenSign2.image.equals("-")) {
                        i = -i;
                    }
                }
                return new Exponent(i4, i);
            }
            if (iJj_ntk2 != 14) {
                this.jj_la1[17] = this.jj_gen;
                jj_consume_token(-1);
                throw new TokenException();
            }
        }
        int iJj_ntk6 = this.jj_ntk;
        if (iJj_ntk6 == -1) {
            iJj_ntk6 = jj_ntk();
        }
        if (iJj_ntk6 == 5 || iJj_ntk6 == 6) {
            tokenSign2 = sign();
        } else {
            this.jj_la1[13] = this.jj_gen;
        }
        int i5 = Integer.parseInt(jj_consume_token(14).image);
        if (tokenSign2 != null && tokenSign2.image.equals("-")) {
            i5 = -i5;
        }
        return new Exponent(i5, 1);
    }

    /* JADX WARN: Code duplicated, block: B:46:0x00d2  */
    public Unit<?> exponentExpr() {
        Token tokenJj_consume_token;
        Unit<Dimensionless> unit = AbstractUnit.ONE;
        boolean zJj_2_2 = jj_2_2(Integer.MAX_VALUE);
        int iJj_ntk = this.jj_ntk;
        double d = 19.0d;
        if (zJj_2_2) {
            if (iJj_ntk == -1) {
                iJj_ntk = jj_ntk();
            }
            if (iJj_ntk == 14) {
                tokenJj_consume_token = jj_consume_token(14);
            } else {
                if (iJj_ntk != 19) {
                    this.jj_la1[5] = this.jj_gen;
                    jj_consume_token(-1);
                    throw new TokenException();
                }
                tokenJj_consume_token = jj_consume_token(19);
            }
            jj_consume_token(10);
            return atomicExpr().transform(new LogConverter(tokenJj_consume_token.kind == 14 ? Integer.parseInt(tokenJj_consume_token.image) : 19.0d).inverse());
        }
        if (iJj_ntk == -1) {
            iJj_ntk = jj_ntk();
        }
        Exponent exponentExp = null;
        Token tokenJj_consume_token2 = null;
        switch (iJj_ntk) {
            case 12:
            case 14:
            case 16:
            case 20:
                Unit<?> unitAtomicExpr = atomicExpr();
                int iJj_ntk2 = this.jj_ntk;
                if (iJj_ntk2 == -1) {
                    iJj_ntk2 = jj_ntk();
                }
                if (iJj_ntk2 == 10 || iJj_ntk2 == 15) {
                    exponentExp = exp();
                } else {
                    this.jj_la1[6] = this.jj_gen;
                }
                if (exponentExp != null) {
                    int i = exponentExp.pow;
                    if (i != 1) {
                        unitAtomicExpr = unitAtomicExpr.pow(i);
                    }
                    int i2 = exponentExp.root;
                    if (i2 != 1) {
                        return unitAtomicExpr.root(i2);
                    }
                }
                return unitAtomicExpr;
            case 13:
            case 15:
            case UnitTokenConstants.f40121E /* 19 */:
            default:
                this.jj_la1[9] = this.jj_gen;
                jj_consume_token(-1);
                throw new TokenException();
            case 17:
            case UnitTokenConstants.NAT_LOG /* 18 */:
                int iJj_ntk3 = this.jj_ntk;
                if (iJj_ntk3 == -1) {
                    iJj_ntk3 = jj_ntk();
                }
                if (iJj_ntk3 == 17) {
                    jj_consume_token(17);
                    int iJj_ntk4 = this.jj_ntk;
                    if (iJj_ntk4 == -1) {
                        iJj_ntk4 = jj_ntk();
                    }
                    if (iJj_ntk4 != 14) {
                        this.jj_la1[7] = this.jj_gen;
                    } else {
                        tokenJj_consume_token2 = jj_consume_token(14);
                    }
                } else {
                    if (iJj_ntk3 != 18) {
                        this.jj_la1[8] = this.jj_gen;
                        jj_consume_token(-1);
                        throw new TokenException();
                    }
                    tokenJj_consume_token2 = jj_consume_token(18);
                }
                jj_consume_token(12);
                Unit<?> unitAddExpr = addExpr();
                jj_consume_token(13);
                if (tokenJj_consume_token2 == null) {
                    d = 10.0d;
                } else {
                    int i3 = tokenJj_consume_token2.kind;
                    if (i3 == 14) {
                        d = Integer.parseInt(tokenJj_consume_token2.image);
                    } else if (i3 != 18) {
                        d = 10.0d;
                    }
                }
                return unitAddExpr.transform(new LogConverter(d));
        }
    }

    public TokenException generateParseException() {
        this.jj_expentries.clear();
        boolean[] zArr = new boolean[21];
        int i = this.jj_kind;
        if (i >= 0) {
            zArr[i] = true;
            this.jj_kind = -1;
        }
        for (int i2 = 0; i2 < 19; i2++) {
            if (this.jj_la1[i2] == this.jj_gen) {
                for (int i3 = 0; i3 < 32; i3++) {
                    if ((jj_la1_0[i2] & (1 << i3)) != 0) {
                        zArr[i3] = true;
                    }
                }
            }
        }
        for (int i4 = 0; i4 < 21; i4++) {
            if (zArr[i4]) {
                int[] iArr = {i4};
                this.jj_expentry = iArr;
                this.jj_expentries.add(iArr);
            }
        }
        this.jj_endpos = 0;
        jj_rescan_token();
        jj_add_error_token(0, 0);
        int[][] iArr2 = new int[this.jj_expentries.size()][];
        for (int i5 = 0; i5 < this.jj_expentries.size(); i5++) {
            iArr2[i5] = this.jj_expentries.get(i5);
        }
        return new TokenException(this.token, iArr2, UnitTokenConstants.tokenImage);
    }

    public final Token getNextToken() {
        Token token = this.token;
        Token token2 = token.next;
        if (token2 != null) {
            this.token = token2;
        } else {
            Token nextToken = this.token_source.getNextToken();
            token.next = nextToken;
            this.token = nextToken;
        }
        this.jj_ntk = -1;
        this.jj_gen++;
        return this.token;
    }

    public final Token getToken(int i) {
        Token token = this.token;
        for (int i2 = 0; i2 < i; i2++) {
            Token nextToken = token.next;
            if (nextToken == null) {
                nextToken = this.token_source.getNextToken();
                token.next = nextToken;
            }
            token = nextToken;
        }
        return token;
    }

    public Unit<?> mixExpr() {
        Unit<Dimensionless> unit = AbstractUnit.ONE;
        Unit<?> unitAddExpr = addExpr();
        while (true) {
            int iJj_ntk = this.jj_ntk;
            if (iJj_ntk == -1) {
                iJj_ntk = jj_ntk();
            }
            if (iJj_ntk != 11) {
                this.jj_la1[0] = this.jj_gen;
                return unitAddExpr;
            }
            jj_consume_token(11);
        }
    }

    public Unit<?> mulExpr() {
        Unit<?> unitExponentExpr;
        Unit<Dimensionless> unit = AbstractUnit.ONE;
        if (UnitTokenConstants.IMAGE_E.equals(this.jj_lastpos.image)) {
            this.jj_ntk = 20;
            this.token.next.kind = 20;
            unitExponentExpr = atomicExpr();
        } else {
            unitExponentExpr = exponentExpr();
        }
        while (true) {
            int iJj_ntk = this.jj_ntk;
            if (iJj_ntk == -1) {
                iJj_ntk = jj_ntk();
            }
            if (iJj_ntk != 7 && iJj_ntk != 8 && iJj_ntk != 9) {
                this.jj_la1[2] = this.jj_gen;
                return unitExponentExpr;
            }
            int iJj_ntk2 = this.jj_ntk;
            if (iJj_ntk2 == -1) {
                iJj_ntk2 = jj_ntk();
            }
            if (iJj_ntk2 == 7 || iJj_ntk2 == 8) {
                int iJj_ntk3 = this.jj_ntk;
                if (iJj_ntk3 == -1) {
                    iJj_ntk3 = jj_ntk();
                }
                if (iJj_ntk3 == 7) {
                    jj_consume_token(7);
                } else {
                    if (iJj_ntk3 != 8) {
                        this.jj_la1[3] = this.jj_gen;
                        jj_consume_token(-1);
                        throw new TokenException();
                    }
                    jj_consume_token(8);
                }
                unitExponentExpr = unitExponentExpr.multiply(exponentExpr());
            } else {
                if (iJj_ntk2 != 9) {
                    this.jj_la1[4] = this.jj_gen;
                    jj_consume_token(-1);
                    throw new TokenException();
                }
                jj_consume_token(9);
                unitExponentExpr = unitExponentExpr.divide(exponentExpr());
            }
        }
    }

    public Number numberExpr() {
        int iJj_ntk = this.jj_ntk;
        if (iJj_ntk == -1) {
            iJj_ntk = jj_ntk();
        }
        if (iJj_ntk == 14) {
            return Long.valueOf(jj_consume_token(14).image);
        }
        if (iJj_ntk == 16) {
            return Double.valueOf(jj_consume_token(16).image);
        }
        this.jj_la1[12] = this.jj_gen;
        jj_consume_token(-1);
        throw new TokenException();
    }

    public Unit<?> parseUnit() {
        Unit<?> unitMixExpr = mixExpr();
        jj_consume_token(0);
        return unitMixExpr;
    }

    public Token sign() {
        int iJj_ntk = this.jj_ntk;
        if (iJj_ntk == -1) {
            iJj_ntk = jj_ntk();
        }
        if (iJj_ntk == 5) {
            return jj_consume_token(5);
        }
        if (iJj_ntk == 6) {
            return jj_consume_token(6);
        }
        this.jj_la1[11] = this.jj_gen;
        jj_consume_token(-1);
        throw new TokenException();
    }

    public UnitFormatParser(InputStream inputStream) {
        this(inputStream, (String) null);
    }

    public UnitFormatParser(SymbolMap symbolMap, Reader reader) {
        this(reader);
        this.symbols = symbolMap;
    }

    public UnitFormatParser(Reader reader) {
        this.jj_la1 = new int[19];
        this.jj_2_rtns = new JJCalls[2];
        int i = 0;
        this.jj_rescan = false;
        this.jj_gc = 0;
        this.jj_ls = new LookaheadSuccess();
        this.jj_expentries = new ArrayList();
        this.jj_kind = -1;
        this.jj_lasttokens = new int[100];
        DefaultCharStream defaultCharStream = new DefaultCharStream(reader, 1, 1);
        this.jj_input_stream = defaultCharStream;
        this.token_source = new UnitTokenManager(defaultCharStream);
        this.token = new Token();
        this.jj_ntk = -1;
        this.jj_gen = 0;
        for (int i2 = 0; i2 < 19; i2++) {
            this.jj_la1[i2] = -1;
        }
        while (true) {
            JJCalls[] jJCallsArr = this.jj_2_rtns;
            if (i >= jJCallsArr.length) {
                return;
            }
            jJCallsArr[i] = new JJCalls();
            i++;
        }
    }

    public UnitFormatParser(UnitTokenManager unitTokenManager) {
        this.jj_la1 = new int[19];
        this.jj_2_rtns = new JJCalls[2];
        int i = 0;
        this.jj_rescan = false;
        this.jj_gc = 0;
        this.jj_ls = new LookaheadSuccess();
        this.jj_expentries = new ArrayList();
        this.jj_kind = -1;
        this.jj_lasttokens = new int[100];
        this.token_source = unitTokenManager;
        this.token = new Token();
        this.jj_ntk = -1;
        this.jj_gen = 0;
        for (int i2 = 0; i2 < 19; i2++) {
            this.jj_la1[i2] = -1;
        }
        while (true) {
            JJCalls[] jJCallsArr = this.jj_2_rtns;
            if (i >= jJCallsArr.length) {
                return;
            }
            jJCallsArr[i] = new JJCalls();
            i++;
        }
    }

    public final void disable_tracing() {
    }

    public final void enable_tracing() {
    }
}
