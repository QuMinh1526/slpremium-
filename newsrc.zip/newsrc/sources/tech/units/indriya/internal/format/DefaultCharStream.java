package tech.units.indriya.internal.format;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import javax.measure.MeasurementError;
import org.apiguardian.api.API;
import org.p003jf.dexlib2.dexbacked.raw.ItemType;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
final class DefaultCharStream {
    public static final boolean staticFlag = false;
    private int available;
    protected int[] bufcolumn;
    protected char[] buffer;
    protected int[] bufline;
    public int bufpos;
    private int bufsize;
    protected int column;
    protected int inBuf;
    protected Reader inputStream;
    protected int line;
    protected int maxNextCharInd;
    protected boolean prevCharIsCR;
    protected boolean prevCharIsLF;
    protected int tabSize;
    private int tokenBegin;

    public DefaultCharStream(Reader reader, int i, int i2, int i3) {
        this.bufpos = -1;
        this.prevCharIsCR = false;
        this.prevCharIsLF = false;
        this.maxNextCharInd = 0;
        this.inBuf = 0;
        this.tabSize = 8;
        this.inputStream = reader;
        this.line = i;
        this.column = i2 - 1;
        this.bufsize = i3;
        this.available = i3;
        this.buffer = new char[i3];
        this.bufline = new int[i3];
        this.bufcolumn = new int[i3];
    }

    public void adjustBeginLineColumn(int i, int i2) {
        int i3;
        int i4 = this.tokenBegin;
        int i5 = this.bufpos;
        int i6 = 0;
        if (i5 >= i4) {
            i3 = (i5 - i4) + this.inBuf + 1;
        } else {
            i3 = this.inBuf + (this.bufsize - i4) + i5 + 1;
        }
        int i7 = 0;
        int i8 = 0;
        while (i6 < i3) {
            int[] iArr = this.bufline;
            int i9 = this.bufsize;
            int i10 = i4 % i9;
            i4++;
            int i11 = i4 % i9;
            if (iArr[i10] != iArr[i11]) {
                i7 = i10;
                break;
            }
            iArr[i10] = i;
            int[] iArr2 = this.bufcolumn;
            int i12 = (iArr2[i11] + i8) - iArr2[i10];
            iArr2[i10] = i8 + i2;
            i6++;
            i8 = i12;
            i7 = i10;
        }
        if (i6 < i3) {
            int i13 = i + 1;
            this.bufline[i7] = i;
            this.bufcolumn[i7] = i2 + i8;
            while (true) {
                int i14 = i6 + 1;
                if (i6 >= i3) {
                    break;
                }
                int[] iArr3 = this.bufline;
                int i15 = this.bufsize;
                i7 = i4 % i15;
                i4++;
                if (iArr3[i7] != iArr3[i4 % i15]) {
                    iArr3[i7] = i13;
                    i13++;
                } else {
                    iArr3[i7] = i13;
                }
                i6 = i14;
            }
        }
        this.line = this.bufline[i7];
        this.column = this.bufcolumn[i7];
    }

    public void backup(int i) {
        this.inBuf += i;
        int i2 = this.bufpos - i;
        this.bufpos = i2;
        if (i2 < 0) {
            this.bufpos = i2 + this.bufsize;
        }
    }

    public char beginToken() throws IOException {
        this.tokenBegin = -1;
        char c = readChar();
        this.tokenBegin = this.bufpos;
        return c;
    }

    public void expandBuff(boolean z) {
        int i = this.bufsize;
        char[] cArr = new char[i + 2048];
        int[] iArr = new int[i + 2048];
        int[] iArr2 = new int[i + 2048];
        char[] cArr2 = this.buffer;
        try {
            if (z) {
                int i2 = this.tokenBegin;
                System.arraycopy(cArr2, i2, cArr, 0, i - i2);
                System.arraycopy(this.buffer, 0, cArr, this.bufsize - this.tokenBegin, this.bufpos);
                this.buffer = cArr;
                int[] iArr3 = this.bufline;
                int i3 = this.tokenBegin;
                System.arraycopy(iArr3, i3, iArr, 0, this.bufsize - i3);
                System.arraycopy(this.bufline, 0, iArr, this.bufsize - this.tokenBegin, this.bufpos);
                this.bufline = iArr;
                int[] iArr4 = this.bufcolumn;
                int i4 = this.tokenBegin;
                System.arraycopy(iArr4, i4, iArr2, 0, this.bufsize - i4);
                System.arraycopy(this.bufcolumn, 0, iArr2, this.bufsize - this.tokenBegin, this.bufpos);
                this.bufcolumn = iArr2;
                int i5 = (this.bufsize - this.tokenBegin) + this.bufpos;
                this.bufpos = i5;
                this.maxNextCharInd = i5;
            } else {
                int i6 = this.tokenBegin;
                System.arraycopy(cArr2, i6, cArr, 0, i - i6);
                this.buffer = cArr;
                int[] iArr5 = this.bufline;
                int i7 = this.tokenBegin;
                System.arraycopy(iArr5, i7, iArr, 0, this.bufsize - i7);
                this.bufline = iArr;
                int[] iArr6 = this.bufcolumn;
                int i8 = this.tokenBegin;
                System.arraycopy(iArr6, i8, iArr2, 0, this.bufsize - i8);
                this.bufcolumn = iArr2;
                int i9 = this.bufpos - this.tokenBegin;
                this.bufpos = i9;
                this.maxNextCharInd = i9;
            }
            int i10 = this.bufsize + 2048;
            this.bufsize = i10;
            this.available = i10;
            this.tokenBegin = 0;
        } catch (Throwable th) {
            throw new MeasurementError(th.getMessage());
        }
    }

    public void fillBuff() throws IOException {
        int i = this.maxNextCharInd;
        int i2 = this.available;
        if (i == i2) {
            int i3 = this.bufsize;
            int i4 = this.tokenBegin;
            if (i2 == i3) {
                if (i4 > 2048) {
                    this.maxNextCharInd = 0;
                    this.bufpos = 0;
                    this.available = i4;
                } else if (i4 < 0) {
                    this.maxNextCharInd = 0;
                    this.bufpos = 0;
                } else {
                    expandBuff(false);
                }
            } else if (i2 > i4) {
                this.available = i3;
            } else if (i4 - i2 < 2048) {
                expandBuff(true);
            } else {
                this.available = i4;
            }
        }
        try {
            Reader reader = this.inputStream;
            char[] cArr = this.buffer;
            int i5 = this.maxNextCharInd;
            int i6 = reader.read(cArr, i5, this.available - i5);
            if (i6 != -1) {
                this.maxNextCharInd += i6;
            } else {
                this.inputStream.close();
                throw new IOException();
            }
        } catch (IOException e) {
            this.bufpos--;
            backup(0);
            if (this.tokenBegin == -1) {
                this.tokenBegin = this.bufpos;
            }
            throw e;
        }
    }

    public int getBeginColumn() {
        return this.bufcolumn[this.tokenBegin];
    }

    public int getBeginLine() {
        return this.bufline[this.tokenBegin];
    }

    public int getEndColumn() {
        return this.bufcolumn[this.bufpos];
    }

    public int getEndLine() {
        return this.bufline[this.bufpos];
    }

    public String getImage() {
        int i = this.bufpos;
        int i2 = this.tokenBegin;
        char[] cArr = this.buffer;
        return i >= i2 ? new String(cArr, i2, (i - i2) + 1) : new String(cArr, i2, this.bufsize - i2).concat(new String(this.buffer, 0, this.bufpos + 1));
    }

    public int getTabSize() {
        return this.tabSize;
    }

    public void reInit(Reader reader, int i, int i2, int i3) {
        this.inputStream = reader;
        this.line = i;
        this.column = i2 - 1;
        char[] cArr = this.buffer;
        if (cArr == null || i3 != cArr.length) {
            this.bufsize = i3;
            this.available = i3;
            this.buffer = new char[i3];
            this.bufline = new int[i3];
            this.bufcolumn = new int[i3];
        }
        this.prevCharIsCR = false;
        this.prevCharIsLF = false;
        this.maxNextCharInd = 0;
        this.inBuf = 0;
        this.tokenBegin = 0;
        this.bufpos = -1;
    }

    public char readChar() throws IOException {
        int i = this.inBuf;
        if (i > 0) {
            this.inBuf = i - 1;
            int i2 = this.bufpos + 1;
            this.bufpos = i2;
            if (i2 == this.bufsize) {
                this.bufpos = 0;
            }
            return this.buffer[this.bufpos];
        }
        int i3 = this.bufpos + 1;
        this.bufpos = i3;
        if (i3 >= this.maxNextCharInd) {
            fillBuff();
        }
        char c = this.buffer[this.bufpos];
        updateLineColumn(c);
        return c;
    }

    public void setTabSize(int i) {
        this.tabSize = i;
    }

    public void updateLineColumn(char c) {
        this.column++;
        if (this.prevCharIsLF) {
            this.prevCharIsLF = false;
            int i = this.line;
            this.column = 1;
            this.line = i + 1;
        } else if (this.prevCharIsCR) {
            this.prevCharIsCR = false;
            if (c == '\n') {
                this.prevCharIsLF = true;
            } else {
                int i2 = this.line;
                this.column = 1;
                this.line = i2 + 1;
            }
        }
        if (c == '\t') {
            int i3 = this.column - 1;
            this.column = i3;
            int i4 = this.tabSize;
            this.column = (i4 - (i3 % i4)) + i3;
        } else if (c == '\n') {
            this.prevCharIsLF = true;
        } else if (c == '\r') {
            this.prevCharIsCR = true;
        }
        int[] iArr = this.bufline;
        int i5 = this.bufpos;
        iArr[i5] = this.line;
        this.bufcolumn[i5] = this.column;
    }

    public DefaultCharStream(Reader reader, int i, int i2) {
        this(reader, i, i2, ItemType.MAP_LIST);
    }

    public DefaultCharStream(Reader reader) {
        this(reader, 1, 1, ItemType.MAP_LIST);
    }

    public DefaultCharStream(InputStream inputStream, String str, int i, int i2, int i3) {
        this(str == null ? new InputStreamReader(inputStream) : new InputStreamReader(inputStream, str), i, i2, i3);
    }

    public void reInit(Reader reader, int i, int i2) {
        reInit(reader, i, i2, ItemType.MAP_LIST);
    }

    public DefaultCharStream(InputStream inputStream, int i, int i2, int i3) {
        this(new InputStreamReader(inputStream), i, i2, i3);
    }

    public void reInit(Reader reader) {
        reInit(reader, 1, 1, ItemType.MAP_LIST);
    }

    public DefaultCharStream(InputStream inputStream, String str, int i, int i2) {
        this(inputStream, str, i, i2, ItemType.MAP_LIST);
    }

    public void reInit(InputStream inputStream, String str, int i, int i2, int i3) {
        reInit(str == null ? new InputStreamReader(inputStream) : new InputStreamReader(inputStream, str), i, i2, i3);
    }

    public DefaultCharStream(InputStream inputStream, int i, int i2) {
        this(inputStream, i, i2, ItemType.MAP_LIST);
    }

    public void reInit(InputStream inputStream, int i, int i2, int i3) {
        reInit(new InputStreamReader(inputStream), i, i2, i3);
    }

    public DefaultCharStream(InputStream inputStream, String str) {
        this(inputStream, str, 1, 1, ItemType.MAP_LIST);
    }

    public void reInit(InputStream inputStream, String str) {
        reInit(inputStream, str, 1, 1, ItemType.MAP_LIST);
    }

    public DefaultCharStream(InputStream inputStream) {
        this(inputStream, 1, 1, ItemType.MAP_LIST);
    }
}
