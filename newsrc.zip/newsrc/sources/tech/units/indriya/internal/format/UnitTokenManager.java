package tech.units.indriya.internal.format;

import com.squareup.picasso.BuildConfig;
import java.io.IOException;
import java.io.PrintStream;
import org.apiguardian.api.API;
import p000.z23;
import tech.units.indriya.format.Token;
import tech.units.indriya.format.TokenMgrError;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
final class UnitTokenManager {
    protected char curChar;
    public PrintStream debugStream;
    protected DefaultCharStream input_stream;
    private int jjmatchedKind;
    private int jjmatchedPos;
    private int jjnewStateCnt;
    private int jjround;
    private final int[] jjrounds;
    private final int[] jjstateSet;
    public static final String[] jjstrLiteralImages = {BuildConfig.VERSION_NAME, null, null, null, null, "+", "-", "*", "·", "/", "^", ":", "(", ")", null, null, null, null, null, UnitTokenConstants.IMAGE_E, null};
    public static final String[] lexStateNames = {"DEFAULT"};
    private static final long[] jjbitVec0 = {0, 0, 147492887796383744L, 0};
    private static final long[] jjbitVec1 = {0, 284008251501051904L, 0, 0};
    private static final long[] jjbitVec2 = {-4294967298L, -1, -1, -1};
    private static final long[] jjbitVec4 = {0, 0, -183521684815347713L, -1};
    private static final long[] jjbitVec5 = {-1, -284008251501051905L, -1, -1};
    private static final int[] jjnextStates = {9, 1, 2, 3, 10, 1, 2, 3, 10, 12, 14, 4, 5};

    public UnitTokenManager(DefaultCharStream defaultCharStream) {
        this.jjrounds = new int[15];
        this.jjstateSet = new int[30];
        this.debugStream = System.out;
        this.input_stream = defaultCharStream;
    }

    private void jjAddStates(int i, int i2) {
        while (true) {
            int[] iArr = this.jjstateSet;
            int i3 = this.jjnewStateCnt;
            this.jjnewStateCnt = i3 + 1;
            iArr[i3] = jjnextStates[i];
            int i4 = i + 1;
            if (i == i2) {
                return;
            } else {
                i = i4;
            }
        }
    }

    private static boolean jjCanMove_0(int i, int i2, long j) {
        if (i != 0) {
            return i == 32 && (jjbitVec1[i2] & j) != 0;
        }
        return (jjbitVec0[i2] & j) != 0;
    }

    private static boolean jjCanMove_1(int i, int i2, int i3, long j, long j2) {
        if (i == 0) {
            return (jjbitVec4[i3] & j2) != 0;
        }
        if (i != 32) {
            return (jjbitVec2[i2] & j) != 0;
        }
        return (jjbitVec5[i3] & j2) != 0;
    }

    private void jjCheckNAdd(int i) {
        int[] iArr = this.jjrounds;
        int i2 = iArr[i];
        int i3 = this.jjround;
        if (i2 != i3) {
            int[] iArr2 = this.jjstateSet;
            int i4 = this.jjnewStateCnt;
            this.jjnewStateCnt = i4 + 1;
            iArr2[i4] = i;
            iArr[i] = i3;
        }
    }

    private void jjCheckNAddStates(int i, int i2) {
        while (true) {
            jjCheckNAdd(jjnextStates[i]);
            int i3 = i + 1;
            if (i == i2) {
                return;
            } else {
                i = i3;
            }
        }
    }

    private void jjCheckNAddTwoStates(int i, int i2) {
        jjCheckNAdd(i);
        jjCheckNAdd(i2);
    }

    /* JADX WARN: Code duplicated, block: B:149:0x020c  */
    /* JADX WARN: Code duplicated, block: B:156:0x0229 A[LOOP:3: B:116:0x019a->B:156:0x0229, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:158:0x021c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:160:0x0228 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:180:0x00ea A[SYNTHETIC] */
    private int jjMoveNfa_0(int i, int i2) {
        int i3;
        int i4;
        long j;
        int i5;
        this.jjnewStateCnt = 15;
        this.jjstateSet[0] = i;
        int i6 = 1;
        int i7 = Integer.MAX_VALUE;
        int i8 = i2;
        int i9 = 1;
        int i10 = 0;
        int i11 = Integer.MAX_VALUE;
        while (true) {
            int i12 = this.jjround + i6;
            this.jjround = i12;
            if (i12 == i7) {
                reInitRounds();
            }
            char c = this.curChar;
            if (c >= '@') {
                if (c < 128) {
                    long j2 = 1 << (c & '?');
                    do {
                        int[] iArr = this.jjstateSet;
                        i9--;
                        int i13 = iArr[i9];
                        if (i13 != 3) {
                            if (i13 == 6) {
                                if ((j2 & (-1073741825)) != 0) {
                                    if (i11 > 20) {
                                        i11 = 20;
                                    }
                                    jjCheckNAdd(7);
                                }
                                if (this.curChar == 'l') {
                                    jjAddStates(9, 10);
                                }
                            } else if (i13 != 7) {
                                switch (i13) {
                                    case 11:
                                        if (this.curChar == 'l') {
                                            jjAddStates(9, 10);
                                        }
                                        break;
                                    case 12:
                                        if (this.curChar == 'o') {
                                            int i14 = this.jjnewStateCnt;
                                            this.jjnewStateCnt = i14 + 1;
                                            iArr[i14] = 13;
                                        }
                                        break;
                                    case 13:
                                        if (this.curChar == 'g' && i11 > 17) {
                                            i5 = 17;
                                            i11 = i5;
                                        }
                                        break;
                                    case 14:
                                        if (this.curChar == 'n') {
                                            i5 = 18;
                                            if (i11 > 18) {
                                                i11 = i5;
                                            }
                                        }
                                        break;
                                }
                            } else if ((j2 & (-1073741825)) != 0) {
                                if (i11 > 20) {
                                    i11 = 20;
                                }
                                jjCheckNAdd(7);
                            }
                        } else if ((j2 & 137438953504L) != 0) {
                            jjAddStates(11, 12);
                        }
                    } while (i9 != i10);
                } else {
                    int i15 = c >> '\b';
                    int i16 = c >> 14;
                    long j3 = 1 << (i15 & 63);
                    int i17 = (c & 255) >> 6;
                    long j4 = 1 << (c & '?');
                    while (true) {
                        i9--;
                        int i18 = this.jjstateSet[i9];
                        if (i18 == 0) {
                            i3 = i15;
                            i4 = i17;
                            j = j4;
                            if (jjCanMove_0(i3, i4, j)) {
                                if (i11 > 15) {
                                    i11 = 15;
                                }
                                jjCheckNAdd(0);
                            }
                            if (i9 == i10) {
                                i15 = i3;
                                i17 = i4;
                                j4 = j;
                            }
                        } else if (i18 == 6) {
                            int i19 = i15;
                            int i20 = i17;
                            long j5 = j4;
                            if (jjCanMove_0(i19, i20, j5)) {
                                if (i11 > 15) {
                                    i11 = 15;
                                }
                                jjCheckNAdd(0);
                            }
                            boolean zJjCanMove_1 = jjCanMove_1(i19, i16, i20, j3, j5);
                            i3 = i19;
                            i4 = i20;
                            j = j5;
                            if (zJjCanMove_1) {
                                if (i11 > 20) {
                                    i11 = 20;
                                }
                                jjCheckNAdd(7);
                            }
                        } else if (i18 != 7) {
                            i3 = i15;
                            i4 = i17;
                            j = j4;
                        } else {
                            i3 = i15;
                            i4 = i17;
                            j = j4;
                            if (jjCanMove_1(i15, i16, i17, j3, j4)) {
                                if (i11 > 20) {
                                    i11 = 20;
                                }
                                jjCheckNAdd(7);
                            }
                        }
                        if (i9 == i10) {
                            i15 = i3;
                            i17 = i4;
                            j4 = j;
                        }
                    }
                }
                if (i11 != Integer.MAX_VALUE) {
                    this.jjmatchedKind = i11;
                    this.jjmatchedPos = i8;
                    i11 = Integer.MAX_VALUE;
                }
                i8++;
                i9 = this.jjnewStateCnt;
                this.jjnewStateCnt = i10;
                i10 = 15 - i10;
                if (i9 == i10) {
                    try {
                        this.curChar = this.input_stream.readChar();
                        i7 = Integer.MAX_VALUE;
                        i6 = 1;
                    } catch (IOException unused) {
                    }
                }
                return i8;
            }
            long j6 = 1 << c;
            do {
                i9--;
                switch (this.jjstateSet[i9]) {
                    case 1:
                        if (this.curChar == '.') {
                            jjCheckNAdd(2);
                        }
                        break;
                    case 2:
                        if ((j6 & 287948901175001088L) != 0) {
                            if (i11 > 16) {
                                i11 = 16;
                            }
                            jjCheckNAddTwoStates(2, 3);
                        }
                        break;
                    case 4:
                        if ((j6 & 43980465111040L) != 0) {
                            jjCheckNAdd(5);
                        }
                        break;
                    case 5:
                        if ((j6 & 287948901175001088L) != 0) {
                            if (i11 > 16) {
                                i11 = 16;
                            }
                            jjCheckNAdd(5);
                        }
                        break;
                    case 6:
                        if ((j6 & (-576442069195685888L)) != 0) {
                            if (i11 > 20) {
                                i11 = 20;
                            }
                            jjCheckNAdd(7);
                        } else if ((j6 & 287948901175001088L) != 0) {
                            if (i11 > 14) {
                                i11 = 14;
                            }
                            jjCheckNAddStates(0, 4);
                        } else if (this.curChar == '.') {
                            jjCheckNAdd(2);
                        }
                        break;
                    case 7:
                        if ((j6 & (-288493168020684800L)) != 0) {
                            if (i11 > 20) {
                                i11 = 20;
                            }
                            jjCheckNAdd(7);
                        }
                        break;
                    case 8:
                        if ((j6 & 287948901175001088L) != 0) {
                            if (i11 > 14) {
                                i11 = 14;
                            }
                            jjCheckNAddStates(0, 4);
                        }
                        break;
                    case 9:
                        if ((j6 & 287948901175001088L) != 0) {
                            if (i11 > 14) {
                                i11 = 14;
                            }
                            jjCheckNAdd(9);
                        }
                        break;
                    case 10:
                        if ((j6 & 287948901175001088L) != 0) {
                            if (i11 > 16) {
                                i11 = 16;
                            }
                            jjCheckNAddStates(5, 8);
                        }
                        break;
                }
            } while (i9 != i10);
            if (i11 != Integer.MAX_VALUE) {
                this.jjmatchedKind = i11;
                this.jjmatchedPos = i8;
                i11 = Integer.MAX_VALUE;
            }
            i8++;
            i9 = this.jjnewStateCnt;
            this.jjnewStateCnt = i10;
            i10 = 15 - i10;
            if (i9 == i10) {
                this.curChar = this.input_stream.readChar();
                i7 = Integer.MAX_VALUE;
                i6 = 1;
            }
            return i8;
        }
    }

    private int jjMoveStringLiteralDfa0_0() {
        char c = this.curChar;
        if (c == '-') {
            return jjStopAtPos(0, 6);
        }
        if (c == '/') {
            return jjStopAtPos(0, 9);
        }
        if (c == ':') {
            return jjStopAtPos(0, 11);
        }
        if (c == '^') {
            return jjStopAtPos(0, 10);
        }
        if (c == 'e') {
            return jjStartNfaWithStates_0(0, 19, 7);
        }
        if (c == 183) {
            return jjStopAtPos(0, 8);
        }
        switch (c) {
            case '(':
                return jjStopAtPos(0, 12);
            case ')':
                return jjStopAtPos(0, 13);
            case '*':
                return jjStopAtPos(0, 7);
            case '+':
                return jjStopAtPos(0, 5);
            default:
                return jjMoveNfa_0(6, 0);
        }
    }

    private int jjStartNfaWithStates_0(int i, int i2, int i3) {
        this.jjmatchedKind = i2;
        this.jjmatchedPos = i;
        try {
            this.curChar = this.input_stream.readChar();
            return jjMoveNfa_0(i3, i + 1);
        } catch (IOException unused) {
            return i + 1;
        }
    }

    private int jjStopAtPos(int i, int i2) {
        this.jjmatchedKind = i2;
        this.jjmatchedPos = i;
        return i + 1;
    }

    private void reInitRounds() {
        this.jjround = -2147483647;
        int i = 15;
        while (true) {
            int i2 = i - 1;
            if (i <= 0) {
                return;
            }
            this.jjrounds[i2] = Integer.MIN_VALUE;
            i = i2;
        }
    }

    public Token getNextToken() {
        String image;
        int i;
        int i2;
        boolean z;
        String str;
        String image2 = BuildConfig.VERSION_NAME;
        int i3 = 0;
        try {
            this.curChar = this.input_stream.beginToken();
            this.jjmatchedKind = Integer.MAX_VALUE;
            this.jjmatchedPos = 0;
            int iJjMoveStringLiteralDfa0_0 = jjMoveStringLiteralDfa0_0();
            if (this.jjmatchedKind != Integer.MAX_VALUE) {
                int i4 = this.jjmatchedPos;
                if (i4 + 1 < iJjMoveStringLiteralDfa0_0) {
                    this.input_stream.backup((iJjMoveStringLiteralDfa0_0 - i4) - 1);
                }
                return jjFillToken();
            }
            int endLine = this.input_stream.getEndLine();
            int endColumn = this.input_stream.getEndColumn();
            try {
                this.input_stream.readChar();
                this.input_stream.backup(1);
                image = null;
                z = false;
                i2 = endLine;
                i = endColumn;
            } catch (IOException unused) {
                image = iJjMoveStringLiteralDfa0_0 <= 1 ? BuildConfig.VERSION_NAME : this.input_stream.getImage();
                char c = this.curChar;
                if (c == '\n' || c == '\r') {
                    endLine++;
                } else {
                    i3 = endColumn + 1;
                }
                i = i3;
                i2 = endLine;
                z = true;
            }
            if (z) {
                str = image;
            } else {
                this.input_stream.backup(1);
                if (iJjMoveStringLiteralDfa0_0 > 1) {
                    image2 = this.input_stream.getImage();
                }
                str = image2;
            }
            throw new TokenMgrError(z, i2, i, str, this.curChar, 0);
        } catch (IOException unused2) {
            this.jjmatchedKind = 0;
            return jjFillToken();
        }
    }

    public Token jjFillToken() {
        String image = jjstrLiteralImages[this.jjmatchedKind];
        if (image == null) {
            image = this.input_stream.getImage();
        }
        int beginLine = this.input_stream.getBeginLine();
        int beginColumn = this.input_stream.getBeginColumn();
        int endLine = this.input_stream.getEndLine();
        int endColumn = this.input_stream.getEndColumn();
        Token tokenM17666of = Token.m17666of(this.jjmatchedKind, image);
        tokenM17666of.beginLine = beginLine;
        tokenM17666of.endLine = endLine;
        tokenM17666of.beginColumn = beginColumn;
        tokenM17666of.endColumn = endColumn;
        return tokenM17666of;
    }

    public void reInit(DefaultCharStream defaultCharStream) {
        this.jjnewStateCnt = 0;
        this.jjmatchedPos = 0;
        this.input_stream = defaultCharStream;
        reInitRounds();
    }

    public void setDebugStream(PrintStream printStream) {
        this.debugStream = printStream;
    }

    public void switchTo(int i) {
        if (i >= 1 || i < 0) {
            throw new TokenMgrError(z23.m20930l(i, "Error: Ignoring invalid lexical state : ", ". State unchanged."), 2);
        }
    }

    public void reInit(DefaultCharStream defaultCharStream, int i) {
        reInit(defaultCharStream);
        switchTo(i);
    }

    public UnitTokenManager(DefaultCharStream defaultCharStream, int i) {
        this(defaultCharStream);
        switchTo(i);
    }
}
