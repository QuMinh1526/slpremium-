package tech.units.indriya.internal.format;

import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import org.apiguardian.api.API;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
public class RationalNumberFormat extends NumberFormat {
    private static final long serialVersionUID = 1;
    private final NumberFormat numberFormat;

    private RationalNumberFormat(NumberFormat numberFormat) {
        this.numberFormat = numberFormat;
    }

    public static RationalNumberFormat wrap(NumberFormat numberFormat) {
        return new RationalNumberFormat(numberFormat);
    }

    @Override // java.text.NumberFormat
    public StringBuffer format(double d, StringBuffer stringBuffer, FieldPosition fieldPosition) {
        return this.numberFormat.format(d, stringBuffer, fieldPosition);
    }

    @Override // java.text.NumberFormat
    public Number parse(String str, ParsePosition parsePosition) {
        return new RationalNumberScanner(str, parsePosition, this.numberFormat).getNumber();
    }

    @Override // java.text.NumberFormat
    public StringBuffer format(long j, StringBuffer stringBuffer, FieldPosition fieldPosition) {
        return this.numberFormat.format(j, stringBuffer, fieldPosition);
    }
}
