package tech.units.indriya.internal.format;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Stack;
import javax.measure.format.MeasurementParseException;
import org.apiguardian.api.API;
import p000.z82;
import tech.units.indriya.function.RationalNumber;
import tech.units.indriya.internal.function.Calculator;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
public class RationalNumberScanner {
    private final CharSequence csq;
    private final ParsePosition cursor;
    private boolean divisionCharacterDetected = false;
    private final NumberFormat numberFormat;

    public RationalNumberScanner(CharSequence charSequence, ParsePosition parsePosition, NumberFormat numberFormat) {
        this.csq = charSequence;
        this.cursor = parsePosition;
        this.numberFormat = numberFormat;
    }

    private int scanForEnd(int i) {
        this.divisionCharacterDetected = false;
        while (i < this.csq.length()) {
            char cCharAt = this.csq.charAt(i);
            if (cCharAt == RationalNumber.DIVISION_CHARACTER) {
                this.divisionCharacterDetected = true;
                break;
            }
            if (Character.isWhitespace(cCharAt)) {
                break;
            }
            i++;
        }
        this.cursor.setIndex(i + 1);
        return i;
    }

    private int scanForStart(int i) {
        while (i < this.csq.length() && Character.isWhitespace(this.csq.charAt(i))) {
            i++;
        }
        return i;
    }

    public Number getNumber() {
        Stack stack = new Stack();
        do {
            int iScanForStart = scanForStart(this.cursor.getIndex());
            stack.push(this.csq.subSequence(iScanForStart, scanForEnd(iScanForStart + 1)).toString());
        } while (this.divisionCharacterDetected);
        if (stack.size() == 2) {
            return RationalNumber.m17691of(new BigInteger((String) stack.pop()), new BigInteger((String) stack.pop()));
        }
        if (stack.size() != 1) {
            throw new MeasurementParseException("Unexpected number of number-literals in '" + ((Object) this.csq) + "'");
        }
        String str = (String) stack.pop();
        NumberFormat numberFormat = this.numberFormat;
        if (numberFormat == null) {
            try {
                return Calculator.m17692of(new BigDecimal(str)).peek();
            } catch (Exception unused) {
                throw new MeasurementParseException(z82.m21089v("Failed to parse number-literal '", str, "'."));
            }
        }
        try {
            return numberFormat.parse(str);
        } catch (ParseException e) {
            throw new MeasurementParseException(e);
        }
    }
}
