package tech.units.indriya.internal.format.l10n;

import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.Vector;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class MultiPropertyResourceBundle extends ResourceBundle {
    private String resourcePath;
    private final Map<String, Object> resources = new HashMap();
    private final StringBuilder mergedBundlePaths = new StringBuilder();

    public MultiPropertyResourceBundle(InputStream inputStream, String str) {
        this.resourcePath = null;
        PropertyResourceBundle propertyResourceBundle = new PropertyResourceBundle(inputStream);
        this.resourcePath = str;
        merge(propertyResourceBundle, str);
    }

    @Override // java.util.ResourceBundle
    public boolean containsKey(String str) {
        return this.resources.containsKey(str);
    }

    @Override // java.util.ResourceBundle
    public Enumeration<String> getKeys() {
        return new Vector(this.resources.keySet()).elements();
    }

    public StringBuilder getMergedBundlePaths() {
        return this.mergedBundlePaths;
    }

    public String getResourcePath() {
        return this.resourcePath;
    }

    @Override // java.util.ResourceBundle
    public Object handleGetObject(String str) {
        Objects.requireNonNull(str);
        return this.resources.get(str);
    }

    @Override // java.util.ResourceBundle
    public Set<String> handleKeySet() {
        return this.resources.keySet();
    }

    @Override // java.util.ResourceBundle
    public Set<String> keySet() {
        return this.resources.keySet();
    }

    public void merge(ResourceBundle resourceBundle, String str) {
        if (resourceBundle != null) {
            Enumeration<String> keys = resourceBundle.getKeys();
            while (keys.hasMoreElements()) {
                String strNextElement = keys.nextElement();
                this.resources.put(strNextElement, resourceBundle.getObject(strNextElement));
            }
        }
        this.mergedBundlePaths.append(str);
        this.mergedBundlePaths.append(":");
    }

    public MultiPropertyResourceBundle(ResourceBundle resourceBundle, String str) {
        this.resourcePath = null;
        this.resourcePath = str;
        merge(resourceBundle, str);
    }
}
