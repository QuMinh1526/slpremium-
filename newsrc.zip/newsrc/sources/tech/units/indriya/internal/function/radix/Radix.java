package tech.units.indriya.internal.function.radix;

import java.util.Objects;
import javax.measure.UnitConverter;
import org.apiguardian.api.API;
import p000.C1521v3;
import tech.units.indriya.function.Calculus;
import tech.units.indriya.spi.NumberSystem;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
public interface Radix {

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class NumberFactorRadix implements Radix {
        private final Number radix;

        public NumberFactorRadix(Number number) {
            this.radix = m17696ns().narrow(number);
        }

        /* JADX INFO: renamed from: ns */
        private static NumberSystem m17696ns() {
            return Calculus.currentNumberSystem();
        }

        @Override // tech.units.indriya.internal.function.radix.Radix
        public Number[] divideAndRemainder(Number number, boolean z) {
            Number[] numberArrDivideAndRemainder = m17696ns().divideAndRemainder(m17696ns().narrow(number), this.radix, z);
            numberArrDivideAndRemainder[0] = m17696ns().narrow(numberArrDivideAndRemainder[0]);
            numberArrDivideAndRemainder[1] = m17696ns().narrow(numberArrDivideAndRemainder[1]);
            return numberArrDivideAndRemainder;
        }

        @Override // tech.units.indriya.internal.function.radix.Radix
        public Number multiply(Number number) {
            return m17696ns().narrow(m17696ns().multiply(this.radix, m17696ns().narrow(number)));
        }
    }

    static Radix ofMultiplyConverter(UnitConverter unitConverter) {
        Objects.requireNonNull(unitConverter, "unitConverter cannot be null");
        if (unitConverter.isLinear()) {
            return new NumberFactorRadix(Calculus.currentNumberSystem().narrow(Double.valueOf(unitConverter.convert(1.0d))));
        }
        C1521v3.m18903j("unitConverter is expected to be a linear transformation (a linear function without offset)");
        return null;
    }

    static Radix ofNumberFactor(Number number) {
        return new NumberFactorRadix(number);
    }

    Number[] divideAndRemainder(Number number, boolean z);

    Number multiply(Number number);
}
