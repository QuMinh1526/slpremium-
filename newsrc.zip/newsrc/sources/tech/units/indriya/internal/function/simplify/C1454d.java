package tech.units.indriya.internal.function.simplify;

import java.util.function.BinaryOperator;
import tech.units.indriya.function.AbstractConverter;

/* JADX INFO: renamed from: tech.units.indriya.internal.function.simplify.d */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class C1454d implements BinaryOperator {
    @Override // java.util.function.BiFunction
    public final Object apply(Object obj, Object obj2) {
        return CompositionTask.lambda$sequenceToConverter$3((AbstractConverter) obj, (AbstractConverter) obj2);
    }
}
