package tech.units.indriya.internal.function.simplify;

import java.util.Map;
import java.util.Objects;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Supplier;
import p000.z82;
import tech.units.indriya.function.AbstractConverter;
import tech.units.indriya.function.Calculus;
import tech.units.indriya.function.ConverterCompositionHandler;
import tech.units.indriya.function.PowerOfIntConverter;
import tech.units.indriya.internal.function.simplify.UnitCompositionHandlerYieldingNormalForm;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class UnitCompositionHandlerYieldingNormalForm implements ConverterCompositionHandler {
    private final Map<Class<? extends AbstractConverter>, Integer> normalFormOrder = Calculus.getNormalFormOrder();

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:11:0x0055 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:12:0x0056 A[RETURN] */
    public boolean isNormalFormOrderWhenCommutative(final AbstractConverter abstractConverter, final AbstractConverter abstractConverter2) {
        final int i = 0;
        final int i2 = 1;
        if (abstractConverter.getClass().equals(abstractConverter2.getClass())) {
            if (!(abstractConverter instanceof PowerOfIntConverter) || ((PowerOfIntConverter) abstractConverter).getBase() <= ((PowerOfIntConverter) abstractConverter2).getBase()) {
                return true;
            }
            return false;
        }
        Integer num = this.normalFormOrder.get(abstractConverter.getClass());
        Objects.requireNonNull(num, (Supplier<String>) new Supplier() { // from class: b5b
            @Override // java.util.function.Supplier
            public final Object get() {
                int i3 = i;
                AbstractConverter abstractConverter3 = abstractConverter;
                switch (i3) {
                    case 0:
                        return UnitCompositionHandlerYieldingNormalForm.lambda$isNormalFormOrderWhenCommutative$0(abstractConverter3);
                    default:
                        return UnitCompositionHandlerYieldingNormalForm.lambda$isNormalFormOrderWhenCommutative$1(abstractConverter3);
                }
            }
        });
        Integer num2 = this.normalFormOrder.get(abstractConverter2.getClass());
        Objects.requireNonNull(num2, (Supplier<String>) new Supplier() { // from class: b5b
            @Override // java.util.function.Supplier
            public final Object get() {
                int i3 = i2;
                AbstractConverter abstractConverter3 = abstractConverter2;
                switch (i3) {
                    case 0:
                        return UnitCompositionHandlerYieldingNormalForm.lambda$isNormalFormOrderWhenCommutative$0(abstractConverter3);
                    default:
                        return UnitCompositionHandlerYieldingNormalForm.lambda$isNormalFormOrderWhenCommutative$1(abstractConverter3);
                }
            }
        });
        if (num.intValue() <= num2.intValue()) {
            return true;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isNormalFormOrderWhenIdentity(AbstractConverter abstractConverter, AbstractConverter abstractConverter2) {
        return abstractConverter.getClass().equals(abstractConverter2.getClass()) || this.normalFormOrder.get(abstractConverter.getClass()).intValue() <= this.normalFormOrder.get(abstractConverter2.getClass()).intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ String lambda$isNormalFormOrderWhenCommutative$0(AbstractConverter abstractConverter) {
        return z82.m21089v("no normal-form order defined for class '", abstractConverter.getClass().getName(), "'");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ String lambda$isNormalFormOrderWhenCommutative$1(AbstractConverter abstractConverter) {
        return z82.m21089v("no normal-form order defined for class '", abstractConverter.getClass().getName(), "'");
    }

    @Override // tech.units.indriya.function.ConverterCompositionHandler
    public AbstractConverter compose(AbstractConverter abstractConverter, AbstractConverter abstractConverter2, BiPredicate<AbstractConverter, AbstractConverter> biPredicate, BinaryOperator<AbstractConverter> binaryOperator) {
        if (abstractConverter.isIdentity()) {
            if (!abstractConverter2.isIdentity() || !isNormalFormOrderWhenIdentity(abstractConverter, abstractConverter2)) {
                return abstractConverter2;
            }
        } else if (!abstractConverter2.isIdentity()) {
            if (biPredicate.test(abstractConverter, abstractConverter2)) {
                return (AbstractConverter) binaryOperator.apply(abstractConverter, abstractConverter2);
            }
            final int i = 0;
            final int i2 = 1;
            return new CompositionTask(new BiPredicate(this) { // from class: c5b

                /* JADX INFO: renamed from: b */
                public final /* synthetic */ UnitCompositionHandlerYieldingNormalForm f5205b;

                {
                    this.f5205b = this;
                }

                @Override // java.util.function.BiPredicate
                public final boolean test(Object obj, Object obj2) {
                    int i3 = i;
                    UnitCompositionHandlerYieldingNormalForm unitCompositionHandlerYieldingNormalForm = this.f5205b;
                    AbstractConverter abstractConverter3 = (AbstractConverter) obj;
                    AbstractConverter abstractConverter4 = (AbstractConverter) obj2;
                    switch (i3) {
                        case 0:
                            return unitCompositionHandlerYieldingNormalForm.isNormalFormOrderWhenIdentity(abstractConverter3, abstractConverter4);
                        default:
                            return unitCompositionHandlerYieldingNormalForm.isNormalFormOrderWhenCommutative(abstractConverter3, abstractConverter4);
                    }
                }
            }, new BiPredicate(this) { // from class: c5b

                /* JADX INFO: renamed from: b */
                public final /* synthetic */ UnitCompositionHandlerYieldingNormalForm f5205b;

                {
                    this.f5205b = this;
                }

                @Override // java.util.function.BiPredicate
                public final boolean test(Object obj, Object obj2) {
                    int i3 = i2;
                    UnitCompositionHandlerYieldingNormalForm unitCompositionHandlerYieldingNormalForm = this.f5205b;
                    AbstractConverter abstractConverter3 = (AbstractConverter) obj;
                    AbstractConverter abstractConverter4 = (AbstractConverter) obj2;
                    switch (i3) {
                        case 0:
                            return unitCompositionHandlerYieldingNormalForm.isNormalFormOrderWhenIdentity(abstractConverter3, abstractConverter4);
                        default:
                            return unitCompositionHandlerYieldingNormalForm.isNormalFormOrderWhenCommutative(abstractConverter3, abstractConverter4);
                    }
                }
            }, biPredicate, binaryOperator).reduceToNormalForm(((abstractConverter.isLinear() && abstractConverter2.isLinear() && !isNormalFormOrderWhenCommutative(abstractConverter, abstractConverter2)) ? new AbstractConverter.Pair(abstractConverter2, abstractConverter) : new AbstractConverter.Pair(abstractConverter, abstractConverter2)).getConversionSteps());
        }
        return abstractConverter;
    }
}
