package tech.units.indriya.internal.function.simplify;

import java.util.BitSet;
import java.util.function.Predicate;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
final class CompositionTaskBitScanner {
    private final BitSet bitSet;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    @FunctionalInterface
    public interface BiIntConsumer {
        void accept(int i, int i2);
    }

    private CompositionTaskBitScanner(BitSet bitSet) {
        this.bitSet = bitSet;
    }

    /* JADX INFO: renamed from: of */
    public static <T> CompositionTaskBitScanner m17702of(T[] tArr, Predicate<T> predicate) {
        BitSet bitSet = new BitSet(tArr.length);
        int i = 0;
        for (T t : tArr) {
            if (predicate.test(t)) {
                bitSet.set(i);
            }
            i++;
        }
        return new CompositionTaskBitScanner(bitSet);
    }

    public void visitBitSequences(BiIntConsumer biIntConsumer) {
        int i = 0;
        while (true) {
            int iNextSetBit = this.bitSet.nextSetBit(i);
            if (iNextSetBit <= -1) {
                return;
            }
            int iNextClearBit = this.bitSet.nextClearBit(iNextSetBit);
            if (iNextClearBit == -1) {
                biIntConsumer.accept(iNextSetBit, this.bitSet.size());
                return;
            } else {
                biIntConsumer.accept(iNextSetBit, iNextClearBit);
                i = iNextClearBit;
            }
        }
    }
}
