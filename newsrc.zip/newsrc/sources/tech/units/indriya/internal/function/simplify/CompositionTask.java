package tech.units.indriya.internal.function.simplify;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import javax.measure.UnitConverter;
import p000.uz1;
import tech.units.indriya.function.AbstractConverter;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
final class CompositionTask {
    private AbstractConverter[] arrayOfConverters;
    private final BiPredicate<AbstractConverter, AbstractConverter> canReduce;
    private final BinaryOperator<AbstractConverter> doReduce;
    private final BiPredicate<AbstractConverter, AbstractConverter> isNormalFormOrderWhenCommutative;
    private final BiPredicate<AbstractConverter, AbstractConverter> isNormalFormOrderWhenIdentity;

    public CompositionTask(BiPredicate<AbstractConverter, AbstractConverter> biPredicate, BiPredicate<AbstractConverter, AbstractConverter> biPredicate2, BiPredicate<AbstractConverter, AbstractConverter> biPredicate3, BinaryOperator<AbstractConverter> binaryOperator) {
        this.isNormalFormOrderWhenIdentity = biPredicate;
        this.isNormalFormOrderWhenCommutative = biPredicate2;
        this.canReduce = biPredicate3;
        this.doReduce = binaryOperator;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ AbstractConverter lambda$sequenceToConverter$3(AbstractConverter abstractConverter, AbstractConverter abstractConverter2) {
        return new AbstractConverter.Pair(abstractConverter, abstractConverter2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ int lambda$sortToNormalFormOrder$1(AbstractConverter abstractConverter, AbstractConverter abstractConverter2) {
        if (abstractConverter.isIdentity()) {
            return (!abstractConverter2.isIdentity() || this.isNormalFormOrderWhenIdentity.test(abstractConverter, abstractConverter2)) ? -1 : 1;
        }
        return (!abstractConverter2.isIdentity() && this.isNormalFormOrderWhenCommutative.test(abstractConverter, abstractConverter2)) ? -1 : 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$sortToNormalFormOrder$2(AbstractConverter[] abstractConverterArr, int i, int i2) {
        Arrays.sort(abstractConverterArr, i, i2, new Comparator() { // from class: tech.units.indriya.internal.function.simplify.a
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return this.f40125e.lambda$sortToNormalFormOrder$1((AbstractConverter) obj, (AbstractConverter) obj2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ AbstractConverter lambda$trySimplify$0(AbstractConverter abstractConverter, AbstractConverter abstractConverter2) {
        if (abstractConverter.isIdentity()) {
            return abstractConverter2;
        }
        if (abstractConverter2.isIdentity()) {
            return abstractConverter;
        }
        if (this.canReduce.test(abstractConverter, abstractConverter2)) {
            return (AbstractConverter) this.doReduce.apply(abstractConverter, abstractConverter2);
        }
        return null;
    }

    private static AbstractConverter sequenceToConverter(AbstractConverter[] abstractConverterArr) {
        if (abstractConverterArr == null || abstractConverterArr.length == 0) {
            return AbstractConverter.IDENTITY;
        }
        if (abstractConverterArr.length == 1) {
            return abstractConverterArr[0];
        }
        return (AbstractConverter) Arrays.stream(abstractConverterArr).skip(2L).reduce(new AbstractConverter.Pair(abstractConverterArr[0], abstractConverterArr[1]), new C1454d());
    }

    private void sortToNormalFormOrder(final AbstractConverter[] abstractConverterArr) {
        CompositionTaskBitScanner.m17702of(abstractConverterArr, new uz1(0)).visitBitSequences(new CompositionTaskBitScanner.BiIntConsumer() { // from class: tech.units.indriya.internal.function.simplify.b
            @Override // tech.units.indriya.internal.function.simplify.CompositionTaskBitScanner.BiIntConsumer
            public final void accept(int i, int i2) {
                this.f40126a.lambda$sortToNormalFormOrder$2(abstractConverterArr, i, i2);
            }
        });
    }

    private int trySimplify() {
        CompositionTaskArrayAdapter compositionTaskArrayAdapterM17701of = CompositionTaskArrayAdapter.m17701of(this.arrayOfConverters);
        int iVisitSequentialPairsAndSimplify = compositionTaskArrayAdapterM17701of.visitSequentialPairsAndSimplify(new BinaryOperator() { // from class: tech.units.indriya.internal.function.simplify.c
            @Override // java.util.function.BiFunction
            public final Object apply(Object obj, Object obj2) {
                return this.f40128a.lambda$trySimplify$0((AbstractConverter) obj, (AbstractConverter) obj2);
            }
        });
        if (iVisitSequentialPairsAndSimplify > 0) {
            this.arrayOfConverters = (AbstractConverter[]) compositionTaskArrayAdapterM17701of.removeNulls(iVisitSequentialPairsAndSimplify);
        }
        return iVisitSequentialPairsAndSimplify;
    }

    public AbstractConverter reduceToNormalForm(List<? extends UnitConverter> list) {
        AbstractConverter[] abstractConverterArr = (AbstractConverter[]) list.toArray(new AbstractConverter[0]);
        this.arrayOfConverters = abstractConverterArr;
        sortToNormalFormOrder(abstractConverterArr);
        while (true) {
            int iTrySimplify = trySimplify();
            AbstractConverter[] abstractConverterArr2 = this.arrayOfConverters;
            if (iTrySimplify <= 0) {
                return sequenceToConverter(abstractConverterArr2);
            }
            sortToNormalFormOrder(abstractConverterArr2);
        }
    }
}
