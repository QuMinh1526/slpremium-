package tech.units.indriya.internal.function.simplify;

import java.util.Arrays;
import java.util.function.BiConsumer;
import java.util.function.BinaryOperator;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
final class CompositionTaskArrayAdapter<T> {
    private final T[] array;

    private CompositionTaskArrayAdapter(T[] tArr) {
        this.array = tArr;
    }

    /* JADX INFO: renamed from: of */
    public static <T> CompositionTaskArrayAdapter<T> m17701of(T[] tArr) {
        return new CompositionTaskArrayAdapter<>(tArr);
    }

    public T[] removeNulls(int i) {
        T[] tArr = this.array;
        T[] tArr2 = (T[]) Arrays.copyOf(tArr, tArr.length - i);
        int i2 = 0;
        int i3 = 0;
        while (true) {
            T[] tArr3 = this.array;
            if (i2 >= tArr3.length) {
                return tArr2;
            }
            T t = tArr3[i2];
            if (t != null) {
                tArr2[i3] = t;
                i3++;
            }
            i2++;
        }
    }

    public void visitSequentialPairs(BiConsumer<T, T> biConsumer) {
        if (this.array.length < 2) {
            return;
        }
        int i = 1;
        while (true) {
            T[] tArr = this.array;
            if (i >= tArr.length) {
                return;
            }
            biConsumer.accept(tArr[i - 1], tArr[i]);
            i++;
        }
    }

    public int visitSequentialPairsAndSimplify(BinaryOperator<T> binaryOperator) {
        Object objApply;
        int i = 0;
        if (this.array.length < 2) {
            return 0;
        }
        int i2 = 1;
        while (true) {
            T[] tArr = this.array;
            if (i2 >= tArr.length) {
                return i;
            }
            int i3 = i2 - 1;
            T t = tArr[i3];
            if (t != null && (objApply = binaryOperator.apply(t, tArr[i2])) != null) {
                Object[] objArr = (T[]) this.array;
                objArr[i3] = objApply;
                objArr[i2] = null;
                i++;
            }
            i2++;
        }
    }
}
