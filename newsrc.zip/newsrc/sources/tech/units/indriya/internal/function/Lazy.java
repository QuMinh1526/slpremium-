package tech.units.indriya.internal.function;

import com.squareup.picasso.BuildConfig;
import java.util.Objects;
import java.util.function.Supplier;
import org.apiguardian.api.API;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
public class Lazy<T> {
    private boolean memorized;
    private final Supplier<? extends T> supplier;
    private T value;

    public Lazy(Supplier<? extends T> supplier) {
        Objects.requireNonNull(supplier, "supplier is required");
        this.supplier = supplier;
    }

    public void clear() {
        synchronized (this) {
            this.memorized = false;
            this.value = null;
        }
    }

    public T get() {
        synchronized (this) {
            try {
                if (this.memorized) {
                    return this.value;
                }
                this.memorized = true;
                T t = this.supplier.get();
                this.value = t;
                return t;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public boolean isMemorized() {
        boolean z;
        synchronized (this) {
            z = this.memorized;
        }
        return z;
    }

    public void set(T t) {
        synchronized (this) {
            try {
                if (this.memorized) {
                    throw new IllegalStateException("cannot set value '" + (BuildConfig.VERSION_NAME + t) + "' on Lazy that has already memoized a value");
                }
                this.memorized = true;
                this.value = t;
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
