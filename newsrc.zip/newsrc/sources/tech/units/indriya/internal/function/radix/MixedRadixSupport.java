package tech.units.indriya.internal.function.radix;

import java.util.function.Consumer;
import org.apiguardian.api.API;
import tech.units.indriya.internal.function.Calculator;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
public class MixedRadixSupport {
    private final Radix[] radices;

    public MixedRadixSupport(Radix[] radixArr) {
        this.radices = radixArr;
    }

    private int invertIndex(int i) {
        return (this.radices.length - i) - 1;
    }

    public Number sumMostSignificant(Number[] numberArr) {
        int length = numberArr.length - 1;
        int i = 0;
        Number numberMultiply = numberArr[0];
        while (true) {
            Radix[] radixArr = this.radices;
            if (i >= radixArr.length) {
                return numberMultiply;
            }
            numberMultiply = radixArr[i].multiply(numberMultiply);
            if (i < length) {
                numberMultiply = Calculator.m17692of(numberMultiply).add(numberArr[i + 1]).peek();
            }
            i++;
        }
    }

    public void visitRadixNumbers(Number number, Consumer<Number> consumer) {
        int i = 0;
        while (true) {
            Radix[] radixArr = this.radices;
            if (i >= radixArr.length) {
                consumer.accept(number);
                return;
            }
            Number[] numberArrDivideAndRemainder = radixArr[invertIndex(i)].divideAndRemainder(number, !(i == 0));
            consumer.accept(numberArrDivideAndRemainder[1]);
            number = numberArrDivideAndRemainder[0];
            i++;
        }
    }
}
