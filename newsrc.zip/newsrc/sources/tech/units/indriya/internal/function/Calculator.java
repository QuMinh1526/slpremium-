package tech.units.indriya.internal.function;

import java.util.Objects;
import org.apiguardian.api.API;
import tech.units.indriya.function.Calculus;
import tech.units.indriya.spi.NumberSystem;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
public final class Calculator {
    private Number acc;

    /* JADX INFO: renamed from: ns */
    private final NumberSystem f40122ns;

    private Calculator(NumberSystem numberSystem) {
        this.acc = 0;
        this.f40122ns = numberSystem;
    }

    private static Calculator getInstance() {
        return new Calculator(Calculus.currentNumberSystem());
    }

    private Calculator load(Number number) {
        Objects.requireNonNull(number);
        this.acc = this.f40122ns.narrow(number);
        return this;
    }

    /* JADX INFO: renamed from: of */
    public static Calculator m17692of(Number number) {
        return getInstance().load(number);
    }

    public Calculator abs() {
        this.acc = this.f40122ns.abs(this.acc);
        return this;
    }

    public Calculator add(Number number) {
        Objects.requireNonNull(number);
        NumberSystem numberSystem = this.f40122ns;
        this.acc = numberSystem.add(this.acc, numberSystem.narrow(number));
        return this;
    }

    public Calculator divide(Number number) {
        NumberSystem numberSystem = this.f40122ns;
        this.acc = numberSystem.divide(this.acc, numberSystem.narrow(number));
        return this;
    }

    public Calculator exp() {
        this.acc = this.f40122ns.exp(this.acc);
        return this;
    }

    public boolean isLessThanOne() {
        return this.f40122ns.isLessThanOne(this.acc);
    }

    public Calculator log() {
        this.acc = this.f40122ns.log(this.acc);
        return this;
    }

    public Calculator multiply(Number number) {
        NumberSystem numberSystem = this.f40122ns;
        this.acc = numberSystem.multiply(this.acc, numberSystem.narrow(number));
        return this;
    }

    public Calculator negate() {
        this.acc = this.f40122ns.negate(this.acc);
        return this;
    }

    public Number peek() {
        return this.f40122ns.narrow(this.acc);
    }

    public Calculator power(int i) {
        this.acc = this.f40122ns.power(this.acc, i);
        return this;
    }

    public Calculator reciprocal() {
        this.acc = this.f40122ns.reciprocal(this.acc);
        return this;
    }

    public Calculator subtract(Number number) {
        Objects.requireNonNull(number);
        NumberSystem numberSystem = this.f40122ns;
        this.acc = numberSystem.subtract(this.acc, numberSystem.narrow(number));
        return this;
    }

    private Calculator() {
        this(Calculus.currentNumberSystem());
    }
}
