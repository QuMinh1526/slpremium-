package tech.units.indriya.internal.function;

import java.util.Objects;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.function.UnaryOperator;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import org.apiguardian.api.API;
import p000.ad7;
import tech.units.indriya.ComparableQuantity;
import tech.units.indriya.function.AbstractConverter;
import tech.units.indriya.quantity.Quantities;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
public final class ScaleHelper {

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public enum OperandMode {
        ALL_ABSOLUTE,
        ALL_RELATIVE,
        MIXED;

        public static OperandMode get(Quantity<?> quantity, Quantity<?> quantity2) {
            if (quantity.getScale() != quantity2.getScale()) {
                return MIXED;
            }
            return ScaleHelper.isAbsolute(quantity) ? ALL_ABSOLUTE : ALL_RELATIVE;
        }

        public boolean isAllRelative() {
            return this == ALL_RELATIVE;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class ToSystemUnitConverter implements UnaryOperator<Number> {
        private final UnaryOperator<Number> inverseOperator;
        private final UnaryOperator<Number> unaryOperator;

        private ToSystemUnitConverter(UnaryOperator<Number> unaryOperator, UnaryOperator<Number> unaryOperator2) {
            this.unaryOperator = unaryOperator;
            this.inverseOperator = unaryOperator2;
        }

        public static ToSystemUnitConverter factor(final Number number) {
            final int i = 0;
            final int i2 = 1;
            return new ToSystemUnitConverter(new UnaryOperator() { // from class: tech.units.indriya.internal.function.a
                @Override // java.util.function.Function
                public final Object apply(Object obj) {
                    int i3 = i;
                    Number number2 = number;
                    Number number3 = (Number) obj;
                    switch (i3) {
                        case 0:
                            return ScaleHelper.ToSystemUnitConverter.lambda$factor$0(number2, number3);
                        default:
                            return ScaleHelper.ToSystemUnitConverter.lambda$factor$1(number2, number3);
                    }
                }
            }, new UnaryOperator() { // from class: tech.units.indriya.internal.function.a
                @Override // java.util.function.Function
                public final Object apply(Object obj) {
                    int i3 = i2;
                    Number number2 = number;
                    Number number3 = (Number) obj;
                    switch (i3) {
                        case 0:
                            return ScaleHelper.ToSystemUnitConverter.lambda$factor$0(number2, number3);
                        default:
                            return ScaleHelper.ToSystemUnitConverter.lambda$factor$1(number2, number3);
                    }
                }
            });
        }

        public static <Q extends Quantity<Q>> ToSystemUnitConverter forQuantity(Quantity<Q> quantity, Unit<Q> unit) {
            if (quantity.getUnit().equals(unit)) {
                return noop();
            }
            UnitConverter converterTo = quantity.getUnit().getConverterTo(unit);
            if (ScaleHelper.isAbsolute(quantity)) {
                Objects.requireNonNull(converterTo);
                return m17695of(new ad7(converterTo, 2));
            }
            Number number = (Number) ScaleHelper.linearFactorOf(converterTo).orElse(null);
            if (number != null) {
                return factor(number);
            }
            throw ScaleHelper.unsupportedConverter(converterTo, quantity.getUnit());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ Number lambda$factor$0(Number number, Number number2) {
            return Calculator.m17692of(number2).multiply(number).peek();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ Number lambda$factor$1(Number number, Number number2) {
            return Calculator.m17692of(number2).divide(number).peek();
        }

        public static ToSystemUnitConverter noop() {
            return new ToSystemUnitConverter(null, null);
        }

        /* JADX INFO: renamed from: of */
        public static ToSystemUnitConverter m17695of(UnaryOperator<Number> unaryOperator) {
            return new ToSystemUnitConverter(unaryOperator, null);
        }

        @Override // java.util.function.Function
        public Number apply(Number number) {
            return isNoop() ? number : (Number) this.unaryOperator.apply(number);
        }

        public Number invert(Number number) {
            return isNoop() ? number : (Number) this.inverseOperator.apply(number);
        }

        public boolean isNoop() {
            return this.unaryOperator == null;
        }
    }

    public static <Q extends Quantity<Q>> ComparableQuantity<Q> addition(Quantity<Q> quantity, Quantity<Q> quantity2, BinaryOperator<Number> binaryOperator) {
        boolean zIsAllRelative = OperandMode.get(quantity, quantity2).isAllRelative();
        ToSystemUnitConverter systemUnitConverterForAdd = toSystemUnitConverterForAdd(quantity, quantity);
        ToSystemUnitConverter systemUnitConverterForAdd2 = toSystemUnitConverterForAdd(quantity, quantity2);
        Number numberConvert = (Number) binaryOperator.apply(systemUnitConverterForAdd.apply(quantity.getValue()), systemUnitConverterForAdd2.apply(quantity2.getValue()));
        if (zIsAllRelative) {
            return Quantities.getQuantity(systemUnitConverterForAdd.invert(numberConvert), quantity.getUnit(), Quantity.Scale.RELATIVE);
        }
        if (!systemUnitConverterForAdd.isNoop() || !systemUnitConverterForAdd2.isNoop()) {
            numberConvert = quantity.getUnit().getConverterTo(quantity.getUnit().getSystemUnit()).inverse().convert(numberConvert);
        }
        return Quantities.getQuantity(numberConvert, quantity.getUnit(), Quantity.Scale.ABSOLUTE);
    }

    public static <Q extends Quantity<Q>> ComparableQuantity<Q> convertTo(Quantity<Q> quantity, Unit<Q> unit) {
        UnitConverter converterTo = quantity.getUnit().getConverterTo(unit);
        if (!isRelative(quantity)) {
            return Quantities.getQuantity(converterTo.convert(quantity.getValue()), unit, Quantity.Scale.ABSOLUTE);
        }
        Number numberOrElse = linearFactorOf(converterTo).orElse(null);
        if (numberOrElse != null) {
            return Quantities.getQuantity(Calculator.m17692of(numberOrElse).multiply(quantity.getValue()).peek(), unit, Quantity.Scale.RELATIVE);
        }
        throw unsupportedRelativeScaleConversion(quantity, unit);
    }

    public static boolean isAbsolute(Quantity<?> quantity) {
        return Quantity.Scale.ABSOLUTE == quantity.getScale();
    }

    public static boolean isRelative(Quantity<?> quantity) {
        return Quantity.Scale.RELATIVE == quantity.getScale();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static Optional<Number> linearFactorOf(UnitConverter unitConverter) {
        return unitConverter instanceof AbstractConverter ? ((AbstractConverter) unitConverter).linearFactor() : Optional.empty();
    }

    public static ComparableQuantity<?> multiplication(Quantity<?> quantity, Quantity<?> quantity2, BinaryOperator<Number> binaryOperator, BinaryOperator<Unit<?>> binaryOperator2) {
        Quantity absoluteLinear = toAbsoluteLinear(quantity);
        Quantity absoluteLinear2 = toAbsoluteLinear(quantity2);
        return Quantities.getQuantity((Number) binaryOperator.apply(absoluteLinear.getValue(), absoluteLinear2.getValue()), (Unit) binaryOperator2.apply(absoluteLinear.getUnit(), absoluteLinear2.getUnit()));
    }

    public static <Q extends Quantity<Q>> ComparableQuantity<Q> scalarMultiplication(Quantity<Q> quantity, UnaryOperator<Number> unaryOperator) {
        if (isRelative(quantity)) {
            return Quantities.getQuantity((Number) unaryOperator.apply(quantity.getValue()), quantity.getUnit(), Quantity.Scale.RELATIVE);
        }
        ToSystemUnitConverter systemUnitConverterForMul = toSystemUnitConverterForMul(quantity);
        Number numberConvert = (Number) unaryOperator.apply(systemUnitConverterForMul.apply(quantity.getValue()));
        if (!systemUnitConverterForMul.isNoop()) {
            numberConvert = quantity.getUnit().getConverterTo(quantity.getUnit().getSystemUnit()).inverse().convert(numberConvert);
        }
        return Quantities.getQuantity(numberConvert, quantity.getUnit(), quantity.getScale());
    }

    private static <Q extends Quantity<Q>> Quantity<Q> toAbsoluteLinear(Quantity<Q> quantity) {
        Unit<Q> systemUnit = quantity.getUnit().getSystemUnit();
        UnitConverter converterTo = quantity.getUnit().getConverterTo(systemUnit);
        if (converterTo.isLinear()) {
            return isAbsolute(quantity) ? quantity : Quantities.getQuantity(quantity.getValue(), quantity.getUnit());
        }
        if (isAbsolute(quantity)) {
            return Quantities.getQuantity(converterTo.convert(quantity.getValue()), systemUnit, Quantity.Scale.ABSOLUTE);
        }
        Number numberOrElse = linearFactorOf(converterTo).orElse(null);
        if (numberOrElse != null) {
            return Quantities.getQuantity(Calculator.m17692of(numberOrElse).multiply(quantity.getValue()).peek(), systemUnit, Quantity.Scale.ABSOLUTE);
        }
        throw unsupportedRelativeScaleConversion(quantity, systemUnit);
    }

    private static <Q extends Quantity<Q>> ToSystemUnitConverter toSystemUnitConverterForAdd(Quantity<Q> quantity, Quantity<Q> quantity2) {
        return ToSystemUnitConverter.forQuantity(quantity2, quantity.getUnit().getSystemUnit());
    }

    private static <T extends Quantity<T>> ToSystemUnitConverter toSystemUnitConverterForMul(Quantity<T> quantity) {
        return ToSystemUnitConverter.forQuantity(quantity, quantity.getUnit().getSystemUnit());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static UnsupportedOperationException unsupportedConverter(UnitConverter unitConverter, Unit<?> unit) {
        return new UnsupportedOperationException(String.format("Scale conversion from RELATIVE to ABSOLUTE for Unit %s having Converter %s is not implemented.", unit, unitConverter));
    }

    private static <Q extends Quantity<Q>> UnsupportedOperationException unsupportedRelativeScaleConversion(Quantity<Q> quantity, Unit<Q> unit) {
        return new UnsupportedOperationException(String.format("Conversion of Quantitity %s to Unit %s is not supported for realtive scale.", quantity, unit));
    }
}
