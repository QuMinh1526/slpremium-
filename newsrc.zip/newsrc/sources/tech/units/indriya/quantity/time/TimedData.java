package tech.units.indriya.quantity.time;

import java.time.Instant;
import java.util.Objects;
import java.util.function.Supplier;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class TimedData<T> implements Supplier<T> {
    private final Instant instant;
    private final String name;
    private final long timestamp;
    private final T value;

    public TimedData(T t, long j, String str) {
        this.value = t;
        this.timestamp = j;
        this.instant = Instant.ofEpochMilli(j);
        this.name = str;
    }

    /* JADX INFO: renamed from: of */
    public static <T> TimedData<T> m17735of(T t, long j) {
        return new TimedData<>(t, j);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof TimedData) {
            TimedData timedData = (TimedData) obj;
            if (Objects.equals(get(), timedData.get()) && Long.valueOf(getTimestamp()).equals(Long.valueOf(timedData.getTimestamp())) && Objects.equals(getName(), timedData.getName())) {
                return true;
            }
        }
        return false;
    }

    @Override // java.util.function.Supplier
    public T get() {
        return this.value;
    }

    public Instant getInstant() {
        return this.instant;
    }

    public String getName() {
        return this.name;
    }

    public long getTimestamp() {
        return this.timestamp;
    }

    public int hashCode() {
        return Objects.hash(this.value, Long.valueOf(this.timestamp), this.name);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("data= ");
        sb.append(get());
        sb.append(", timestamp= ");
        sb.append(getTimestamp());
        if (this.name != null) {
            sb.append(", name= ");
            sb.append(getName());
        }
        return sb.toString();
    }

    /* JADX INFO: renamed from: of */
    public static <T> TimedData<T> m17736of(T t, long j, String str) {
        return new TimedData<>(t, j, str);
    }

    public TimedData(T t, long j) {
        this(t, j, null);
    }
}
