package tech.units.indriya.quantity.time;

import javax.measure.Quantity;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class TimedQuantityData<Q extends Quantity<Q>> extends TimedData<Quantity<Q>> {
    public TimedQuantityData(Quantity<Q> quantity, long j) {
        super(quantity, j);
    }

    /* JADX INFO: renamed from: of */
    public static <Q extends Quantity<Q>> TimedQuantityData<Q> m17737of(Quantity<Q> quantity, long j) {
        return new TimedQuantityData<>(quantity, j);
    }
}
