package tech.units.indriya.quantity.time;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.BinaryOperator;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.quantity.Frequency;
import javax.measure.quantity.Time;
import p000.C0805m0;
import p000.C1521v3;
import tech.units.indriya.AbstractQuantity;
import tech.units.indriya.ComparableQuantity;
import tech.units.indriya.function.Calculus;
import tech.units.indriya.internal.function.Calculator;
import tech.units.indriya.quantity.Quantities;
import tech.units.indriya.unit.Units;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class TimeUnitQuantity extends AbstractQuantity<Time> {
    private static final long serialVersionUID = -5840251813363744230L;
    private final TimeUnit timeUnit;
    private final Number value;

    /* JADX INFO: renamed from: tech.units.indriya.quantity.time.TimeUnitQuantity$1 */
    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static /* synthetic */ class C14561 {
        static final /* synthetic */ int[] $SwitchMap$java$util$concurrent$TimeUnit;

        static {
            int[] iArr = new int[TimeUnit.values().length];
            $SwitchMap$java$util$concurrent$TimeUnit = iArr;
            try {
                iArr[TimeUnit.MICROSECONDS.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$java$util$concurrent$TimeUnit[TimeUnit.MILLISECONDS.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$java$util$concurrent$TimeUnit[TimeUnit.NANOSECONDS.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$java$util$concurrent$TimeUnit[TimeUnit.SECONDS.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$java$util$concurrent$TimeUnit[TimeUnit.MINUTES.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                $SwitchMap$java$util$concurrent$TimeUnit[TimeUnit.HOURS.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                $SwitchMap$java$util$concurrent$TimeUnit[TimeUnit.DAYS.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    public TimeUnitQuantity(TimeUnit timeUnit, Number number) {
        super(toUnit(timeUnit));
        this.timeUnit = timeUnit;
        this.value = number;
    }

    private ComparableQuantity<Time> applyMultiplicativeNumberOperation(Number number, BinaryOperator<Number> binaryOperator) {
        return Quantities.getQuantity((Number) binaryOperator.apply(getValue(), number), getUnit());
    }

    private ComparableQuantity<?> applyMultiplicativeQuantityOperation(Quantity<?> quantity, BinaryOperator<Number> binaryOperator, BinaryOperator<Unit<?>> binaryOperator2) {
        return Quantities.getQuantity((Number) binaryOperator.apply(quantityValue(this), quantityValue(quantity)), (Unit) binaryOperator2.apply(getUnit(), quantity.getUnit()));
    }

    private static <R extends Quantity<R>> Number convertedQuantityValue(Quantity<R> quantity, Unit<R> unit) {
        return quantity.getUnit().getConverterTo(unit).convert(quantity.getValue());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$divide$0(Number number, Number number2) {
        return Calculator.m17692of(number).divide(number2).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$divide$1(Number number, Number number2) {
        return Calculator.m17692of(number).divide(number2).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$multiply$2(Number number, Number number2) {
        return Calculator.m17692of(number).multiply(number2).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$multiply$3(Number number, Number number2) {
        return Calculator.m17692of(number).multiply(number2).peek();
    }

    /* JADX INFO: renamed from: of */
    public static TimeUnitQuantity m17733of(Quantity<Time> quantity) {
        Objects.requireNonNull(quantity);
        return new TimeUnitQuantity(TimeUnit.SECONDS, quantity.mo11214to(Units.SECOND).getValue());
    }

    private static <R extends Quantity<R>> Number quantityValue(Quantity<R> quantity) {
        return convertedQuantityValue(quantity, quantity.getUnit());
    }

    private static Unit<Time> toUnit(TimeUnit timeUnit) {
        switch (C14561.$SwitchMap$java$util$concurrent$TimeUnit[timeUnit.ordinal()]) {
            case 1:
                return TimeQuantities.MICROSECOND;
            case 2:
                return TimeQuantities.MILLISECOND;
            case 3:
                return TimeQuantities.NANOSECOND;
            case 4:
                return Units.SECOND;
            case 5:
                return Units.MINUTE;
            case 6:
                return Units.HOUR;
            case 7:
                return Units.DAY;
            default:
                C1521v3.m18909p("In TimeUnitQuantity just supports DAYS, HOURS, MICROSECONDS, MILLISECONDS, MINUTES, NANOSECONDS, SECONDS ");
                return null;
        }
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Time> add(Quantity<Time> quantity) {
        Unit unit = Calculus.currentNumberSystem().compare(Double.valueOf(getUnit().getConverterTo(quantity.getUnit()).convert(1.0d)), Double.valueOf(1.0d)) > 0 ? quantity.getUnit() : getUnit();
        return Quantities.getQuantity(Calculator.m17692of(convertedQuantityValue(this, unit)).add(convertedQuantityValue(quantity, unit)).peek(), unit);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<?> divide(Quantity<?> quantity) {
        return applyMultiplicativeQuantityOperation(quantity, new C0805m0(19), new C0805m0(11));
    }

    @Override // tech.units.indriya.AbstractQuantity
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (TimeUnitQuantity.class.isInstance(obj)) {
            TimeUnitQuantity timeUnitQuantity = (TimeUnitQuantity) TimeUnitQuantity.class.cast(obj);
            return Objects.equals(this.timeUnit, timeUnitQuantity.timeUnit) && Objects.equals(this.value, timeUnitQuantity.value);
        }
        if (!(obj instanceof Quantity)) {
            return super.equals(obj);
        }
        Quantity quantity = (Quantity) obj;
        return Objects.equals(getUnit(), quantity.getUnit()) && Calculus.currentNumberSystem().compare(this.value, quantity.getValue()) == 0;
    }

    public TimeUnit getTimeUnit() {
        return this.timeUnit;
    }

    @Override // tech.units.indriya.AbstractQuantity
    public int hashCode() {
        return Objects.hash(this.timeUnit, this.value);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Frequency> inverse() {
        return Quantities.getQuantity(Calculator.m17692of(this.value).reciprocal().peek(), toUnit(this.timeUnit).inverse()).asType(Frequency.class);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<?> multiply(Quantity<?> quantity) {
        return applyMultiplicativeQuantityOperation(quantity, new C0805m0(20), new C0805m0(14));
    }

    @Override // javax.measure.Quantity
    public Quantity<Time> negate() {
        return m17732of(Calculator.m17692of(this.value).negate().peek(), getTimeUnit());
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Time> subtract(Quantity<Time> quantity) {
        return add(quantity.negate());
    }

    /* JADX INFO: renamed from: to */
    public TimeUnitQuantity m17734to(TimeUnit timeUnit) {
        return new TimeUnitQuantity(timeUnit, Long.valueOf(toQuantity().mo11214to(toUnit(timeUnit)).getValue().longValue()));
    }

    public Quantity<Time> toQuantity() {
        return Quantities.getQuantity(this.value, toUnit());
    }

    @Override // tech.units.indriya.AbstractQuantity
    public String toString() {
        return "Time unit:" + this.timeUnit + " value: " + this.value;
    }

    @Override // tech.units.indriya.AbstractQuantity, p000.w8b
    public Number getValue() {
        return this.value;
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public /* bridge */ /* synthetic */ Quantity subtract(Quantity quantity) {
        return subtract((Quantity<Time>) quantity);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public /* bridge */ /* synthetic */ Quantity divide(Quantity quantity) {
        return divide((Quantity<?>) quantity);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public /* bridge */ /* synthetic */ Quantity multiply(Quantity quantity) {
        return multiply((Quantity<?>) quantity);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Time> divide(Number number) {
        return applyMultiplicativeNumberOperation(number, new C0805m0(17));
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Time> multiply(Number number) {
        return applyMultiplicativeNumberOperation(number, new C0805m0(18));
    }

    /* JADX INFO: renamed from: of */
    public static TimeUnitQuantity m17732of(Number number, TimeUnit timeUnit) {
        Objects.requireNonNull(timeUnit);
        Objects.requireNonNull(number);
        return new TimeUnitQuantity(timeUnit, number);
    }

    public Unit<Time> toUnit() {
        return toUnit(this.timeUnit);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public /* bridge */ /* synthetic */ Quantity add(Quantity quantity) {
        return add((Quantity<Time>) quantity);
    }
}
