package tech.units.indriya.quantity.time;

import com.squareup.picasso.BuildConfig;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAmount;
import java.time.temporal.TemporalUnit;
import java.util.Objects;
import java.util.function.BinaryOperator;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.quantity.Frequency;
import javax.measure.quantity.Time;
import p000.C0805m0;
import p000.C1521v3;
import p000.f38;
import tech.units.indriya.AbstractQuantity;
import tech.units.indriya.ComparableQuantity;
import tech.units.indriya.function.Calculus;
import tech.units.indriya.internal.function.Calculator;
import tech.units.indriya.quantity.Quantities;
import tech.units.indriya.unit.Units;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class TemporalQuantity extends AbstractQuantity<Time> {
    private static final long serialVersionUID = -707159906206272775L;
    private final Object $lock1;
    private transient TemporalAmount amount;
    private final TemporalUnit timeUnit;
    private final Number value;

    /* JADX INFO: renamed from: tech.units.indriya.quantity.time.TemporalQuantity$1 */
    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static /* synthetic */ class C14551 {
        static final /* synthetic */ int[] $SwitchMap$java$time$temporal$ChronoUnit;

        static {
            int[] iArr = new int[ChronoUnit.values().length];
            $SwitchMap$java$time$temporal$ChronoUnit = iArr;
            try {
                ChronoUnit unused = ChronoUnit.MICROS;
                iArr[ChronoUnit.MICROS.ordinal()] = 1;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                int[] iArr2 = $SwitchMap$java$time$temporal$ChronoUnit;
                ChronoUnit unused3 = ChronoUnit.MILLIS;
                iArr2[ChronoUnit.MILLIS.ordinal()] = 2;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                int[] iArr3 = $SwitchMap$java$time$temporal$ChronoUnit;
                ChronoUnit unused5 = ChronoUnit.NANOS;
                iArr3[ChronoUnit.NANOS.ordinal()] = 3;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                int[] iArr4 = $SwitchMap$java$time$temporal$ChronoUnit;
                ChronoUnit unused7 = ChronoUnit.SECONDS;
                iArr4[ChronoUnit.SECONDS.ordinal()] = 4;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                int[] iArr5 = $SwitchMap$java$time$temporal$ChronoUnit;
                ChronoUnit unused9 = ChronoUnit.MINUTES;
                iArr5[ChronoUnit.MINUTES.ordinal()] = 5;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                int[] iArr6 = $SwitchMap$java$time$temporal$ChronoUnit;
                ChronoUnit unused11 = ChronoUnit.HOURS;
                iArr6[ChronoUnit.HOURS.ordinal()] = 6;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                int[] iArr7 = $SwitchMap$java$time$temporal$ChronoUnit;
                ChronoUnit unused13 = ChronoUnit.DAYS;
                iArr7[ChronoUnit.DAYS.ordinal()] = 7;
            } catch (NoSuchFieldError unused14) {
            }
        }
    }

    public TemporalQuantity(Number number, TemporalUnit temporalUnit) {
        super(toUnit(temporalUnit));
        this.$lock1 = new Object[0];
        this.timeUnit = temporalUnit;
        this.value = number;
    }

    private ComparableQuantity<Time> applyMultiplicativeNumberOperation(Number number, BinaryOperator<Number> binaryOperator) {
        return Quantities.getQuantity((Number) binaryOperator.apply(getValue(), number), getUnit());
    }

    private ComparableQuantity<?> applyMultiplicativeQuantityOperation(Quantity<?> quantity, BinaryOperator<Number> binaryOperator, BinaryOperator<Unit<?>> binaryOperator2) {
        return Quantities.getQuantity((Number) binaryOperator.apply(quantityValue(this), quantityValue(quantity)), (Unit) binaryOperator2.apply(getUnit(), quantity.getUnit()));
    }

    private static <R extends Quantity<R>> Number convertedQuantityValue(Quantity<R> quantity, Unit<R> unit) {
        return quantity.getUnit().getConverterTo(unit).convert(quantity.getValue());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$divide$0(Number number, Number number2) {
        return Calculator.m17692of(number).divide(number2).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$divide$1(Number number, Number number2) {
        return Calculator.m17692of(number).divide(number2).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$multiply$2(Number number, Number number2) {
        return Calculator.m17692of(number).multiply(number2).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$multiply$3(Number number, Number number2) {
        return Calculator.m17692of(number).multiply(number2).peek();
    }

    /* JADX INFO: renamed from: of */
    public static TemporalQuantity m17726of(Quantity<Time> quantity) {
        Objects.requireNonNull(quantity);
        return new TemporalQuantity(quantity.mo11214to(Units.SECOND).getValue(), ChronoUnit.SECONDS);
    }

    private static <R extends Quantity<R>> Number quantityValue(Quantity<R> quantity) {
        return convertedQuantityValue(quantity, quantity.getUnit());
    }

    private static Unit<Time> toUnit(TemporalUnit temporalUnit) {
        if (!f38.m7932x(temporalUnit)) {
            C1521v3.m18903j("TemporalQuantity only supports temporal units of type ChronoUnit");
            return null;
        }
        switch (C14551.$SwitchMap$java$time$temporal$ChronoUnit[f38.m7923o(temporalUnit).ordinal()]) {
            case 1:
                return TimeQuantities.MICROSECOND;
            case 2:
                return TimeQuantities.MILLISECOND;
            case 3:
                return TimeQuantities.NANOSECOND;
            case 4:
                return Units.SECOND;
            case 5:
                return Units.MINUTE;
            case 6:
                return Units.HOUR;
            case 7:
                return Units.DAY;
            default:
                C1521v3.m18903j("TemporalQuantity only supports DAYS, HOURS, MICROS, MILLIS, MINUTES, NANOS, SECONDS ");
                return null;
        }
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Time> add(Quantity<Time> quantity) {
        Unit unit = Calculus.currentNumberSystem().compare(Double.valueOf(getUnit().getConverterTo(quantity.getUnit()).convert(1.0d)), Double.valueOf(1.0d)) > 0 ? quantity.getUnit() : getUnit();
        return Quantities.getQuantity(Calculator.m17692of(convertedQuantityValue(this, unit)).add(convertedQuantityValue(quantity, unit)).peek(), unit);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<?> divide(Quantity<?> quantity) {
        return applyMultiplicativeQuantityOperation(quantity, new C0805m0(16), new C0805m0(11));
    }

    @Override // tech.units.indriya.AbstractQuantity
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (TemporalQuantity.class.isInstance(obj)) {
            TemporalQuantity temporalQuantity = (TemporalQuantity) TemporalQuantity.class.cast(obj);
            return Objects.equals(this.timeUnit, temporalQuantity.timeUnit) && Objects.equals(this.value, temporalQuantity.value);
        }
        if (!(obj instanceof Quantity)) {
            return super.equals(obj);
        }
        Quantity quantity = (Quantity) obj;
        return Objects.equals(getUnit(), quantity.getUnit()) && Calculus.currentNumberSystem().compare(this.value, quantity.getValue()) == 0;
    }

    public TemporalAmount getTemporalAmount() {
        synchronized (this.$lock1) {
            try {
                if (this.amount == null) {
                    long jLongValue = this.value.longValue();
                    if (Calculus.currentNumberSystem().compare(Calculator.m17692of(this.value).subtract(Long.valueOf(jLongValue)).abs().peek(), 1) > 0) {
                        throw new ArithmeticException("cannot round number " + (BuildConfig.VERSION_NAME + this.value) + " to long");
                    }
                    this.amount = Duration.of(jLongValue, this.timeUnit);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return this.amount;
    }

    public TemporalUnit getTemporalUnit() {
        return this.timeUnit;
    }

    @Override // tech.units.indriya.AbstractQuantity
    public int hashCode() {
        return Objects.hash(this.timeUnit, this.value);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Frequency> inverse() {
        return Quantities.getQuantity(Calculator.m17692of(this.value).reciprocal().peek(), toUnit(this.timeUnit).inverse()).asType(Frequency.class);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<?> multiply(Quantity<?> quantity) {
        return applyMultiplicativeQuantityOperation(quantity, new C0805m0(13), new C0805m0(14));
    }

    @Override // javax.measure.Quantity
    public Quantity<Time> negate() {
        return m17725of(Calculator.m17692of(this.value).negate().peek(), getTemporalUnit());
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Time> subtract(Quantity<Time> quantity) {
        return add(quantity.negate());
    }

    /* JADX INFO: renamed from: to */
    public TemporalQuantity m17727to(TemporalUnit temporalUnit) {
        return new TemporalQuantity(Long.valueOf(toQuantity().mo11214to(toUnit(temporalUnit)).getValue().longValue()), temporalUnit);
    }

    public Quantity<Time> toQuantity() {
        return Quantities.getQuantity(this.value, toUnit());
    }

    @Override // tech.units.indriya.AbstractQuantity
    public String toString() {
        return "Temporal unit:" + this.timeUnit + " value: " + this.value;
    }

    @Override // tech.units.indriya.AbstractQuantity, p000.w8b
    public Number getValue() {
        return this.value;
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public /* bridge */ /* synthetic */ Quantity subtract(Quantity quantity) {
        return subtract((Quantity<Time>) quantity);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public /* bridge */ /* synthetic */ Quantity divide(Quantity quantity) {
        return divide((Quantity<?>) quantity);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public /* bridge */ /* synthetic */ Quantity multiply(Quantity quantity) {
        return multiply((Quantity<?>) quantity);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Time> divide(Number number) {
        return applyMultiplicativeNumberOperation(number, new C0805m0(12));
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Time> multiply(Number number) {
        return applyMultiplicativeNumberOperation(number, new C0805m0(15));
    }

    /* JADX INFO: renamed from: of */
    public static TemporalQuantity m17725of(Number number, TemporalUnit temporalUnit) {
        Objects.requireNonNull(number);
        Objects.requireNonNull(temporalUnit);
        return new TemporalQuantity(number, f38.m7924p(temporalUnit));
    }

    public Unit<Time> toUnit() {
        return toUnit(this.timeUnit);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public /* bridge */ /* synthetic */ Quantity add(Quantity quantity) {
        return add((Quantity<Time>) quantity);
    }
}
