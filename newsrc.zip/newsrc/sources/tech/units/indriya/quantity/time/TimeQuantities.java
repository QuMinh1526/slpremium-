package tech.units.indriya.quantity.time;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalUnit;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import javax.measure.MetricPrefix;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.quantity.Time;
import p000.f38;
import p000.ita;
import tech.units.indriya.function.MultiplyConverter;
import tech.units.indriya.quantity.Quantities;
import tech.units.indriya.unit.TransformedUnit;
import tech.units.indriya.unit.Units;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class TimeQuantities {
    public static final Unit<Time> MICROSECOND;
    public static final TransformedUnit<Time> MILLISECOND;
    public static final TransformedUnit<Time> NANOSECOND;

    static {
        Unit<Time> unit = Units.SECOND;
        MICROSECOND = new TransformedUnit("μs", unit, unit, MultiplyConverter.ofPrefix(MetricPrefix.MICRO));
        MILLISECOND = new TransformedUnit<>("ms", unit, unit, MultiplyConverter.ofPrefix(MetricPrefix.MILLI));
        NANOSECOND = new TransformedUnit<>("ns", unit, unit, MultiplyConverter.ofPrefix(MetricPrefix.NANO));
    }

    private TimeQuantities() {
    }

    public static Quantity<Time> getQuantity(Temporal temporal, Temporal temporal2) {
        ChronoUnit unused = ChronoUnit.DAYS;
        return Quantities.getQuantity(Long.valueOf(ChronoUnit.DAYS.between(temporal, temporal2)), Units.DAY);
    }

    public static TemporalQuantity toTemporalSeconds(Quantity<Time> quantity) {
        Objects.requireNonNull(quantity);
        return TemporalQuantity.m17726of(quantity.mo11214to(Units.SECOND));
    }

    public static TimeUnitQuantity toTimeUnitSeconds(Quantity<Time> quantity) {
        Objects.requireNonNull(quantity);
        return new TimeUnitQuantity(TimeUnit.SECONDS, Long.valueOf(quantity.mo11214to(Units.SECOND).getValue().longValue()));
    }

    public static Quantity<Time> getQuantity(LocalTime localTime, LocalTime localTime2) {
        ChronoUnit unused = ChronoUnit.HOURS;
        return Quantities.getQuantity(Long.valueOf(ChronoUnit.HOURS.between(localTime, localTime2)), Units.HOUR);
    }

    public static Quantity<Time> getQuantity(Temporal temporal, Supplier<TemporalAdjuster> supplier) {
        return getQuantity(temporal, temporal.with(ita.m10901k(supplier.get())));
    }

    public static Quantity<Time> getQuantity(LocalTime localTime, Supplier<TemporalAdjuster> supplier) {
        return getQuantity(localTime, localTime.with(ita.m10901k(supplier.get())));
    }

    public static TimeUnitQuantity getQuantity(Long l, TimeUnit timeUnit) {
        Objects.requireNonNull(timeUnit);
        Objects.requireNonNull(l);
        return new TimeUnitQuantity(timeUnit, l);
    }

    public static TemporalQuantity getQuantity(Long l, TemporalUnit temporalUnit) {
        Objects.requireNonNull(l);
        Objects.requireNonNull(temporalUnit);
        return new TemporalQuantity(l, f38.m7924p(temporalUnit));
    }
}
