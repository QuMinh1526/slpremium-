package tech.units.indriya.quantity;

import java.util.Objects;
import javax.measure.Quantity;
import p000.ro6;
import tech.units.indriya.ComparableQuantity;
import tech.units.indriya.spi.Range;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class QuantityRange<Q extends Quantity<Q>> implements Range<Quantity<Q>> {
    private final Quantity<Q> max;
    private final Quantity<Q> min;
    private Quantity<Q> res;

    public QuantityRange(Quantity<Q> quantity, Quantity<Q> quantity2, Quantity<Q> quantity3) {
        this.min = quantity;
        this.max = quantity2;
        this.res = quantity3;
    }

    private boolean fulfillsMaximumConstraint(Quantity<Q> quantity) {
        return !hasMaximum() || isBelowMaximum(quantity);
    }

    private boolean fulfillsMinimumConstraint(Quantity<Q> quantity) {
        return !hasMinimum() || isAboveMinimum(quantity);
    }

    private boolean isAboveMinimum(Quantity<Q> quantity) {
        if (quantity instanceof ComparableQuantity) {
            return ((ComparableQuantity) quantity).isGreaterThanOrEqualTo(getMinimum());
        }
        return quantity.mo11214to(getMinimum().getUnit()).getValue().doubleValue() >= getMinimum().getValue().doubleValue();
    }

    private boolean isBelowMaximum(Quantity<Q> quantity) {
        if (quantity instanceof ComparableQuantity) {
            return ((ComparableQuantity) quantity).isLessThanOrEqualTo(getMaximum());
        }
        return quantity.mo11214to(getMaximum().getUnit()).getValue().doubleValue() <= getMaximum().getValue().doubleValue();
    }

    private static boolean isCompatibleQuantityPair(Quantity quantity, Quantity quantity2) {
        return quantity == null || quantity2 == null || quantity.getUnit().isCompatible(quantity2.getUnit());
    }

    private static boolean isCompatibleQuantityTriple(Quantity quantity, Quantity quantity2, Quantity quantity3) {
        return isCompatibleQuantityPair(quantity, quantity2) && isCompatibleQuantityPair(quantity, quantity3) && isCompatibleQuantityPair(quantity2, quantity3);
    }

    /* JADX INFO: renamed from: of */
    public static QuantityRange m17720of(Quantity quantity, Quantity quantity2, Quantity quantity3) {
        if (isCompatibleQuantityTriple(quantity, quantity2, quantity3)) {
            return new QuantityRange(quantity, quantity2, quantity3);
        }
        ro6.m16608s();
        return null;
    }

    @Override // tech.units.indriya.spi.Range
    public boolean contains(Quantity<Q> quantity) {
        Objects.requireNonNull(quantity);
        return quantity.getValue() != null && quantity.getUnit() != null && fulfillsMinimumConstraint(quantity) && fulfillsMaximumConstraint(quantity);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof QuantityRange) {
            QuantityRange quantityRange = (QuantityRange) obj;
            if (Objects.equals(getMinimum(), quantityRange.getMinimum()) && Objects.equals(getMaximum(), quantityRange.getMaximum()) && Objects.equals(getResolution(), quantityRange.getResolution())) {
                return true;
            }
        }
        return false;
    }

    @Override // tech.units.indriya.spi.Range
    public boolean hasMaximum() {
        return this.max != null;
    }

    @Override // tech.units.indriya.spi.Range
    public boolean hasMinimum() {
        return this.min != null;
    }

    public int hashCode() {
        return Objects.hash(getMinimum(), getMaximum(), getResolution());
    }

    public String toString() {
        return "QuantityRange[minimum=" + getMinimum() + ", maximum=" + getMaximum() + ", resolution=" + getResolution() + "]";
    }

    @Override // tech.units.indriya.spi.Range
    public Quantity<Q> getMaximum() {
        return this.max;
    }

    @Override // tech.units.indriya.spi.Range
    public Quantity<Q> getMinimum() {
        return this.min;
    }

    @Override // tech.units.indriya.spi.Range
    public Quantity<Q> getResolution() {
        return this.res;
    }

    public QuantityRange(Quantity<Q> quantity, Quantity<Q> quantity2) {
        this(quantity, quantity2, null);
    }

    /* JADX INFO: renamed from: of */
    public static QuantityRange m17719of(Quantity quantity, Quantity quantity2) {
        if (isCompatibleQuantityPair(quantity, quantity2)) {
            return new QuantityRange(quantity, quantity2);
        }
        ro6.m16608s();
        return null;
    }
}
