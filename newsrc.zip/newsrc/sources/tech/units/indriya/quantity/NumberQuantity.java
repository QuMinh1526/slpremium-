package tech.units.indriya.quantity;

import javax.measure.Quantity;
import javax.measure.Unit;
import org.apiguardian.api.API;
import p000.C0805m0;
import p000.ad7;
import tech.units.indriya.AbstractQuantity;
import tech.units.indriya.ComparableQuantity;
import tech.units.indriya.internal.function.Calculator;
import tech.units.indriya.internal.function.ScaleHelper;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.MAINTAINED)
public final class NumberQuantity<Q extends Quantity<Q>> extends AbstractQuantity<Q> {
    private static final long serialVersionUID = -6494337491031528402L;
    private final Number value;

    public NumberQuantity(Number number, Unit<Q> unit, Quantity.Scale scale) {
        super(unit, scale);
        this.value = Calculator.m17692of(number).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$add$0(Number number, Number number2) {
        return Calculator.m17692of(number).add(number2).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$divide$2(Number number, Number number2) {
        return Calculator.m17692of(number).divide(number2).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$divide$4(Number number, Number number2) {
        return Calculator.m17692of(number2).divide(number).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$multiply$5(Number number, Number number2) {
        return Calculator.m17692of(number).multiply(number2).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$multiply$7(Number number, Number number2) {
        return Calculator.m17692of(number2).multiply(number).peek();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$subtract$1(Number number, Number number2) {
        return Calculator.m17692of(number).subtract(number2).peek();
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Q> add(Quantity<Q> quantity) {
        return ScaleHelper.addition(this, quantity, new C0805m0(3));
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<?> divide(Quantity<?> quantity) {
        return ScaleHelper.multiplication(this, quantity, new C0805m0(4), new C0805m0(5));
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<?> inverse() {
        return Quantities.getQuantity(Calculator.m17692of(getValue()).reciprocal().peek(), getUnit().inverse(), getScale());
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<?> multiply(Quantity<?> quantity) {
        return ScaleHelper.multiplication(this, quantity, new C0805m0(1), new C0805m0(2));
    }

    @Override // javax.measure.Quantity
    public Quantity<Q> negate() {
        return Quantities.getQuantity(Calculator.m17692of(getValue()).negate().peek(), getUnit(), getScale());
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Q> subtract(Quantity<Q> quantity) {
        return ScaleHelper.addition(this, quantity, new C0805m0(6));
    }

    @Override // tech.units.indriya.AbstractQuantity, p000.w8b
    public Number getValue() {
        return this.value;
    }

    public NumberQuantity(Number number, Unit<Q> unit) {
        this(number, unit, Quantity.Scale.ABSOLUTE);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public /* bridge */ /* synthetic */ Quantity divide(Quantity quantity) {
        return divide((Quantity<?>) quantity);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public /* bridge */ /* synthetic */ Quantity multiply(Quantity quantity) {
        return multiply((Quantity<?>) quantity);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Q> divide(Number number) {
        return ScaleHelper.scalarMultiplication(this, new ad7(number, 1));
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public ComparableQuantity<Q> multiply(Number number) {
        return ScaleHelper.scalarMultiplication(this, new ad7(number, 0));
    }
}
