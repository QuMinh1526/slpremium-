package tech.units.indriya.quantity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.measure.Quantity;
import javax.measure.Unit;
import org.apiguardian.api.API;
import p000.C1521v3;
import p000.cm6;
import tech.units.indriya.format.SimpleQuantityFormat;
import tech.units.indriya.function.Calculus;
import tech.units.indriya.function.MixedRadix;
import tech.units.indriya.internal.function.Calculator;
import tech.units.indriya.spi.NumberSystem;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.MAINTAINED)
public final class MixedQuantity<Q extends Quantity<Q>> implements Serializable {
    private static final long serialVersionUID = 5863961588282485676L;
    private Quantity.Scale commonScale;
    private Unit<Q> leastSignificantUnit;
    private MixedRadix<Q> mixedRadixIfPossible;
    private final Object[] quantityArray;
    private final List<Quantity<Q>> quantityList;
    private final List<Unit<Q>> unitList;

    public MixedQuantity(List<Quantity<Q>> list) {
        ArrayList arrayList = new ArrayList();
        for (Quantity<Q> quantity : list) {
            Unit<Q> unit = quantity.getUnit();
            arrayList.add(unit);
            this.commonScale = quantity.getScale();
            if (this.leastSignificantUnit == null) {
                this.leastSignificantUnit = unit;
            } else {
                NumberSystem numberSystemCurrentNumberSystem = Calculus.currentNumberSystem();
                if (numberSystemCurrentNumberSystem.isLessThanOne(numberSystemCurrentNumberSystem.abs(Double.valueOf(this.leastSignificantUnit.getConverterTo(unit).convert(1.0d))))) {
                    this.leastSignificantUnit = unit;
                }
            }
        }
        this.quantityList = Collections.unmodifiableList(new ArrayList(list));
        this.quantityArray = list.toArray();
        this.unitList = Collections.unmodifiableList(arrayList);
        try {
            this.mixedRadixIfPossible = MixedRadix.m17674of(getUnits());
        } catch (Exception unused) {
            this.mixedRadixIfPossible = null;
        }
    }

    @SafeVarargs
    public static <Q extends Quantity<Q>> MixedQuantity<Q> fromArray(Quantity<Q>... quantityArr) {
        guardAgainstIllegalQuantitiesArgument((Quantity<?>[]) quantityArr);
        return new MixedQuantity<>(Arrays.asList(quantityArr));
    }

    private static <Q extends Quantity<Q>> void guardAgainstIllegalQuantitiesArgument(List<Quantity<Q>> list) {
        if (list == null || list.size() < 1) {
            C1521v3.m18903j("At least one quantity is required.");
            return;
        }
        Quantity.Scale scale = null;
        for (Quantity<Q> quantity : list) {
            if (quantity == null) {
                C1521v3.m18903j("Quantities must not contain null.");
                return;
            } else if (scale == null && (scale = quantity.getScale()) == null) {
                C1521v3.m18903j("Quantities must have a scale.");
                return;
            } else if (!scale.equals(quantity.getScale())) {
                C1521v3.m18903j("Quantities do not have the same scale.");
                return;
            }
        }
    }

    @SafeVarargs
    /* JADX INFO: renamed from: of */
    public static <Q extends Quantity<Q>> MixedQuantity<Q> m17709of(Quantity<Q>... quantityArr) {
        guardAgainstIllegalQuantitiesArgument((Quantity<?>[]) quantityArr);
        return new MixedQuantity<>(Arrays.asList(quantityArr));
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof MixedQuantity) {
            return Arrays.equals(this.quantityArray, ((MixedQuantity) obj).quantityArray);
        }
        return false;
    }

    public List<Quantity<Q>> getQuantities() {
        return this.quantityList;
    }

    public List<Unit<Q>> getUnits() {
        return this.unitList;
    }

    public int hashCode() {
        return Objects.hash(this.quantityArray);
    }

    /* JADX INFO: renamed from: to */
    public Quantity<Q> m17710to(Unit<Q> unit) {
        if (this.mixedRadixIfPossible != null) {
            return this.mixedRadixIfPossible.createQuantity((Number[]) ((List) getQuantities().stream().map(new cm6(23)).collect(Collectors.toList())).toArray(new Number[0])).mo11214to(unit);
        }
        Calculator calculatorM17692of = Calculator.m17692of(0);
        for (Quantity<Q> quantity : this.quantityList) {
            calculatorM17692of.add(quantity.getUnit().getConverterTo(this.leastSignificantUnit).convert(quantity.getValue()));
        }
        return Quantities.getQuantity(calculatorM17692of.peek(), this.leastSignificantUnit, this.commonScale).mo11214to((Unit) unit);
    }

    public String toString() {
        return SimpleQuantityFormat.getInstance().format(this);
    }

    /* JADX INFO: renamed from: of */
    public static <Q extends Quantity<Q>> MixedQuantity<Q> m17708of(List<Quantity<Q>> list) {
        guardAgainstIllegalQuantitiesArgument(list);
        return new MixedQuantity<>(list);
    }

    private static void guardAgainstIllegalQuantitiesArgument(Quantity<?>[] quantityArr) {
        if (quantityArr != null && quantityArr.length >= 1) {
            Quantity.Scale scale = null;
            for (Quantity<?> quantity : quantityArr) {
                if (quantity == null) {
                    C1521v3.m18903j("Quantities must not contain null.");
                    return;
                }
                if (scale == null && (scale = quantity.getScale()) == null) {
                    C1521v3.m18903j("Quantities must have a scale.");
                    return;
                } else {
                    if (!scale.equals(quantity.getScale())) {
                        C1521v3.m18903j("Quantities do not have the same scale.");
                        return;
                    }
                }
            }
            return;
        }
        C1521v3.m18903j("At least one quantity is required.");
    }
}
