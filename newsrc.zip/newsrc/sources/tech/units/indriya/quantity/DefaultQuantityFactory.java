package tech.units.indriya.quantity;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.quantity.Acceleration;
import javax.measure.quantity.AmountOfSubstance;
import javax.measure.quantity.Angle;
import javax.measure.quantity.Area;
import javax.measure.quantity.CatalyticActivity;
import javax.measure.quantity.Dimensionless;
import javax.measure.quantity.ElectricCapacitance;
import javax.measure.quantity.ElectricCharge;
import javax.measure.quantity.ElectricConductance;
import javax.measure.quantity.ElectricCurrent;
import javax.measure.quantity.ElectricInductance;
import javax.measure.quantity.ElectricPotential;
import javax.measure.quantity.ElectricResistance;
import javax.measure.quantity.Energy;
import javax.measure.quantity.Force;
import javax.measure.quantity.Frequency;
import javax.measure.quantity.Illuminance;
import javax.measure.quantity.Length;
import javax.measure.quantity.LuminousFlux;
import javax.measure.quantity.LuminousIntensity;
import javax.measure.quantity.MagneticFlux;
import javax.measure.quantity.MagneticFluxDensity;
import javax.measure.quantity.Mass;
import javax.measure.quantity.Power;
import javax.measure.quantity.Pressure;
import javax.measure.quantity.RadiationDoseAbsorbed;
import javax.measure.quantity.RadiationDoseEffective;
import javax.measure.quantity.Radioactivity;
import javax.measure.quantity.SolidAngle;
import javax.measure.quantity.Speed;
import javax.measure.quantity.Temperature;
import javax.measure.quantity.Time;
import javax.measure.quantity.Volume;
import javax.measure.spi.QuantityFactory;
import p000.C0844n0;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.unit.Units;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class DefaultQuantityFactory<Q extends Quantity<Q>> implements QuantityFactory<Q> {
    private static final Map<Class, Unit> CLASS_TO_SYSTEM_UNIT;
    static final Level DEFAULT_LOG_LEVEL;
    static final Map<Class, QuantityFactory> INSTANCES = new ConcurrentHashMap();
    static final Logger LOGGER;
    private final Unit<Q> systemUnit;
    private final Class<Q> type;

    static {
        Logger logger = Logger.getLogger(DefaultQuantityFactory.class.getName());
        LOGGER = logger;
        DEFAULT_LOG_LEVEL = Level.FINER;
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        CLASS_TO_SYSTEM_UNIT = concurrentHashMap;
        concurrentHashMap.put(Dimensionless.class, AbstractUnit.ONE);
        concurrentHashMap.put(ElectricCurrent.class, Units.AMPERE);
        concurrentHashMap.put(LuminousIntensity.class, Units.CANDELA);
        concurrentHashMap.put(Temperature.class, Units.KELVIN);
        concurrentHashMap.put(Mass.class, Units.KILOGRAM);
        concurrentHashMap.put(Length.class, Units.METRE);
        concurrentHashMap.put(AmountOfSubstance.class, Units.MOLE);
        concurrentHashMap.put(Time.class, Units.SECOND);
        concurrentHashMap.put(Angle.class, Units.RADIAN);
        concurrentHashMap.put(SolidAngle.class, Units.STERADIAN);
        concurrentHashMap.put(Frequency.class, Units.HERTZ);
        concurrentHashMap.put(Force.class, Units.NEWTON);
        concurrentHashMap.put(Pressure.class, Units.PASCAL);
        concurrentHashMap.put(Energy.class, Units.JOULE);
        concurrentHashMap.put(Power.class, Units.WATT);
        concurrentHashMap.put(ElectricCharge.class, Units.COULOMB);
        concurrentHashMap.put(ElectricPotential.class, Units.VOLT);
        concurrentHashMap.put(ElectricCapacitance.class, Units.FARAD);
        concurrentHashMap.put(ElectricResistance.class, Units.OHM);
        concurrentHashMap.put(ElectricConductance.class, Units.SIEMENS);
        concurrentHashMap.put(MagneticFlux.class, Units.WEBER);
        concurrentHashMap.put(MagneticFluxDensity.class, Units.TESLA);
        concurrentHashMap.put(ElectricInductance.class, Units.HENRY);
        concurrentHashMap.put(LuminousFlux.class, Units.LUMEN);
        concurrentHashMap.put(Illuminance.class, Units.LUX);
        concurrentHashMap.put(Radioactivity.class, Units.BECQUEREL);
        concurrentHashMap.put(RadiationDoseAbsorbed.class, Units.GRAY);
        concurrentHashMap.put(RadiationDoseEffective.class, Units.SIEVERT);
        concurrentHashMap.put(CatalyticActivity.class, Units.KATAL);
        concurrentHashMap.put(Speed.class, Units.METRE_PER_SECOND);
        concurrentHashMap.put(Acceleration.class, Units.METRE_PER_SQUARE_SECOND);
        concurrentHashMap.put(Area.class, Units.SQUARE_METRE);
        concurrentHashMap.put(Volume.class, Units.CUBIC_METRE);
        if (logger.isLoggable(Level.CONFIG)) {
            logger.config(String.format("Registered quantity types: %s", concurrentHashMap.keySet()));
        }
    }

    private DefaultQuantityFactory(Class<Q> cls) {
        this.type = cls;
        this.systemUnit = CLASS_TO_SYSTEM_UNIT.get(cls);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static <Q extends Quantity<Q>> QuantityFactory<Q> createNewFactoryInstance(Class<Q> cls) {
        if (Quantity.class.isAssignableFrom(cls)) {
            return new DefaultQuantityFactory(cls);
        }
        throw new ClassCastException(cls + " is not a Quantity type");
    }

    public static <Q extends Quantity<Q>> QuantityFactory<Q> getInstance(Class<Q> cls) {
        LOGGER.log(DEFAULT_LOG_LEVEL, "Type: " + cls + ": " + cls.isInterface());
        return INSTANCES.computeIfAbsent(cls, new C0844n0(3));
    }

    @Override // javax.measure.spi.QuantityFactory
    public Quantity<Q> create(Number number, Unit<Q> unit) {
        return Quantities.getQuantity(number, unit);
    }

    public boolean equals(Object obj) {
        if (!DefaultQuantityFactory.class.isInstance(obj)) {
            return false;
        }
        return Objects.equals(this.type, ((DefaultQuantityFactory) DefaultQuantityFactory.class.cast(obj)).type);
    }

    @Override // javax.measure.spi.QuantityFactory
    public Unit<Q> getSystemUnit() {
        return this.systemUnit;
    }

    public int hashCode() {
        return this.type.hashCode();
    }

    public String toString() {
        return getClass().getName() + " <" + this.type.getName() + '>';
    }

    @Override // javax.measure.spi.QuantityFactory
    public Quantity<Q> create(Number number, Unit<Q> unit, Quantity.Scale scale) {
        return Quantities.getQuantity(number, unit, scale);
    }
}
