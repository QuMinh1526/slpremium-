package tech.units.indriya.quantity;

import java.util.Objects;
import javax.measure.Quantity;
import javax.measure.Unit;
import tech.units.indriya.ComparableQuantity;
import tech.units.indriya.format.SimpleQuantityFormat;
import tech.units.indriya.function.MixedRadix;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class Quantities {
    private Quantities() {
    }

    public static <Q extends Quantity<Q>> MixedQuantity<Q> getMixedQuantity(Number[] numberArr, Unit<Q>[] unitArr, Quantity.Scale scale) {
        Objects.requireNonNull(numberArr);
        Objects.requireNonNull(unitArr);
        if (numberArr.length == unitArr.length) {
            return MixedRadix.m17676of(unitArr).createMixedQuantity(numberArr, scale);
        }
        throw new IllegalArgumentException(numberArr.length + " values don't match " + unitArr.length + " units");
    }

    public static <Q extends Quantity<Q>> Quantity<Q> getQuantity(Number[] numberArr, Unit<Q>[] unitArr, Quantity.Scale scale) {
        Objects.requireNonNull(numberArr);
        Objects.requireNonNull(unitArr);
        if (numberArr.length == unitArr.length) {
            return MixedRadix.m17676of(unitArr).createQuantity(numberArr, scale);
        }
        throw new IllegalArgumentException(numberArr.length + " values don't match " + unitArr.length + " units");
    }

    public static <Q extends Quantity<Q>> MixedQuantity<Q> getMixedQuantity(Number[] numberArr, Unit<Q>[] unitArr) {
        return getMixedQuantity(numberArr, unitArr, Quantity.Scale.ABSOLUTE);
    }

    public static <Q extends Quantity<Q>> ComparableQuantity<Q> getQuantity(Number number, Unit<Q> unit, Quantity.Scale scale) {
        Objects.requireNonNull(number);
        Objects.requireNonNull(unit);
        Objects.requireNonNull(scale);
        return new NumberQuantity(number, unit, scale);
    }

    public static <Q extends Quantity<Q>> ComparableQuantity<Q> getQuantity(Number number, Unit<Q> unit) {
        return getQuantity(number, unit, Quantity.Scale.ABSOLUTE);
    }

    public static Quantity<?> getQuantity(CharSequence charSequence) {
        return SimpleQuantityFormat.getInstance("n u~ ").parse(charSequence);
    }

    @SafeVarargs
    public static <Q extends Quantity<Q>> Quantity<Q> getQuantity(Number[] numberArr, Unit<Q>... unitArr) {
        return getQuantity(numberArr, unitArr, Quantity.Scale.ABSOLUTE);
    }
}
