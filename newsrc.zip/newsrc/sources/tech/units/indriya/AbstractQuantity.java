package tech.units.indriya;

import java.math.BigDecimal;
import java.util.Objects;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.quantity.Dimensionless;
import org.apiguardian.api.API;
import p000.w8b;
import tech.units.indriya.format.SimpleQuantityFormat;
import tech.units.indriya.function.Calculus;
import tech.units.indriya.internal.function.ScaleHelper;
import tech.units.indriya.quantity.Quantities;
import tech.units.indriya.spi.NumberSystem;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.STABLE)
public abstract class AbstractQuantity<Q extends Quantity<Q>> implements ComparableQuantity<Q>, w8b {
    public static final Quantity<Dimensionless> NONE;
    public static final Quantity<Dimensionless> ONE;
    private static final long serialVersionUID = 293852425369811882L;
    private final Quantity.Scale scale;
    private final Unit<Q> unit;

    static {
        Unit<Dimensionless> unit = AbstractUnit.ONE;
        NONE = Quantities.getQuantity((Number) 0, (Unit) unit);
        ONE = Quantities.getQuantity((Number) 1, (Unit) unit);
    }

    public AbstractQuantity(Unit<Q> unit, Quantity.Scale scale) {
        this.unit = unit;
        this.scale = scale;
    }

    private NumberSystem numberSystem() {
        return Calculus.currentNumberSystem();
    }

    public static Quantity<?> parse(CharSequence charSequence) {
        return SimpleQuantityFormat.getInstance().parse(charSequence);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    public final <T extends Quantity<T>> ComparableQuantity<T> asType(Class<T> cls) {
        getUnit().asType(cls);
        return this;
    }

    @Override // java.lang.Comparable
    public int compareTo(Quantity<Q> quantity) {
        return getUnit().equals(quantity.getUnit()) ? numberSystem().compare(getValue(), quantity.getValue()) : numberSystem().compare(getValue(), quantity.mo11214to(getUnit()).getValue());
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // tech.units.indriya.ComparableQuantity
    public <T extends Quantity<T>, E extends Quantity<E>> ComparableQuantity<E> divide(Quantity<T> quantity, Class<E> cls) {
        Objects.requireNonNull(quantity);
        ComparableQuantity<?> comparableQuantityDivide = divide((Quantity<?>) quantity);
        Objects.requireNonNull(cls);
        return comparableQuantityDivide.asType((Class) cls);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Quantity) {
            Quantity quantity = (Quantity) obj;
            if (Objects.equals(getUnit(), quantity.getUnit()) && Objects.equals(getScale(), quantity.getScale()) && Objects.equals(getValue(), quantity.getValue())) {
                return true;
            }
        }
        return false;
    }

    @Override // javax.measure.Quantity
    public Quantity.Scale getScale() {
        return this.scale;
    }

    @Override // javax.measure.Quantity
    public Unit<Q> getUnit() {
        return this.unit;
    }

    @Override // p000.w8b
    public abstract Number getValue();

    public boolean hasFraction(BigDecimal bigDecimal) {
        return bigDecimal.remainder(BigDecimal.ONE).compareTo(BigDecimal.ZERO) != 0;
    }

    public int hashCode() {
        return Objects.hash(getUnit(), getScale(), getValue());
    }

    @Override // tech.units.indriya.ComparableQuantity
    public <T extends Quantity<T>> ComparableQuantity<T> inverse(Class<T> cls) {
        return inverse().asType((Class) cls);
    }

    @Override // javax.measure.Quantity
    public boolean isEquivalentTo(Quantity<Q> quantity) {
        return compareTo((Quantity) quantity) == 0;
    }

    @Override // tech.units.indriya.ComparableQuantity
    public boolean isGreaterThan(Quantity<Q> quantity) {
        return compareTo((Quantity) quantity) > 0;
    }

    @Override // tech.units.indriya.ComparableQuantity
    public boolean isGreaterThanOrEqualTo(Quantity<Q> quantity) {
        return compareTo((Quantity) quantity) >= 0;
    }

    @Override // tech.units.indriya.ComparableQuantity
    public boolean isLessThan(Quantity<Q> quantity) {
        return compareTo((Quantity) quantity) < 0;
    }

    @Override // tech.units.indriya.ComparableQuantity
    public boolean isLessThanOrEqualTo(Quantity<Q> quantity) {
        return compareTo((Quantity) quantity) <= 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // tech.units.indriya.ComparableQuantity
    public <T extends Quantity<T>, E extends Quantity<E>> ComparableQuantity<E> multiply(Quantity<T> quantity, Class<E> cls) {
        Objects.requireNonNull(quantity);
        ComparableQuantity<?> comparableQuantityMultiply = multiply((Quantity<?>) quantity);
        Objects.requireNonNull(cls);
        return comparableQuantityMultiply.asType((Class) cls);
    }

    @Override // tech.units.indriya.ComparableQuantity, javax.measure.Quantity
    /* JADX INFO: renamed from: to */
    public ComparableQuantity<Q> mo11214to(Unit<Q> unit) {
        return unit.equals(getUnit()) ? this : ScaleHelper.convertTo(this, unit);
    }

    public String toString() {
        return SimpleQuantityFormat.getInstance().format((Quantity<?>) this);
    }

    public AbstractQuantity(Unit<Q> unit) {
        this(unit, Quantity.Scale.ABSOLUTE);
    }

    public boolean hasFraction(double d) {
        return ((double) Math.round(d)) != d;
    }
}
