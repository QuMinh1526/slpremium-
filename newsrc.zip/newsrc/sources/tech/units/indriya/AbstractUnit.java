package tech.units.indriya;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import javax.measure.Dimension;
import javax.measure.IncommensurableException;
import javax.measure.Prefix;
import javax.measure.Quantity;
import javax.measure.UnconvertibleException;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import javax.measure.quantity.Dimensionless;
import javax.measure.spi.SystemOfUnits;
import org.apiguardian.api.API;
import tech.units.indriya.format.SimpleUnitFormat;
import tech.units.indriya.function.AbstractConverter;
import tech.units.indriya.function.AddConverter;
import tech.units.indriya.function.Calculus;
import tech.units.indriya.function.MultiplyConverter;
import tech.units.indriya.function.RationalNumber;
import tech.units.indriya.internal.function.Calculator;
import tech.units.indriya.spi.DimensionalModel;
import tech.units.indriya.unit.AlternateUnit;
import tech.units.indriya.unit.AnnotatedUnit;
import tech.units.indriya.unit.ProductUnit;
import tech.units.indriya.unit.TransformedUnit;
import tech.units.indriya.unit.Units;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class AbstractUnit<Q extends Quantity<Q>> implements Unit<Q>, Comparable<Unit<Q>>, Serializable {
    public static final Unit<Dimensionless> ONE = new ProductUnit();
    protected static final transient Map<String, Unit<?>> SYMBOL_TO_UNIT = new HashMap();
    private static final long serialVersionUID = -4344589505537030204L;
    private String name;
    protected Quantity.Scale scale = Quantity.Scale.ABSOLUTE;
    private String symbol;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class Equalizer {
        public static boolean areEqual(Unit unit, Unit unit2) {
            return unit != null && unit.equals(unit2);
        }
    }

    public AbstractUnit(String str) {
        this.symbol = str;
    }

    private int compareToWithPossibleNullValues(String str, String str2) {
        if (str == null) {
            return str2 == null ? 0 : -1;
        }
        if (str2 == null) {
            return 1;
        }
        return str.compareTo(str2);
    }

    private final boolean internalIsCompatible(Unit<?> unit, boolean z) {
        if (z) {
            if (this == unit || equals(unit)) {
                return true;
            }
        } else if (this == unit) {
            return true;
        }
        if (unit == null) {
            return false;
        }
        Dimension dimension = getDimension();
        Dimension dimension2 = unit.getDimension();
        if (dimension.equals(dimension2)) {
            return true;
        }
        DimensionalModel dimensionalModelCurrent = DimensionalModel.current();
        return dimensionalModelCurrent.getFundamentalDimension(dimension).equals(dimensionalModelCurrent.getFundamentalDimension(dimension2));
    }

    public static Unit<?> parse(CharSequence charSequence) {
        return SimpleUnitFormat.getInstance().parse(charSequence);
    }

    @Override // javax.measure.Unit
    public final Unit<Q> alternate(String str) {
        return new AlternateUnit(this, str);
    }

    public final Unit<Q> annotate(String str) {
        return new AnnotatedUnit(this, str);
    }

    public final <T extends Quantity<T>> Unit<T> asType(Class<T> cls, SystemOfUnits systemOfUnits) {
        Unit<Q> unit = systemOfUnits.getUnit(cls);
        Dimension dimension = unit != null ? unit.getDimension() : null;
        if (dimension == null || dimension.equals(getDimension())) {
            return this;
        }
        throw new ClassCastException("The unit: " + this + " is not compatible with quantities of type " + cls);
    }

    @Override // java.lang.Comparable
    public int compareTo(Unit<Q> unit) {
        int iCompareToWithPossibleNullValues = compareToWithPossibleNullValues(getSymbol(), unit.getSymbol());
        return iCompareToWithPossibleNullValues == 0 ? compareToWithPossibleNullValues(this.name, unit.getName()) : iCompareToWithPossibleNullValues;
    }

    @Override // javax.measure.Unit
    public final Unit<Q> divide(Number number) {
        return Calculus.currentNumberSystem().isOne(number) ? this : transform(MultiplyConverter.m17678of(Calculator.m17692of(number).reciprocal().peek()));
    }

    public abstract boolean equals(Object obj);

    public Type getActualType() {
        return ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0].getClass().getGenericInterfaces()[0];
    }

    @Override // javax.measure.Unit
    public abstract Map<? extends Unit<?>, Integer> getBaseUnits();

    @API(status = API.Status.EXPERIMENTAL)
    public final UnitConverter getConverterTo(Unit<Q> unit, Quantity.Scale scale) {
        this.scale = scale;
        return getConverterTo(unit);
    }

    @API(status = API.Status.EXPERIMENTAL)
    public final UnitConverter getConverterToAny(Unit<?> unit, Quantity.Scale scale) throws IncommensurableException {
        if (isCompatible(unit)) {
            this.scale = scale;
            AbstractUnit abstractUnit = (AbstractUnit) unit;
            DimensionalModel dimensionalModelCurrent = DimensionalModel.current();
            return dimensionalModelCurrent.getDimensionalTransform(abstractUnit.getSystemUnit().getDimension()).concatenate(abstractUnit.getSystemConverter()).inverse().concatenate(dimensionalModelCurrent.getDimensionalTransform(getSystemUnit().getDimension()).concatenate(getSystemConverter()));
        }
        throw new IncommensurableException(this + " is not compatible with " + unit);
    }

    @Override // javax.measure.Unit
    public abstract Dimension getDimension();

    @Override // javax.measure.Unit
    public String getName() {
        return this.name;
    }

    @Override // javax.measure.Unit
    public String getSymbol() {
        return this.symbol;
    }

    public abstract UnitConverter getSystemConverter();

    @Override // javax.measure.Unit
    public final Unit<Q> getSystemUnit() {
        return toSystemUnit();
    }

    public abstract int hashCode();

    public final UnitConverter internalGetConverterTo(Unit<Q> unit, boolean z) {
        if (z) {
            if (this == unit || equals(unit)) {
                return AbstractConverter.IDENTITY;
            }
        } else if (this == unit) {
            return AbstractConverter.IDENTITY;
        }
        Unit<Q> systemUnit = getSystemUnit();
        Unit<Q> systemUnit2 = unit.getSystemUnit();
        if (systemUnit.equals(systemUnit2)) {
            return unit.getConverterTo(systemUnit2).inverse().concatenate(getSystemConverter());
        }
        try {
            return getConverterToAny(unit);
        } catch (IncommensurableException e) {
            throw new UnconvertibleException(e);
        }
    }

    @Override // javax.measure.Unit
    public final Unit<?> inverse() {
        Unit<Dimensionless> unit = ONE;
        return equals(unit) ? this : ProductUnit.ofQuotient(unit, this);
    }

    @Override // javax.measure.Unit
    public final boolean isCompatible(Unit<?> unit) {
        return internalIsCompatible(unit, true);
    }

    @Override // javax.measure.Unit
    public boolean isEquivalentTo(Unit<Q> unit) {
        return getConverterTo(unit).isIdentity();
    }

    public boolean isSystemUnit() {
        Unit<Q> systemUnit = toSystemUnit();
        return this == systemUnit || equals(systemUnit);
    }

    @Override // javax.measure.Unit
    public final Unit<?> multiply(Unit<?> unit) {
        Unit<Dimensionless> unit2 = ONE;
        if (equals(unit2)) {
            return unit;
        }
        return unit.equals(unit2) ? this : ProductUnit.ofProduct(this, unit);
    }

    @Override // javax.measure.Unit
    public Unit<?> pow(int i) {
        if (i > 0) {
            return multiply(pow(i - 1));
        }
        return i == 0 ? ONE : ONE.divide(pow(-i));
    }

    @Override // javax.measure.Unit
    public Unit<Q> prefix(Prefix prefix) {
        return transform(MultiplyConverter.ofPrefix(prefix));
    }

    @Override // javax.measure.Unit
    public final Unit<?> root(int i) {
        if (i > 0) {
            return ProductUnit.ofRoot(this, i);
        }
        if (i != 0) {
            return ONE.divide(root(-i));
        }
        throw new ArithmeticException("Root's order of zero");
    }

    public void setName(String str) {
        this.name = str;
    }

    public void setSymbol(String str) {
        this.symbol = str;
    }

    @Override // javax.measure.Unit
    public final Unit<Q> shift(Number number) {
        return Calculus.currentNumberSystem().isZero(number) ? this : transform(new AddConverter(number));
    }

    @Override // javax.measure.Unit
    public String toString() {
        return SimpleUnitFormat.getInstance().format(this);
    }

    public abstract Unit<Q> toSystemUnit();

    @Override // javax.measure.Unit
    public final Unit<Q> transform(UnitConverter unitConverter) {
        Unit<Q> systemUnit = getSystemUnit();
        if (isSystemUnit()) {
            unitConverter = getSystemConverter().concatenate(unitConverter);
        }
        return unitConverter.isIdentity() ? systemUnit : new TransformedUnit((String) null, this, systemUnit, unitConverter);
    }

    @Override // javax.measure.Unit
    public final UnitConverter getConverterTo(Unit<Q> unit) {
        return internalGetConverterTo(unit, true);
    }

    public AbstractUnit() {
    }

    @Override // javax.measure.Unit
    public Unit<Q> multiply(double d) {
        return multiply(RationalNumber.m17688of(d));
    }

    @Override // javax.measure.Unit
    public Unit<Q> shift(double d) {
        return shift(RationalNumber.m17688of(d));
    }

    @Override // javax.measure.Unit
    public final Unit<Q> multiply(Number number) {
        return Calculus.currentNumberSystem().isOne(number) ? this : transform(MultiplyConverter.m17678of(number));
    }

    @Override // javax.measure.Unit
    public Unit<Q> divide(double d) {
        return divide(RationalNumber.m17688of(d));
    }

    @Override // javax.measure.Unit
    public final Unit<?> divide(Unit<?> unit) {
        return multiply(unit.inverse());
    }

    @Override // javax.measure.Unit
    public final <T extends Quantity<T>> Unit<T> asType(Class<T> cls) {
        return asType(cls, Units.getInstance());
    }

    @Override // javax.measure.Unit
    public final UnitConverter getConverterToAny(Unit<?> unit) {
        return getConverterToAny(unit, Quantity.Scale.ABSOLUTE);
    }
}
