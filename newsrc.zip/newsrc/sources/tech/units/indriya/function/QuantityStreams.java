package tech.units.indriya.function;

import java.util.stream.Collector;
import javax.measure.MeasurementError;
import javax.measure.Quantity;
import javax.measure.Unit;
import p000.C0805m0;
import p000.gn8;
import p000.ug8;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class QuantityStreams {
    private QuantityStreams() {
        throw new MeasurementError("no instances");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ QuantitySummaryStatistics lambda$summarizeQuantity$0(Unit unit) {
        return new QuantitySummaryStatistics(unit);
    }

    public static <Q extends Quantity<Q>> Collector<Quantity<Q>, QuantitySummaryStatistics<Q>, QuantitySummaryStatistics<Q>> summarizeQuantity(Unit<Q> unit) {
        return Collector.of(new ug8(unit, 1), new gn8(0), new C0805m0(9), new Collector.Characteristics[0]);
    }
}
