package tech.units.indriya.function;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ServiceLoader;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;
import p000.C1521v3;
import p000.r81;
import p000.z82;
import tech.units.indriya.spi.NumberSystem;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class Calculus {
    public static final MathContext DEFAULT_MATH_CONTEXT;
    private static final String DEFAULT_NUMBER_SYSTEM = "tech.units.indriya.function.DefaultNumberSystem";
    public static MathContext MATH_CONTEXT;
    private static NumberSystem currentSystem;
    private static final Logger log = Logger.getLogger(Calculus.class.getName());
    private static final Map<Class<? extends AbstractConverter>, Integer> normalFormOrder;

    /* JADX INFO: renamed from: tech.units.indriya.function.Calculus$Pi */
    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class C1438Pi {
        private static final BigDecimal TWO = new BigDecimal("2");
        private static final BigDecimal THREE = new BigDecimal("3");
        private static final BigDecimal FOUR = new BigDecimal("4");
        private static final BigDecimal FIVE = new BigDecimal("5");
        private static final BigDecimal TWO_HUNDRED_THIRTY_NINE = new BigDecimal("239");
        private static final Map<Integer, BigDecimal> piCache = new ConcurrentHashMap();

        private C1438Pi() {
        }

        /* JADX WARN: Type inference failed for: r3v2, types: [tech.units.indriya.function.a] */
        private static BigDecimal arccot(final BigDecimal bigDecimal, int i) {
            BigDecimal bigDecimal2 = BigDecimal.ONE;
            RoundingMode roundingMode = RoundingMode.DOWN;
            BigDecimal bigDecimalDivide = bigDecimal2.setScale(i, roundingMode).divide(bigDecimal, roundingMode);
            BigDecimal bigDecimal3 = new BigDecimal(bigDecimalDivide.toString());
            final BigDecimal bigDecimalScaleByPowerOfTen = bigDecimal2.scaleByPowerOfTen(-i);
            Logger logger = Calculus.log;
            Level level = Level.FINER;
            logger.log(Level.FINER, (Supplier<String>) new Supplier() { // from class: tech.units.indriya.function.a
                @Override // java.util.function.Supplier
                public final Object get() {
                    return Calculus.C1438Pi.lambda$arccot$1(bigDecimal, bigDecimalScaleByPowerOfTen);
                }
            });
            BigDecimal bigDecimalAdd = THREE;
            BigDecimal bigDecimalDivide2 = null;
            boolean z = false;
            int i2 = 0;
            while (true) {
                if ((bigDecimalDivide2 != null && bigDecimalDivide2.equals(BigDecimal.ZERO)) || (bigDecimalDivide2 != null && bigDecimalDivide2.compareTo(bigDecimalScaleByPowerOfTen) < 0)) {
                    break;
                }
                BigDecimal bigDecimalPow = bigDecimal.pow(2);
                RoundingMode roundingMode2 = RoundingMode.DOWN;
                bigDecimal3 = bigDecimal3.divide(bigDecimalPow, roundingMode2);
                bigDecimalDivide2 = bigDecimal3.divide(bigDecimalAdd, roundingMode2);
                bigDecimalDivide = z ? bigDecimalDivide.add(bigDecimalDivide2) : bigDecimalDivide.subtract(bigDecimalDivide2);
                z = !z;
                Logger logger2 = Calculus.log;
                Level level2 = Level.FINEST;
                if (logger2.isLoggable(level2)) {
                    Calculus.log.log(level2, "arccot: term=" + bigDecimalDivide2);
                }
                i2++;
                bigDecimalAdd = bigDecimalAdd.add(TWO);
            }
            if (Calculus.log.isLoggable(Level.FINEST)) {
                Calculus.log.log(Level.FINER, "arccot: done. nTerms=" + i2);
            }
            return bigDecimalDivide;
        }

        private static BigDecimal calculatePi(int i) {
            int i2 = i + 10;
            BigDecimal bigDecimal = FOUR;
            return bigDecimal.multiply(bigDecimal.multiply(arccot(FIVE, i2)).subtract(arccot(TWO_HUNDRED_THIRTY_NINE, i2))).setScale(i, RoundingMode.DOWN);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ String lambda$arccot$1(BigDecimal bigDecimal, BigDecimal bigDecimal2) {
            return "arccot: ARGUMENT=" + bigDecimal + " (nearZero=" + bigDecimal2 + ")";
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ BigDecimal lambda$ofNumDigits$0(int i, Integer num) {
            return calculatePi(i);
        }

        public static BigDecimal ofNumDigits(final int i) {
            if (i > 0) {
                return piCache.computeIfAbsent(Integer.valueOf(i), new Function() { // from class: tech.units.indriya.function.b
                    @Override // java.util.function.Function
                    public final Object apply(Object obj) {
                        return Calculus.C1438Pi.lambda$ofNumDigits$0(i, (Integer) obj);
                    }
                });
            }
            C1521v3.m18903j("numDigits is required to be greater than zero");
            return null;
        }
    }

    static {
        MathContext mathContext = MathContext.DECIMAL128;
        DEFAULT_MATH_CONTEXT = mathContext;
        MATH_CONTEXT = mathContext;
        normalFormOrder = new HashMap(9);
    }

    public static NumberSystem currentNumberSystem() {
        if (currentSystem == null) {
            currentSystem = getNumberSystem(DEFAULT_NUMBER_SYSTEM);
        }
        return currentSystem;
    }

    public static List<NumberSystem> getAvailableNumberSystems() {
        ArrayList arrayList = new ArrayList();
        ServiceLoader.load(NumberSystem.class, NumberSystem.class.getClassLoader()).forEach(new r81(arrayList, 0));
        return arrayList;
    }

    public static Map<Class<? extends AbstractConverter>, Integer> getNormalFormOrder() {
        Map<Class<? extends AbstractConverter>, Integer> map = normalFormOrder;
        synchronized (map) {
            try {
                if (map.isEmpty()) {
                    map.put((Class<? extends AbstractConverter>) AbstractConverter.IDENTITY.getClass(), 0);
                    map.put(PowerOfIntConverter.class, 1);
                    map.put(RationalConverter.class, 2);
                    map.put(PowerOfPiConverter.class, 3);
                    map.put(DoubleMultiplyConverter.class, 4);
                    map.put(AddConverter.class, 5);
                    map.put(LogConverter.class, 6);
                    map.put(ExpConverter.class, 7);
                    map.put(AbstractConverter.Pair.class, 99);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return Collections.unmodifiableMap(map);
    }

    public static NumberSystem getNumberSystem(String str) {
        for (NumberSystem numberSystem : ServiceLoader.load(NumberSystem.class, NumberSystem.class.getClassLoader())) {
            if (str.equals(numberSystem.getClass().getName())) {
                return numberSystem;
            }
        }
        C1521v3.m18903j(z82.m21089v("NumberSystem ", str, " not found"));
        return null;
    }

    public static void setCurrentNumberSystem(NumberSystem numberSystem) {
        currentSystem = numberSystem;
    }
}
