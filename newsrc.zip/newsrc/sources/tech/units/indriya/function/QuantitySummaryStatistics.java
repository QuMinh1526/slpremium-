package tech.units.indriya.function;

import java.util.Objects;
import java.util.function.BinaryOperator;
import javax.measure.Quantity;
import javax.measure.Unit;
import p000.C0805m0;
import tech.units.indriya.ComparableQuantity;
import tech.units.indriya.quantity.Quantities;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class QuantitySummaryStatistics<Q extends Quantity<Q>> {
    private Quantity<Q> average;
    private long count;
    private final Quantity<Q> empty;
    private Quantity<Q> max;
    private Quantity<Q> min;
    private Quantity<Q> sum;
    private final BinaryOperator<Quantity<Q>> minFunctions = new C0805m0(8);
    private final BinaryOperator<Quantity<Q>> maxFunctions = new C0805m0(7);

    public QuantitySummaryStatistics(Unit<Q> unit) {
        ComparableQuantity quantity = Quantities.getQuantity((Number) 0, (Unit) unit);
        this.empty = quantity;
        setQuantity(quantity);
    }

    private void doSummary(Quantity<Q> quantity) {
        this.min = (Quantity) this.minFunctions.apply(this.min, quantity);
        this.max = (Quantity) this.maxFunctions.apply(this.max, quantity);
        Quantity<Q> quantityAdd = this.sum.add(quantity);
        this.sum = quantityAdd;
        long j = this.count + 1;
        this.count = j;
        this.average = quantityAdd.divide(Long.valueOf(j));
    }

    private boolean isEmpty() {
        return this.count == 0;
    }

    private void setQuantity(Quantity<Q> quantity) {
        this.min = quantity;
        this.max = quantity;
        this.sum = quantity;
        this.average = quantity;
    }

    public void accept(Quantity<Q> quantity) {
        Objects.requireNonNull(quantity);
        boolean zIsEmpty = isEmpty();
        Quantity<Q> quantity2 = this.empty;
        if (!zIsEmpty) {
            doSummary(quantity.mo11214to(quantity2.getUnit()));
        } else {
            setQuantity(quantity.mo11214to(quantity2.getUnit()));
            this.count++;
        }
    }

    public QuantitySummaryStatistics<Q> combine(QuantitySummaryStatistics<Q> quantitySummaryStatistics) {
        Objects.requireNonNull(quantitySummaryStatistics);
        if (!equals(quantitySummaryStatistics)) {
            return this;
        }
        this.min = (Quantity) this.minFunctions.apply(this.min, quantitySummaryStatistics.min.mo11214to(this.empty.getUnit()));
        this.max = (Quantity) this.maxFunctions.apply(this.max, quantitySummaryStatistics.max.mo11214to(this.empty.getUnit()));
        Quantity<Q> quantityAdd = this.sum.add(quantitySummaryStatistics.sum);
        this.sum = quantityAdd;
        long j = this.count + quantitySummaryStatistics.count;
        this.count = j;
        this.average = quantityAdd.divide(Long.valueOf(j));
        return this;
    }

    public boolean equals(Object obj) {
        if (!QuantitySummaryStatistics.class.isInstance(obj)) {
            return false;
        }
        return Objects.equals(this.empty.getUnit(), ((QuantitySummaryStatistics) QuantitySummaryStatistics.class.cast(obj)).empty.getUnit());
    }

    public Quantity<Q> getAverage(Unit<Q> unit) {
        return this.average.mo11214to(unit);
    }

    public long getCount() {
        return this.count;
    }

    public Quantity<Q> getMax(Unit<Q> unit) {
        return this.max.mo11214to(unit);
    }

    public Quantity<Q> getMin(Unit<Q> unit) {
        return this.min.mo11214to(unit);
    }

    public Quantity<Q> getSum(Unit<Q> unit) {
        return this.sum.mo11214to(unit);
    }

    public int hashCode() {
        return this.empty.getUnit().hashCode();
    }

    /* JADX INFO: renamed from: to */
    public QuantitySummaryStatistics<Q> m17684to(Unit<Q> unit) {
        QuantitySummaryStatistics<Q> quantitySummaryStatistics = new QuantitySummaryStatistics<>(unit);
        quantitySummaryStatistics.average = this.average.mo11214to(unit);
        quantitySummaryStatistics.count = this.count;
        quantitySummaryStatistics.max = this.max.mo11214to(unit);
        quantitySummaryStatistics.min = this.min.mo11214to(unit);
        quantitySummaryStatistics.sum = this.sum.mo11214to(unit);
        return quantitySummaryStatistics;
    }

    public String toString() {
        return "[unit: " + this.empty.getUnit() + ",count:" + this.count + ",min:" + this.min + ",max:" + this.max + ",sum:" + this.sum + ",average:" + this.average + "]";
    }

    public Quantity<Q> getAverage() {
        return this.average;
    }

    public Quantity<Q> getMax() {
        return this.max;
    }

    public Quantity<Q> getMin() {
        return this.min;
    }

    public Quantity<Q> getSum() {
        return this.sum;
    }
}
