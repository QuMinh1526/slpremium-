package tech.units.indriya.function;

import java.math.BigInteger;
import java.util.Objects;
import javax.measure.UnitConverter;
import tech.units.indriya.internal.function.Calculator;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class RationalConverter extends AbstractConverter implements MultiplyConverter {
    private static final long serialVersionUID = -9192231963353351648L;
    private final RationalNumber factor;

    public RationalConverter(BigInteger bigInteger, BigInteger bigInteger2) {
        this.factor = RationalNumber.m17691of(bigInteger, bigInteger2);
    }

    private AbstractConverter composeSameType(RationalConverter rationalConverter) {
        BigInteger bigIntegerMultiply = getDividend().multiply(rationalConverter.getDividend());
        BigInteger bigIntegerMultiply2 = getDivisor().multiply(rationalConverter.getDivisor());
        BigInteger bigIntegerGcd = bigIntegerMultiply.gcd(bigIntegerMultiply2);
        BigInteger bigIntegerDivide = bigIntegerMultiply.divide(bigIntegerGcd);
        BigInteger bigIntegerDivide2 = bigIntegerMultiply2.divide(bigIntegerGcd);
        BigInteger bigInteger = BigInteger.ONE;
        return (bigIntegerDivide.equals(bigInteger) && bigIntegerDivide2.equals(bigInteger)) ? AbstractConverter.IDENTITY : new RationalConverter(bigIntegerDivide, bigIntegerDivide2);
    }

    /* JADX INFO: renamed from: of */
    public static RationalConverter m17687of(RationalNumber rationalNumber) {
        return new RationalConverter(rationalNumber);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean canReduceWith(AbstractConverter abstractConverter) {
        if (abstractConverter instanceof RationalConverter) {
            return true;
        }
        return abstractConverter instanceof PowerOfIntConverter;
    }

    @Override // java.lang.Comparable
    public int compareTo(UnitConverter unitConverter) {
        if (this == unitConverter) {
            return 0;
        }
        return unitConverter instanceof RationalConverter ? this.factor.compareTo(((RationalConverter) unitConverter).factor) : RationalConverter.class.getName().compareTo(unitConverter.getClass().getName());
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public Number convertWhenNotIdentity(Number number) {
        return Calculator.m17692of(this.factor).multiply(number).peek();
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof RationalConverter) {
            return Objects.equals(this.factor, ((RationalConverter) obj).factor);
        }
        return false;
    }

    @Override // java.util.function.DoubleSupplier
    public double getAsDouble() {
        return this.factor.doubleValue();
    }

    public BigInteger getDividend() {
        return this.factor.getDividend();
    }

    public BigInteger getDivisor() {
        return this.factor.getDivisor();
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public int hashCode() {
        return this.factor.hashCode();
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public RationalConverter inverseWhenNotIdentity() {
        return m17687of(this.factor.reciprocal());
    }

    @Override // javax.measure.UnitConverter
    public boolean isIdentity() {
        return this.factor.compareTo(RationalNumber.ONE) == 0;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public AbstractConverter reduce(AbstractConverter abstractConverter) {
        if (abstractConverter instanceof RationalConverter) {
            return composeSameType((RationalConverter) abstractConverter);
        }
        if (abstractConverter instanceof PowerOfIntConverter) {
            return composeSameType(((PowerOfIntConverter) abstractConverter).toRationalConverter());
        }
        throw new IllegalStateException(String.format("%s.simpleCompose() not handled for converter %s", this, abstractConverter));
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public final String transformationLiteral() {
        return "x -> x * " + this.factor;
    }

    @Override // tech.units.indriya.function.MultiplyConverter, p000.w8b
    public Number getValue() {
        return this.factor;
    }

    /* JADX INFO: renamed from: of */
    public static RationalConverter m17686of(BigInteger bigInteger, BigInteger bigInteger2) {
        return new RationalConverter(bigInteger, bigInteger2);
    }

    /* JADX INFO: renamed from: of */
    public static RationalConverter m17685of(long j, long j2) {
        return new RationalConverter(j, j2);
    }

    public RationalConverter(RationalNumber rationalNumber) {
        Objects.requireNonNull(rationalNumber);
        this.factor = rationalNumber;
    }

    public RationalConverter(long j, long j2) {
        this.factor = RationalNumber.m17689of(j, j2);
    }
}
