package tech.units.indriya.function;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.measure.UnitConverter;
import p000.C0768l0;
import p000.C0805m0;
import p000.C0844n0;
import p000.C1521v3;
import p000.bna;
import p000.cla;
import tech.units.indriya.internal.function.Calculator;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class AbstractConverter implements UnitConverter, Serializable, Comparable<UnitConverter> {
    public static final AbstractConverter IDENTITY = new Identity();
    public static ConverterCompositionHandler UNIT_COMPOSITION_HANDLER = ConverterCompositionHandler.yieldingNormalForm();
    private static final long serialVersionUID = 5790242858468427131L;
    protected List<? extends UnitConverter> conversionSteps;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class Identity extends AbstractConverter {
        private static final Optional<Number> ONE = Optional.of(1);
        private static final long serialVersionUID = -4460463244427587361L;

        private Identity() {
        }

        private IllegalStateException unreachable() {
            return new IllegalStateException("code was reached, that is expected unreachable");
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public boolean canReduceWith(AbstractConverter abstractConverter) {
            throw unreachable();
        }

        @Override // java.lang.Comparable
        public int compareTo(UnitConverter unitConverter) {
            return unitConverter instanceof Identity ? 0 : -1;
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public /* bridge */ /* synthetic */ Object convert(Object obj) {
            return convert((Number) obj);
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public Number convertWhenNotIdentity(Number number) {
            throw unreachable();
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public boolean equals(Object obj) {
            return obj instanceof Identity;
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public int hashCode() {
            return 0;
        }

        @Override // tech.units.indriya.function.AbstractConverter, javax.measure.UnitConverter
        public /* bridge */ /* synthetic */ UnitConverter inverse() {
            return inverse();
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public AbstractConverter inverseWhenNotIdentity() {
            throw unreachable();
        }

        @Override // javax.measure.UnitConverter
        public boolean isIdentity() {
            return true;
        }

        @Override // javax.measure.UnitConverter
        public boolean isLinear() {
            return true;
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public Optional<Number> linearFactor() {
            return ONE;
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public AbstractConverter reduce(AbstractConverter abstractConverter) {
            throw unreachable();
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public String transformationLiteral() {
            return null;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class Pair extends AbstractConverter implements Serializable {

        /* JADX INFO: renamed from: e */
        public static final /* synthetic */ int f40115e = 0;
        private static final long serialVersionUID = -123063827821728331L;
        private static final Comparator unitComparator = new cla(5);
        private final UnitConverter left;
        private final UnitConverter right;

        public Pair(UnitConverter unitConverter, UnitConverter unitConverter2) {
            if (unitConverter == null || unitConverter2 == null) {
                C1521v3.m18903j("Converters cannot be null");
                throw null;
            }
            this.left = unitConverter;
            this.right = unitConverter2;
        }

        private IllegalArgumentException requiresAbstractConverter() {
            return new IllegalArgumentException("can only handle instances of AbstractConverter");
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public boolean canReduceWith(AbstractConverter abstractConverter) {
            return false;
        }

        @Override // java.lang.Comparable
        public int compareTo(UnitConverter unitConverter) {
            if (this == unitConverter) {
                return 0;
            }
            if (!(unitConverter instanceof Pair)) {
                return -1;
            }
            Pair pair = (Pair) unitConverter;
            UnitConverter unitConverter2 = this.left;
            UnitConverter unitConverter3 = pair.left;
            Comparator comparator = unitComparator;
            return Objects.compare(this.right, pair.right, comparator) + Objects.compare(unitConverter2, unitConverter3, comparator);
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public /* bridge */ /* synthetic */ Object convert(Object obj) {
            return convert((Number) obj);
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public Number convertWhenNotIdentity(Number number) {
            UnitConverter unitConverter = this.left;
            if (!(unitConverter instanceof AbstractConverter)) {
                throw requiresAbstractConverter();
            }
            UnitConverter unitConverter2 = this.right;
            if (unitConverter2 instanceof AbstractConverter) {
                return ((AbstractConverter) unitConverter).convertWhenNotIdentity(((AbstractConverter) unitConverter2).convertWhenNotIdentity(number));
            }
            throw requiresAbstractConverter();
        }

        public List<? extends UnitConverter> createConversionSteps() {
            List<? extends UnitConverter> conversionSteps = this.left.getConversionSteps();
            List<? extends UnitConverter> conversionSteps2 = this.right.getConversionSteps();
            ArrayList arrayList = new ArrayList(conversionSteps2.size() + conversionSteps.size());
            arrayList.addAll(conversionSteps);
            arrayList.addAll(conversionSteps2);
            return arrayList;
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj instanceof Pair) {
                Pair pair = (Pair) obj;
                if (Objects.equals(this.left, pair.left) && Objects.equals(this.right, pair.right)) {
                    return true;
                }
            }
            return false;
        }

        public UnitConverter getLeft() {
            return this.left;
        }

        public UnitConverter getRight() {
            return this.right;
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public int hashCode() {
            return Objects.hash(this.left, this.right);
        }

        @Override // tech.units.indriya.function.AbstractConverter, javax.measure.UnitConverter
        public /* bridge */ /* synthetic */ UnitConverter inverse() {
            return inverse();
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public Pair inverseWhenNotIdentity() {
            return new Pair(this.right.inverse(), this.left.inverse());
        }

        @Override // javax.measure.UnitConverter
        public boolean isIdentity() {
            return false;
        }

        @Override // javax.measure.UnitConverter
        public boolean isLinear() {
            return this.left.isLinear() && this.right.isLinear();
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public Optional<Number> linearFactor() {
            UnitConverter unitConverter = this.left;
            if (!(unitConverter instanceof AbstractConverter)) {
                throw requiresAbstractConverter();
            }
            if (!(this.right instanceof AbstractConverter)) {
                throw requiresAbstractConverter();
            }
            Optional<Number> optionalLinearFactor = ((AbstractConverter) unitConverter).linearFactor();
            return (optionalLinearFactor.isPresent() && optionalLinearFactor.isPresent()) ? Optional.of(Calculator.m17692of(optionalLinearFactor.get()).multiply(((AbstractConverter) this.right).linearFactor().get()).peek()) : Optional.empty();
        }

        @Override // tech.units.indriya.function.AbstractConverter
        public String transformationLiteral() {
            return String.format("%s", getConversionSteps().stream().map(new C0844n0(0)).collect(Collectors.joining(" ○ ")));
        }
    }

    public abstract boolean canReduceWith(AbstractConverter abstractConverter);

    @Override // javax.measure.UnitConverter
    public final UnitConverter concatenate(UnitConverter unitConverter) {
        Objects.requireNonNull(unitConverter, "Cannot compose with converter that is null.");
        if (unitConverter instanceof AbstractConverter) {
            return UNIT_COMPOSITION_HANDLER.compose(this, (AbstractConverter) unitConverter, new C0768l0(), new C0805m0(0));
        }
        if (unitConverter.isIdentity()) {
            return this;
        }
        return isIdentity() ? unitConverter : new Pair(this, unitConverter);
    }

    @Override // 
    public final Number convert(Number number) {
        if (isIdentity()) {
            return number;
        }
        if (number != null) {
            return convertWhenNotIdentity(number);
        }
        C1521v3.m18903j("Value cannot be null");
        return null;
    }

    public abstract Number convertWhenNotIdentity(Number number);

    public abstract boolean equals(Object obj);

    @Override // javax.measure.UnitConverter
    public final List<? extends UnitConverter> getConversionSteps() {
        List<? extends UnitConverter> list = this.conversionSteps;
        if (list != null) {
            return list;
        }
        if (this instanceof Pair) {
            List<? extends UnitConverter> listCreateConversionSteps = ((Pair) this).createConversionSteps();
            this.conversionSteps = listCreateConversionSteps;
            return listCreateConversionSteps;
        }
        List<? extends UnitConverter> listSingletonList = Collections.singletonList(this);
        this.conversionSteps = listSingletonList;
        return listSingletonList;
    }

    public abstract int hashCode();

    @Override // javax.measure.UnitConverter
    public final AbstractConverter inverse() {
        return isIdentity() ? this : inverseWhenNotIdentity();
    }

    public abstract AbstractConverter inverseWhenNotIdentity();

    /* JADX WARN: Multi-variable type inference failed */
    public Optional<Number> linearFactor() {
        if (this instanceof AddConverter) {
            return Identity.ONE;
        }
        return this instanceof MultiplyConverter ? Optional.of(((MultiplyConverter) this).m21792getFactor()) : Optional.empty();
    }

    public AbstractConverter reduce(AbstractConverter abstractConverter) {
        throw new IllegalStateException(String.format("Concrete UnitConverter '%s' does not implement reduce(...).", this));
    }

    public final String toString() {
        String simpleName = getClass().getSimpleName();
        if (simpleName.endsWith("Converter")) {
            simpleName = simpleName.substring(0, simpleName.length() - 9);
        }
        if (isIdentity()) {
            return simpleName.concat("(IDENTITY)");
        }
        String strTransformationLiteral = transformationLiteral();
        return (strTransformationLiteral == null || strTransformationLiteral.length() == 0) ? simpleName : bna.m2615l(simpleName, "(", strTransformationLiteral, ")");
    }

    public abstract String transformationLiteral();

    @Override // javax.measure.UnitConverter
    public final double convert(double d) {
        return isIdentity() ? d : convertWhenNotIdentity(Double.valueOf(d)).doubleValue();
    }
}
