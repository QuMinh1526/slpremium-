package tech.units.indriya.function;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.function.DoubleSupplier;
import javax.measure.Prefix;
import javax.measure.UnitConverter;
import p000.vf3;
import p000.w8b;
import tech.units.indriya.spi.NumberSystem;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public interface MultiplyConverter extends UnitConverter, w8b, DoubleSupplier, Comparable<UnitConverter> {
    static MultiplyConverter identity() {
        return IdentityMultiplyConverter.INSTANCE;
    }

    /* JADX INFO: renamed from: of */
    static MultiplyConverter m17678of(Number number) {
        NumberSystem numberSystemCurrentNumberSystem = Calculus.currentNumberSystem();
        if (numberSystemCurrentNumberSystem.isOne(number)) {
            return identity();
        }
        Number numberNarrow = numberSystemCurrentNumberSystem.narrow(number);
        if (numberNarrow instanceof RationalNumber) {
            return ofRational((RationalNumber) numberNarrow);
        }
        if (numberSystemCurrentNumberSystem.isInteger(numberNarrow)) {
            if (numberNarrow instanceof BigInteger) {
                return ofRational(RationalNumber.ofInteger((BigInteger) numberNarrow));
            }
            if (numberSystemCurrentNumberSystem instanceof DefaultNumberSystem) {
                return ofRational(RationalNumber.ofInteger(numberNarrow.longValue()));
            }
            vf3.m19097o("not yet supported");
            return null;
        }
        if ((numberNarrow instanceof Double) || (numberNarrow instanceof Float)) {
            return m17677of(numberNarrow.doubleValue());
        }
        if (numberNarrow instanceof BigDecimal) {
            return ofRational(RationalNumber.m17690of((BigDecimal) numberNarrow));
        }
        vf3.m19097o("not yet supported");
        return null;
    }

    static MultiplyConverter ofExponent(int i, int i2) {
        return i2 == 0 ? identity() : PowerOfIntConverter.m17679of(i, i2);
    }

    static MultiplyConverter ofPiExponent(int i) {
        return i == 0 ? identity() : PowerOfPiConverter.m17682of(i);
    }

    static MultiplyConverter ofPrefix(Prefix prefix) {
        if (prefix == null) {
            return identity();
        }
        if (prefix.getExponent() == 1) {
            return m17678of(prefix.getValue());
        }
        NumberSystem numberSystemCurrentNumberSystem = Calculus.currentNumberSystem();
        return !numberSystemCurrentNumberSystem.isInteger(prefix.getValue()) ? m17678of(numberSystemCurrentNumberSystem.power(prefix.getValue(), prefix.getExponent())) : PowerOfIntConverter.m17681of(prefix);
    }

    static MultiplyConverter ofRational(RationalNumber rationalNumber) {
        return rationalNumber.equals(RationalNumber.ONE) ? identity() : RationalConverter.m17687of(rationalNumber);
    }

    static MultiplyConverter ofTenExponent(int i) {
        return i == 0 ? identity() : PowerOfIntConverter.m17679of(10, i);
    }

    /* synthetic */ Object convert(Object obj);

    /* JADX INFO: renamed from: getFactor, reason: merged with bridge method [inline-methods] */
    default Number m21792getFactor() {
        return (Number) getValue();
    }

    @Override // p000.w8b
    /* synthetic */ Object getValue();

    @Override // javax.measure.UnitConverter
    default boolean isLinear() {
        return true;
    }

    static MultiplyConverter ofRational(long j, long j2) {
        return ofRational(RationalNumber.m17689of(j, j2));
    }

    static MultiplyConverter ofRational(BigInteger bigInteger, BigInteger bigInteger2) {
        return ofRational(RationalNumber.m17691of(bigInteger, bigInteger2));
    }

    /* JADX INFO: renamed from: of */
    static MultiplyConverter m17677of(double d) {
        if (d == 1.0d) {
            return identity();
        }
        return ofRational(RationalNumber.m17688of(d));
    }
}
