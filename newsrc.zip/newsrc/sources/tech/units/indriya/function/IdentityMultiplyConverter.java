package tech.units.indriya.function;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import javax.measure.UnitConverter;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
final class IdentityMultiplyConverter implements MultiplyConverter, Serializable {
    static final IdentityMultiplyConverter INSTANCE = new IdentityMultiplyConverter();
    private static final long serialVersionUID = 1;

    private IdentityMultiplyConverter() {
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof IdentityMultiplyConverter) {
            return isIdentity() && ((IdentityMultiplyConverter) obj).isIdentity();
        }
        return false;
    }

    @Override // java.util.function.DoubleSupplier
    public double getAsDouble() {
        return 1.0d;
    }

    @Override // javax.measure.UnitConverter
    public List<? extends UnitConverter> getConversionSteps() {
        return Collections.EMPTY_LIST;
    }

    @Override // tech.units.indriya.function.MultiplyConverter, p000.w8b
    public Number getValue() {
        return 1;
    }

    public int hashCode() {
        return Objects.hashCode(getValue());
    }

    @Override // javax.measure.UnitConverter
    public boolean isIdentity() {
        return true;
    }

    @Override // java.lang.Comparable
    public int compareTo(UnitConverter unitConverter) {
        return AbstractConverter.IDENTITY.compareTo(unitConverter);
    }

    @Override // tech.units.indriya.function.MultiplyConverter
    public Number convert(Number number) {
        return number;
    }

    @Override // javax.measure.UnitConverter
    public double convert(double d) {
        return d;
    }

    @Override // javax.measure.UnitConverter
    public UnitConverter inverse() {
        return this;
    }

    @Override // javax.measure.UnitConverter
    public UnitConverter concatenate(UnitConverter unitConverter) {
        return unitConverter;
    }
}
