package tech.units.indriya.function;

import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import tech.units.indriya.internal.function.simplify.UnitCompositionHandlerYieldingNormalForm;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public interface ConverterCompositionHandler {
    static ConverterCompositionHandler yieldingNormalForm() {
        return new UnitCompositionHandlerYieldingNormalForm();
    }

    AbstractConverter compose(AbstractConverter abstractConverter, AbstractConverter abstractConverter2, BiPredicate<AbstractConverter, AbstractConverter> biPredicate, BinaryOperator<AbstractConverter> binaryOperator);
}
