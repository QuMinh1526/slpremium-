package tech.units.indriya.function;

import java.util.Objects;
import javax.measure.UnitConverter;
import p000.z82;
import tech.units.indriya.internal.function.Calculator;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
final class PowerOfPiConverter extends AbstractConverter implements MultiplyConverter {
    public static final PowerOfPiConverter ONE = m17682of(1);
    private static final long serialVersionUID = 5000593326722785126L;
    private final Object $lock1 = new Object[0];
    private final int exponent;
    private final int hashCode;
    private transient Number scaleFactor;

    public PowerOfPiConverter(int i) {
        this.exponent = i;
        this.hashCode = Objects.hash(Integer.valueOf(i));
    }

    /* JADX INFO: renamed from: of */
    public static PowerOfPiConverter m17682of(int i) {
        return new PowerOfPiConverter(i);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean canReduceWith(AbstractConverter abstractConverter) {
        return abstractConverter instanceof PowerOfPiConverter;
    }

    @Override // java.lang.Comparable
    public int compareTo(UnitConverter unitConverter) {
        if (this == unitConverter) {
            return 0;
        }
        if (isIdentity() && unitConverter.isIdentity()) {
            return 0;
        }
        return unitConverter instanceof PowerOfPiConverter ? Integer.compare(this.exponent, ((PowerOfPiConverter) unitConverter).exponent) : PowerOfPiConverter.class.getName().compareTo(unitConverter.getClass().getName());
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public Number convertWhenNotIdentity(Number number) {
        return Calculator.m17692of(m21792getFactor()).multiply(number).peek();
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof UnitConverter) {
            UnitConverter unitConverter = (UnitConverter) obj;
            if (isIdentity() && unitConverter.isIdentity()) {
                return true;
            }
        }
        return (obj instanceof PowerOfPiConverter) && this.exponent == ((PowerOfPiConverter) obj).exponent;
    }

    @Override // java.util.function.DoubleSupplier
    public double getAsDouble() {
        return getValue().doubleValue();
    }

    public int getExponent() {
        return this.exponent;
    }

    @Override // tech.units.indriya.function.MultiplyConverter, p000.w8b
    public Number getValue() {
        synchronized (this.$lock1) {
            try {
                if (this.scaleFactor == null) {
                    int precision = Calculus.MATH_CONTEXT.getPrecision();
                    if (precision == 0) {
                        throw new ArithmeticException("Pi multiplication with unlimited precision");
                    }
                    this.scaleFactor = Calculator.m17692of(Calculus.C1438Pi.ofNumDigits(precision)).power(this.exponent).peek();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return this.scaleFactor;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public int hashCode() {
        return this.hashCode;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public AbstractConverter inverseWhenNotIdentity() {
        return new PowerOfPiConverter(-this.exponent);
    }

    @Override // javax.measure.UnitConverter
    public boolean isIdentity() {
        return this.exponent == 0;
    }

    @Override // javax.measure.UnitConverter
    public boolean isLinear() {
        return true;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public AbstractConverter reduce(AbstractConverter abstractConverter) {
        return new PowerOfPiConverter(this.exponent + ((PowerOfPiConverter) abstractConverter).exponent);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public final String transformationLiteral() {
        return z82.m21085r(this.exponent, "x -> x * π^");
    }
}
