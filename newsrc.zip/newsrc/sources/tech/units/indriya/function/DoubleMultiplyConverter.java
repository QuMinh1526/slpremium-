package tech.units.indriya.function;

import javax.measure.UnitConverter;
import tech.units.indriya.internal.function.Calculator;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
final class DoubleMultiplyConverter extends AbstractConverter implements MultiplyConverter {
    private static final long serialVersionUID = 6588759878444545649L;
    private final double doubleFactor;

    private DoubleMultiplyConverter(double d) {
        this.doubleFactor = d;
    }

    /* JADX INFO: renamed from: of */
    public static DoubleMultiplyConverter m17671of(double d) {
        return new DoubleMultiplyConverter(d);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean canReduceWith(AbstractConverter abstractConverter) {
        return abstractConverter instanceof DoubleMultiplyConverter;
    }

    @Override // java.lang.Comparable
    public int compareTo(UnitConverter unitConverter) {
        if (this == unitConverter) {
            return 0;
        }
        if (unitConverter instanceof DoubleMultiplyConverter) {
            return getValue().compareTo(((DoubleMultiplyConverter) unitConverter).getValue());
        }
        return -1;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public Number convertWhenNotIdentity(Number number) {
        return Calculator.m17692of(Double.valueOf(this.doubleFactor)).multiply(number).peek();
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof DoubleMultiplyConverter) {
            return Double.valueOf(this.doubleFactor).equals(Double.valueOf(((DoubleMultiplyConverter) obj).doubleFactor));
        }
        return false;
    }

    @Override // java.util.function.DoubleSupplier
    public double getAsDouble() {
        return this.doubleFactor;
    }

    @Override // tech.units.indriya.function.MultiplyConverter, p000.w8b
    public Double getValue() {
        return Double.valueOf(this.doubleFactor);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public int hashCode() {
        return Double.valueOf(this.doubleFactor).hashCode();
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public DoubleMultiplyConverter inverseWhenNotIdentity() {
        return new DoubleMultiplyConverter(1.0d / this.doubleFactor);
    }

    @Override // javax.measure.UnitConverter
    public boolean isIdentity() {
        return this.doubleFactor == 1.0d;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public AbstractConverter reduce(AbstractConverter abstractConverter) {
        return new DoubleMultiplyConverter(this.doubleFactor * ((DoubleMultiplyConverter) abstractConverter).doubleFactor);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public final String transformationLiteral() {
        return "x -> x * " + this.doubleFactor;
    }
}
