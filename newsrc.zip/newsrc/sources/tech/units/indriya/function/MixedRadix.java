package tech.units.indriya.function;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import javax.measure.MeasurementException;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import p000.C1521v3;
import p000.nxa;
import p000.r81;
import p000.ro6;
import p000.tr4;
import tech.units.indriya.internal.function.Calculator;
import tech.units.indriya.internal.function.radix.MixedRadixSupport;
import tech.units.indriya.internal.function.radix.Radix;
import tech.units.indriya.quantity.MixedQuantity;
import tech.units.indriya.quantity.Quantities;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class MixedRadix<Q extends Quantity<Q>> {
    public static PrimaryUnitPick PRIMARY_UNIT_PICK;
    public static final PrimaryUnitPick PRIMARY_UNIT_PICK_DEFAULT;
    private final MixedRadixSupport mixedRadixSupport;
    private final List<Unit<Q>> mixedRadixUnits;
    private final PrimaryUnitPickState pickState;
    private final Unit<Q> primaryUnit;

    /* JADX INFO: renamed from: tech.units.indriya.function.MixedRadix$1 */
    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static /* synthetic */ class C14451 {

        /* JADX INFO: renamed from: $SwitchMap$tech$units$indriya$function$MixedRadix$PrimaryUnitPick */
        static final /* synthetic */ int[] f40116xf4b79b2f;

        static {
            int[] iArr = new int[PrimaryUnitPick.values().length];
            f40116xf4b79b2f = iArr;
            try {
                iArr[PrimaryUnitPick.LEADING_UNIT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f40116xf4b79b2f[PrimaryUnitPick.TRAILING_UNIT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public enum PrimaryUnitPick {
        LEADING_UNIT,
        TRAILING_UNIT
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class PrimaryUnitPickState {
        private static final int LEADING_IS_PRIMARY_UNIT = 0;
        private static final int TRAILING_IS_PRIMARY_UNIT = -1;
        private final boolean explicitlyPicked;
        private final int pickedIndex;

        private PrimaryUnitPickState(boolean z, int i) {
            this.explicitlyPicked = z;
            this.pickedIndex = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void assertNotExplicitlyPicked() {
            if (this.explicitlyPicked) {
                C1521v3.m18909p("a primary unit was already picked");
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public int nonNegativePrimaryUnitIndex(int i) {
            int i2 = this.pickedIndex;
            return i2 < 0 ? i + i2 : i2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static PrimaryUnitPickState pickByConvention() {
            int i;
            int i2 = C14451.f40116xf4b79b2f[MixedRadix.PRIMARY_UNIT_PICK.ordinal()];
            if (i2 == 1) {
                i = 0;
            } else {
                if (i2 != 2) {
                    throw new MeasurementException("internal error: unmatched switch case <" + MixedRadix.PRIMARY_UNIT_PICK + ">");
                }
                i = -1;
            }
            return new PrimaryUnitPickState(false, i);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static PrimaryUnitPickState pickByExplicitIndex(int i) {
            return new PrimaryUnitPickState(true, i);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static PrimaryUnitPickState pickLeading() {
            return new PrimaryUnitPickState(true, 0);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    @FunctionalInterface
    public interface Visitor<Q extends Quantity<Q>> {
        void accept(int i, Unit<Q> unit, Number number);
    }

    static {
        PrimaryUnitPick primaryUnitPick = PrimaryUnitPick.TRAILING_UNIT;
        PRIMARY_UNIT_PICK_DEFAULT = primaryUnitPick;
        PRIMARY_UNIT_PICK = primaryUnitPick;
    }

    private MixedRadix(PrimaryUnitPickState primaryUnitPickState, List<Unit<Q>> list) {
        this.pickState = primaryUnitPickState;
        this.mixedRadixUnits = list;
        this.primaryUnit = list.get(primaryUnitPickState.nonNegativePrimaryUnitIndex(getUnitCount()));
        int unitCount = getUnitCount() - 1;
        Radix[] radixArr = new Radix[unitCount];
        int i = 0;
        while (i < unitCount) {
            int i2 = i + 1;
            radixArr[i] = toRadix(list.get(i).getConverterTo(list.get(i2)));
            i = i2;
        }
        this.mixedRadixSupport = new MixedRadixSupport(radixArr);
    }

    private MixedRadix<Q> append(PrimaryUnitPickState primaryUnitPickState, Unit<Q> unit) {
        assertDecreasingOrderOfSignificanceAndLinearity(getTrailingUnit(), unit);
        ArrayList arrayList = new ArrayList(this.mixedRadixUnits);
        arrayList.add(unit);
        return new MixedRadix<>(primaryUnitPickState, arrayList);
    }

    private void assertDecreasingOrderOfSignificanceAndLinearity(Unit<Q> unit, Unit<Q> unit2) {
        if (!unit2.getConverterTo(unit).isLinear()) {
            nxa.m14377b(unit2.getClass(), "the appended mixed-radix unit <", "> must be linear, that is, its system converter must be a linear transformation (a linear function without offset)");
            return;
        }
        if (Calculator.m17692of(Double.valueOf(unit.getConverterTo(unit2).convert(1.0d))).abs().isLessThanOne()) {
            throw new MeasurementException("the appended mixed-radix unit <" + unit2.getClass() + "> must be of lesser significance than the one it is appended to: <" + unit.getClass() + ">");
        }
    }

    private Unit<Q> getTrailingUnit() {
        List<Unit<Q>> list = this.mixedRadixUnits;
        return list.get(list.size() - 1);
    }

    private int getUnitCount() {
        return this.mixedRadixUnits.size();
    }

    private void guardAgainstIllegalNumbersArgument(Number[] numberArr) {
        if (numberArr == null || numberArr.length < 1) {
            C1521v3.m18903j("at least the leading unit's number is required");
            return;
        }
        int length = numberArr.length;
        int size = this.mixedRadixUnits.size();
        if (length <= size) {
            return;
        }
        ro6.m16606q("number of values given <%d> exceeds the number of mixed-radix units available <%d>", new Object[]{Integer.valueOf(length), Integer.valueOf(size)});
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void lambda$extractValuesInto$0(Number[] numberArr, int i, Unit unit, Number number) {
        numberArr[i] = number;
    }

    /* JADX INFO: renamed from: of */
    public static <X extends Quantity<X>> MixedRadix<X> m17674of(Collection<Unit<X>> collection) {
        MixedRadix<X> mixedRadixM17675of = null;
        if (collection == null || collection.size() < 1) {
            C1521v3.m18903j("at least the leading unit is required");
            return null;
        }
        for (Unit<X> unit : collection) {
            mixedRadixM17675of = mixedRadixM17675of == null ? m17675of(unit) : mixedRadixM17675of.mix(unit);
        }
        return mixedRadixM17675of;
    }

    public static <X extends Quantity<X>> MixedRadix<X> ofPrimary(Unit<X> unit) {
        Objects.requireNonNull(unit);
        return new MixedRadix<>(PrimaryUnitPickState.pickLeading(), Collections.singletonList(unit));
    }

    private Radix toRadix(UnitConverter unitConverter) {
        return Radix.ofMultiplyConverter(unitConverter);
    }

    public MixedQuantity<Q> createMixedQuantity(Number[] numberArr, Quantity.Scale scale) {
        Objects.requireNonNull(scale);
        guardAgainstIllegalNumbersArgument(numberArr);
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < numberArr.length; i++) {
            arrayList.add(Quantities.getQuantity(numberArr[i], this.mixedRadixUnits.get(i), scale));
        }
        return MixedQuantity.m17708of(arrayList);
    }

    public Quantity<Q> createQuantity(Number[] numberArr, Quantity.Scale scale) {
        Objects.requireNonNull(scale);
        guardAgainstIllegalNumbersArgument(numberArr);
        return Quantities.getQuantity(this.mixedRadixSupport.sumMostSignificant(numberArr), getTrailingUnit(), scale).mo11214to((Unit) getPrimaryUnit());
    }

    public Number[] extractValues(Quantity<Q> quantity) {
        Objects.requireNonNull(quantity);
        return extractValuesInto(quantity, new Number[this.mixedRadixUnits.size()]);
    }

    public Number[] extractValuesInto(Quantity<Q> quantity, final Number[] numberArr) {
        Objects.requireNonNull(quantity);
        Objects.requireNonNull(numberArr);
        visitQuantity(quantity, numberArr.length, new Visitor() { // from class: tech.units.indriya.function.c
            @Override // tech.units.indriya.function.MixedRadix.Visitor
            public final void accept(int i, Unit unit, Number number) {
                MixedRadix.lambda$extractValuesInto$0(numberArr, i, unit, number);
            }
        });
        return numberArr;
    }

    public Unit<Q> getPrimaryUnit() {
        return this.primaryUnit;
    }

    public List<Unit<Q>> getUnits() {
        return Collections.unmodifiableList(this.mixedRadixUnits);
    }

    public MixedRadix<Q> mix(Unit<Q> unit) {
        Objects.requireNonNull(unit);
        return append(this.pickState, unit);
    }

    public MixedRadix<Q> mixPrimary(Unit<Q> unit) {
        this.pickState.assertNotExplicitlyPicked();
        Objects.requireNonNull(unit);
        return append(PrimaryUnitPickState.pickByExplicitIndex(getUnitCount()), unit);
    }

    public String toString() {
        return tr4.m17882f(new StringBuilder("MixedRadix [units="), this.mixedRadixUnits, "]");
    }

    public void visitQuantity(Quantity<Q> quantity, int i, Visitor<Q> visitor) {
        int iMin = Math.min(i, getUnitCount());
        if (iMin == 0) {
            return;
        }
        Number value = quantity.mo11214to(getTrailingUnit()).getValue();
        ArrayList arrayList = new ArrayList(getUnitCount());
        this.mixedRadixSupport.visitRadixNumbers(value, new r81(arrayList, 1));
        for (int i2 = 0; i2 < iMin; i2++) {
            visitor.accept(i2, this.mixedRadixUnits.get(i2), (Number) arrayList.get((getUnitCount() - 1) - i2));
        }
    }

    public Quantity<Q> createQuantity(Number... numberArr) {
        return createQuantity(numberArr, Quantity.Scale.ABSOLUTE);
    }

    public MixedQuantity<Q> createMixedQuantity(Number... numberArr) {
        return createMixedQuantity(numberArr, Quantity.Scale.ABSOLUTE);
    }

    @SafeVarargs
    /* JADX INFO: renamed from: of */
    public static <X extends Quantity<X>> MixedRadix<X> m17676of(Unit<X>... unitArr) {
        if (unitArr != null && unitArr.length >= 1) {
            return m17674of(Arrays.asList(unitArr));
        }
        C1521v3.m18903j("at least the leading unit is required");
        return null;
    }

    /* JADX INFO: renamed from: of */
    public static <X extends Quantity<X>> MixedRadix<X> m17675of(Unit<X> unit) {
        Objects.requireNonNull(unit);
        return new MixedRadix<>(PrimaryUnitPickState.pickByConvention(), Collections.singletonList(unit));
    }
}
