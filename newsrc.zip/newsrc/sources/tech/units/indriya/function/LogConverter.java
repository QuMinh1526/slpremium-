package tech.units.indriya.function;

import java.util.Objects;
import javax.measure.UnitConverter;
import p000.w8b;
import tech.units.indriya.internal.function.Calculator;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class LogConverter extends AbstractConverter implements w8b {
    private static final long serialVersionUID = -7584688290961460870L;
    private final double base;
    private final double logOfBase;

    public LogConverter(double d) {
        this.base = d;
        this.logOfBase = Math.log(d);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean canReduceWith(AbstractConverter abstractConverter) {
        return (abstractConverter instanceof ExpConverter) && ((ExpConverter) abstractConverter).getBase() == this.base;
    }

    @Override // java.lang.Comparable
    public int compareTo(UnitConverter unitConverter) {
        if (this == unitConverter) {
            return 0;
        }
        if (unitConverter instanceof w8b) {
            return getValue().compareTo(String.valueOf(((w8b) unitConverter).getValue()));
        }
        return -1;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public Number convertWhenNotIdentity(Number number) {
        return Calculator.m17692of(number).log().divide(Double.valueOf(this.logOfBase)).peek();
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof LogConverter) {
            return Double.valueOf(this.base).equals(Double.valueOf(((LogConverter) obj).base));
        }
        return false;
    }

    public double getBase() {
        return this.base;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public int hashCode() {
        return Objects.hash(Double.valueOf(this.base));
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public AbstractConverter inverseWhenNotIdentity() {
        return new ExpConverter(this.base);
    }

    @Override // javax.measure.UnitConverter
    public boolean isIdentity() {
        return false;
    }

    @Override // javax.measure.UnitConverter
    public boolean isLinear() {
        return false;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public AbstractConverter reduce(AbstractConverter abstractConverter) {
        return AbstractConverter.IDENTITY;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public final String transformationLiteral() {
        double d = this.base;
        if (d == 2.718281828459045d) {
            return "x -> ln(x)";
        }
        return "x -> log(base=" + d + ", x)";
    }

    @Override // p000.w8b
    public String getValue() {
        return toString();
    }
}
