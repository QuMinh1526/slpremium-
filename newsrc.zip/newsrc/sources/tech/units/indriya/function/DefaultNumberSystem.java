package tech.units.indriya.function;

import com.squareup.picasso.BuildConfig;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.UnaryOperator;
import p000.C1521v3;
import p000.z23;
import p000.z82;
import tech.units.indriya.function.DefaultNumberSystem;
import tech.units.indriya.spi.NumberSystem;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class DefaultNumberSystem implements NumberSystem {
    private Number addWideAndNarrow(NumberType numberType, Number number, NumberType numberType2, Number number2) {
        if (numberType.isZero(number)) {
            return number2;
        }
        if (numberType2.isZero(number2)) {
            return number;
        }
        if (numberType.isIntegerOnly()) {
            if (number instanceof BigInteger) {
                return ((BigInteger) number).add(integerToBigInteger(number2));
            }
            if (Math.max(bitLengthOfInteger(number), bitLengthOfInteger(number2)) + 1 < 63) {
                return Long.valueOf(number2.longValue() + number.longValue());
            }
            return integerToBigInteger(number).add(integerToBigInteger(number2));
        }
        if (number instanceof RationalNumber) {
            return number2 instanceof RationalNumber ? ((RationalNumber) number).add((RationalNumber) number2) : ((RationalNumber) number).add(RationalNumber.ofInteger(integerToBigInteger(number2)));
        }
        if (number instanceof BigDecimal) {
            if (number2 instanceof BigDecimal) {
                return ((BigDecimal) number).add((BigDecimal) number2, Calculus.MATH_CONTEXT);
            }
            if ((number2 instanceof Double) || (number2 instanceof Float)) {
                return ((BigDecimal) number).add(BigDecimal.valueOf(number2.doubleValue()), Calculus.MATH_CONTEXT);
            }
            return number2 instanceof RationalNumber ? ((BigDecimal) number).add(((RationalNumber) number2).bigDecimalValue()) : ((BigDecimal) number).add(BigDecimal.valueOf(number2.longValue()));
        }
        if ((number2 instanceof Double) || (number2 instanceof Float)) {
            return BigDecimal.valueOf(number.doubleValue()).add(BigDecimal.valueOf(number2.doubleValue()));
        }
        if (number2 instanceof RationalNumber) {
            return BigDecimal.valueOf(number.doubleValue()).add(((RationalNumber) number2).bigDecimalValue());
        }
        return number2 instanceof BigInteger ? BigDecimal.valueOf(number.doubleValue()).add(new BigDecimal((BigInteger) number2)) : BigDecimal.valueOf(number.doubleValue()).add(BigDecimal.valueOf(number2.longValue()));
    }

    private static Number[] applyToArray(Number[] numberArr, UnaryOperator<Number> unaryOperator) {
        return new Number[]{(Number) unaryOperator.apply(numberArr[0]), (Number) unaryOperator.apply(numberArr[1])};
    }

    private int bitLengthOfInteger(Number number) {
        if (number instanceof BigInteger) {
            return ((BigInteger) number).bitLength();
        }
        long jLongValue = number.longValue();
        if (jLongValue == Long.MIN_VALUE) {
            return 63;
        }
        return 64 - Long.numberOfLeadingZeros(Math.abs(jLongValue));
    }

    private int compareWideVsNarrow(NumberType numberType, Number number, NumberType numberType2, Number number2) {
        if (numberType.isIntegerOnly()) {
            return number instanceof BigInteger ? ((BigInteger) number).compareTo(integerToBigInteger(number2)) : Long.compare(number.longValue(), number2.longValue());
        }
        if (number instanceof RationalNumber) {
            return number2 instanceof RationalNumber ? ((RationalNumber) number).compareTo((RationalNumber) number2) : ((RationalNumber) number).compareTo(RationalNumber.ofInteger(integerToBigInteger(number2)));
        }
        if (!(number instanceof BigDecimal)) {
            if ((number2 instanceof Double) || (number2 instanceof Float)) {
                return Double.compare(number.doubleValue(), number2.doubleValue());
            }
            if (number2 instanceof RationalNumber) {
                return BigDecimal.valueOf(number.doubleValue()).compareTo(((RationalNumber) number2).bigDecimalValue());
            }
            return number2 instanceof BigInteger ? BigDecimal.valueOf(number.doubleValue()).compareTo(new BigDecimal((BigInteger) number2)) : BigDecimal.valueOf(number.doubleValue()).compareTo(BigDecimal.valueOf(number2.longValue()));
        }
        if (number2 instanceof BigDecimal) {
            return ((BigDecimal) number).compareTo((BigDecimal) number2);
        }
        if ((number2 instanceof Double) || (number2 instanceof Float)) {
            return ((BigDecimal) number).compareTo(BigDecimal.valueOf(number2.doubleValue()));
        }
        if (number2 instanceof RationalNumber) {
            return ((BigDecimal) number).compareTo(((RationalNumber) number2).bigDecimalValue());
        }
        return number2 instanceof BigInteger ? ((BigDecimal) number).compareTo(new BigDecimal((BigInteger) number2)) : ((BigDecimal) number).compareTo(BigDecimal.valueOf(number2.longValue()));
    }

    private static BigInteger copySignTo(int i, BigInteger bigInteger) {
        return i == -1 ? bigInteger.negate() : bigInteger;
    }

    private BigInteger integerToBigInteger(Number number) {
        return number instanceof BigInteger ? (BigInteger) number : BigInteger.valueOf(number.longValue());
    }

    public static boolean isFractional(BigDecimal bigDecimal) {
        if (bigDecimal.signum() != 0 && bigDecimal.scale() > 0) {
            return (bigDecimal.signum() == 0 ? new BigDecimal(BigInteger.ZERO, 0) : bigDecimal.stripTrailingZeros()).scale() > 0;
        }
        return false;
    }

    private boolean isInteger(NumberType numberType, Number number) {
        if (numberType.isIntegerOnly()) {
            return true;
        }
        if (number instanceof RationalNumber) {
            return ((RationalNumber) number).isInteger();
        }
        if (number instanceof BigDecimal) {
            return !isFractional((BigDecimal) number);
        }
        if ((number instanceof Double) || (number instanceof Float)) {
            return !numberType.isZero(number) && number.doubleValue() % 1.0d == 0.0d;
        }
        throw unsupportedNumberType(number);
    }

    private boolean isIntegerOnly(Number number) {
        return NumberType.valueOf(number).isIntegerOnly();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$divideAndRemainder$0(int i, Number number) {
        return copySignTo(i, (BigInteger) number);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Number lambda$divideAndRemainder$1(int i, Number number) {
        return copySignTo(i, (BigDecimal) number);
    }

    private Number multiplyWideAndNarrow(NumberType numberType, Number number, NumberType numberType2, Number number2) {
        if (numberType.isZero(number) || numberType2.isZero(number2)) {
            return 0;
        }
        if (numberType.isIntegerOnly()) {
            if (number instanceof BigInteger) {
                return ((BigInteger) number).multiply(integerToBigInteger(number2));
            }
            if (bitLengthOfInteger(number) + bitLengthOfInteger(number2) < 63) {
                return Long.valueOf(number2.longValue() * number.longValue());
            }
            return integerToBigInteger(number).multiply(integerToBigInteger(number2));
        }
        if (number instanceof RationalNumber) {
            return number2 instanceof RationalNumber ? ((RationalNumber) number).multiply((RationalNumber) number2) : ((RationalNumber) number).multiply(RationalNumber.ofInteger(integerToBigInteger(number2)));
        }
        if (!(number instanceof BigDecimal)) {
            if ((number2 instanceof Double) || (number2 instanceof Float)) {
                return Double.valueOf(number2.doubleValue() * number.doubleValue());
            }
            if (number2 instanceof RationalNumber) {
                return BigDecimal.valueOf(number.doubleValue()).multiply(((RationalNumber) number2).bigDecimalValue());
            }
            return number2 instanceof BigInteger ? BigDecimal.valueOf(number.doubleValue()).multiply(new BigDecimal((BigInteger) number2)) : BigDecimal.valueOf(number.doubleValue()).multiply(BigDecimal.valueOf(number2.longValue()));
        }
        if (number2 instanceof BigDecimal) {
            return ((BigDecimal) number).multiply((BigDecimal) number2, Calculus.MATH_CONTEXT);
        }
        if (number2 instanceof BigInteger) {
            return ((BigDecimal) number).multiply(new BigDecimal((BigInteger) number2), Calculus.MATH_CONTEXT);
        }
        if ((number2 instanceof Double) || (number2 instanceof Float)) {
            return ((BigDecimal) number).multiply(BigDecimal.valueOf(number2.doubleValue()), Calculus.MATH_CONTEXT);
        }
        return number2 instanceof RationalNumber ? ((BigDecimal) number).multiply(((RationalNumber) number2).bigDecimalValue()) : ((BigDecimal) number).multiply(BigDecimal.valueOf(number2.longValue()));
    }

    private BigDecimal toBigDecimal(Number number) {
        if (number instanceof BigDecimal) {
            return (BigDecimal) number;
        }
        if (number instanceof BigInteger) {
            return new BigDecimal((BigInteger) number);
        }
        if ((number instanceof Long) || (number instanceof AtomicLong) || (number instanceof Integer) || (number instanceof AtomicInteger) || (number instanceof Short) || (number instanceof Byte)) {
            return BigDecimal.valueOf(number.longValue());
        }
        if ((number instanceof Double) || (number instanceof Float)) {
            return BigDecimal.valueOf(number.doubleValue());
        }
        if (number instanceof RationalNumber) {
            throw unexpectedCodeReach();
        }
        throw unsupportedNumberType(number);
    }

    private IllegalStateException unexpectedCodeReach() {
        return new IllegalStateException("Implementation Error: Code was reached that is expected unreachable");
    }

    private IllegalArgumentException unsupportedNumberType(Number number) {
        return new IllegalArgumentException(z23.m20935q("Unsupported number type '", number.getClass().getName(), "' in number system '", getClass().getName(), "'"));
    }

    private IllegalArgumentException unsupportedNumberValue(Number number) {
        String str = BuildConfig.VERSION_NAME + number;
        Class<?> cls = number.getClass();
        String name = getClass().getName();
        StringBuilder sb = new StringBuilder("Unsupported number value '");
        sb.append(str);
        sb.append("' of type '");
        sb.append(cls);
        sb.append("' in number system '");
        return new IllegalArgumentException(z82.m21092y(sb, name, "'"));
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number abs(Number number) {
        if (number instanceof BigInteger) {
            return ((BigInteger) number).abs();
        }
        if (number instanceof BigDecimal) {
            return ((BigDecimal) number).abs();
        }
        if (number instanceof RationalNumber) {
            return ((RationalNumber) number).abs();
        }
        if (number instanceof Double) {
            return Double.valueOf(Math.abs(((Double) number).doubleValue()));
        }
        if (number instanceof Float) {
            return Float.valueOf(Math.abs(((Float) number).floatValue()));
        }
        if ((number instanceof Long) || (number instanceof AtomicLong)) {
            long jLongValue = number.longValue();
            return jLongValue == Long.MIN_VALUE ? BigInteger.valueOf(jLongValue).abs() : Long.valueOf(Math.abs(jLongValue));
        }
        if ((number instanceof Integer) || (number instanceof AtomicInteger)) {
            int iIntValue = number.intValue();
            return iIntValue == Integer.MIN_VALUE ? Long.valueOf(Math.abs(number.longValue())) : Integer.valueOf(Math.abs(iIntValue));
        }
        if ((number instanceof Short) || (number instanceof Byte)) {
            return Integer.valueOf(Math.abs(number.intValue()));
        }
        throw unsupportedNumberType(number);
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number add(Number number, Number number2) {
        NumberType numberTypeValueOf = NumberType.valueOf(number);
        NumberType numberTypeValueOf2 = NumberType.valueOf(number2);
        return numberTypeValueOf2.ordinal() > numberTypeValueOf.ordinal() ? addWideAndNarrow(numberTypeValueOf2, number2, numberTypeValueOf, number) : addWideAndNarrow(numberTypeValueOf, number, numberTypeValueOf2, number2);
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public int compare(Number number, Number number2) {
        NumberType numberTypeValueOf = NumberType.valueOf(number);
        NumberType numberTypeValueOf2 = NumberType.valueOf(number2);
        return numberTypeValueOf2.ordinal() > numberTypeValueOf.ordinal() ? -compareWideVsNarrow(numberTypeValueOf2, number2, numberTypeValueOf, number) : compareWideVsNarrow(numberTypeValueOf, number, numberTypeValueOf2, number2);
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number divide(Number number, Number number2) {
        return multiply(number, reciprocal(number2));
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number[] divideAndRemainder(Number number, Number number2, boolean z) {
        final int i = 0;
        int iSignum = signum(number);
        int iSignum2 = signum(number2);
        final int i2 = iSignum * iSignum2;
        final int i3 = 1;
        if (i2 == 0) {
            if (iSignum2 == 0) {
                throw new ArithmeticException("division by zero");
            }
            if (iSignum == 0) {
                return new Number[]{0, 0};
            }
        }
        Number numberAbs = abs(number);
        Number numberAbs2 = abs(number2);
        NumberType numberTypeValueOf = NumberType.valueOf(numberAbs);
        NumberType numberTypeValueOf2 = NumberType.valueOf(numberAbs2);
        if (numberTypeValueOf.isIntegerOnly() && numberTypeValueOf2.isIntegerOnly()) {
            return applyToArray(integerToBigInteger(numberAbs).divideAndRemainder(integerToBigInteger(numberAbs2)), new UnaryOperator() { // from class: xl2
                @Override // java.util.function.Function
                public final Object apply(Object obj) {
                    int i4 = i;
                    int i5 = i2;
                    Number number3 = (Number) obj;
                    switch (i4) {
                        case 0:
                            return DefaultNumberSystem.lambda$divideAndRemainder$0(i5, number3);
                        default:
                            return DefaultNumberSystem.lambda$divideAndRemainder$1(i5, number3);
                    }
                }
            });
        }
        MathContext mathContext = new MathContext(Calculus.MATH_CONTEXT.getPrecision(), RoundingMode.FLOOR);
        NumberType numberType = NumberType.RATIONAL;
        BigDecimal[] bigDecimalArrDivideAndRemainder = (numberTypeValueOf == numberType ? ((RationalNumber) numberAbs).bigDecimalValue() : toBigDecimal(numberAbs)).divideAndRemainder(numberTypeValueOf2 == numberType ? ((RationalNumber) numberAbs2).bigDecimalValue() : toBigDecimal(numberAbs2), mathContext);
        return z ? new Number[]{copySignTo(i2, bigDecimalArrDivideAndRemainder[0]), copySignTo(i2, bigDecimalArrDivideAndRemainder[1].toBigInteger())} : applyToArray(bigDecimalArrDivideAndRemainder, new UnaryOperator() { // from class: xl2
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                int i4 = i3;
                int i5 = i2;
                Number number3 = (Number) obj;
                switch (i4) {
                    case 0:
                        return DefaultNumberSystem.lambda$divideAndRemainder$0(i5, number3);
                    default:
                        return DefaultNumberSystem.lambda$divideAndRemainder$1(i5, number3);
                }
            }
        });
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number exp(Number number) {
        return Double.valueOf(Math.exp(number.doubleValue()));
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public boolean isLessThanOne(Number number) {
        return compare(NumberType.valueOf(number).one, number) > 0;
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public boolean isOne(Number number) {
        return compare(NumberType.valueOf(number).one, number) == 0;
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public boolean isZero(Number number) {
        return NumberType.valueOf(number).isZero(number);
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number log(Number number) {
        return Double.valueOf(Math.log(number.doubleValue()));
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number multiply(Number number, Number number2) {
        NumberType numberTypeValueOf = NumberType.valueOf(number);
        NumberType numberTypeValueOf2 = NumberType.valueOf(number2);
        return numberTypeValueOf2.ordinal() > numberTypeValueOf.ordinal() ? multiplyWideAndNarrow(numberTypeValueOf2, number2, numberTypeValueOf, number) : multiplyWideAndNarrow(numberTypeValueOf, number, numberTypeValueOf2, number2);
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number narrow(Number number) {
        if ((number instanceof Integer) || (number instanceof AtomicInteger) || (number instanceof Short) || (number instanceof Byte)) {
            return number;
        }
        if ((number instanceof Double) || (number instanceof Float)) {
            double dDoubleValue = number.doubleValue();
            if (Double.isFinite(dDoubleValue)) {
                return (dDoubleValue % 1.0d != 0.0d || isZero(number)) ? number : narrow(BigDecimal.valueOf(dDoubleValue));
            }
            throw unsupportedNumberValue(Double.valueOf(dDoubleValue));
        }
        if (isIntegerOnly(number)) {
            int iBitLengthOfInteger = bitLengthOfInteger(number);
            if (iBitLengthOfInteger < 31) {
                return Integer.valueOf(number.intValue());
            }
            if (iBitLengthOfInteger < 63) {
                return Long.valueOf(number.longValue());
            }
        } else {
            if (number instanceof BigDecimal) {
                BigDecimal bigDecimal = (BigDecimal) number;
                if (!isFractional(bigDecimal)) {
                    try {
                        return narrow(bigDecimal.toBigIntegerExact());
                    } catch (ArithmeticException unused) {
                    }
                }
                return number;
            }
            if (number instanceof RationalNumber) {
                RationalNumber rationalNumber = (RationalNumber) number;
                if (rationalNumber.isInteger()) {
                    return narrow(rationalNumber.getDividend());
                }
            }
        }
        return number;
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number negate(Number number) {
        if (number instanceof BigInteger) {
            return ((BigInteger) number).negate();
        }
        if (number instanceof BigDecimal) {
            return ((BigDecimal) number).negate();
        }
        if (number instanceof RationalNumber) {
            return ((RationalNumber) number).negate();
        }
        if (number instanceof Double) {
            return Double.valueOf(-((Double) number).doubleValue());
        }
        if (number instanceof Float) {
            return Float.valueOf(-((Float) number).floatValue());
        }
        if ((number instanceof Long) || (number instanceof AtomicLong)) {
            long jLongValue = number.longValue();
            return jLongValue == Long.MIN_VALUE ? BigInteger.valueOf(jLongValue).negate() : Long.valueOf(-jLongValue);
        }
        if ((number instanceof Integer) || (number instanceof AtomicInteger)) {
            int iIntValue = number.intValue();
            return iIntValue == Integer.MIN_VALUE ? Long.valueOf(-number.longValue()) : Integer.valueOf(-iIntValue);
        }
        if (number instanceof Short) {
            short sShortValue = ((Short) number).shortValue();
            return sShortValue == Short.MIN_VALUE ? Integer.valueOf(-number.intValue()) : Integer.valueOf(-sShortValue);
        }
        if (!(number instanceof Byte)) {
            throw unsupportedNumberType(number);
        }
        short sByteValue = ((Byte) number).byteValue();
        return sByteValue == -128 ? Integer.valueOf(-number.intValue()) : Integer.valueOf(-sByteValue);
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number power(Number number, int i) {
        if (i == 0) {
            if (isZero(number)) {
                throw new ArithmeticException("0^0 is not defined");
            }
            return 1;
        }
        if (i == 1) {
            return number;
        }
        if ((number instanceof BigInteger) || (number instanceof Long) || (number instanceof AtomicLong) || (number instanceof Integer) || (number instanceof AtomicInteger) || (number instanceof Short) || (number instanceof Byte)) {
            BigInteger bigIntegerIntegerToBigInteger = integerToBigInteger(number);
            return i > 0 ? bigIntegerIntegerToBigInteger.pow(i) : RationalNumber.ofInteger(bigIntegerIntegerToBigInteger).pow(i);
        }
        if (number instanceof BigDecimal) {
            return ((BigDecimal) number).pow(i, Calculus.MATH_CONTEXT);
        }
        if (number instanceof RationalNumber) {
            ((RationalNumber) number).pow(i);
        }
        if ((number instanceof Double) || (number instanceof Float)) {
            return toBigDecimal(number).pow(i, Calculus.MATH_CONTEXT);
        }
        throw unsupportedNumberType(number);
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number reciprocal(Number number) {
        if (isIntegerOnly(number)) {
            return RationalNumber.m17691of(BigInteger.ONE, integerToBigInteger(number));
        }
        if (number instanceof BigDecimal) {
            return RationalNumber.m17690of((BigDecimal) number).reciprocal();
        }
        if (number instanceof RationalNumber) {
            return ((RationalNumber) number).reciprocal();
        }
        if (number instanceof Double) {
            return RationalNumber.m17688of(((Double) number).doubleValue()).reciprocal();
        }
        if (number instanceof Float) {
            return RationalNumber.m17688of(number.doubleValue()).reciprocal();
        }
        throw unsupportedNumberType(number);
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public int signum(Number number) {
        if (number instanceof BigInteger) {
            return ((BigInteger) number).signum();
        }
        if (number instanceof BigDecimal) {
            return ((BigDecimal) number).signum();
        }
        if (number instanceof RationalNumber) {
            return ((RationalNumber) number).signum();
        }
        if (number instanceof Double) {
            return (int) Math.signum(((Double) number).doubleValue());
        }
        if (number instanceof Float) {
            return (int) Math.signum(((Float) number).floatValue());
        }
        if ((number instanceof Long) || (number instanceof AtomicLong)) {
            return Long.signum(number.longValue());
        }
        if ((number instanceof Integer) || (number instanceof AtomicInteger) || (number instanceof Short) || (number instanceof Byte)) {
            return Integer.signum(number.intValue());
        }
        throw unsupportedNumberType(number);
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public Number subtract(Number number, Number number2) {
        return add(number, negate(number2));
    }

    private static BigDecimal copySignTo(int i, BigDecimal bigDecimal) {
        return i == -1 ? bigDecimal.negate() : bigDecimal;
    }

    @Override // tech.units.indriya.spi.NumberSystem
    public boolean isInteger(Number number) {
        return isInteger(NumberType.valueOf(number), number);
    }

    /* JADX WARN: Enum visitor error
    jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'INTEGER_ATOMIC' uses external variables
    	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:485)
    	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByRegister(EnumVisitor.java:422)
    	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:351)
    	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:284)
    	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:153)
    	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:102)
     */
    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class NumberType {
        private static final /* synthetic */ NumberType[] $VALUES;
        public static final NumberType BIG_DECIMAL;
        public static final NumberType BIG_INTEGER;
        public static final NumberType BYTE_BOXED;
        public static final NumberType DOUBLE_BOXED;
        public static final NumberType FLOAT_BOXED;
        public static final NumberType INTEGER_ATOMIC;
        public static final NumberType INTEGER_BOXED;
        public static final NumberType LONG_ATOMIC;
        public static final NumberType LONG_BOXED;
        public static final NumberType RATIONAL;
        public static final NumberType SHORT_BOXED;
        private final boolean integerOnly;
        private final Number one;
        private final Class<? extends Number> type;
        private final Number zero;

        static {
            int i = 0;
            NumberType numberType = new NumberType("BYTE_BOXED", 0, true, Byte.class, (byte) 1, (byte) 0);
            BYTE_BOXED = numberType;
            NumberType numberType2 = new NumberType("SHORT_BOXED", 1, true, Short.class, (short) 1, (short) 0);
            SHORT_BOXED = numberType2;
            NumberType numberType3 = new NumberType("INTEGER_BOXED", 2, true, Integer.class, 1, 0);
            INTEGER_BOXED = numberType3;
            NumberType numberType4 = new NumberType("INTEGER_ATOMIC", 3, true, AtomicInteger.class, 1, i) { // from class: tech.units.indriya.function.DefaultNumberSystem.NumberType.1
                @Override // tech.units.indriya.function.DefaultNumberSystem.NumberType
                public boolean isZero(Number number) {
                    return ((AtomicInteger) number).intValue() == 0;
                }
            };
            INTEGER_ATOMIC = numberType4;
            NumberType numberType5 = new NumberType("LONG_BOXED", 4, true, Long.class, 1L, 0L);
            LONG_BOXED = numberType5;
            NumberType numberType6 = new NumberType("LONG_ATOMIC", 5, true, AtomicLong.class, 1L, i) { // from class: tech.units.indriya.function.DefaultNumberSystem.NumberType.2
                @Override // tech.units.indriya.function.DefaultNumberSystem.NumberType
                public boolean isZero(Number number) {
                    return ((AtomicLong) number).longValue() == 0;
                }
            };
            LONG_ATOMIC = numberType6;
            NumberType numberType7 = new NumberType("BIG_INTEGER", 6, true, BigInteger.class, BigInteger.ONE, BigInteger.ZERO) { // from class: tech.units.indriya.function.DefaultNumberSystem.NumberType.3
                @Override // tech.units.indriya.function.DefaultNumberSystem.NumberType
                public boolean isZero(Number number) {
                    return ((BigInteger) number).signum() == 0;
                }
            };
            BIG_INTEGER = numberType7;
            NumberType numberType8 = new NumberType("RATIONAL", 7, false, RationalNumber.class, RationalNumber.ONE, RationalNumber.ZERO) { // from class: tech.units.indriya.function.DefaultNumberSystem.NumberType.4
                @Override // tech.units.indriya.function.DefaultNumberSystem.NumberType
                public boolean isZero(Number number) {
                    return ((RationalNumber) number).signum() == 0;
                }
            };
            RATIONAL = numberType8;
            NumberType numberType9 = new NumberType("FLOAT_BOXED", 8, false, Float.class, Float.valueOf(1.0f), Float.valueOf(0.0f));
            FLOAT_BOXED = numberType9;
            NumberType numberType10 = new NumberType("DOUBLE_BOXED", 9, false, Double.class, Double.valueOf(1.0d), Double.valueOf(0.0d));
            DOUBLE_BOXED = numberType10;
            NumberType numberType11 = new NumberType("BIG_DECIMAL", 10, false, BigDecimal.class, BigDecimal.ONE, BigDecimal.ZERO) { // from class: tech.units.indriya.function.DefaultNumberSystem.NumberType.5
                @Override // tech.units.indriya.function.DefaultNumberSystem.NumberType
                public boolean isZero(Number number) {
                    return ((BigDecimal) number).signum() == 0;
                }
            };
            BIG_DECIMAL = numberType11;
            $VALUES = new NumberType[]{numberType, numberType2, numberType3, numberType4, numberType5, numberType6, numberType7, numberType8, numberType9, numberType10, numberType11};
        }

        private NumberType(String str, int i, boolean z, Class cls, Number number, Number number2) {
            super(str, i);
            this.integerOnly = z;
            this.type = cls;
            this.one = number;
            this.zero = number2;
        }

        public static NumberType valueOf(Number number) {
            if (number instanceof Long) {
                return LONG_BOXED;
            }
            if (number instanceof AtomicLong) {
                return LONG_ATOMIC;
            }
            if (number instanceof Integer) {
                return INTEGER_BOXED;
            }
            if (number instanceof AtomicInteger) {
                return INTEGER_ATOMIC;
            }
            if (number instanceof Double) {
                return DOUBLE_BOXED;
            }
            if (number instanceof Short) {
                return SHORT_BOXED;
            }
            if (number instanceof Byte) {
                return BYTE_BOXED;
            }
            if (number instanceof Float) {
                return FLOAT_BOXED;
            }
            if (number instanceof BigDecimal) {
                return BIG_DECIMAL;
            }
            if (number instanceof BigInteger) {
                return BIG_INTEGER;
            }
            if (number instanceof RationalNumber) {
                return RATIONAL;
            }
            C1521v3.m18903j(z82.m21089v("Unsupported number type '", number.getClass().getName(), "'"));
            return null;
        }

        public static NumberType[] values() {
            return (NumberType[]) $VALUES.clone();
        }

        public Class<? extends Number> getType() {
            return this.type;
        }

        public boolean isIntegerOnly() {
            return this.integerOnly;
        }

        public boolean isZero(Number number) {
            return this.zero.equals(number);
        }

        public static NumberType valueOf(String str) {
            return (NumberType) Enum.valueOf(NumberType.class, str);
        }
    }
}
