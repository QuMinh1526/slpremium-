package tech.units.indriya.function;

import java.math.BigInteger;
import java.util.Objects;
import javax.measure.Prefix;
import javax.measure.UnitConverter;
import p000.C1521v3;
import p000.z23;
import tech.units.indriya.internal.function.Calculator;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class PowerOfIntConverter extends AbstractConverter implements MultiplyConverter {
    private static final long serialVersionUID = 3546932001671571300L;
    private final int base;
    private final int exponent;
    private final int hashCode;
    private final RationalNumber rationalFactor;

    public PowerOfIntConverter(int i, int i2) {
        if (i == 0) {
            C1521v3.m18903j("base cannot be zero (because 0^0 is undefined)");
            throw null;
        }
        this.base = i;
        this.exponent = i2;
        this.hashCode = Objects.hash(Integer.valueOf(i), Integer.valueOf(i2));
        this.rationalFactor = calculateRationalNumberFactor();
    }

    private RationalNumber calculateRationalNumberFactor() {
        if (this.exponent == 0) {
            return RationalNumber.ONE;
        }
        BigInteger bigIntegerPow = BigInteger.valueOf(this.base).pow(Math.abs(this.exponent));
        return this.exponent > 0 ? RationalNumber.ofInteger(bigIntegerPow) : RationalNumber.m17691of(BigInteger.ONE, bigIntegerPow);
    }

    private PowerOfIntConverter composeSameBaseNonIdentity(PowerOfIntConverter powerOfIntConverter) {
        return new PowerOfIntConverter(this.base, this.exponent + powerOfIntConverter.exponent);
    }

    /* JADX INFO: renamed from: of */
    public static PowerOfIntConverter m17681of(Prefix prefix) {
        return m17680of(prefix.getValue(), prefix.getExponent());
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean canReduceWith(AbstractConverter abstractConverter) {
        if (abstractConverter instanceof PowerOfIntConverter) {
            return ((PowerOfIntConverter) abstractConverter).base == this.base;
        }
        return abstractConverter instanceof RationalConverter;
    }

    @Override // java.lang.Comparable
    public int compareTo(UnitConverter unitConverter) {
        if (this == unitConverter) {
            return 0;
        }
        if (isIdentity() && unitConverter.isIdentity()) {
            return 0;
        }
        if (!(unitConverter instanceof PowerOfIntConverter)) {
            return PowerOfIntConverter.class.getName().compareTo(unitConverter.getClass().getName());
        }
        PowerOfIntConverter powerOfIntConverter = (PowerOfIntConverter) unitConverter;
        int iCompare = Integer.compare(this.base, powerOfIntConverter.base);
        return iCompare != 0 ? iCompare : Integer.compare(this.exponent, powerOfIntConverter.exponent);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public Number convertWhenNotIdentity(Number number) {
        return Calculator.m17692of(this.rationalFactor).multiply(number).peek();
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof UnitConverter) {
            UnitConverter unitConverter = (UnitConverter) obj;
            if (isIdentity() && unitConverter.isIdentity()) {
                return true;
            }
        }
        if (obj instanceof PowerOfIntConverter) {
            PowerOfIntConverter powerOfIntConverter = (PowerOfIntConverter) obj;
            if (this.base == powerOfIntConverter.base && this.exponent == powerOfIntConverter.exponent) {
                return true;
            }
        }
        return false;
    }

    @Override // java.util.function.DoubleSupplier
    public double getAsDouble() {
        return this.rationalFactor.doubleValue();
    }

    public int getBase() {
        return this.base;
    }

    public int getExponent() {
        return this.exponent;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public int hashCode() {
        return this.hashCode;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public AbstractConverter inverseWhenNotIdentity() {
        return new PowerOfIntConverter(this.base, -this.exponent);
    }

    @Override // javax.measure.UnitConverter
    public boolean isIdentity() {
        return this.base == 1 || this.exponent == 0;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public AbstractConverter reduce(AbstractConverter abstractConverter) {
        if (abstractConverter instanceof PowerOfIntConverter) {
            PowerOfIntConverter powerOfIntConverter = (PowerOfIntConverter) abstractConverter;
            if (this.base == powerOfIntConverter.base) {
                return composeSameBaseNonIdentity(powerOfIntConverter);
            }
        }
        if (abstractConverter instanceof RationalConverter) {
            return (AbstractConverter) toRationalConverter().concatenate(abstractConverter);
        }
        throw new IllegalStateException(String.format("%s.simpleCompose() not handled for converter %s", this, abstractConverter));
    }

    public RationalConverter toRationalConverter() {
        return new RationalConverter(this.rationalFactor);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public final String transformationLiteral() {
        int i = this.base;
        int i2 = this.exponent;
        return i < 0 ? z23.m20927i(i, i2, "x -> x * (", ")^") : z23.m20927i(i, i2, "x -> x * ", "^");
    }

    @Override // tech.units.indriya.function.MultiplyConverter, p000.w8b
    public Number getValue() {
        return this.rationalFactor;
    }

    /* JADX INFO: renamed from: of */
    public static PowerOfIntConverter m17679of(int i, int i2) {
        return new PowerOfIntConverter(i, i2);
    }

    /* JADX INFO: renamed from: of */
    public static PowerOfIntConverter m17680of(Number number, int i) {
        return new PowerOfIntConverter(number.intValue(), i);
    }
}
