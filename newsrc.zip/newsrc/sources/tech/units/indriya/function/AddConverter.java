package tech.units.indriya.function;

import java.util.Objects;
import javax.measure.UnitConverter;
import p000.w8b;
import tech.units.indriya.internal.function.Calculator;
import tech.units.indriya.spi.NumberSystem;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class AddConverter extends AbstractConverter implements w8b {
    private static final long serialVersionUID = -2981335308595652284L;
    private final Number offset;

    public AddConverter(Number number) {
        this.offset = Calculus.currentNumberSystem().narrow(number);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean canReduceWith(AbstractConverter abstractConverter) {
        return abstractConverter instanceof AddConverter;
    }

    @Override // java.lang.Comparable
    public int compareTo(UnitConverter unitConverter) {
        if (this == unitConverter) {
            return 0;
        }
        if (unitConverter instanceof AddConverter) {
            return Calculus.currentNumberSystem().compare(getValue(), ((AddConverter) unitConverter).getValue());
        }
        return -1;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public Number convertWhenNotIdentity(Number number) {
        return Calculator.m17692of(this.offset).add(number).peek();
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof AddConverter) {
            return Objects.equals(this.offset, ((AddConverter) obj).offset);
        }
        return false;
    }

    public Number getOffset() {
        return this.offset;
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public int hashCode() {
        return Objects.hashCode(this.offset);
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public AddConverter inverseWhenNotIdentity() {
        return new AddConverter(Calculus.currentNumberSystem().negate(this.offset));
    }

    @Override // javax.measure.UnitConverter
    public boolean isIdentity() {
        return Calculus.currentNumberSystem().isZero(this.offset);
    }

    @Override // javax.measure.UnitConverter
    public boolean isLinear() {
        return isIdentity();
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public AbstractConverter reduce(AbstractConverter abstractConverter) {
        return new AddConverter(Calculus.currentNumberSystem().add(this.offset, ((AddConverter) abstractConverter).offset));
    }

    @Override // tech.units.indriya.function.AbstractConverter
    public String transformationLiteral() {
        NumberSystem numberSystemCurrentNumberSystem = Calculus.currentNumberSystem();
        return String.format("x -> x %s %s", numberSystemCurrentNumberSystem.signum(this.offset) < 0 ? "-" : "+", numberSystemCurrentNumberSystem.abs(this.offset));
    }

    @Override // p000.w8b
    public Number getValue() {
        return this.offset;
    }
}
