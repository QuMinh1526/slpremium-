package tech.units.indriya.function;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Objects;
import p000.C1521v3;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class RationalNumber extends Number {
    public static char DIVISION_CHARACTER = 247;
    private static final long serialVersionUID = 1;
    private final Object $lock1 = new Object[0];
    private final Object $lock2 = new Object[0];
    private final BigInteger absDividend;
    private final BigInteger absDivisor;
    private transient BigDecimal divisionResult;
    private final int hashCode;
    private final boolean isInteger;
    private transient Long longValue;
    private final int signum;
    public static final RationalNumber ZERO = ofInteger(BigInteger.ZERO);
    public static final RationalNumber ONE = ofInteger(BigInteger.ONE);

    private RationalNumber(int i, BigInteger bigInteger, BigInteger bigInteger2) {
        this.signum = i;
        this.absDividend = bigInteger;
        this.absDivisor = bigInteger2;
        this.hashCode = Objects.hash(Integer.valueOf(i), bigInteger, bigInteger2);
        this.isInteger = BigInteger.ONE.equals(bigInteger2);
    }

    private String layoutChars(boolean z, char c) {
        if (this.signum == 0) {
            return "0";
        }
        if (this.isInteger) {
            return getDividend().toString();
        }
        if (!z) {
            return String.valueOf(bigDecimalValue());
        }
        return getDividend().toString() + c + this.absDivisor;
    }

    /* JADX INFO: renamed from: of */
    public static RationalNumber m17691of(BigInteger bigInteger, BigInteger bigInteger2) {
        Objects.requireNonNull(bigInteger);
        Objects.requireNonNull(bigInteger2);
        if (BigInteger.ONE.equals(bigInteger2)) {
            return ofInteger(bigInteger);
        }
        if (BigInteger.ZERO.equals(bigInteger2)) {
            C1521v3.m18903j("cannot initalize a rational number with divisor equal to ZERO");
            return null;
        }
        int iSignum = bigInteger2.signum() * bigInteger.signum();
        if (iSignum == 0) {
            return ZERO;
        }
        BigInteger bigIntegerAbs = bigInteger.abs();
        BigInteger bigIntegerAbs2 = bigInteger2.abs();
        BigInteger bigIntegerGcd = bigIntegerAbs.gcd(bigIntegerAbs2);
        return new RationalNumber(iSignum, bigIntegerAbs.divide(bigIntegerGcd), bigIntegerAbs2.divide(bigIntegerGcd));
    }

    public static RationalNumber ofInteger(BigInteger bigInteger) {
        Objects.requireNonNull(bigInteger);
        return new RationalNumber(bigInteger.signum(), bigInteger.abs(), BigInteger.ONE);
    }

    public RationalNumber abs() {
        return this.signum < 0 ? new RationalNumber(1, this.absDividend, this.absDivisor) : this;
    }

    public RationalNumber add(RationalNumber rationalNumber) {
        BigInteger bigIntegerNegate = this.absDividend;
        BigInteger bigInteger = this.absDivisor;
        BigInteger bigIntegerNegate2 = rationalNumber.absDividend;
        BigInteger bigInteger2 = rationalNumber.absDivisor;
        if (this.signum < 0) {
            bigIntegerNegate = bigIntegerNegate.negate();
        }
        if (rationalNumber.signum < 0) {
            bigIntegerNegate2 = bigIntegerNegate2.negate();
        }
        return m17691of(bigIntegerNegate.multiply(bigInteger2).add(bigInteger.multiply(bigIntegerNegate2)), bigInteger.multiply(bigInteger2));
    }

    public BigDecimal bigDecimalValue() {
        synchronized (this.$lock1) {
            try {
                if (this.divisionResult == null) {
                    BigDecimal bigDecimalDivide = new BigDecimal(this.absDividend).divide(new BigDecimal(this.absDivisor), Calculus.MATH_CONTEXT);
                    this.divisionResult = bigDecimalDivide;
                    if (this.signum < 0) {
                        this.divisionResult = bigDecimalDivide.negate();
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return this.divisionResult;
    }

    public int compareTo(RationalNumber rationalNumber) {
        int iCompare = Integer.compare(this.signum, rationalNumber.signum);
        if (iCompare != 0) {
            return iCompare;
        }
        if (iCompare == 0 && this.signum == 0) {
            return 0;
        }
        int iCompareTo = this.absDividend.multiply(rationalNumber.absDivisor).compareTo(this.absDivisor.multiply(rationalNumber.absDividend));
        return this.signum > 0 ? iCompareTo : -iCompareTo;
    }

    public RationalNumber divide(RationalNumber rationalNumber) {
        return multiply(rationalNumber.reciprocal());
    }

    @Override // java.lang.Number
    public double doubleValue() {
        return bigDecimalValue().doubleValue();
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof RationalNumber) {
            return Objects.equals(bigDecimalValue(), ((RationalNumber) obj).bigDecimalValue());
        }
        return false;
    }

    @Override // java.lang.Number
    public float floatValue() {
        return (float) doubleValue();
    }

    public BigInteger getDividend() {
        int i = this.signum;
        BigInteger bigInteger = this.absDividend;
        return i < 0 ? bigInteger.negate() : bigInteger;
    }

    public BigInteger getDivisor() {
        return this.absDivisor;
    }

    public int hashCode() {
        return this.hashCode;
    }

    @Override // java.lang.Number
    public int intValue() {
        return (int) longValue();
    }

    public boolean isInteger() {
        return this.isInteger;
    }

    @Override // java.lang.Number
    public long longValue() {
        synchronized (this.$lock2) {
            try {
                if (this.longValue == null) {
                    int iSignum = signum();
                    BigInteger bigInteger = this.absDividend;
                    this.longValue = Long.valueOf(iSignum < 0 ? bigInteger.negate().divide(this.absDivisor).longValue() : bigInteger.divide(this.absDivisor).longValue());
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return this.longValue.longValue();
    }

    public RationalNumber multiply(RationalNumber rationalNumber) {
        int i = this.signum * rationalNumber.signum;
        if (i == 0) {
            return ZERO;
        }
        BigInteger bigInteger = this.absDividend;
        BigInteger bigInteger2 = this.absDivisor;
        BigInteger bigInteger3 = rationalNumber.absDividend;
        BigInteger bigInteger4 = rationalNumber.absDivisor;
        BigInteger bigIntegerMultiply = bigInteger.multiply(bigInteger3);
        BigInteger bigIntegerMultiply2 = bigInteger2.multiply(bigInteger4);
        BigInteger bigIntegerGcd = bigIntegerMultiply.gcd(bigIntegerMultiply2);
        return new RationalNumber(i, bigIntegerMultiply.divide(bigIntegerGcd), bigIntegerMultiply2.divide(bigIntegerGcd));
    }

    public RationalNumber negate() {
        return new RationalNumber(-this.signum, this.absDividend, this.absDivisor);
    }

    public RationalNumber pow(int i) {
        int i2 = this.signum;
        if (i == 0) {
            if (i2 != 0) {
                return ONE;
            }
            throw new ArithmeticException("0^0 is not defined");
        }
        if (i2 == 0) {
            return ZERO;
        }
        int i3 = 1;
        boolean z = (i & 1) == 0;
        if (i2 < 0 && !z) {
            i3 = -1;
        }
        return i > 0 ? new RationalNumber(i3, this.absDividend.pow(i), this.absDivisor.pow(i)) : new RationalNumber(i3, this.absDivisor.pow(i), this.absDividend.pow(i));
    }

    public RationalNumber reciprocal() {
        return new RationalNumber(this.signum, this.absDivisor, this.absDividend);
    }

    public int signum() {
        return this.signum;
    }

    public RationalNumber subtract(RationalNumber rationalNumber) {
        return add(rationalNumber.negate());
    }

    public String toRationalString() {
        return layoutChars(true, DIVISION_CHARACTER);
    }

    public String toString() {
        return layoutChars(false, DIVISION_CHARACTER);
    }

    public String toRationalString(char c) {
        return layoutChars(true, c);
    }

    public static RationalNumber ofInteger(long j) {
        return ofInteger(BigInteger.valueOf(j));
    }

    /* JADX INFO: renamed from: of */
    public static RationalNumber m17688of(double d) {
        return m17690of(BigDecimal.valueOf(d));
    }

    /* JADX INFO: renamed from: of */
    public static RationalNumber m17690of(BigDecimal bigDecimal) {
        Objects.requireNonNull(bigDecimal);
        int iScale = bigDecimal.scale();
        if (iScale <= 0) {
            return ofInteger(bigDecimal.toBigIntegerExact());
        }
        return m17691of(bigDecimal.unscaledValue(), BigInteger.TEN.pow(iScale));
    }

    /* JADX INFO: renamed from: of */
    public static RationalNumber m17689of(long j, long j2) {
        return m17691of(BigInteger.valueOf(j), BigInteger.valueOf(j2));
    }
}
