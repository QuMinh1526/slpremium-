package tech.units.indriya;

import java.io.Serializable;
import javax.measure.Quantity;
import javax.measure.Unit;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public interface ComparableQuantity<Q extends Quantity<Q>> extends Quantity<Q>, Comparable<Quantity<Q>>, Serializable {
    @Override // javax.measure.Quantity
    ComparableQuantity<Q> add(Quantity<Q> quantity);

    @Override // javax.measure.Quantity
    <T extends Quantity<T>> ComparableQuantity<T> asType(Class<T> cls);

    @Override // javax.measure.Quantity
    ComparableQuantity<Q> divide(Number number);

    @Override // javax.measure.Quantity
    ComparableQuantity<?> divide(Quantity<?> quantity);

    <T extends Quantity<T>, E extends Quantity<E>> ComparableQuantity<E> divide(Quantity<T> quantity, Class<E> cls);

    @Override // javax.measure.Quantity
    ComparableQuantity<?> inverse();

    <T extends Quantity<T>> ComparableQuantity<T> inverse(Class<T> cls);

    boolean isGreaterThan(Quantity<Q> quantity);

    boolean isGreaterThanOrEqualTo(Quantity<Q> quantity);

    boolean isLessThan(Quantity<Q> quantity);

    boolean isLessThanOrEqualTo(Quantity<Q> quantity);

    @Override // javax.measure.Quantity
    ComparableQuantity<Q> multiply(Number number);

    @Override // javax.measure.Quantity
    ComparableQuantity<?> multiply(Quantity<?> quantity);

    <T extends Quantity<T>, E extends Quantity<E>> ComparableQuantity<E> multiply(Quantity<T> quantity, Class<E> cls);

    @Override // javax.measure.Quantity
    ComparableQuantity<Q> subtract(Quantity<Q> quantity);

    @Override // javax.measure.Quantity
    /* JADX INFO: renamed from: to */
    ComparableQuantity<Q> mo11214to(Unit<Q> unit);

    @Override // javax.measure.Quantity
    /* bridge */ /* synthetic */ default Quantity divide(Quantity quantity) {
        return divide((Quantity<?>) quantity);
    }

    @Override // javax.measure.Quantity
    /* bridge */ /* synthetic */ default Quantity multiply(Quantity quantity) {
        return multiply((Quantity<?>) quantity);
    }
}
