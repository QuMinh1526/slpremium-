package tech.units.indriya.spi;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.measure.spi.SystemOfUnits;
import javax.measure.spi.SystemOfUnitsService;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class AbstractSystemOfUnitsService implements SystemOfUnitsService {
    protected final Map<String, SystemOfUnits> souMap = new ConcurrentHashMap();

    @Override // javax.measure.spi.SystemOfUnitsService
    public Collection<SystemOfUnits> getAvailableSystemsOfUnits() {
        return this.souMap.values();
    }

    @Override // javax.measure.spi.SystemOfUnitsService
    public SystemOfUnits getSystemOfUnits(String str) {
        return this.souMap.get(str);
    }
}
