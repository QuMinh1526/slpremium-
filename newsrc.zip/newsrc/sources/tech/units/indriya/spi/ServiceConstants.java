package tech.units.indriya.spi;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
interface ServiceConstants {
    public static final int DEFAULT_PRIO = 10;
    public static final String DEFAULT_PROVIDER_NAME = "Default";
}
