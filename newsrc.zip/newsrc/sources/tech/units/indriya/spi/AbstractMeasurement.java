package tech.units.indriya.spi;

import java.time.Instant;
import javax.measure.Quantity;
import javax.measure.Unit;
import p000.wx5;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.ComparableQuantity;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
abstract class AbstractMeasurement<Q extends Quantity<Q>> implements Measurement<Q>, Comparable<Measurement<Q>> {
    private static final long serialVersionUID = 2417644773551236879L;
    private final Instant instant;
    private final Quantity<Q> quantity;

    public AbstractMeasurement(Quantity<Q> quantity, Instant instant) {
        this.quantity = quantity;
        this.instant = instant;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        AbstractMeasurement abstractMeasurement = (AbstractMeasurement) obj;
        return this.quantity.equals(abstractMeasurement.quantity) && this.instant.equals(abstractMeasurement.instant);
    }

    @Override // tech.units.indriya.spi.Measurement
    public final Instant getInstant() {
        return this.instant;
    }

    @Override // tech.units.indriya.spi.Measurement
    public Quantity<Q> getQuantity() {
        return this.quantity;
    }

    @Override // tech.units.indriya.spi.Measurement
    public final long getTimestamp() {
        return this.instant.toEpochMilli();
    }

    public int hashCode() {
        return this.instant.hashCode() + (this.quantity.hashCode() * 31);
    }

    public String toString() {
        return "Measurement{quantity=" + this.quantity + ", instant=" + this.instant + '}';
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class Default<Q extends Quantity<Q>> extends AbstractMeasurement<Q> {
        private static final long serialVersionUID = 823899472806334856L;

        public Default(Quantity quantity, Instant instant) {
            super(quantity, instant);
        }

        @Override // java.lang.Comparable
        public int compareTo(Measurement<Q> measurement) {
            int i = 6;
            if (!(getQuantity().getUnit() instanceof AbstractUnit)) {
                if (wx5.f46183i == null) {
                    wx5.f46183i = new wx5(i);
                }
                wx5 wx5Var = wx5.f46183i;
                Number value = getQuantity().getValue();
                Number value2 = measurement.getQuantity().getValue();
                wx5Var.getClass();
                return getInstant().compareTo(measurement.getInstant()) + wx5.m19785b(value, value2);
            }
            int iCompareTo = ((AbstractUnit) getQuantity().getUnit()).compareTo((Unit) measurement.getQuantity().getUnit());
            if (wx5.f46183i == null) {
                wx5.f46183i = new wx5(i);
            }
            wx5 wx5Var2 = wx5.f46183i;
            Number value3 = getQuantity().getValue();
            Number value4 = measurement.getQuantity().getValue();
            wx5Var2.getClass();
            return getInstant().compareTo(measurement.getInstant()) + wx5.m19785b(value3, value4) + iCompareTo;
        }

        public Default(Quantity quantity, long j) {
            super(quantity, j);
        }

        public Default(Quantity quantity) {
            super(quantity);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class DefaultComparable<Q extends Quantity<Q>> extends AbstractMeasurement<Q> {
        private static final long serialVersionUID = -175450754835481596L;

        public DefaultComparable(ComparableQuantity comparableQuantity, Instant instant) {
            super(comparableQuantity, instant);
        }

        @Override // java.lang.Comparable
        public int compareTo(Measurement<Q> measurement) {
            if (!(measurement instanceof DefaultComparable)) {
                return 0;
            }
            return getInstant().compareTo(measurement.getInstant()) + getQuantity().compareTo(measurement.getQuantity());
        }

        @Override // tech.units.indriya.spi.AbstractMeasurement, tech.units.indriya.spi.Measurement
        public ComparableQuantity<Q> getQuantity() {
            return (ComparableQuantity) super.getQuantity();
        }

        public DefaultComparable(ComparableQuantity comparableQuantity, long j) {
            super(comparableQuantity, j);
        }

        public DefaultComparable(ComparableQuantity comparableQuantity) {
            super(comparableQuantity);
        }
    }

    public AbstractMeasurement(Quantity<Q> quantity, long j) {
        this(quantity, Instant.ofEpochMilli(j));
    }

    public AbstractMeasurement(Quantity<Q> quantity) {
        this(quantity, System.currentTimeMillis());
    }
}
