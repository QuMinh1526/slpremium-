package tech.units.indriya.spi;

import com.squareup.picasso.BuildConfig;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.spi.LocaleServiceProvider;
import p000.C1521v3;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class UnitNameProvider extends LocaleServiceProvider {
    public String getDisplayName(String str, Locale locale) {
        if (str == null || locale == null) {
            throw null;
        }
        char[] charArray = str.toCharArray();
        if (charArray.length != 3) {
            C1521v3.m18903j("The unitCode is not in the form of three upper-case letters.");
            return null;
        }
        for (char c : charArray) {
            if (c < 'A' || c > 'Z') {
                C1521v3.m18903j("The unit is not in the form of three upper-case letters.");
                return null;
            }
        }
        ResourceBundle.Control noFallbackControl = ResourceBundle.Control.getNoFallbackControl(ResourceBundle.Control.FORMAT_DEFAULT);
        for (Locale locale2 : getAvailableLocales()) {
            if (noFallbackControl.getCandidateLocales(BuildConfig.VERSION_NAME, locale2).contains(locale)) {
                return null;
            }
        }
        C1521v3.m18903j("The locale is not available");
        return null;
    }

    public abstract String getSymbol(String str, Locale locale);
}
