package tech.units.indriya.spi;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public interface NumberSystem {

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class DivisionResult {
        public final Number quotient;
        public final Number remainder;

        private DivisionResult(Number number, Number number2) {
            this.quotient = number;
            this.remainder = number2;
        }

        /* JADX INFO: renamed from: of */
        public static DivisionResult m17744of(Number number, Number number2) {
            return new DivisionResult(number, number2);
        }
    }

    Number abs(Number number);

    Number add(Number number, Number number2);

    int compare(Number number, Number number2);

    Number divide(Number number, Number number2);

    Number[] divideAndRemainder(Number number, Number number2, boolean z);

    default boolean equals(Number number, Number number2) {
        if (number == number2) {
            return true;
        }
        if (number.getClass().equals(number2.getClass())) {
            return number.equals(number2);
        }
        return false;
    }

    Number exp(Number number);

    boolean isInteger(Number number);

    boolean isLessThanOne(Number number);

    boolean isOne(Number number);

    boolean isZero(Number number);

    Number log(Number number);

    Number multiply(Number number, Number number2);

    Number narrow(Number number);

    Number negate(Number number);

    Number power(Number number, int i);

    Number reciprocal(Number number);

    int signum(Number number);

    Number subtract(Number number, Number number2);
}
