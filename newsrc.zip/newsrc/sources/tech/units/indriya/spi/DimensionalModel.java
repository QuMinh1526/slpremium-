package tech.units.indriya.spi;

import java.util.Map;
import javax.measure.Dimension;
import tech.units.indriya.function.AbstractConverter;
import tech.units.indriya.unit.UnitDimension;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class DimensionalModel {
    private static DimensionalModel currentModel = new StandardModel();

    public static DimensionalModel current() {
        return currentModel;
    }

    public static void setCurrent(DimensionalModel dimensionalModel) {
        currentModel = dimensionalModel;
    }

    public AbstractConverter getDimensionalTransform(Dimension dimension) {
        Map<? extends Dimension, Integer> baseDimensions = dimension.getBaseDimensions();
        if (baseDimensions == null) {
            return AbstractConverter.IDENTITY;
        }
        AbstractConverter abstractConverter = AbstractConverter.IDENTITY;
        for (Map.Entry<? extends Dimension, Integer> entry : baseDimensions.entrySet()) {
            AbstractConverter dimensionalTransform = getDimensionalTransform(entry.getKey());
            if (!dimensionalTransform.isLinear()) {
                throw new UnsupportedOperationException("cannot use " + dimensionalTransform + " for dimensional transform, because " + dimensionalTransform + " is NOT a linear transformation (a linear function without offset)");
            }
            int iIntValue = entry.getValue().intValue();
            if (iIntValue < 0) {
                iIntValue = -iIntValue;
                dimensionalTransform = dimensionalTransform.inverse();
            }
            for (int i = 0; i < iIntValue; i++) {
                abstractConverter = (AbstractConverter) abstractConverter.concatenate(dimensionalTransform);
            }
        }
        return abstractConverter;
    }

    public Dimension getFundamentalDimension(Dimension dimension) {
        Map<? extends Dimension, Integer> baseDimensions = dimension.getBaseDimensions();
        if (baseDimensions == null) {
            return dimension;
        }
        Dimension dimensionPow = UnitDimension.NONE;
        for (Map.Entry<? extends Dimension, Integer> entry : baseDimensions.entrySet()) {
            dimensionPow = dimensionPow.multiply(getFundamentalDimension(entry.getKey())).pow(entry.getValue().intValue());
        }
        return dimensionPow;
    }
}
