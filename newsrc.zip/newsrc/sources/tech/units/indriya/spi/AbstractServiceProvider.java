package tech.units.indriya.spi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.ServiceLoader;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.measure.Quantity;
import javax.measure.spi.FormatService;
import javax.measure.spi.QuantityFactory;
import javax.measure.spi.ServiceProvider;
import javax.measure.spi.SystemOfUnitsService;
import p000.C0004a3;
import tech.units.indriya.quantity.DefaultQuantityFactory;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class AbstractServiceProvider extends ServiceProvider implements Comparable<ServiceProvider> {
    private static final Comparator<Object> SERVICE_COMPARATOR = new C0004a3(0);
    private final Map<Class, List<Object>> servicesLoaded = new ConcurrentHashMap();
    private final Map<Class, QuantityFactory> QUANTITY_FACTORIES = new ConcurrentHashMap();

    /* JADX INFO: Access modifiers changed from: private */
    public static int compareServices(Object obj, Object obj2) {
        return obj2.getClass().getSimpleName().compareTo(obj.getClass().getSimpleName());
    }

    private <T> List<T> loadServices(Class<T> cls) {
        ArrayList arrayList = new ArrayList();
        try {
            Iterator it = ServiceLoader.load(cls).iterator();
            while (it.hasNext()) {
                arrayList.add(it.next());
            }
            Collections.sort(arrayList, SERVICE_COMPARATOR);
            List<Object> listPutIfAbsent = this.servicesLoaded.putIfAbsent(cls, arrayList);
            if (listPutIfAbsent == null) {
                listPutIfAbsent = arrayList;
            }
            return Collections.unmodifiableList(listPutIfAbsent);
        } catch (Exception e) {
            Logger.getLogger(AbstractServiceProvider.class.getName()).log(Level.WARNING, "Error loading services of type " + cls, (Throwable) e);
            Collections.sort(arrayList, SERVICE_COMPARATOR);
            return arrayList;
        }
    }

    @Override // java.lang.Comparable
    public int compareTo(ServiceProvider serviceProvider) {
        return Integer.compare(getPriority(), serviceProvider.getPriority());
    }

    @Override // javax.measure.spi.ServiceProvider
    public FormatService getFormatService() {
        return (FormatService) getService(FormatService.class);
    }

    @Override // javax.measure.spi.ServiceProvider
    public final <Q extends Quantity<Q>> QuantityFactory<Q> getQuantityFactory(Class<Q> cls) {
        Objects.requireNonNull(cls);
        if (!this.QUANTITY_FACTORIES.containsKey(cls)) {
            synchronized (this.QUANTITY_FACTORIES) {
                this.QUANTITY_FACTORIES.put(cls, DefaultQuantityFactory.getInstance(cls));
            }
        }
        return this.QUANTITY_FACTORIES.get(cls);
    }

    public <T> T getService(Class<T> cls) {
        List<T> services = getServices(cls);
        if (services.isEmpty()) {
            return null;
        }
        return services.get(0);
    }

    public <T> List<T> getServices(Class<T> cls) {
        List<T> list = (List) this.servicesLoaded.get(cls);
        return list != null ? list : loadServices(cls);
    }

    @Override // javax.measure.spi.ServiceProvider
    public SystemOfUnitsService getSystemOfUnitsService() {
        return (SystemOfUnitsService) getService(SystemOfUnitsService.class);
    }

    public abstract String toString();
}
