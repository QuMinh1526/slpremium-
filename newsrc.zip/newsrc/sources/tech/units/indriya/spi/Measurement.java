package tech.units.indriya.spi;

import java.io.Serializable;
import java.time.Instant;
import javax.measure.Quantity;
import tech.units.indriya.ComparableQuantity;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public interface Measurement<Q extends Quantity<Q>> extends Serializable {
    /* JADX INFO: renamed from: of */
    static <Q extends Quantity<Q>> Measurement<Q> m17739of(Quantity<Q> quantity) {
        return new AbstractMeasurement.Default(quantity);
    }

    Instant getInstant();

    /* synthetic */ Quantity getQuantity();

    long getTimestamp();

    /* JADX INFO: renamed from: of */
    static <Q extends Quantity<Q>> Measurement<Q> m17741of(Quantity<Q> quantity, Instant instant) {
        return new AbstractMeasurement.Default(quantity, instant);
    }

    /* JADX INFO: renamed from: of */
    static <Q extends Quantity<Q>> Measurement<Q> m17742of(ComparableQuantity<Q> comparableQuantity) {
        return new AbstractMeasurement.DefaultComparable(comparableQuantity);
    }

    /* JADX INFO: renamed from: of */
    static <Q extends Quantity<Q>> Measurement<Q> m17743of(ComparableQuantity<Q> comparableQuantity, Instant instant) {
        return new AbstractMeasurement.DefaultComparable(comparableQuantity, instant);
    }

    /* JADX INFO: renamed from: of */
    static <Q extends Quantity<Q>> Measurement<Q> m17740of(Quantity<Q> quantity, long j) {
        return new AbstractMeasurement.Default(quantity, j);
    }
}
