package tech.units.indriya.unit;

import java.util.Comparator;

/* JADX INFO: renamed from: tech.units.indriya.unit.a */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class C1458a implements Comparator {
    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return ProductUnit.ElementUtil.compare((ProductUnit.Element) obj, (ProductUnit.Element) obj2);
    }
}
