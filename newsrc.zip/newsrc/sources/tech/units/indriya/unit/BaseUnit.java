package tech.units.indriya.unit;

import java.util.Map;
import java.util.Objects;
import javax.measure.Dimension;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.function.AbstractConverter;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class BaseUnit<Q extends Quantity<Q>> extends AbstractUnit<Q> {
    private static final long serialVersionUID = 1721629233768215930L;
    private final Dimension dimension;

    public BaseUnit(String str, String str2, Dimension dimension) {
        super(str);
        setName(str2);
        this.dimension = dimension;
    }

    @Override // tech.units.indriya.AbstractUnit
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || BaseUnit.class != obj.getClass()) {
            return false;
        }
        BaseUnit baseUnit = (BaseUnit) obj;
        return Objects.equals(this.dimension, baseUnit.dimension) && Objects.equals(getSymbol(), baseUnit.getSymbol());
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Map<? extends AbstractUnit<Q>, Integer> getBaseUnits() {
        return null;
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Dimension getDimension() {
        return this.dimension;
    }

    @Override // tech.units.indriya.AbstractUnit
    public UnitConverter getSystemConverter() {
        return AbstractConverter.IDENTITY;
    }

    @Override // tech.units.indriya.AbstractUnit
    public int hashCode() {
        int iHashCode = 31 + (getSymbol() == null ? 0 : getSymbol().hashCode());
        int i = (iHashCode * 31) + iHashCode;
        Dimension dimension = this.dimension;
        return i + (dimension != null ? dimension.hashCode() : 0);
    }

    public BaseUnit(String str) {
        super(str);
        this.dimension = UnitDimension.NONE;
    }

    public BaseUnit(String str, String str2) {
        this(str);
        setName(str2);
    }

    public BaseUnit(String str, Dimension dimension) {
        super(str);
        this.dimension = dimension;
    }

    @Override // tech.units.indriya.AbstractUnit
    public Unit<Q> toSystemUnit() {
        return this;
    }
}
