package tech.units.indriya.unit;

import java.util.Set;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.quantity.Acceleration;
import javax.measure.quantity.AmountOfSubstance;
import javax.measure.quantity.Angle;
import javax.measure.quantity.Area;
import javax.measure.quantity.CatalyticActivity;
import javax.measure.quantity.Dimensionless;
import javax.measure.quantity.ElectricCapacitance;
import javax.measure.quantity.ElectricCharge;
import javax.measure.quantity.ElectricConductance;
import javax.measure.quantity.ElectricCurrent;
import javax.measure.quantity.ElectricInductance;
import javax.measure.quantity.ElectricPotential;
import javax.measure.quantity.ElectricResistance;
import javax.measure.quantity.Energy;
import javax.measure.quantity.Force;
import javax.measure.quantity.Frequency;
import javax.measure.quantity.Illuminance;
import javax.measure.quantity.Length;
import javax.measure.quantity.LuminousFlux;
import javax.measure.quantity.LuminousIntensity;
import javax.measure.quantity.MagneticFlux;
import javax.measure.quantity.MagneticFluxDensity;
import javax.measure.quantity.Mass;
import javax.measure.quantity.Power;
import javax.measure.quantity.Pressure;
import javax.measure.quantity.RadiationDoseAbsorbed;
import javax.measure.quantity.RadiationDoseEffective;
import javax.measure.quantity.Radioactivity;
import javax.measure.quantity.SolidAngle;
import javax.measure.quantity.Speed;
import javax.measure.quantity.Temperature;
import javax.measure.quantity.Time;
import javax.measure.quantity.Volume;
import tech.units.indriya.AbstractSystemOfUnits;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.function.AddConverter;
import tech.units.indriya.function.MultiplyConverter;
import tech.units.indriya.function.RationalNumber;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class Units extends AbstractSystemOfUnits {
    public static final Unit<ElectricCurrent> AMPERE;
    public static final Unit<Radioactivity> BECQUEREL;
    public static final Unit<LuminousIntensity> CANDELA;
    public static final Unit<Temperature> CELSIUS;
    public static final Unit<ElectricCharge> COULOMB;
    public static final Unit<Volume> CUBIC_METRE;
    public static final Unit<Time> DAY;
    public static final Unit<ElectricCapacitance> FARAD;
    public static final Unit<Mass> GRAM;
    public static final Unit<RadiationDoseAbsorbed> GRAY;
    public static final Unit<ElectricInductance> HENRY;
    public static final Unit<Frequency> HERTZ;
    public static final Unit<Time> HOUR;
    private static final Units INSTANCE;
    public static final Unit<Energy> JOULE;
    public static final Unit<CatalyticActivity> KATAL;
    public static final Unit<Temperature> KELVIN;
    public static final Unit<Mass> KILOGRAM;
    public static final Unit<Speed> KILOMETRE_PER_HOUR;
    public static final Unit<Volume> LITRE;
    public static final Unit<LuminousFlux> LUMEN;
    public static final Unit<Illuminance> LUX;
    public static final Unit<Length> METRE;
    public static final Unit<Speed> METRE_PER_SECOND;
    public static final Unit<Acceleration> METRE_PER_SQUARE_SECOND;
    public static final Unit<Time> MINUTE;
    public static final Unit<AmountOfSubstance> MOLE;
    public static final Unit<Time> MONTH;
    public static final Unit<Force> NEWTON;
    public static final Unit<ElectricResistance> OHM;
    public static final Unit<Pressure> PASCAL;
    public static final Unit<Dimensionless> PERCENT;
    public static final Unit<Angle> RADIAN;
    public static final Unit<Time> SECOND;
    public static final Unit<ElectricConductance> SIEMENS;
    public static final Unit<RadiationDoseEffective> SIEVERT;
    public static final Unit<Area> SQUARE_METRE;
    public static final Unit<SolidAngle> STERADIAN;
    public static final Unit<MagneticFluxDensity> TESLA;
    public static final Unit<ElectricPotential> VOLT;
    public static final Unit<Power> WATT;
    public static final Unit<MagneticFlux> WEBER;
    public static final Unit<Time> WEEK;
    public static final Unit<Time> YEAR;

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    static {
        Units units = new Units();
        INSTANCE = units;
        AbstractUnit abstractUnitAddUnit = addUnit(new BaseUnit("A", "Ampere", UnitDimension.ELECTRIC_CURRENT), (Class<? extends Quantity<?>>) ElectricCurrent.class);
        AMPERE = abstractUnitAddUnit;
        AbstractUnit abstractUnitAddUnit2 = addUnit(new BaseUnit("cd", "Candela", UnitDimension.LUMINOUS_INTENSITY), (Class<? extends Quantity<?>>) LuminousIntensity.class);
        CANDELA = abstractUnitAddUnit2;
        AbstractUnit abstractUnitAddUnit3 = addUnit(new BaseUnit("K", "Kelvin", UnitDimension.TEMPERATURE), (Class<? extends Quantity<?>>) Temperature.class);
        KELVIN = abstractUnitAddUnit3;
        AbstractUnit abstractUnitAddUnit4 = addUnit(new BaseUnit("kg", "Kilogram", UnitDimension.MASS), (Class<? extends Quantity<?>>) Mass.class);
        KILOGRAM = abstractUnitAddUnit4;
        AbstractUnit abstractUnitAddUnit5 = addUnit(new BaseUnit("m", "Metre", UnitDimension.LENGTH), (Class<? extends Quantity<?>>) Length.class);
        METRE = abstractUnitAddUnit5;
        AbstractUnit abstractUnitAddUnit6 = addUnit(new BaseUnit("mol", "Mole", UnitDimension.AMOUNT_OF_SUBSTANCE), (Class<? extends Quantity<?>>) AmountOfSubstance.class);
        MOLE = abstractUnitAddUnit6;
        AbstractUnit abstractUnitAddUnit7 = addUnit(new BaseUnit("s", "Second", UnitDimension.TIME), (Class<? extends Quantity<?>>) Time.class);
        SECOND = abstractUnitAddUnit7;
        GRAM = addUnit(units.units, abstractUnitAddUnit4.divide(1000.0d), "Gram");
        Unit unit = AbstractUnit.ONE;
        RADIAN = addUnit(AlternateUnit.m17746of(unit, "rad", "Radian"), (Class<? extends Quantity<?>>) Angle.class);
        AbstractUnit abstractUnitAddUnit8 = addUnit(new AlternateUnit(unit, "sr", "Steradian"), (Class<? extends Quantity<?>>) SolidAngle.class);
        STERADIAN = abstractUnitAddUnit8;
        HERTZ = addUnit(new AlternateUnit(unit.divide(abstractUnitAddUnit7), "Hz", "Hertz"), (Class<? extends Quantity<?>>) Frequency.class);
        AbstractUnit abstractUnitAddUnit9 = addUnit(new AlternateUnit(abstractUnitAddUnit5.multiply(abstractUnitAddUnit4).divide(abstractUnitAddUnit7.pow(2)), "N", "Newton"), (Class<? extends Quantity<?>>) Force.class);
        NEWTON = abstractUnitAddUnit9;
        PASCAL = addUnit(new AlternateUnit(abstractUnitAddUnit9.divide(abstractUnitAddUnit5.pow(2)), "Pa", "Pascal"), (Class<? extends Quantity<?>>) Pressure.class);
        AbstractUnit abstractUnitAddUnit10 = addUnit(new AlternateUnit(abstractUnitAddUnit9.multiply(abstractUnitAddUnit5), "J", "Joule"), (Class<? extends Quantity<?>>) Energy.class);
        JOULE = abstractUnitAddUnit10;
        AbstractUnit abstractUnitAddUnit11 = addUnit(new AlternateUnit(abstractUnitAddUnit10.divide(abstractUnitAddUnit7), "W", "Watt"), (Class<? extends Quantity<?>>) Power.class);
        WATT = abstractUnitAddUnit11;
        AbstractUnit abstractUnitAddUnit12 = addUnit(new AlternateUnit(abstractUnitAddUnit7.multiply(abstractUnitAddUnit), "C", "Coulomb"), (Class<? extends Quantity<?>>) ElectricCharge.class);
        COULOMB = abstractUnitAddUnit12;
        AbstractUnit abstractUnitAddUnit13 = addUnit(new AlternateUnit(abstractUnitAddUnit11.divide(abstractUnitAddUnit), "V", "Volt"), (Class<? extends Quantity<?>>) ElectricPotential.class);
        VOLT = abstractUnitAddUnit13;
        FARAD = addUnit(new AlternateUnit(abstractUnitAddUnit12.divide(abstractUnitAddUnit13), "F", "Farad"), (Class<? extends Quantity<?>>) ElectricCapacitance.class);
        OHM = addUnit(new AlternateUnit(abstractUnitAddUnit13.divide(abstractUnitAddUnit), "Ω", "Ohm"), (Class<? extends Quantity<?>>) ElectricResistance.class);
        SIEMENS = addUnit(new AlternateUnit(abstractUnitAddUnit.divide(abstractUnitAddUnit13), "S", "Siemens"), (Class<? extends Quantity<?>>) ElectricConductance.class);
        AbstractUnit abstractUnitAddUnit14 = addUnit(new AlternateUnit(abstractUnitAddUnit13.multiply(abstractUnitAddUnit7), "Wb", "Weber"), (Class<? extends Quantity<?>>) MagneticFlux.class);
        WEBER = abstractUnitAddUnit14;
        TESLA = addUnit(new AlternateUnit(abstractUnitAddUnit14.divide(abstractUnitAddUnit5.pow(2)), "T", "Tesla"), (Class<? extends Quantity<?>>) MagneticFluxDensity.class);
        HENRY = addUnit(new AlternateUnit(abstractUnitAddUnit14.divide(abstractUnitAddUnit), "H", "Henry"), (Class<? extends Quantity<?>>) ElectricInductance.class);
        CELSIUS = AbstractSystemOfUnits.Helper.addUnit(units.units, new TransformedUnit(abstractUnitAddUnit3, new AddConverter(Double.valueOf(273.15d))), "Celsius", "℃");
        AbstractUnit abstractUnitAddUnit15 = addUnit(new AlternateUnit(abstractUnitAddUnit2.multiply(abstractUnitAddUnit8), "lm", "Lumen"), (Class<? extends Quantity<?>>) LuminousFlux.class);
        LUMEN = abstractUnitAddUnit15;
        LUX = addUnit(new AlternateUnit(abstractUnitAddUnit15.divide(abstractUnitAddUnit5.pow(2)), "lx", "Lux"), (Class<? extends Quantity<?>>) Illuminance.class);
        BECQUEREL = addUnit(new AlternateUnit(unit.divide(abstractUnitAddUnit7), "Bq", "Becquerel"), (Class<? extends Quantity<?>>) Radioactivity.class);
        GRAY = addUnit(new AlternateUnit(abstractUnitAddUnit10.divide(abstractUnitAddUnit4), "Gy", "Gray"), (Class<? extends Quantity<?>>) RadiationDoseAbsorbed.class);
        SIEVERT = addUnit(new AlternateUnit(abstractUnitAddUnit10.divide(abstractUnitAddUnit4), "Sv", "Sievert"), (Class<? extends Quantity<?>>) RadiationDoseEffective.class);
        KATAL = addUnit(new AlternateUnit(abstractUnitAddUnit6.divide(abstractUnitAddUnit7), "kat", "Katal"), (Class<? extends Quantity<?>>) CatalyticActivity.class);
        AbstractUnit abstractUnitAddUnit16 = addUnit(new ProductUnit(abstractUnitAddUnit5.divide(abstractUnitAddUnit7)), "Metre per Second", (Class<? extends Quantity<?>>) Speed.class);
        METRE_PER_SECOND = abstractUnitAddUnit16;
        METRE_PER_SQUARE_SECOND = addUnit(new ProductUnit(abstractUnitAddUnit16.divide(abstractUnitAddUnit7)), "Metre per square second", (Class<? extends Quantity<?>>) Acceleration.class);
        AbstractUnit abstractUnitAddUnit17 = addUnit(new ProductUnit(abstractUnitAddUnit5.multiply(abstractUnitAddUnit5)), "Square metre", (Class<? extends Quantity<?>>) Area.class);
        SQUARE_METRE = abstractUnitAddUnit17;
        AbstractUnit abstractUnitAddUnit18 = addUnit(new ProductUnit(abstractUnitAddUnit17.multiply(abstractUnitAddUnit5)), "Cubic metre", (Class<? extends Quantity<?>>) Volume.class);
        CUBIC_METRE = abstractUnitAddUnit18;
        KILOMETRE_PER_HOUR = addUnit(units.units, abstractUnitAddUnit16.multiply(RationalNumber.m17689of(5L, 18L)), "Kilometre per hour").asType(Speed.class);
        PERCENT = addUnit(new TransformedUnit("%", "Percent", unit, MultiplyConverter.ofRational(1L, 100L)));
        MINUTE = addUnit(new TransformedUnit("min", "Minute", abstractUnitAddUnit7, abstractUnitAddUnit7, MultiplyConverter.ofRational(60L, 1L)));
        HOUR = addUnit(new TransformedUnit("h", "Hour", abstractUnitAddUnit7, abstractUnitAddUnit7, MultiplyConverter.ofRational(3600L, 1L)));
        Unit<Time> unitAddUnit = addUnit(new TransformedUnit("d", "Day", abstractUnitAddUnit7, abstractUnitAddUnit7, MultiplyConverter.ofRational(86400L, 1L)));
        DAY = unitAddUnit;
        WEEK = AbstractSystemOfUnits.Helper.addUnit(units.units, unitAddUnit.multiply(7.0d), "Week", "wk");
        Unit<Time> unitAddUnit2 = AbstractSystemOfUnits.Helper.addUnit(units.units, unitAddUnit.multiply(365.2425d), "Year", "yr");
        YEAR = unitAddUnit2;
        MONTH = AbstractSystemOfUnits.Helper.addUnit(units.units, unitAddUnit2.divide(12.0d), "Month", "mo");
        LITRE = AbstractSystemOfUnits.Helper.addUnit(units.units, new TransformedUnit(abstractUnitAddUnit18, MultiplyConverter.ofRational(1L, 1000L)), "Litre", "l");
        addUnit(units.units, unit);
        AbstractSystemOfUnits.Helper.addUnit(units.units, unit, "One");
        units.quantityToUnit.put(Dimensionless.class, unit);
    }

    public static <U extends Unit<?>> U addUnit(Set<Unit<?>> set, U u, String str) {
        if (str != null && (u instanceof AbstractUnit)) {
            return (U) AbstractSystemOfUnits.Helper.addUnit(set, u, str);
        }
        set.add(u);
        return u;
    }

    public static Units getInstance() {
        return INSTANCE;
    }

    @Override // tech.units.indriya.AbstractSystemOfUnits, javax.measure.spi.SystemOfUnits
    public String getName() {
        return "Units";
    }

    public static <U extends AbstractUnit<?>> U addUnit(Set<Unit<?>> set, U u, String str, String str2) {
        return (U) AbstractSystemOfUnits.Helper.addUnit(set, u, str, str2);
    }

    public static <U extends Unit<?>> U addUnit(Set<Unit<?>> set, U u) {
        set.add(u);
        return u;
    }

    private static <U extends Unit<?>> U addUnit(U u) {
        return (U) addUnit(INSTANCE.units, u);
    }

    private static <U extends AbstractUnit<?>> U addUnit(U u, String str, Class<? extends Quantity<?>> cls) {
        Units units = INSTANCE;
        AbstractSystemOfUnits.Helper.addUnit(units.units, u, str);
        units.quantityToUnit.put(cls, u);
        return u;
    }

    private static <U extends AbstractUnit<?>> U addUnit(U u, Class<? extends Quantity<?>> cls) {
        Units units = INSTANCE;
        units.units.add(u);
        units.quantityToUnit.put(cls, u);
        return u;
    }
}
