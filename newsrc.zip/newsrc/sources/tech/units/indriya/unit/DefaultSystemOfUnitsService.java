package tech.units.indriya.unit;

import javax.measure.spi.SystemOfUnits;
import tech.units.indriya.spi.AbstractSystemOfUnitsService;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class DefaultSystemOfUnitsService extends AbstractSystemOfUnitsService {
    public DefaultSystemOfUnitsService() {
        this.souMap.put("Units", Units.getInstance());
    }

    @Override // javax.measure.spi.SystemOfUnitsService
    public SystemOfUnits getSystemOfUnits() {
        return getSystemOfUnits("Units");
    }
}
