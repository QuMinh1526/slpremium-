package tech.units.indriya.unit;

import com.squareup.picasso.BuildConfig;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import javax.measure.Dimension;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import p000.ug8;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.function.AbstractConverter;
import tech.units.indriya.internal.function.Lazy;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class ProductUnit<Q extends Quantity<Q>> extends AbstractUnit<Q> {
    private static final long serialVersionUID = 962983585531030093L;
    private final Element[] elements;
    private transient Lazy<Integer> hashCode;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class Element implements Serializable {
        private static final long serialVersionUID = 452938412398890507L;
        private final int pow;
        private final int root;
        private final Unit<?> unit;

        private Element(Unit<?> unit, int i, int i2) {
            this.unit = unit;
            this.pow = i;
            this.root = i2;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || Element.class != obj.getClass()) {
                return false;
            }
            Element element = (Element) obj;
            if (Integer.valueOf(this.pow).equals(Integer.valueOf(element.pow)) && Integer.valueOf(this.root).equals(Integer.valueOf(element.root))) {
                return Objects.equals(this.unit, element.unit);
            }
            return false;
        }

        public int getPow() {
            return this.pow;
        }

        public int getRoot() {
            return this.root;
        }

        public Unit<?> getUnit() {
            return this.unit;
        }

        public int hashCode() {
            return Objects.hash(this.unit, Integer.valueOf(this.pow), Integer.valueOf(this.root));
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class ElementUtil {
        private ElementUtil() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static boolean arrayEqualsArbitraryOrder(Element[] elementArr, Element[] elementArr2) {
            if (elementArr.length != elementArr2.length) {
                return false;
            }
            for (Element element : elementArr) {
                for (Element element2 : elementArr2) {
                    if (element.unit.equals(element2.unit)) {
                        if (element.pow != element2.pow || element.root != element2.root) {
                            return false;
                        }
                    }
                }
                return false;
            }
            return true;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static int compare(Element element, Element element2) {
            Unit<Q> systemUnit = element.getUnit().getSystemUnit();
            Unit<Q> systemUnit2 = element2.getUnit().getSystemUnit();
            String symbol = systemUnit.getSymbol();
            String symbol2 = systemUnit2.getSymbol();
            return (symbol == null || symbol2 == null) ? systemUnit.toString().compareTo(systemUnit2.toString()) : symbol.compareTo(symbol2);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static Element[] copyAndSort(Element[] elementArr) {
            if (elementArr == null || elementArr.length <= 1) {
                return elementArr;
            }
            Element[] elementArr2 = (Element[]) Arrays.copyOf(elementArr, elementArr.length);
            Arrays.sort(elementArr2, new C1458a());
            return elementArr2;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class SerializationProxy implements Serializable {
        private static final long serialVersionUID = 1;
        private final Element[] elements;
        private final String symbol;

        private SerializationProxy(ProductUnit<?> productUnit) {
            this.elements = ((ProductUnit) productUnit).elements;
            this.symbol = productUnit.getSymbol();
        }

        private Object readResolve() {
            ProductUnit productUnit = new ProductUnit(this.elements);
            productUnit.setSymbol(this.symbol);
            return productUnit;
        }
    }

    public ProductUnit(Unit<?> unit) {
        super(unit.getSymbol());
        this.hashCode = new Lazy<>(new ug8(this, 0));
        this.elements = ((ProductUnit) unit).elements;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int calculateHashCode() {
        return Objects.hash(ElementUtil.copyAndSort(this.elements));
    }

    private static int gcd(int i, int i2) {
        return i2 == 0 ? i : gcd(i2, i % i2);
    }

    private static Unit<?> getInstance(Element[] elementArr, Element[] elementArr2) {
        int i;
        Element[] elementArr3 = new Element[elementArr.length + elementArr2.length];
        int length = elementArr.length;
        int i2 = 0;
        int i3 = 0;
        while (true) {
            int i4 = 1;
            if (i2 >= length) {
                break;
            }
            Element element = elementArr[i2];
            Unit unit = element.unit;
            int i5 = element.pow;
            int i6 = element.root;
            int length2 = elementArr2.length;
            int i7 = 0;
            while (true) {
                if (i7 >= length2) {
                    i = 0;
                    break;
                }
                Element element2 = elementArr2[i7];
                if (unit.equals(element2.unit)) {
                    i = element2.pow;
                    i4 = element2.root;
                    break;
                }
                i7++;
            }
            int i8 = (i * i6) + (i5 * i4);
            int i9 = i6 * i4;
            if (i8 != 0) {
                int iGcd = gcd(Math.abs(i8), i9);
                elementArr3[i3] = new Element(unit, i8 / iGcd, i9 / iGcd);
                i3++;
            }
            i2++;
        }
        for (Element element3 : elementArr2) {
            Unit unit2 = element3.unit;
            int length3 = elementArr.length;
            int i10 = 0;
            while (true) {
                if (i10 >= length3) {
                    elementArr3[i3] = element3;
                    i3++;
                    break;
                }
                if (unit2.equals(elementArr[i10].unit)) {
                    break;
                }
                i10++;
            }
        }
        if (i3 == 0) {
            return AbstractUnit.ONE;
        }
        if (i3 == 1 && elementArr3[0].pow == elementArr3[0].root) {
            return elementArr3[0].unit;
        }
        Element[] elementArr4 = new Element[i3];
        System.arraycopy(elementArr3, 0, elementArr4, 0, i3);
        return new ProductUnit(elementArr4);
    }

    public static Unit<?> ofPow(Unit<?> unit, int i) {
        Element[] elementArr;
        if (unit instanceof ProductUnit) {
            Element[] elementArr2 = ((ProductUnit) unit).elements;
            elementArr = new Element[elementArr2.length];
            for (int i2 = 0; i2 < elementArr2.length; i2++) {
                int iGcd = gcd(Math.abs(elementArr2[i2].pow * i), elementArr2[i2].root);
                elementArr[i2] = new Element(elementArr2[i2].unit, (elementArr2[i2].pow * i) / iGcd, elementArr2[i2].root / iGcd);
            }
        } else {
            elementArr = new Element[]{new Element(unit, i, 1)};
        }
        return getInstance(elementArr, new Element[0]);
    }

    public static Unit<?> ofProduct(Unit<?> unit, Unit<?> unit2) {
        int i = 1;
        return getInstance(unit instanceof ProductUnit ? ((ProductUnit) unit).elements : new Element[]{new Element(unit, i, i)}, unit2 instanceof ProductUnit ? ((ProductUnit) unit2).elements : new Element[]{new Element(unit2, i, i)});
    }

    public static Unit<?> ofQuotient(Unit<?> unit, Unit<?> unit2) {
        Element[] elementArr;
        int i = 1;
        Element[] elementArr2 = unit instanceof ProductUnit ? ((ProductUnit) unit).elements : new Element[]{new Element(unit, i, i)};
        if (unit2 instanceof ProductUnit) {
            Element[] elementArr3 = ((ProductUnit) unit2).elements;
            elementArr = new Element[elementArr3.length];
            for (int i2 = 0; i2 < elementArr3.length; i2++) {
                elementArr[i2] = new Element(elementArr3[i2].unit, -elementArr3[i2].pow, elementArr3[i2].root);
            }
        } else {
            elementArr = new Element[]{new Element(unit2, -1, i)};
        }
        return getInstance(elementArr2, elementArr);
    }

    public static Unit<?> ofRoot(Unit<?> unit, int i) {
        Element[] elementArr;
        if (unit instanceof ProductUnit) {
            Element[] elementArr2 = ((ProductUnit) unit).elements;
            elementArr = new Element[elementArr2.length];
            for (int i2 = 0; i2 < elementArr2.length; i2++) {
                int iGcd = gcd(Math.abs(elementArr2[i2].pow), elementArr2[i2].root * i);
                elementArr[i2] = new Element(elementArr2[i2].unit, elementArr2[i2].pow / iGcd, (elementArr2[i2].root * i) / iGcd);
            }
        } else {
            elementArr = new Element[]{new Element(unit, 1, i)};
        }
        return getInstance(elementArr, new Element[0]);
    }

    private void readObject(ObjectInputStream objectInputStream) throws InvalidObjectException {
        throw new InvalidObjectException("Proxy required");
    }

    private Object writeReplace() {
        return new SerializationProxy();
    }

    @Override // tech.units.indriya.AbstractUnit
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof ProductUnit) {
            return ElementUtil.arrayEqualsArbitraryOrder(this.elements, ((ProductUnit) obj).elements);
        }
        return false;
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Map<Unit<?>, Integer> getBaseUnits() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (int i = 0; i < getUnitCount(); i++) {
            linkedHashMap.put(getUnit(i), Integer.valueOf(getUnitPow(i)));
        }
        return linkedHashMap;
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Dimension getDimension() {
        Dimension dimensionMultiply = UnitDimension.NONE;
        for (int i = 0; i < getUnitCount(); i++) {
            Unit<?> unit = getUnit(i);
            if (this.elements != null && unit.getDimension() != null) {
                dimensionMultiply = dimensionMultiply.multiply(unit.getDimension().pow(getUnitPow(i)).root(getUnitRoot(i)));
            }
        }
        return dimensionMultiply;
    }

    @Override // tech.units.indriya.AbstractUnit
    public UnitConverter getSystemConverter() {
        UnitConverter unitConverterConcatenate = AbstractConverter.IDENTITY;
        for (Element element : this.elements) {
            if (element.unit instanceof AbstractUnit) {
                UnitConverter systemConverter = ((AbstractUnit) element.unit).getSystemConverter();
                if (!Quantity.Scale.RELATIVE.equals(this.scale) && !systemConverter.isLinear()) {
                    StringBuilder sb = new StringBuilder("cannot compose ");
                    sb.append(element.unit);
                    Unit unit = element.unit;
                    sb.append(" into a product converter, because ");
                    sb.append(unit);
                    sb.append(" holds a system converter that is NOT a linear transformation (a linear function without offset)");
                    throw new UnsupportedOperationException(sb.toString());
                }
                if (element.root != 1) {
                    StringBuilder sb2 = new StringBuilder("cannot compose ");
                    sb2.append(element.unit);
                    Unit unit2 = element.unit;
                    sb2.append(" into a product converter, because ");
                    sb2.append(unit2);
                    sb2.append(" holds a base unit with exponent not equal to 1");
                    throw new UnsupportedOperationException(sb2.toString());
                }
                int i = element.pow;
                if (i < 0) {
                    i = -i;
                    systemConverter = systemConverter.inverse();
                }
                for (int i2 = 0; i2 < i; i2++) {
                    unitConverterConcatenate = unitConverterConcatenate.concatenate(systemConverter);
                }
            }
        }
        return unitConverterConcatenate;
    }

    public Unit<?> getUnit(int i) {
        return this.elements[i].getUnit();
    }

    public int getUnitCount() {
        return this.elements.length;
    }

    public int getUnitPow(int i) {
        return this.elements[i].getPow();
    }

    public int getUnitRoot(int i) {
        return this.elements[i].getRoot();
    }

    @Override // tech.units.indriya.AbstractUnit
    public int hashCode() {
        return this.hashCode.get().intValue();
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Unit<?> pow(int i) {
        return ofPow(this, i);
    }

    @Override // tech.units.indriya.AbstractUnit
    public Unit<Q> toSystemUnit() {
        Unit unitMultiply = AbstractUnit.ONE;
        for (Element element : this.elements) {
            unitMultiply = unitMultiply.multiply(element.unit.getSystemUnit().pow(element.pow).root(element.root));
        }
        return (AbstractUnit) unitMultiply;
    }

    public ProductUnit() {
        super(BuildConfig.VERSION_NAME);
        this.hashCode = new Lazy<>(new ug8(this, 0));
        this.elements = new Element[0];
    }

    private ProductUnit(Element[] elementArr) {
        super(null);
        this.hashCode = new Lazy<>(new ug8(this, 0));
        this.elements = elementArr;
    }
}
