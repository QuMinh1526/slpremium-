package tech.units.indriya.unit;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.measure.Dimension;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.spi.ServiceProvider;
import javax.measure.spi.SystemOfUnits;
import tech.units.indriya.AbstractUnit;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class UnitDimension implements Dimension, Serializable {
    private static final long serialVersionUID = 7806787530512644696L;
    private final Unit<?> pseudoUnit;
    private static final Logger LOGGER = Logger.getLogger(UnitDimension.class.getName());
    public static final Dimension NONE = new UnitDimension(AbstractUnit.ONE);
    public static final Dimension LENGTH = new UnitDimension('L');
    public static final Dimension MASS = new UnitDimension('M');
    public static final Dimension TIME = new UnitDimension('T');
    public static final Dimension ELECTRIC_CURRENT = new UnitDimension('I');
    public static final Dimension TEMPERATURE = new UnitDimension((char) 920);
    public static final Dimension AMOUNT_OF_SUBSTANCE = new UnitDimension('N');
    public static final Dimension LUMINOUS_INTENSITY = new UnitDimension('J');

    private UnitDimension(char c) {
        this.pseudoUnit = new BaseUnit("[" + c + ']', NONE);
    }

    /* JADX INFO: renamed from: of */
    public static <Q extends Quantity<Q>> Dimension m17750of(Class<Q> cls) {
        Unit unitTypedUnitFor = typedUnitFor(cls);
        if (unitTypedUnitFor == null) {
            Logger logger = LOGGER;
            Level level = Level.FINE;
            if (logger.isLoggable(level)) {
                logger.log(level, "Quantity type: " + cls + " unknown");
            }
        }
        if (unitTypedUnitFor != null) {
            return unitTypedUnitFor.getDimension();
        }
        return null;
    }

    public static Dimension parse(char c) {
        return new UnitDimension(c);
    }

    private static <Q extends Quantity<Q>> Unit<Q> typedUnitFor(Class<Q> cls) {
        Iterator<ServiceProvider> it = ServiceProvider.available().iterator();
        while (it.hasNext()) {
            Iterator<SystemOfUnits> it2 = it.next().getSystemOfUnitsService().getAvailableSystemsOfUnits().iterator();
            while (it2.hasNext()) {
                Unit<Q> unit = it2.next().getUnit(cls);
                if (unit != null) {
                    return unit;
                }
            }
        }
        return null;
    }

    @Override // javax.measure.Dimension
    public Dimension divide(Dimension dimension) {
        return dimension instanceof UnitDimension ? divide((UnitDimension) dimension) : dimension.divide(this).pow(-1);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof UnitDimension) {
            return Objects.equals(this.pseudoUnit, ((UnitDimension) obj).pseudoUnit);
        }
        return false;
    }

    @Override // javax.measure.Dimension
    public Map<? extends Dimension, Integer> getBaseDimensions() {
        Map<? extends Unit<?>, Integer> baseUnits = this.pseudoUnit.getBaseUnits();
        if (baseUnits == null) {
            return null;
        }
        HashMap map = new HashMap();
        for (Map.Entry<? extends Unit<?>, Integer> entry : baseUnits.entrySet()) {
            map.put(new UnitDimension(entry.getKey()), entry.getValue());
        }
        return map;
    }

    public int hashCode() {
        return Objects.hashCode(this.pseudoUnit);
    }

    @Override // javax.measure.Dimension
    public Dimension multiply(Dimension dimension) {
        return dimension instanceof UnitDimension ? multiply((UnitDimension) dimension) : dimension.multiply(this);
    }

    @Override // javax.measure.Dimension
    public UnitDimension pow(int i) {
        return new UnitDimension(this.pseudoUnit.pow(i));
    }

    @Override // javax.measure.Dimension
    public UnitDimension root(int i) {
        return new UnitDimension(this.pseudoUnit.root(i));
    }

    public String toString() {
        return this.pseudoUnit.toString();
    }

    private UnitDimension multiply(UnitDimension unitDimension) {
        return new UnitDimension(this.pseudoUnit.multiply(unitDimension.pseudoUnit));
    }

    private UnitDimension divide(UnitDimension unitDimension) {
        return new UnitDimension(ProductUnit.ofQuotient(this.pseudoUnit, unitDimension.pseudoUnit));
    }

    private UnitDimension(Unit<?> unit) {
        this.pseudoUnit = unit;
    }

    public UnitDimension() {
        this(AbstractUnit.ONE);
    }
}
