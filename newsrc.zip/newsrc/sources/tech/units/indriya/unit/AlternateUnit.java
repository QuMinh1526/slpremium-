package tech.units.indriya.unit;

import java.util.Map;
import java.util.Objects;
import javax.measure.Dimension;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import p000.nxa;
import tech.units.indriya.AbstractUnit;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class AlternateUnit<Q extends Quantity<Q>> extends AbstractUnit<Q> {
    private static final long serialVersionUID = 4696690756456282705L;
    private final Unit<?> parentUnit;

    public AlternateUnit(Unit<?> unit, String str) {
        super(str);
        if (!(unit instanceof AbstractUnit)) {
            nxa.m14382h(unit, "The parent unit: ", " is not an AbstractUnit");
            throw null;
        }
        if (((AbstractUnit) unit).isSystemUnit()) {
            this.parentUnit = unit instanceof AlternateUnit ? ((AlternateUnit) unit).getParentUnit() : unit;
        } else {
            nxa.m14382h(unit, "The parent unit: ", " is not an unscaled SI unit");
            throw null;
        }
    }

    /* JADX INFO: renamed from: of */
    public static <Q extends Quantity<Q>> AlternateUnit<Q> m17745of(Unit<?> unit, String str) {
        return new AlternateUnit<>(unit, str);
    }

    @Override // tech.units.indriya.AbstractUnit
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof AlternateUnit) {
            AlternateUnit alternateUnit = (AlternateUnit) obj;
            if (Objects.equals(this.parentUnit, alternateUnit.parentUnit) && Objects.equals(getSymbol(), alternateUnit.getSymbol())) {
                return true;
            }
        }
        return false;
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Map<? extends Unit<?>, Integer> getBaseUnits() {
        return this.parentUnit.getBaseUnits();
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Dimension getDimension() {
        return this.parentUnit.getDimension();
    }

    public Unit<?> getParentUnit() {
        return this.parentUnit;
    }

    @Override // tech.units.indriya.AbstractUnit
    public UnitConverter getSystemConverter() {
        return ((AbstractUnit) this.parentUnit).getSystemConverter();
    }

    @Override // tech.units.indriya.AbstractUnit
    public int hashCode() {
        return Objects.hash(this.parentUnit, getSymbol());
    }

    /* JADX INFO: renamed from: of */
    public static <Q extends Quantity<Q>> AlternateUnit<Q> m17746of(Unit<?> unit, String str, String str2) {
        return new AlternateUnit<>(unit, str, str2);
    }

    public AlternateUnit(Unit<?> unit, String str, String str2) {
        this(unit, str);
        setName(str2);
    }

    @Override // tech.units.indriya.AbstractUnit
    public Unit<Q> toSystemUnit() {
        return this;
    }
}
