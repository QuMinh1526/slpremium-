package tech.units.indriya.unit;

import java.util.Map;
import java.util.Objects;
import javax.measure.Dimension;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import tech.units.indriya.AbstractUnit;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class AnnotatedUnit<Q extends Quantity<Q>> extends AbstractUnit<Q> {
    private static final long serialVersionUID = -5676462045106887728L;
    private final Unit<Q> actualUnit;
    private final String annotation;

    public AnnotatedUnit(Unit<Q> unit, String str) {
        this.actualUnit = unit instanceof AnnotatedUnit ? ((AnnotatedUnit) unit).actualUnit : unit;
        this.annotation = str;
    }

    /* JADX INFO: renamed from: of */
    public static <Q extends Quantity<Q>> AnnotatedUnit<Q> m17747of(Unit<Q> unit, String str) {
        return new AnnotatedUnit<>(unit, str);
    }

    @Override // tech.units.indriya.AbstractUnit
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof AnnotatedUnit) {
            AnnotatedUnit annotatedUnit = (AnnotatedUnit) obj;
            if (Objects.equals(this.actualUnit, annotatedUnit.actualUnit) && Objects.equals(this.annotation, annotatedUnit.annotation)) {
                return true;
            }
        }
        return false;
    }

    public Unit<Q> getActualUnit() {
        return this.actualUnit;
    }

    public String getAnnotation() {
        return this.annotation;
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Map<? extends Unit<?>, Integer> getBaseUnits() {
        return this.actualUnit.getBaseUnits();
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Dimension getDimension() {
        return this.actualUnit.getDimension();
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public String getSymbol() {
        return this.actualUnit.getSymbol();
    }

    @Override // tech.units.indriya.AbstractUnit
    public UnitConverter getSystemConverter() {
        return ((AbstractUnit) this.actualUnit).getSystemConverter();
    }

    @Override // tech.units.indriya.AbstractUnit
    public int hashCode() {
        return Objects.hash(this.actualUnit, this.annotation);
    }

    @Override // tech.units.indriya.AbstractUnit
    public Unit<Q> toSystemUnit() {
        return this.actualUnit.getSystemUnit();
    }
}
