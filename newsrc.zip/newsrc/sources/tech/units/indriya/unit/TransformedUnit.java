package tech.units.indriya.unit;

import java.util.Map;
import java.util.Objects;
import javax.measure.Dimension;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import p000.nxa;
import tech.units.indriya.AbstractUnit;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class TransformedUnit<Q extends Quantity<Q>> extends AbstractUnit<Q> {
    private static final long serialVersionUID = 1;
    private final UnitConverter converter;
    private final AbstractUnit<Q> parentUnit;
    private final Unit<Q> systemUnit;

    public TransformedUnit(String str, String str2, Unit<Q> unit, Unit<Q> unit2, UnitConverter unitConverter) {
        if (!(unit instanceof AbstractUnit)) {
            nxa.m14382h(unit, "The parent unit: ", " is not an abstract unit.");
            throw null;
        }
        this.systemUnit = unit2;
        this.parentUnit = (AbstractUnit) unit;
        this.converter = unitConverter;
        setSymbol(str);
        setName(str2);
    }

    @Override // tech.units.indriya.AbstractUnit
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof TransformedUnit) {
            TransformedUnit transformedUnit = (TransformedUnit) obj;
            if (Objects.equals(this.parentUnit, transformedUnit.parentUnit) && Objects.equals(this.converter, transformedUnit.converter)) {
                return true;
            }
        }
        return false;
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Map<? extends Unit<?>, Integer> getBaseUnits() {
        return this.parentUnit.getBaseUnits();
    }

    public UnitConverter getConverter() {
        return this.converter;
    }

    @Override // tech.units.indriya.AbstractUnit, javax.measure.Unit
    public Dimension getDimension() {
        return this.parentUnit.getDimension();
    }

    public Unit<Q> getParentUnit() {
        return this.parentUnit;
    }

    @Override // tech.units.indriya.AbstractUnit
    public UnitConverter getSystemConverter() {
        return this.parentUnit.getSystemConverter().concatenate(this.converter);
    }

    @Override // tech.units.indriya.AbstractUnit
    public int hashCode() {
        return Objects.hash(this.parentUnit, this.converter);
    }

    @Override // tech.units.indriya.AbstractUnit
    public Unit<Q> toSystemUnit() {
        Unit<Q> unit = this.systemUnit;
        return unit != null ? unit : this.parentUnit.getSystemUnit();
    }

    public TransformedUnit(String str, String str2, Unit<Q> unit, UnitConverter unitConverter) {
        this(str, str2, unit, unit.getSystemUnit(), unitConverter);
    }

    public TransformedUnit(String str, Unit<Q> unit, UnitConverter unitConverter) {
        this(str, unit, unit.getSystemUnit(), unitConverter);
    }

    public TransformedUnit(Unit<Q> unit, UnitConverter unitConverter) {
        this(null, unit, unitConverter);
    }

    public TransformedUnit(String str, Unit<Q> unit, Unit<Q> unit2, UnitConverter unitConverter) {
        this(str, null, unit, unit2, unitConverter);
    }
}
