package tech.units.indriya;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.measure.Dimension;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.spi.SystemOfUnits;
import p000.C0442e3;
import p000.C0479f3;
import tech.units.indriya.format.SimpleUnitFormat;
import tech.units.indriya.format.UnitStyle;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class AbstractSystemOfUnits implements SystemOfUnits {
    protected static final Logger logger = Logger.getLogger(AbstractSystemOfUnits.class.getName());
    protected final Set<Unit<?>> units = new HashSet();
    protected final Map<Class<? extends Quantity>, Unit> quantityToUnit = new HashMap();

    /* JADX INFO: renamed from: tech.units.indriya.AbstractSystemOfUnits$1 */
    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static /* synthetic */ class C14301 {
        static final /* synthetic */ int[] $SwitchMap$tech$units$indriya$format$UnitStyle;

        static {
            int[] iArr = new int[UnitStyle.values().length];
            $SwitchMap$tech$units$indriya$format$UnitStyle = iArr;
            try {
                iArr[UnitStyle.NAME.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$tech$units$indriya$format$UnitStyle[UnitStyle.SYMBOL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$tech$units$indriya$format$UnitStyle[UnitStyle.NAME_AND_SYMBOL.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$tech$units$indriya$format$UnitStyle[UnitStyle.SYMBOL_AND_LABEL.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$tech$units$indriya$format$UnitStyle[UnitStyle.LABEL.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean lambda$getUnit$1(String str, Unit unit) {
        return str.equals(unit.toString());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean lambda$getUnit$2(String str, Unit unit) {
        return str.equalsIgnoreCase(unit.getName());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean lambda$getUnit$3(String str, Unit unit) {
        return str.equals(unit.getName());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean lambda$getUnit$4(String str, Unit unit) {
        return str.equalsIgnoreCase(unit.getSymbol());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean lambda$getUnit$5(String str, Unit unit) {
        return str.equals(unit.getSymbol());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean lambda$getUnits$0(Dimension dimension, Unit unit) {
        return dimension.equals(unit.getDimension());
    }

    @Override // javax.measure.spi.SystemOfUnits
    public abstract String getName();

    public Unit<?> getUnit(String str, UnitStyle unitStyle, boolean z) {
        Objects.requireNonNull(str);
        int i = C14301.$SwitchMap$tech$units$indriya$format$UnitStyle[unitStyle.ordinal()];
        int i2 = 2;
        int i3 = 1;
        if (i == 1) {
            return z ? getUnits().stream().filter(new C0479f3(str, i3)).findFirst().orElse(null) : getUnits().stream().filter(new C0479f3(str, i2)).findFirst().orElse(null);
        }
        if (i != 2) {
            return getUnit(str);
        }
        return z ? getUnits().stream().filter(new C0479f3(str, 3)).findFirst().orElse(null) : getUnits().stream().filter(new C0479f3(str, 4)).findFirst().orElse(null);
    }

    @Override // javax.measure.spi.SystemOfUnits
    public Set<? extends Unit<?>> getUnits(Dimension dimension) {
        return (Set) getUnits().stream().filter(new C0442e3(dimension, 0)).collect(Collectors.toSet());
    }

    @Override // javax.measure.spi.SystemOfUnits
    public Set<Unit<?>> getUnits() {
        return Collections.unmodifiableSet(this.units);
    }

    @Override // javax.measure.spi.SystemOfUnits
    public Unit<?> getUnit(String str) {
        Objects.requireNonNull(str);
        return getUnits().stream().filter(new C0479f3(str, 0)).findAny().orElse(null);
    }

    @Override // javax.measure.spi.SystemOfUnits
    public <Q extends Quantity<Q>> Unit<Q> getUnit(Class<Q> cls) {
        return this.quantityToUnit.get(cls);
    }

    public Unit<?> getUnit(String str, UnitStyle unitStyle) {
        return getUnit(str, unitStyle, false);
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class Helper {
        public static <U extends Unit<?>> U addUnit(Set<Unit<?>> set, U u, String str, String str2, UnitStyle unitStyle) {
            int i = C14301.$SwitchMap$tech$units$indriya$format$UnitStyle[unitStyle.ordinal()];
            if (i != 1) {
                if (i == 2 || i == 3) {
                    if (u instanceof AbstractUnit) {
                        AbstractUnit abstractUnit = (AbstractUnit) u;
                        if (str != null && UnitStyle.NAME_AND_SYMBOL.equals(unitStyle)) {
                            abstractUnit.setName(str);
                        }
                        if (str != null && (UnitStyle.SYMBOL.equals(unitStyle) || UnitStyle.NAME_AND_SYMBOL.equals(unitStyle))) {
                            abstractUnit.setSymbol(str2);
                        }
                        set.add(abstractUnit);
                        return abstractUnit;
                    }
                } else if (i != 4) {
                    Logger logger = AbstractSystemOfUnits.logger;
                    Level level = Level.FINEST;
                    if (logger.isLoggable(level)) {
                        logger.log(level, "Unknown style " + unitStyle + "; unit " + u + " can't be rendered with '" + str2 + "'.");
                    }
                } else if (str != null && str2 != null && (u instanceof AbstractUnit)) {
                    AbstractUnit abstractUnit2 = (AbstractUnit) u;
                    abstractUnit2.setName(str);
                    if (UnitStyle.SYMBOL.equals(unitStyle) || UnitStyle.SYMBOL_AND_LABEL.equals(unitStyle)) {
                        abstractUnit2.setSymbol(str2);
                    }
                    if (UnitStyle.LABEL.equals(unitStyle) || UnitStyle.SYMBOL_AND_LABEL.equals(unitStyle)) {
                        SimpleUnitFormat.getInstance().label(u, str2);
                    }
                    set.add(abstractUnit2);
                    return abstractUnit2;
                }
            } else if (str != null && (u instanceof AbstractUnit)) {
                AbstractUnit abstractUnit3 = (AbstractUnit) u;
                abstractUnit3.setName(str);
                set.add(abstractUnit3);
                return abstractUnit3;
            }
            if (UnitStyle.LABEL.equals(unitStyle) || UnitStyle.SYMBOL_AND_LABEL.equals(unitStyle)) {
                SimpleUnitFormat.getInstance().label(u, str2);
            }
            set.add(u);
            return u;
        }

        public static Set<Unit<?>> getUnitsOfDimension(Set<Unit<?>> set, Dimension dimension) {
            if (dimension != null) {
                return (Set) set.stream().filter(new C0442e3(dimension, 1)).collect(Collectors.toSet());
            }
            return null;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ boolean lambda$getUnitsOfDimension$0(Dimension dimension, Unit unit) {
            return dimension.equals(unit.getDimension());
        }

        public static <U extends Unit<?>> U addUnit(Set<Unit<?>> set, U u, String str, String str2) {
            return (U) addUnit(set, u, str, str2, UnitStyle.NAME_AND_SYMBOL);
        }

        public static <U extends Unit<?>> U addUnit(Set<Unit<?>> set, U u, String str) {
            return (U) addUnit(set, u, str, UnitStyle.NAME);
        }

        public static <U extends Unit<?>> U addUnit(Set<Unit<?>> set, U u, String str, UnitStyle unitStyle) {
            int i = C14301.$SwitchMap$tech$units$indriya$format$UnitStyle[unitStyle.ordinal()];
            if (i != 1) {
                if (i != 2) {
                    if (i != 4) {
                        if (i != 5) {
                            AbstractSystemOfUnits.logger.log(Level.FINEST, "Unknown style " + unitStyle + "; unit " + u + " can't be rendered with '" + str + "'.");
                        } else {
                            SimpleUnitFormat.getInstance().label(u, str);
                        }
                    } else {
                        if (str != null && (u instanceof AbstractUnit)) {
                            AbstractUnit abstractUnit = (AbstractUnit) u;
                            abstractUnit.setSymbol(str);
                            set.add(abstractUnit);
                            SimpleUnitFormat.getInstance().label(abstractUnit, str);
                            return abstractUnit;
                        }
                        SimpleUnitFormat.getInstance().label(u, str);
                    }
                } else if (str != null && (u instanceof AbstractUnit)) {
                    AbstractUnit abstractUnit2 = (AbstractUnit) u;
                    abstractUnit2.setSymbol(str);
                    set.add(abstractUnit2);
                    return abstractUnit2;
                }
            } else if (str != null && (u instanceof AbstractUnit)) {
                AbstractUnit abstractUnit3 = (AbstractUnit) u;
                abstractUnit3.setName(str);
                set.add(abstractUnit3);
                return abstractUnit3;
            }
            set.add(u);
            return u;
        }
    }
}
