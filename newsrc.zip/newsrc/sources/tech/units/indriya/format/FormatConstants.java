package tech.units.indriya.format;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
interface FormatConstants {
    public static final int ADDITION_PRECEDENCE = 0;
    public static final char EXPONENT_1 = 185;
    public static final char EXPONENT_2 = 178;
    public static final int EXPONENT_PRECEDENCE = 4;
    public static final char MIDDLE_DOT = 183;
    public static final int NOOP_PRECEDENCE = Integer.MAX_VALUE;
    public static final int PRODUCT_PRECEDENCE = 2;
}
