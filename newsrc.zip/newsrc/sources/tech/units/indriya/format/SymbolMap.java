package tech.units.indriya.format;

import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.measure.Prefix;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import p000.tia;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.function.MultiplyConverter;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class SymbolMap {
    private static final Logger logger = Logger.getLogger(SymbolMap.class.getName());
    private final Map<UnitConverter, Prefix> converterToPrefix;
    private final Map<Object, String> prefixToSymbol;
    private final Map<String, Object> symbolToPrefix;
    private final Map<String, Unit<?>> symbolToUnit;
    private final Map<Unit<?>, String> unitToSymbol;

    private SymbolMap(ResourceBundle resourceBundle) {
        this();
        Enumeration<String> keys = resourceBundle.getKeys();
        while (keys.hasMoreElements()) {
            String strNextElement = keys.nextElement();
            String string = resourceBundle.getString(strNextElement);
            int iLastIndexOf = strNextElement.lastIndexOf(46);
            boolean z = false;
            String strSubstring = strNextElement.substring(0, iLastIndexOf);
            String strSubstring2 = strNextElement.substring(iLastIndexOf + 1, strNextElement.length());
            if (Character.isDigit(strSubstring2.charAt(0))) {
                int iLastIndexOf2 = strSubstring.lastIndexOf(46);
                String strSubstring3 = strSubstring.substring(0, iLastIndexOf2);
                strSubstring2 = strSubstring.substring(iLastIndexOf2 + 1, strSubstring.length());
                strSubstring = strSubstring3;
                z = true;
            }
            try {
                Object obj = Class.forName(strSubstring).getField(strSubstring2).get(null);
                if (obj instanceof Unit) {
                    if (z) {
                        alias((Unit) obj, string);
                    } else {
                        label((AbstractUnit) obj, string);
                    }
                } else {
                    if (!(obj instanceof Prefix)) {
                        throw new ClassCastException("unable to cast " + obj + " to Unit or Prefix");
                    }
                    label((Prefix) obj, string);
                }
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error", (Throwable) e);
            }
        }
    }

    /* JADX INFO: renamed from: of */
    public static SymbolMap m17664of(ResourceBundle resourceBundle) {
        return new SymbolMap(resourceBundle);
    }

    public void alias(Unit<?> unit, String str) {
        this.symbolToUnit.put(str, unit);
    }

    public Prefix getPrefix(String str) {
        List<String> list = (List) this.symbolToPrefix.keySet().stream().collect(Collectors.toList());
        Collections.sort(list, Comparator.comparing(new tia(0)).reversed());
        for (String str2 : list) {
            if (str.startsWith(str2)) {
                return (Prefix) this.symbolToPrefix.get(str2);
            }
        }
        return null;
    }

    public String getSymbol(Unit<?> unit) {
        return this.unitToSymbol.get(unit);
    }

    public Unit<?> getUnit(String str) {
        return this.symbolToUnit.get(str);
    }

    public void label(Prefix prefix, String str) {
        this.symbolToPrefix.put(str, prefix);
        this.prefixToSymbol.put(prefix, str);
        this.converterToPrefix.put(MultiplyConverter.ofPrefix(prefix), prefix);
    }

    public String toString() {
        return "tech.units.indriya.format.SymbolMap: [symbolToUnit: " + this.symbolToUnit + ",unitToSymbol: " + this.unitToSymbol + ",symbolToPrefix: " + this.symbolToPrefix + ",prefixToSymbol: " + this.prefixToSymbol + ",converterToPrefix: " + this.converterToPrefix + ",converterToPrefix: " + this.converterToPrefix + " ]";
    }

    public String getSymbol(Prefix prefix) {
        return this.prefixToSymbol.get(prefix);
    }

    public void label(Unit<?> unit, String str) {
        this.symbolToUnit.put(str, unit);
        this.unitToSymbol.put(unit, str);
    }

    public Prefix getPrefix(UnitConverter unitConverter) {
        return this.converterToPrefix.get(unitConverter);
    }

    private SymbolMap() {
        this.symbolToUnit = new TreeMap();
        this.unitToSymbol = new HashMap();
        this.symbolToPrefix = new TreeMap();
        this.prefixToSymbol = new HashMap();
        this.converterToPrefix = new HashMap();
    }
}
