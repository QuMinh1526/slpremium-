package tech.units.indriya.format;

import java.io.IOException;
import java.text.ParsePosition;
import javax.measure.MeasurementException;
import javax.measure.Unit;
import javax.measure.format.UnitFormat;
import tech.units.indriya.AbstractUnit;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class AbstractUnitFormat implements UnitFormat {
    @Override // javax.measure.format.UnitFormat
    public abstract Appendable format(Unit<?> unit, Appendable appendable);

    @Override // javax.measure.format.UnitFormat
    public final String format(Unit<?> unit) {
        if (unit instanceof AbstractUnit) {
            return format((AbstractUnit<?>) unit, new StringBuilder()).toString();
        }
        try {
            return format(unit, new StringBuilder()).toString();
        } catch (IOException e) {
            throw new MeasurementException(e);
        }
    }

    public abstract Unit<?> parse(CharSequence charSequence, int i);

    @Override // javax.measure.format.UnitFormat
    public abstract Unit<?> parse(CharSequence charSequence, ParsePosition parsePosition);

    private final StringBuilder format(AbstractUnit<?> abstractUnit, StringBuilder sb) {
        try {
            return (StringBuilder) format((Unit<?>) abstractUnit, (Appendable) sb);
        } catch (IOException e) {
            throw new MeasurementException(e);
        }
    }

    @Override // javax.measure.format.UnitFormat
    public void label(Unit<?> unit, String str) {
    }
}
