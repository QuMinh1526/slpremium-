package tech.units.indriya.format;

import java.io.IOException;
import java.io.StringReader;
import java.text.ParsePosition;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.format.MeasurementParseException;
import p000.C1521v3;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.internal.format.UnitFormatParser;
import tech.units.indriya.unit.AnnotatedUnit;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class EBNFUnitFormat extends AbstractUnitFormat {
    private static final String BUNDLE_NAME = "tech.units.indriya.format.messages";
    private static final EBNFUnitFormat DEFAULT_INSTANCE = new EBNFUnitFormat();
    private final transient SymbolMap symbolMap;

    public EBNFUnitFormat() {
        this(SymbolMap.m17664of(ResourceBundle.getBundle(BUNDLE_NAME, Locale.ROOT)));
    }

    public static EBNFUnitFormat getInstance(SymbolMap symbolMap) {
        return new EBNFUnitFormat(symbolMap);
    }

    public static EBNFUnitFormat getNewInstance() {
        return new EBNFUnitFormat();
    }

    public void alias(Unit<?> unit, String str) {
        this.symbolMap.alias(unit, str);
    }

    @Override // tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
    public Appendable format(Unit<?> unit, Appendable appendable) throws IOException {
        EBNFHelper.formatInternal(unit, appendable, this.symbolMap);
        if (unit instanceof AnnotatedUnit) {
            AnnotatedUnit annotatedUnit = (AnnotatedUnit) unit;
            if (annotatedUnit.getAnnotation() != null) {
                appendable.append('{');
                appendable.append(annotatedUnit.getAnnotation());
                appendable.append('}');
            }
        }
        return appendable;
    }

    public SymbolMap getSymbols() {
        return this.symbolMap;
    }

    @Override // tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
    public void label(Unit<?> unit, String str) {
        this.symbolMap.label(unit, str);
    }

    @Override // tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
    public Unit<? extends Quantity<?>> parse(CharSequence charSequence, ParsePosition parsePosition) {
        int index = parsePosition != null ? parsePosition.getIndex() : 0;
        int length = charSequence.length();
        if (length <= index) {
            return AbstractUnit.ONE;
        }
        String strTrim = charSequence.subSequence(index, length).toString().trim();
        if (strTrim.length() == 0) {
            return AbstractUnit.ONE;
        }
        try {
            Unit unit = new UnitFormatParser(this.symbolMap, new StringReader(strTrim)).parseUnit();
            if (parsePosition == null) {
                return unit;
            }
            parsePosition.setIndex(length);
            return unit;
        } catch (TokenException e) {
            Token token = e.currentToken;
            if (token != null) {
                parsePosition.setErrorIndex(index + token.endColumn);
            } else {
                parsePosition.setErrorIndex(index);
            }
            throw new MeasurementParseException(e);
        } catch (TokenMgrError e2) {
            parsePosition.setErrorIndex(index);
            C1521v3.m18903j(e2.getMessage());
            return null;
        }
    }

    public String toString() {
        return getClass().getSimpleName();
    }

    public static EBNFUnitFormat getInstance() {
        return DEFAULT_INSTANCE;
    }

    private EBNFUnitFormat(SymbolMap symbolMap) {
        this.symbolMap = symbolMap;
    }

    @Override // tech.units.indriya.format.AbstractUnitFormat
    public Unit<?> parse(CharSequence charSequence, int i) {
        return parse(charSequence, new ParsePosition(i));
    }

    @Override // javax.measure.format.UnitFormat
    public Unit<?> parse(CharSequence charSequence) {
        return parse(charSequence, 0);
    }
}
