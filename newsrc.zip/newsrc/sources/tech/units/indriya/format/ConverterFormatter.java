package tech.units.indriya.format;

import java.util.Formattable;
import java.util.Formatter;
import javax.measure.Prefix;
import javax.measure.UnitConverter;
import org.apiguardian.api.API;
import p000.C1521v3;
import tech.units.indriya.function.AbstractConverter;
import tech.units.indriya.function.AddConverter;
import tech.units.indriya.function.Calculus;
import tech.units.indriya.function.ExpConverter;
import tech.units.indriya.function.LogConverter;
import tech.units.indriya.function.MultiplyConverter;
import tech.units.indriya.function.PowerOfIntConverter;
import tech.units.indriya.function.RationalNumber;
import tech.units.indriya.spi.NumberSystem;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
class ConverterFormatter {
    private static final String LOCAL_FORMAT_PATTERN = "%s";

    private static int additionPrecedence(AddConverter addConverter, boolean z, int i, StringBuilder sb) {
        if (i < 0) {
            sb.insert(0, '(');
            sb.append(')');
        }
        NumberSystem numberSystemCurrentNumberSystem = Calculus.currentNumberSystem();
        Number offset = addConverter.getOffset();
        if (numberSystemCurrentNumberSystem.compare(offset, 0) < 0) {
            sb.append("-");
            offset = numberSystemCurrentNumberSystem.negate(offset);
        } else if (z) {
            sb.append("+");
        }
        sb.append(offset);
        return 0;
    }

    private static int exponentPrecedenceExpConveter(ExpConverter expConverter, int i, StringBuilder sb) {
        if (i < 4) {
            sb.insert(0, '(');
            sb.append(')');
        }
        StringBuilder sb2 = new StringBuilder();
        double base = expConverter.getBase();
        if (base == 2.718281828459045d) {
            sb2.append('e');
        } else {
            sb2.append((int) base);
        }
        sb2.append('^');
        sb.insert(0, (CharSequence) sb2);
        return 4;
    }

    private static int exponentPrecedenceLogConveter(LogConverter logConverter, StringBuilder sb) {
        double base = logConverter.getBase();
        StringBuilder sb2 = new StringBuilder();
        if (base == 2.718281828459045d) {
            sb2.append("ln");
        } else {
            sb2.append("log");
            if (base != 10.0d) {
                sb2.append((int) base);
            }
        }
        sb2.append("(");
        sb.insert(0, (CharSequence) sb2);
        sb.append(")");
        return 4;
    }

    public static int formatConverter(UnitConverter unitConverter, boolean z, int i, StringBuilder sb, SymbolMap symbolMap) {
        if (unitConverter instanceof AddConverter) {
            return additionPrecedence((AddConverter) unitConverter, z, i, sb);
        }
        if (unitConverter instanceof LogConverter) {
            return exponentPrecedenceLogConveter((LogConverter) unitConverter, sb);
        }
        if (unitConverter instanceof ExpConverter) {
            return exponentPrecedenceExpConveter((ExpConverter) unitConverter, i, sb);
        }
        if ((unitConverter instanceof MultiplyConverter) && !(unitConverter instanceof PowerOfIntConverter)) {
            Prefix prefix = symbolMap.getPrefix(unitConverter);
            return (prefix == null || i != Integer.MAX_VALUE) ? productPrecedence((MultiplyConverter) unitConverter, z, i, sb) : noopPrecedence(sb, symbolMap, prefix);
        }
        if (unitConverter instanceof PowerOfIntConverter) {
            Prefix prefix2 = symbolMap.getPrefix(unitConverter);
            return (prefix2 == null || i != Integer.MAX_VALUE) ? productPrecedence((PowerOfIntConverter) unitConverter, z, i, sb) : noopPrecedence(sb, symbolMap, prefix2);
        }
        if (!(unitConverter instanceof AbstractConverter.Pair)) {
            if (unitConverter != null) {
                sb.replace(0, 1, unitConverter.toString());
                return Integer.MAX_VALUE;
            }
            C1521v3.m18903j("Unable to format, no UnitConverter given");
            return 0;
        }
        AbstractConverter.Pair pair = (AbstractConverter.Pair) unitConverter;
        if (pair.getLeft() == AbstractConverter.IDENTITY) {
            return formatConverter(pair.getRight(), true, i, sb, symbolMap);
        }
        if (pair.getLeft() instanceof Formattable) {
            return formatFormattable((Formattable) pair.getLeft(), i, sb);
        }
        return pair.getRight() instanceof Formattable ? formatFormattable((Formattable) pair.getRight(), i, sb) : formatConverter(pair.getLeft(), true, i, sb, symbolMap);
    }

    public static int formatConverterLocal(UnitConverter unitConverter, boolean z, int i, StringBuilder sb, SymbolMap symbolMap) {
        Prefix prefix = symbolMap.getPrefix(unitConverter);
        if (prefix != null && i == Integer.MAX_VALUE) {
            sb.insert(0, symbolMap.getSymbol(prefix));
            return Integer.MAX_VALUE;
        }
        if (unitConverter instanceof AddConverter) {
            if (i < 0) {
                sb.insert(0, '(');
                sb.append(')');
            }
            NumberSystem numberSystemCurrentNumberSystem = Calculus.currentNumberSystem();
            Number offset = ((AddConverter) unitConverter).getOffset();
            if (numberSystemCurrentNumberSystem.compare(offset, 0) < 0) {
                sb.append("-");
                offset = numberSystemCurrentNumberSystem.negate(offset);
            } else if (z) {
                sb.append("+");
            }
            sb.append(offset);
            return 0;
        }
        if (!(unitConverter instanceof MultiplyConverter)) {
            sb.insert(0, unitConverter.toString() + "(");
            sb.append(")");
            return 4;
        }
        if (i < 2) {
            sb.insert(0, '(');
            sb.append(')');
        }
        if (z) {
            sb.append(FormatConstants.MIDDLE_DOT);
        }
        Object objM21792getFactor = ((MultiplyConverter) unitConverter).m21792getFactor();
        if (objM21792getFactor instanceof RationalNumber) {
            sb.append(((RationalNumber) objM21792getFactor).toRationalString('/'));
        } else {
            sb.append(objM21792getFactor);
        }
        return 2;
    }

    private static int formatFormattable(Formattable formattable, int i, StringBuilder sb) {
        Formatter formatter = new Formatter();
        formatter.format(LOCAL_FORMAT_PATTERN, formattable);
        sb.replace(0, 1, formatter.toString());
        formatter.close();
        return i;
    }

    private static int noopPrecedence(StringBuilder sb, SymbolMap symbolMap, Prefix prefix) {
        sb.insert(0, symbolMap.getSymbol(prefix));
        return Integer.MAX_VALUE;
    }

    private static int productPrecedence(MultiplyConverter multiplyConverter, boolean z, int i, StringBuilder sb) {
        if (i < 2) {
            sb.insert(0, '(');
            sb.append(')');
        }
        Number numberM21792getFactor = multiplyConverter.m21792getFactor();
        if (numberM21792getFactor instanceof RationalNumber) {
            RationalNumber rationalNumber = (RationalNumber) numberM21792getFactor;
            if (!z) {
                sb.append(rationalNumber.toRationalString('/'));
            } else if (rationalNumber.isInteger()) {
                sb.append(FormatConstants.MIDDLE_DOT);
                sb.append(rationalNumber.toString());
            } else {
                RationalNumber rationalNumberReciprocal = rationalNumber.reciprocal();
                if (rationalNumberReciprocal.isInteger()) {
                    sb.append('/');
                    sb.append(rationalNumberReciprocal.toString());
                } else {
                    sb.append(FormatConstants.MIDDLE_DOT);
                    sb.append(rationalNumber.toRationalString('/'));
                }
            }
        } else {
            if (z) {
                sb.append(FormatConstants.MIDDLE_DOT);
            }
            sb.append(String.valueOf(numberM21792getFactor));
        }
        return 2;
    }

    private static int productPrecedence(PowerOfIntConverter powerOfIntConverter, boolean z, int i, StringBuilder sb) {
        if (i < 2) {
            sb.insert(0, '(');
            sb.append(')');
        }
        if (!powerOfIntConverter.isIdentity()) {
            if (z) {
                sb.append(FormatConstants.MIDDLE_DOT);
            }
            sb.append(powerOfIntConverter.getBase());
            sb.append("^");
            sb.append(powerOfIntConverter.getExponent());
        }
        return 2;
    }
}
