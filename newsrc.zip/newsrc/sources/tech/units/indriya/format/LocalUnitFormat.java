package tech.units.indriya.format;

import androidx.appcompat.widget.ActivityChooserModel;
import java.io.IOException;
import java.io.StringReader;
import java.text.ParsePosition;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import javax.measure.format.MeasurementParseException;
import org.p003jf.dexlib2.dexbacked.raw.HeaderItem;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.internal.format.UnitFormatParser;
import tech.units.indriya.unit.AlternateUnit;
import tech.units.indriya.unit.AnnotatedUnit;
import tech.units.indriya.unit.BaseUnit;
import tech.units.indriya.unit.ProductUnit;
import tech.units.indriya.unit.TransformedUnit;
import tech.units.indriya.unit.Units;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class LocalUnitFormat extends AbstractUnitFormat {
    private static final LocalUnitFormat DEFAULT_INSTANCE = new LocalUnitFormat(SymbolMap.m17664of(ResourceBundle.getBundle(LocalUnitFormat.class.getPackage().getName() + ".messages")));
    private final transient SymbolMap symbolMap;

    private LocalUnitFormat(SymbolMap symbolMap) {
        this.symbolMap = symbolMap;
    }

    private void formatExponent(Unit<?> unit, int i, int i2, boolean z, Appendable appendable) throws IOException {
        if (z) {
            appendable.append(FormatConstants.MIDDLE_DOT);
        }
        StringBuffer stringBuffer = new StringBuffer();
        if (formatInternal(unit, stringBuffer) < 2) {
            stringBuffer.insert(0, '(');
            stringBuffer.append(')');
        }
        appendable.append(stringBuffer);
        if (i2 == 1 && i == 1) {
            return;
        }
        if (i2 != 1 || i <= 1) {
            if (i2 == 1) {
                appendable.append("^");
                appendable.append(String.valueOf(i));
                return;
            }
            appendable.append("^(");
            appendable.append(String.valueOf(i));
            appendable.append('/');
            appendable.append(String.valueOf(i2));
            appendable.append(')');
            return;
        }
        String string = Integer.toString(i);
        for (int i3 = 0; i3 < string.length(); i3++) {
            switch (string.charAt(i3)) {
                case '0':
                    appendable.append((char) 8304);
                    break;
                case '1':
                    appendable.append(FormatConstants.EXPONENT_1);
                    break;
                case ActivityChooserModel.DEFAULT_HISTORY_MAX_LENGTH /* 50 */:
                    appendable.append(FormatConstants.EXPONENT_2);
                    break;
                case '3':
                    appendable.append((char) 179);
                    break;
                case HeaderItem.MAP_OFFSET /* 52 */:
                    appendable.append((char) 8308);
                    break;
                case '5':
                    appendable.append((char) 8309);
                    break;
                case '6':
                    appendable.append((char) 8310);
                    break;
                case '7':
                    appendable.append((char) 8311);
                    break;
                case HeaderItem.STRING_COUNT_OFFSET /* 56 */:
                    appendable.append((char) 8312);
                    break;
                case '9':
                    appendable.append((char) 8313);
                    break;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private int formatInternal(Unit<?> unit, Appendable appendable) throws IOException {
        Unit<?> actualUnit = unit instanceof AnnotatedUnit ? ((AnnotatedUnit) unit).getActualUnit() : unit;
        CharSequence symbol = this.symbolMap.getSymbol((AbstractUnit) actualUnit);
        if (symbol != null) {
            appendable.append(symbol);
            return Integer.MAX_VALUE;
        }
        if (!(actualUnit instanceof ProductUnit) || actualUnit.getBaseUnits() == null) {
            if (actualUnit instanceof BaseUnit) {
                appendable.append(((BaseUnit) actualUnit).getSymbol());
                return Integer.MAX_VALUE;
            }
            if (actualUnit instanceof AlternateUnit) {
                appendable.append(actualUnit.getSymbol());
                return Integer.MAX_VALUE;
            }
            StringBuilder sb = new StringBuilder();
            Unit systemUnit = actualUnit.getSystemUnit();
            UnitConverter systemConverter = ((AbstractUnit) actualUnit).getSystemConverter();
            if (Units.KILOGRAM.equals(systemUnit)) {
                systemUnit = Units.GRAM;
                if (actualUnit.equals(systemUnit)) {
                    appendable.append(this.symbolMap.getSymbol((Unit<?>) systemUnit));
                    return Integer.MAX_VALUE;
                }
                systemConverter = actualUnit instanceof TransformedUnit ? ((TransformedUnit) actualUnit).getConverter() : actualUnit.getConverterTo(systemUnit);
            } else if (Units.CUBIC_METRE.equals(systemUnit) && systemConverter != null) {
                systemUnit = Units.LITRE;
            }
            if (actualUnit instanceof TransformedUnit) {
                TransformedUnit transformedUnit = (TransformedUnit) actualUnit;
                if (systemUnit == null || transformedUnit.getParentUnit() != null) {
                    Unit parentUnit = transformedUnit.getParentUnit();
                    systemUnit = parentUnit;
                }
                systemConverter = transformedUnit.getConverter();
            }
            int converterLocal = ConverterFormatter.formatConverterLocal(systemConverter, !systemUnit.equals(AbstractUnit.ONE), formatInternal(systemUnit, sb), sb, this.symbolMap);
            appendable.append(sb);
            return converterLocal;
        }
        Map<? extends Unit<?>, Integer> baseUnits = actualUnit.getBaseUnits();
        boolean z = true;
        int i = 0;
        for (Map.Entry<? extends Unit<?>, Integer> entry : baseUnits.entrySet()) {
            int iIntValue = entry.getValue().intValue();
            if (iIntValue >= 0) {
                formatExponent(entry.getKey(), iIntValue, 1, !z, appendable);
                z = false;
            } else {
                i++;
            }
        }
        if (i <= 0) {
            return 2;
        }
        if (z) {
            appendable.append('1');
        }
        appendable.append('/');
        if (i > 1) {
            appendable.append('(');
        }
        boolean z2 = true;
        for (Map.Entry<? extends Unit<?>, Integer> entry2 : baseUnits.entrySet()) {
            int iIntValue2 = entry2.getValue().intValue();
            if (iIntValue2 < 0) {
                formatExponent(entry2.getKey(), -iIntValue2, 1, !z2, appendable);
                z2 = false;
            }
        }
        if (i <= 1) {
            return 2;
        }
        appendable.append(')');
        return 2;
    }

    public static LocalUnitFormat getInstance(Locale locale) {
        return new LocalUnitFormat(SymbolMap.m17664of(ResourceBundle.getBundle(LocalUnitFormat.class.getPackage().getName() + ".messages", locale)));
    }

    @Override // tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
    public Appendable format(Unit<?> unit, Appendable appendable) throws IOException {
        if (!(unit instanceof AbstractUnit)) {
            return appendable.append(unit.toString());
        }
        formatInternal(unit, appendable);
        return appendable;
    }

    public SymbolMap getSymbols() {
        return this.symbolMap;
    }

    @Override // javax.measure.format.UnitFormat
    public boolean isLocaleSensitive() {
        return true;
    }

    @Override // tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
    public Unit<?> parse(CharSequence charSequence, ParsePosition parsePosition) {
        int index = parsePosition.getIndex();
        int length = charSequence.length();
        if (length <= index) {
            return AbstractUnit.ONE;
        }
        String strTrim = charSequence.subSequence(index, length).toString().trim();
        if (strTrim.length() == 0) {
            return AbstractUnit.ONE;
        }
        try {
            Unit<?> unit = new UnitFormatParser(this.symbolMap, new StringReader(strTrim)).parseUnit();
            parsePosition.setIndex(length);
            return unit;
        } catch (TokenException e) {
            Token token = e.currentToken;
            if (token != null) {
                parsePosition.setErrorIndex(index + token.endColumn);
            } else {
                parsePosition.setErrorIndex(index);
            }
            throw new IllegalArgumentException(e);
        } catch (TokenMgrError e2) {
            parsePosition.setErrorIndex(index);
            throw new MeasurementParseException(e2);
        }
    }

    public String toString() {
        return getClass().getSimpleName();
    }

    public static LocalUnitFormat getInstance() {
        return DEFAULT_INSTANCE;
    }

    public static LocalUnitFormat getInstance(SymbolMap symbolMap) {
        return new LocalUnitFormat(symbolMap);
    }

    @Override // tech.units.indriya.format.AbstractUnitFormat
    public Unit<?> parse(CharSequence charSequence, int i) {
        return parse(charSequence, new ParsePosition(i));
    }

    @Override // javax.measure.format.UnitFormat
    public Unit<? extends Quantity<?>> parse(CharSequence charSequence) {
        return parse(charSequence, new ParsePosition(0));
    }
}
