package tech.units.indriya.format;

import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.Iterator;
import java.util.Objects;
import javax.measure.Quantity;
import javax.measure.Unit;
import p000.C1521v3;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.internal.format.RationalNumberScanner;
import tech.units.indriya.quantity.MixedQuantity;
import tech.units.indriya.quantity.Quantities;
import tech.units.indriya.spi.Range;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class SimpleQuantityFormat extends AbstractQuantityFormat {
    private static final SimpleQuantityFormat DEFAULT = new SimpleQuantityFormat();
    private static final String DEFAULT_PATTERN = "n u";
    private static final String NUM_PART = "n";
    private static final String RADIX = "~";
    private static final String RANGE_COMPACT = "rc";
    private static final String UNIT_PART = "u";
    private static final long serialVersionUID = 2758248665095734058L;
    private String delimiter;
    private String mixDelimiter;
    private final String pattern;
    private final boolean rangeCompact;

    public SimpleQuantityFormat(String str) {
        Objects.requireNonNull(str);
        if (str.isEmpty()) {
            C1521v3.m18903j("Pattern cannot be empty");
            throw null;
        }
        if (RANGE_COMPACT.equals(str)) {
            this.rangeCompact = true;
            this.pattern = DEFAULT_PATTERN;
        } else if (str.contains(RANGE_COMPACT)) {
            this.pattern = str;
            this.rangeCompact = true;
        } else {
            this.pattern = str;
            this.rangeCompact = false;
        }
        boolean zContains = this.pattern.contains(RADIX);
        String str2 = this.pattern;
        if (!zContains) {
            this.delimiter = str2.substring(str2.indexOf(NUM_PART) + 1, this.pattern.indexOf(UNIT_PART));
            return;
        }
        String strSubstring = str2.substring(0, str2.indexOf(RADIX));
        String str3 = this.pattern;
        this.mixDelimiter = str3.substring(str3.indexOf(RADIX) + 1);
        this.delimiter = strSubstring.substring(this.pattern.indexOf(NUM_PART) + 1, this.pattern.indexOf(UNIT_PART));
    }

    public static SimpleQuantityFormat getInstance(String str) {
        return new SimpleQuantityFormat(str);
    }

    @Override // tech.units.indriya.format.AbstractQuantityFormat, javax.measure.format.QuantityFormat
    public Appendable format(Quantity<?> quantity, Appendable appendable) throws IOException {
        Unit<Q> unit = quantity.getUnit();
        appendable.append(quantity.getValue().toString());
        if (quantity.getUnit().equals(AbstractUnit.ONE)) {
            return appendable;
        }
        appendable.append(this.delimiter);
        return SimpleUnitFormat.getInstance().format((Unit<?>) unit, appendable);
    }

    @Override // tech.units.indriya.format.AbstractQuantityFormat
    public StringBuffer formatMixed(MixedQuantity<?> mixedQuantity, StringBuffer stringBuffer) {
        StringBuffer stringBuffer2 = new StringBuffer();
        Iterator it = mixedQuantity.getQuantities().iterator();
        int i = 0;
        while (it.hasNext()) {
            stringBuffer2.append(format((Quantity<?>) it.next()));
            if (i < mixedQuantity.getQuantities().size() - 1) {
                String str = this.mixDelimiter;
                if (str == null) {
                    str = " ";
                }
                stringBuffer2.append(str);
            }
            i++;
        }
        return stringBuffer2;
    }

    public String formatRange(Range<?> range) {
        StringBuilder sb = new StringBuilder();
        sb.append(this.rangeCompact ? "min=" : "minimum=");
        sb.append(range.getMinimum());
        sb.append(this.rangeCompact ? ", max=" : ", maximum=");
        sb.append(range.getMaximum());
        if (range.getResolution() != null) {
            sb.append(this.rangeCompact ? ", res=" : ", resolution=");
            sb.append(range.getResolution());
        }
        return sb.toString();
    }

    public String getPattern() {
        return this.pattern;
    }

    @Override // tech.units.indriya.format.AbstractQuantityFormat, javax.measure.format.QuantityFormat
    public Quantity<?> parse(CharSequence charSequence, ParsePosition parsePosition) {
        NumberFormat numberFormat = NumberFormat.getInstance();
        SimpleUnitFormat simpleUnitFormat = SimpleUnitFormat.getInstance();
        String str = this.mixDelimiter;
        if (str != null && !str.equals(this.delimiter)) {
            return CommonFormatter.parseMixedAsLeading(charSequence.toString(), numberFormat, simpleUnitFormat, this.delimiter, this.mixDelimiter, parsePosition.getIndex());
        }
        String str2 = this.mixDelimiter;
        return (str2 == null || !str2.equals(this.delimiter)) ? Quantities.getQuantity(new RationalNumberScanner(charSequence, parsePosition, null).getNumber(), simpleUnitFormat.parse(charSequence, parsePosition)) : CommonFormatter.parseMixedAsLeading(charSequence.toString(), numberFormat, simpleUnitFormat, this.delimiter, parsePosition.getIndex());
    }

    public String toString() {
        return getClass().getSimpleName();
    }

    public static SimpleQuantityFormat getInstance() {
        return DEFAULT;
    }

    @Override // tech.units.indriya.format.AbstractQuantityFormat
    public Quantity<?> parse(CharSequence charSequence, int i) {
        return parse(charSequence, new ParsePosition(i));
    }

    @Override // tech.units.indriya.format.AbstractQuantityFormat
    public Quantity<?> parse(CharSequence charSequence) {
        return parse(charSequence, new ParsePosition(0));
    }

    public SimpleQuantityFormat() {
        this(DEFAULT_PATTERN);
    }
}
