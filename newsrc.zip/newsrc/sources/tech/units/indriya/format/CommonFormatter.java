package tech.units.indriya.format;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.format.MeasurementParseException;
import javax.measure.format.UnitFormat;
import org.apiguardian.api.API;
import p000.C1521v3;
import p000.ro6;
import tech.units.indriya.internal.format.RationalNumberFormat;
import tech.units.indriya.quantity.MixedQuantity;
import tech.units.indriya.quantity.Quantities;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
@API(status = API.Status.INTERNAL)
abstract class CommonFormatter {
    private static final String ERR_PRIMARY_UNIT_NOT_FOUND = "The primary unit <%s> is not part of the mixed units <%s>";

    private static final <Q extends Quantity<Q>> Unit<Q> getLeadingUnit(MixedQuantity<Q> mixedQuantity) {
        Objects.requireNonNull(mixedQuantity);
        Iterator<Unit<Q>> it = mixedQuantity.getUnits().iterator();
        if (it.hasNext()) {
            return it.next();
        }
        return null;
    }

    public static MixedQuantity<?> parseMixed(String str, NumberFormat numberFormat, UnitFormat unitFormat, String str2, int i) {
        Objects.requireNonNull(str);
        String strSubstring = str.substring(i);
        ArrayList arrayList = new ArrayList();
        RationalNumberFormat rationalNumberFormatWrap = RationalNumberFormat.wrap(numberFormat);
        String[] strArrSplit = strSubstring.split(str2);
        if (strArrSplit.length < 2) {
            C1521v3.m18903j("No Unit found");
            return null;
        }
        for (int i2 = 0; i2 < strArrSplit.length - 1; i2 += 2) {
            try {
                Number number = rationalNumberFormatWrap.parse(strArrSplit[i2]);
                Unit<?> unit = unitFormat.parse(strArrSplit[i2 + 1]);
                if (number != null && unit != null) {
                    arrayList.add(Quantities.getQuantity(number, unit));
                }
            } catch (ParseException e) {
                throw new MeasurementParseException(e);
            }
        }
        return MixedQuantity.m17709of((Quantity[]) arrayList.toArray(new Quantity[arrayList.size()]));
    }

    public static Quantity<?> parseMixedAsLeading(String str, NumberFormat numberFormat, UnitFormat unitFormat, String str2, String str3, int i) {
        MixedQuantity<?> mixed = parseMixed(str, numberFormat, unitFormat, str2, str3, i);
        return mixed.m17710to(getLeadingUnit(mixed));
    }

    public static Quantity<?> parseMixedAsPrimary(String str, NumberFormat numberFormat, UnitFormat unitFormat, Unit unit, String str2, String str3, int i) {
        MixedQuantity<?> mixed = parseMixed(str, numberFormat, unitFormat, str2, str3, i);
        if (mixed.getUnits().contains(unit)) {
            return mixed.m17710to(unit);
        }
        ro6.m16606q(ERR_PRIMARY_UNIT_NOT_FOUND, new Object[]{unit, mixed.getUnits()});
        return null;
    }

    public static Quantity<?> parseMixedAsPrimary(String str, NumberFormat numberFormat, UnitFormat unitFormat, Unit unit, String str2, int i) {
        MixedQuantity<?> mixed = parseMixed(str, numberFormat, unitFormat, str2, i);
        if (mixed.getUnits().contains(unit)) {
            return mixed.m17710to(unit);
        }
        ro6.m16606q(ERR_PRIMARY_UNIT_NOT_FOUND, new Object[]{unit, mixed.getUnits()});
        return null;
    }

    public static Quantity<?> parseMixedAsPrimary(String str, NumberFormat numberFormat, UnitFormat unitFormat, Unit unit, String str2) {
        return parseMixedAsPrimary(str, numberFormat, unitFormat, unit, str2, 0);
    }

    public static Quantity<?> parseMixedAsLeading(String str, NumberFormat numberFormat, UnitFormat unitFormat, String str2, int i) {
        MixedQuantity<?> mixed = parseMixed(str, numberFormat, unitFormat, str2, i);
        return mixed.m17710to(getLeadingUnit(mixed));
    }

    public static Quantity<?> parseMixedAsLeading(String str, NumberFormat numberFormat, UnitFormat unitFormat, String str2) {
        return parseMixedAsLeading(str, numberFormat, unitFormat, str2, 0);
    }

    public static MixedQuantity<?> parseMixed(String str, NumberFormat numberFormat, UnitFormat unitFormat, String str2, String str3) {
        return parseMixed(str, numberFormat, unitFormat, str2, str3, 0);
    }

    public static MixedQuantity<?> parseMixed(String str, NumberFormat numberFormat, UnitFormat unitFormat, String str2, String str3, int i) {
        String[] strArrSplit = str.substring(i).split(str3);
        ArrayList arrayList = new ArrayList();
        RationalNumberFormat rationalNumberFormatWrap = RationalNumberFormat.wrap(numberFormat);
        for (String str4 : strArrSplit) {
            String[] strArrSplit2 = str4.split(str2);
            if (strArrSplit2.length >= 2) {
                try {
                    Number number = rationalNumberFormatWrap.parse(strArrSplit2[0]);
                    Unit<?> unit = unitFormat.parse(strArrSplit2[1]);
                    if (number != null && unit != null) {
                        arrayList.add(Quantities.getQuantity(number, unit));
                    }
                } catch (ParseException e) {
                    throw new MeasurementParseException(e);
                }
            } else {
                C1521v3.m18903j("No Unit found");
                return null;
            }
        }
        Quantity[] quantityArr = new Quantity[arrayList.size()];
        arrayList.toArray(quantityArr);
        return MixedQuantity.m17709of(quantityArr);
    }

    public static MixedQuantity<?> parseMixed(String str, NumberFormat numberFormat, UnitFormat unitFormat, String str2) {
        return parseMixed(str, numberFormat, unitFormat, str2, 0);
    }
}
