package tech.units.indriya.format;

import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.Iterator;
import java.util.Locale;
import java.util.Objects;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.format.UnitFormat;
import p000.C1521v3;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.quantity.MixedQuantity;
import tech.units.indriya.quantity.Quantities;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class NumberDelimiterQuantityFormat extends AbstractQuantityFormat {
    private static final long serialVersionUID = 3546952599885869402L;
    private String delimiter;
    private boolean localeSensitive;
    private String mixDelimiter;
    private transient NumberFormat numberFormat;
    private transient Unit primaryUnit;
    private transient UnitFormat unitFormat;
    private static final NumberDelimiterQuantityFormat SIMPLE_INSTANCE = new Builder().setNumberFormat(NumberFormat.getInstance(Locale.ROOT)).setUnitFormat(SimpleUnitFormat.getInstance()).build();
    private static final NumberDelimiterQuantityFormat LOCAL_INSTANCE = new Builder().setNumberFormat(NumberFormat.getInstance()).setUnitFormat(LocalUnitFormat.getInstance()).setLocaleSensitive(true).build();

    /* JADX INFO: renamed from: tech.units.indriya.format.NumberDelimiterQuantityFormat$1 */
    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static /* synthetic */ class C14321 {
        static final /* synthetic */ int[] $SwitchMap$tech$units$indriya$format$FormatBehavior;

        static {
            int[] iArr = new int[FormatBehavior.values().length];
            $SwitchMap$tech$units$indriya$format$FormatBehavior = iArr;
            try {
                iArr[FormatBehavior.LOCALE_SENSITIVE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$tech$units$indriya$format$FormatBehavior[FormatBehavior.LOCALE_NEUTRAL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class Builder {
        private transient String delimiter = " ";
        private boolean localeSensitive;
        private transient String mixedRadixDelimiter;
        private transient NumberFormat numberFormat;
        private transient Unit primaryUnit;
        private transient UnitFormat unitFormat;

        public NumberDelimiterQuantityFormat build() {
            NumberDelimiterQuantityFormat numberDelimiterQuantityFormat = new NumberDelimiterQuantityFormat(null);
            numberDelimiterQuantityFormat.numberFormat = this.numberFormat;
            numberDelimiterQuantityFormat.unitFormat = this.unitFormat;
            numberDelimiterQuantityFormat.primaryUnit = this.primaryUnit;
            numberDelimiterQuantityFormat.delimiter = this.delimiter;
            numberDelimiterQuantityFormat.mixDelimiter = this.mixedRadixDelimiter;
            numberDelimiterQuantityFormat.localeSensitive = this.localeSensitive;
            return numberDelimiterQuantityFormat;
        }

        public Builder setDelimiter(String str) {
            Objects.requireNonNull(str);
            this.delimiter = str;
            return this;
        }

        public Builder setLocaleSensitive(boolean z) {
            this.localeSensitive = z;
            return this;
        }

        public Builder setNumberFormat(NumberFormat numberFormat) {
            Objects.requireNonNull(numberFormat);
            this.numberFormat = numberFormat;
            return this;
        }

        public Builder setPrimaryUnit(Unit unit) {
            Objects.requireNonNull(unit);
            this.primaryUnit = unit;
            return this;
        }

        public Builder setRadixPartsDelimiter(String str) {
            Objects.requireNonNull(str);
            this.mixedRadixDelimiter = str;
            return this;
        }

        public Builder setUnitFormat(UnitFormat unitFormat) {
            Objects.requireNonNull(unitFormat);
            this.unitFormat = unitFormat;
            this.localeSensitive = unitFormat.isLocaleSensitive();
            return this;
        }
    }

    public /* synthetic */ NumberDelimiterQuantityFormat(C14321 c14321) {
        this();
    }

    public static final Builder builder() {
        return new Builder();
    }

    private static int getFractionDigitsCount(double d) {
        if (d >= 1.0d) {
            d -= (long) d;
        }
        if (d == 0.0d) {
            return 0;
        }
        double d2 = d * 10.0d;
        int i = 1;
        while (d2 - ((long) d2) != 0.0d) {
            d2 *= 10.0d;
            i++;
        }
        return i;
    }

    public static NumberDelimiterQuantityFormat getInstance(NumberFormat numberFormat, UnitFormat unitFormat) {
        return new Builder().setNumberFormat(numberFormat).setUnitFormat(unitFormat).build();
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // tech.units.indriya.format.AbstractQuantityFormat, javax.measure.format.QuantityFormat
    public Appendable format(Quantity<?> quantity, Appendable appendable) throws IOException {
        int fractionDigitsCount = (quantity == null || quantity.getValue() == null) ? 0 : getFractionDigitsCount(quantity.getValue().doubleValue());
        if (fractionDigitsCount > 1) {
            this.numberFormat.setMaximumFractionDigits(fractionDigitsCount + 1);
        }
        appendable.append(this.numberFormat.format(quantity.getValue()));
        if (quantity.getUnit().equals(AbstractUnit.ONE)) {
            return appendable;
        }
        appendable.append(this.delimiter);
        return this.unitFormat.format(quantity.getUnit(), appendable);
    }

    @Override // tech.units.indriya.format.AbstractQuantityFormat
    public StringBuffer formatMixed(MixedQuantity<?> mixedQuantity, StringBuffer stringBuffer) {
        StringBuffer stringBuffer2 = new StringBuffer();
        Iterator it = mixedQuantity.getQuantities().iterator();
        int i = 0;
        while (it.hasNext()) {
            stringBuffer2.append(format((Quantity<?>) it.next()));
            if (i < mixedQuantity.getQuantities().size() - 1) {
                String str = this.mixDelimiter;
                if (str == null) {
                    str = " ";
                }
                stringBuffer2.append(str);
            }
            i++;
        }
        return stringBuffer2;
    }

    @Override // javax.measure.format.QuantityFormat
    public boolean isLocaleSensitive() {
        return this.localeSensitive;
    }

    @Override // tech.units.indriya.format.AbstractQuantityFormat, javax.measure.format.QuantityFormat
    public Quantity<?> parse(CharSequence charSequence, ParsePosition parsePosition) {
        String string = charSequence.toString();
        int index = parsePosition.getIndex();
        String str = this.mixDelimiter;
        if (str != null && !str.equals(this.delimiter)) {
            Unit unit = this.primaryUnit;
            NumberFormat numberFormat = this.numberFormat;
            return unit != null ? CommonFormatter.parseMixedAsPrimary(string, numberFormat, this.unitFormat, unit, this.delimiter, this.mixDelimiter, index) : CommonFormatter.parseMixedAsLeading(string, numberFormat, this.unitFormat, this.delimiter, this.mixDelimiter, index);
        }
        String str2 = this.mixDelimiter;
        if (str2 != null && str2.equals(this.delimiter)) {
            Unit unit2 = this.primaryUnit;
            NumberFormat numberFormat2 = this.numberFormat;
            return unit2 != null ? CommonFormatter.parseMixedAsPrimary(string, numberFormat2, this.unitFormat, unit2, this.delimiter, index) : CommonFormatter.parseMixedAsLeading(string, numberFormat2, this.unitFormat, this.delimiter, index);
        }
        Number number = this.numberFormat.parse(string, parsePosition);
        if (number == null) {
            C1521v3.m18903j("Number cannot be parsed");
            return null;
        }
        String[] strArrSplit = string.substring(index).split(this.delimiter);
        if (strArrSplit.length >= 2) {
            return Quantities.getQuantity(number, this.unitFormat.parse(strArrSplit[1]));
        }
        C1521v3.m18903j("No Unit found");
        return null;
    }

    public MixedQuantity<?> parseMixed(CharSequence charSequence, ParsePosition parsePosition) {
        String string = charSequence.toString();
        int index = parsePosition.getIndex();
        String str = this.mixDelimiter;
        if (str != null && !str.equals(this.delimiter)) {
            return CommonFormatter.parseMixed(string, this.numberFormat, this.unitFormat, this.delimiter, this.mixDelimiter, index);
        }
        String str2 = this.mixDelimiter;
        if (str2 != null && str2.equals(this.delimiter)) {
            return CommonFormatter.parseMixed(string, this.numberFormat, this.unitFormat, this.delimiter, index);
        }
        Number number = this.numberFormat.parse(string, parsePosition);
        if (number == null) {
            C1521v3.m18903j("Number cannot be parsed");
            return null;
        }
        String[] strArrSplit = string.substring(index).split(this.delimiter);
        if (strArrSplit.length >= 2) {
            return MixedQuantity.m17709of(Quantities.getQuantity(number, this.unitFormat.parse(strArrSplit[1])));
        }
        C1521v3.m18903j("No Unit found");
        return null;
    }

    public String toString() {
        return getClass().getSimpleName();
    }

    private NumberDelimiterQuantityFormat() {
    }

    public static NumberDelimiterQuantityFormat getInstance(FormatBehavior formatBehavior, int i) {
        return getInstance(formatBehavior);
    }

    public static NumberDelimiterQuantityFormat getInstance() {
        return getInstance(FormatBehavior.LOCALE_NEUTRAL);
    }

    public static NumberDelimiterQuantityFormat getInstance(FormatBehavior formatBehavior) {
        if (C14321.$SwitchMap$tech$units$indriya$format$FormatBehavior[formatBehavior.ordinal()] != 1) {
            return SIMPLE_INSTANCE;
        }
        return LOCAL_INSTANCE;
    }

    public MixedQuantity<?> parseMixed(CharSequence charSequence, int i) {
        return parseMixed(charSequence, new ParsePosition(i));
    }

    public MixedQuantity<?> parseMixed(CharSequence charSequence) {
        return parseMixed(charSequence, 0);
    }

    @Override // tech.units.indriya.format.AbstractQuantityFormat
    public Quantity<?> parse(CharSequence charSequence, int i) {
        return parse(charSequence, new ParsePosition(i));
    }

    @Override // tech.units.indriya.format.AbstractQuantityFormat
    public Quantity<?> parse(CharSequence charSequence) {
        return parse(charSequence, 0);
    }
}
