package tech.units.indriya.format;

import java.io.IOException;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.measure.BinaryPrefix;
import javax.measure.MeasurementError;
import javax.measure.MetricPrefix;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import javax.measure.format.MeasurementParseException;
import javax.measure.quantity.Mass;
import javax.measure.quantity.Temperature;
import p000.C1521v3;
import p000.cm6;
import p000.z23;
import p000.z82;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.function.AddConverter;
import tech.units.indriya.function.MultiplyConverter;
import tech.units.indriya.function.RationalNumber;
import tech.units.indriya.unit.AlternateUnit;
import tech.units.indriya.unit.AnnotatedUnit;
import tech.units.indriya.unit.BaseUnit;
import tech.units.indriya.unit.ProductUnit;
import tech.units.indriya.unit.TransformedUnit;
import tech.units.indriya.unit.Units;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class SimpleUnitFormat extends AbstractUnitFormat {

    /* JADX INFO: renamed from: MU */
    private static final String f40110MU = "μ";
    private static final DefaultFormat DEFAULT_INSTANCE = new DefaultFormat().init();
    private static final ASCIIFormat ASCII_INSTANCE = new ASCIIFormat().init();

    /* JADX INFO: renamed from: tech.units.indriya.format.SimpleUnitFormat$2 */
    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static /* synthetic */ class C14342 {
        static final /* synthetic */ int[] $SwitchMap$javax$measure$MetricPrefix;

        /* JADX INFO: renamed from: $SwitchMap$tech$units$indriya$format$SimpleUnitFormat$DefaultFormat$Token */
        static final /* synthetic */ int[] f40111x242fa8fa;
        static final /* synthetic */ int[] $SwitchMap$tech$units$indriya$format$SimpleUnitFormat$Flavor;

        static {
            int[] iArr = new int[DefaultFormat.Token.values().length];
            f40111x242fa8fa = iArr;
            try {
                iArr[DefaultFormat.Token.IDENTIFIER.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f40111x242fa8fa[DefaultFormat.Token.OPEN_PAREN.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f40111x242fa8fa[DefaultFormat.Token.EXPONENT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f40111x242fa8fa[DefaultFormat.Token.MULTIPLY.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f40111x242fa8fa[DefaultFormat.Token.DIVIDE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f40111x242fa8fa[DefaultFormat.Token.PLUS.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f40111x242fa8fa[DefaultFormat.Token.EOF.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                f40111x242fa8fa[DefaultFormat.Token.CLOSE_PAREN.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            int[] iArr2 = new int[MetricPrefix.values().length];
            $SwitchMap$javax$measure$MetricPrefix = iArr2;
            try {
                iArr2[MetricPrefix.KILO.ordinal()] = 1;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                $SwitchMap$javax$measure$MetricPrefix[MetricPrefix.MICRO.ordinal()] = 2;
            } catch (NoSuchFieldError unused10) {
            }
            int[] iArr3 = new int[Flavor.values().length];
            $SwitchMap$tech$units$indriya$format$SimpleUnitFormat$Flavor = iArr3;
            try {
                iArr3[Flavor.ASCII.ordinal()] = 1;
            } catch (NoSuchFieldError unused11) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class Exponent {
        public final int pow;
        public final int root;

        public Exponent(int i, int i2) {
            this.pow = i;
            this.root = i2;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public enum Flavor {
        Default,
        DEFAULT,
        ASCII
    }

    public static SimpleUnitFormat getInstance(Flavor flavor) {
        return C14342.$SwitchMap$tech$units$indriya$format$SimpleUnitFormat$Flavor[flavor.ordinal()] != 1 ? DEFAULT_INSTANCE : ASCII_INSTANCE;
    }

    public static SimpleUnitFormat getNewInstance(Flavor flavor) {
        return C14342.$SwitchMap$tech$units$indriya$format$SimpleUnitFormat$Flavor[flavor.ordinal()] != 1 ? new DefaultFormat().init() : new ASCIIFormat().init();
    }

    public abstract void alias(Unit<?> unit, String str);

    @Override // tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
    public abstract Appendable format(Unit<?> unit, Appendable appendable);

    public final StringBuffer format(Object obj, final StringBuffer stringBuffer, FieldPosition fieldPosition) {
        try {
            if (stringBuffer != null) {
                format((Unit<?>) obj, stringBuffer);
                return stringBuffer;
            }
            format((Unit<?>) obj, new Appendable() { // from class: tech.units.indriya.format.SimpleUnitFormat.1
                @Override // java.lang.Appendable
                public Appendable append(CharSequence charSequence, int i, int i2) {
                    stringBuffer.append(charSequence.subSequence(i, i2));
                    return null;
                }

                @Override // java.lang.Appendable
                public Appendable append(CharSequence charSequence) {
                    stringBuffer.append(charSequence);
                    return null;
                }

                @Override // java.lang.Appendable
                public Appendable append(char c) {
                    stringBuffer.append(c);
                    return null;
                }
            });
            return stringBuffer;
        } catch (IOException e) {
            throw new MeasurementError(e);
        }
    }

    public abstract boolean isValidIdentifier(String str);

    @Override // tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
    public abstract void label(Unit<?> unit, String str);

    public final Unit<?> parseObject(String str, ParsePosition parsePosition) {
        return parseProductUnit(str, parsePosition);
    }

    public abstract Unit<? extends Quantity> parseProductUnit(CharSequence charSequence, ParsePosition parsePosition);

    public abstract Unit<? extends Quantity> parseSingleUnit(CharSequence charSequence, ParsePosition parsePosition);

    public abstract void removeAlias(Unit<?> unit, String str);

    public abstract void removeAliases(Unit<?> unit);

    public abstract void removeLabel(Unit<?> unit);

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static final class ASCIIFormat extends DefaultFormat {
        private void aliasWithAsciiPrefixes(Unit<?> unit, String str) {
            if (!isValidIdentifier(str)) {
                return;
            }
            alias(unit, str);
            int i = 0;
            int i2 = 0;
            while (true) {
                String[] strArr = DefaultFormat.METRIC_PREFIX_SYMBOLS;
                if (i2 >= strArr.length) {
                    break;
                }
                alias(unit.prefix(MetricPrefix.values()[i2]), z82.m21092y(new StringBuilder(), asciiPrefix(strArr[i2]), str));
                i2++;
            }
            while (true) {
                String[] strArr2 = DefaultFormat.BINARY_PREFIX_SYMBOLS;
                if (i >= strArr2.length) {
                    return;
                }
                alias(unit.prefix(BinaryPrefix.values()[i]), z82.m21092y(new StringBuilder(), asciiPrefix(strArr2[i]), str));
                i++;
            }
        }

        private static String asciiPrefix(String str) {
            return "µ".equals(str) ? "micro" : str;
        }

        private static String asciiSymbol(String str) {
            return "Ω".equals(str) ? "Ohm" : str;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public ASCIIFormat init() {
            int i = 0;
            while (true) {
                Unit<?>[] unitArr = DefaultFormat.METRIC_UNITS;
                if (i >= unitArr.length) {
                    break;
                }
                Unit<?> unit = unitArr[i];
                String symbol = (unit instanceof BaseUnit ? (BaseUnit) unit : (AlternateUnit) unit).getSymbol();
                if (isAllAscii(symbol)) {
                    label(unit, symbol);
                }
                int i2 = 0;
                while (true) {
                    String[] strArr = DefaultFormat.METRIC_PREFIX_SYMBOLS;
                    if (i2 < strArr.length) {
                        Unit<?> unitPrefix = unit.prefix(MetricPrefix.values()[i2]);
                        if ("µ".equals(strArr[i2])) {
                            label(unitPrefix, "micro" + asciiSymbol(symbol));
                        }
                        i2++;
                    }
                }
                i++;
            }
            label(Units.GRAM, "g");
            for (MetricPrefix metricPrefix : MetricPrefix.values()) {
                int i3 = C14342.$SwitchMap$javax$measure$MetricPrefix[metricPrefix.ordinal()];
                if (i3 == 1) {
                    label(Units.KILOGRAM, "kg");
                } else if (i3 != 2) {
                    label(Units.GRAM.prefix(metricPrefix), metricPrefix.getSymbol() + "g");
                } else {
                    label(MetricPrefix.MICRO(Units.GRAM), "microg");
                }
            }
            labelWithAsciiPrefixes(Units.OHM, "Ohm");
            Unit<Temperature> unit2 = Units.CELSIUS;
            labelWithAsciiPrefixes(unit2, "Celsius");
            aliasWithAsciiPrefixes(unit2, "Cel");
            label(Units.METRE, "m");
            label(Units.SECOND, "s");
            label(Units.KILOMETRE_PER_HOUR, "km/h");
            alias(Units.SQUARE_METRE, "m2");
            alias(Units.CUBIC_METRE, "m3");
            label(Units.LITRE, "l");
            for (MetricPrefix metricPrefix2 : MetricPrefix.values()) {
                if (metricPrefix2 == MetricPrefix.MICRO) {
                    label(MetricPrefix.MICRO(Units.LITRE), "microL");
                } else {
                    label(Units.LITRE.prefix(metricPrefix2), metricPrefix2.getSymbol() + "L");
                }
            }
            label(Units.NEWTON, "N");
            label(Units.RADIAN, "rad");
            label(AbstractUnit.ONE, "one");
            return this;
        }

        private static boolean isAllAscii(String str) {
            for (int i = 0; i < str.length(); i++) {
                if (str.charAt(i) > 127) {
                    return false;
                }
            }
            return true;
        }

        private void labelWithAsciiPrefixes(Unit<?> unit, String str) {
            if (!isValidIdentifier(str)) {
                return;
            }
            label(unit, str);
            int i = 0;
            int i2 = 0;
            while (true) {
                String[] strArr = DefaultFormat.METRIC_PREFIX_SYMBOLS;
                if (i2 >= strArr.length) {
                    break;
                }
                label(unit.prefix(MetricPrefix.values()[i2]), z82.m21092y(new StringBuilder(), asciiPrefix(strArr[i2]), str));
                i2++;
            }
            while (true) {
                String[] strArr2 = DefaultFormat.BINARY_PREFIX_SYMBOLS;
                if (i >= strArr2.length) {
                    return;
                }
                label(unit.prefix(BinaryPrefix.values()[i]), z82.m21092y(new StringBuilder(), asciiPrefix(strArr2[i]), str));
                i++;
            }
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat.DefaultFormat, tech.units.indriya.format.SimpleUnitFormat, tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
        public Appendable format(Unit<?> unit, Appendable appendable) throws IOException {
            String strNameFor = nameFor(unit);
            if (strNameFor != null) {
                return appendable.append(strNameFor);
            }
            if (!(unit instanceof ProductUnit)) {
                C1521v3.m18903j("Cannot format given Object as a Unit");
                return null;
            }
            ProductUnit productUnit = (ProductUnit) unit;
            for (int i = 0; i < productUnit.getUnitCount(); i++) {
                if (i != 0) {
                    appendable.append('*');
                }
                String strNameFor2 = nameFor(productUnit.getUnit(i));
                int unitPow = productUnit.getUnitPow(i);
                int unitRoot = productUnit.getUnitRoot(i);
                appendable.append(strNameFor2);
                if (unitPow != 1 || unitRoot != 1) {
                    appendable.append('^');
                    appendable.append(String.valueOf(unitPow));
                    if (unitRoot != 1) {
                        appendable.append(':');
                        appendable.append(String.valueOf(unitRoot));
                    }
                }
            }
            return appendable;
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat.DefaultFormat, tech.units.indriya.format.SimpleUnitFormat
        public boolean isValidIdentifier(String str) {
            return str != null && str.length() != 0 && DefaultFormat.isUnitIdentifierPart(str.charAt(0)) && isAllAscii(str);
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat.DefaultFormat
        public String nameFor(Unit<?> unit) {
            String str = this.unitToName.get(unit);
            return str != null ? str : SimpleUnitFormat.DEFAULT_INSTANCE.nameFor(unit);
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat.DefaultFormat
        public String toString() {
            return "SimpleUnitFormat - ASCII";
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat.DefaultFormat
        public Unit<?> unitFor(String str) {
            Unit<?> unit = this.nameToUnit.get(str);
            return unit != null ? unit : SimpleUnitFormat.DEFAULT_INSTANCE.unitFor(str);
        }

        private ASCIIFormat() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class DefaultFormat extends SimpleUnitFormat {
        protected final Map<String, Unit<?>> nameToUnit;
        private final Map<String, Unit<?>> symbolToUnit;
        protected final Map<Unit<?>, String> unitToName;
        static final Unit<?>[] METRIC_UNITS = {Units.AMPERE, Units.BECQUEREL, Units.CANDELA, Units.COULOMB, Units.FARAD, Units.GRAY, Units.HENRY, Units.HERTZ, Units.JOULE, Units.KATAL, Units.KELVIN, Units.LUMEN, Units.LUX, Units.METRE, Units.MOLE, Units.NEWTON, Units.OHM, Units.PASCAL, Units.RADIAN, Units.SECOND, Units.SIEMENS, Units.SIEVERT, Units.STERADIAN, Units.TESLA, Units.VOLT, Units.WATT, Units.WEBER};
        static final String[] METRIC_PREFIX_SYMBOLS = (String[]) ((List) Stream.of((Object[]) MetricPrefix.values()).map(new cm6(25)).collect(Collectors.toList())).toArray(new String[0]);
        static final UnitConverter[] METRIC_PREFIX_CONVERTERS = (UnitConverter[]) ((List) Stream.of((Object[]) MetricPrefix.values()).map(new cm6(26)).collect(Collectors.toList())).toArray(new UnitConverter[0]);
        static final String[] BINARY_PREFIX_SYMBOLS = (String[]) ((List) Stream.of((Object[]) BinaryPrefix.values()).map(new cm6(27)).collect(Collectors.toList())).toArray(new String[0]);
        static final UnitConverter[] BINARY_PREFIX_CONVERTERS = (UnitConverter[]) ((List) Stream.of((Object[]) BinaryPrefix.values()).map(new cm6(28)).collect(Collectors.toList())).toArray(new UnitConverter[0]);

        /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
        public enum Token {
            EOF,
            IDENTIFIER,
            OPEN_PAREN,
            CLOSE_PAREN,
            EXPONENT,
            MULTIPLY,
            DIVIDE,
            PLUS,
            INTEGER,
            FLOAT
        }

        public DefaultFormat() {
            HashMap map = new HashMap();
            this.symbolToUnit = map;
            this.nameToUnit = new HashMap();
            this.unitToName = new HashMap();
            String str = MetricPrefix.MICRO.getSymbol() + "g";
            Unit<Mass> unit = Units.GRAM;
            map.put(str, MetricPrefix.MICRO(unit));
            map.put("μg", MetricPrefix.MICRO(unit));
            map.put("μg", MetricPrefix.MICRO(unit));
        }

        private void aliasWithPrefixes(Unit<?> unit, String str) {
            alias(unit, str);
            int i = 0;
            int i2 = 0;
            while (true) {
                String[] strArr = METRIC_PREFIX_SYMBOLS;
                if (i2 >= strArr.length) {
                    break;
                }
                alias(unit.prefix(MetricPrefix.values()[i2]), z82.m21092y(new StringBuilder(), strArr[i2], str));
                i2++;
            }
            while (true) {
                String[] strArr2 = BINARY_PREFIX_SYMBOLS;
                if (i >= strArr2.length) {
                    return;
                }
                alias(unit.prefix(BinaryPrefix.values()[i]), z82.m21092y(new StringBuilder(), strArr2[i], str));
                i++;
            }
        }

        private static void append(Appendable appendable, CharSequence charSequence, int i, int i2) throws IOException {
            appendable.append(charSequence);
            if (i == 1 && i2 == 1) {
                return;
            }
            if (i == 2 && i2 == 1) {
                appendable.append(FormatConstants.EXPONENT_2);
                return;
            }
            if (i == 3 && i2 == 1) {
                appendable.append((char) 179);
                return;
            }
            appendable.append('^');
            appendable.append(String.valueOf(i));
            if (i2 != 1) {
                appendable.append(':');
                appendable.append(String.valueOf(i2));
            }
        }

        private static void check(boolean z, String str, CharSequence charSequence, int i) {
            if (z) {
                return;
            }
            throw new MeasurementParseException(str + " (in " + ((Object) charSequence) + " at index " + i + ")", i);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public DefaultFormat init() {
            int i = 0;
            while (true) {
                Unit<?>[] unitArr = METRIC_UNITS;
                if (i >= unitArr.length) {
                    break;
                }
                Unit<?> unit = unitArr[i];
                String symbol = (unit instanceof BaseUnit ? (BaseUnit) unit : (AlternateUnit) unit).getSymbol();
                label(unit, symbol);
                int i2 = 0;
                while (true) {
                    String[] strArr = METRIC_PREFIX_SYMBOLS;
                    if (i2 < strArr.length) {
                        Unit<Q> unitPrefix = unit.prefix(MetricPrefix.values()[i2]);
                        label(unitPrefix, z82.m21092y(new StringBuilder(), strArr[i2], symbol));
                        if ("µ".equals(strArr[i2])) {
                            label(unitPrefix, z23.m20934p(SimpleUnitFormat.f40110MU, symbol));
                        }
                        i2++;
                    }
                }
                i++;
            }
            label(Units.GRAM, "g");
            for (MetricPrefix metricPrefix : MetricPrefix.values()) {
                int i3 = C14342.$SwitchMap$javax$measure$MetricPrefix[metricPrefix.ordinal()];
                if (i3 == 1) {
                    label(Units.KILOGRAM, "kg");
                } else if (i3 != 2) {
                    label(Units.GRAM.prefix(metricPrefix), metricPrefix.getSymbol() + "g");
                } else {
                    label(Units.GRAM.prefix(metricPrefix), metricPrefix.getSymbol() + "g");
                }
            }
            label(MetricPrefix.MICRO(Units.GRAM), MetricPrefix.MICRO.getSymbol() + "g");
            aliasWithPrefixes(Units.OHM, "Ohm");
            Unit<?> unit2 = Units.CELSIUS;
            labelWithPrefixes(unit2, "℃");
            aliasWithPrefixes(unit2, "°C");
            label(AbstractUnit.ONE, "one");
            label(Units.PERCENT, "%");
            label(Units.MINUTE, "min");
            label(Units.HOUR, "h");
            Unit<?> unit3 = Units.DAY;
            label(unit3, "d");
            alias(unit3, "day");
            Unit<?> unit4 = Units.WEEK;
            label(unit4, "wk");
            alias(unit4, "week");
            Unit<?> unit5 = Units.YEAR;
            label(unit5, "yr");
            alias(unit5, "y");
            alias(unit5, "year");
            alias(unit5, "days365");
            alias(unit5, "a");
            Unit<?> unit6 = Units.MONTH;
            label(unit6, "mo");
            alias(unit6, "mon");
            alias(unit6, "month");
            label(Units.KILOMETRE_PER_HOUR, "km/h");
            Unit<?> unit7 = Units.SQUARE_METRE;
            labelWithPrefixes(unit7, "m²");
            aliasWithPrefixes(unit7, "㎡");
            aliasWithPrefixes(unit7, "m2");
            Unit<?> unit8 = Units.CUBIC_METRE;
            labelWithPrefixes(unit8, "m³");
            aliasWithPrefixes(unit8, "㎥");
            aliasWithPrefixes(unit8, "m3");
            labelWithPrefixes(Units.LITRE, "l");
            return this;
        }

        public static boolean isUnitIdentifierPart(char c) {
            if (Character.isLetter(c)) {
                return true;
            }
            return (Character.isWhitespace(c) || Character.isDigit(c) || c == 183 || c == '*' || c == '/' || c == '(' || c == ')' || c == '[' || c == ']' || c == 185 || c == 178 || c == 179 || c == '^' || c == '+' || c == '-') ? false : true;
        }

        private void labelWithPrefixes(Unit<?> unit, String str) {
            label(unit, str);
            int i = 0;
            int i2 = 0;
            while (true) {
                String[] strArr = METRIC_PREFIX_SYMBOLS;
                if (i2 >= strArr.length) {
                    break;
                }
                label(unit.prefix(MetricPrefix.values()[i2]), z82.m21092y(new StringBuilder(), strArr[i2], str));
                i2++;
            }
            while (true) {
                String[] strArr2 = BINARY_PREFIX_SYMBOLS;
                if (i >= strArr2.length) {
                    return;
                }
                label(unit.prefix(BinaryPrefix.values()[i]), z82.m21092y(new StringBuilder(), strArr2[i], str));
                i++;
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ boolean lambda$removeAliases$1(Unit unit, String str, Map.Entry entry) {
            return ((Unit) entry.getValue()).equals(unit) && !((String) entry.getKey()).equals(str);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ boolean lambda$removeLabel$0(Unit unit, Map.Entry entry) {
            return ((Unit) entry.getValue()).equals(unit);
        }

        private static Token nextToken(CharSequence charSequence, ParsePosition parsePosition) {
            int length = charSequence.length();
            while (parsePosition.getIndex() < length) {
                char cCharAt = charSequence.charAt(parsePosition.getIndex());
                if (isUnitIdentifierPart(cCharAt)) {
                    return Token.IDENTIFIER;
                }
                if (cCharAt == '(') {
                    return Token.OPEN_PAREN;
                }
                if (cCharAt == ')') {
                    return Token.CLOSE_PAREN;
                }
                if (cCharAt == '^' || cCharAt == 185 || cCharAt == 178 || cCharAt == 179) {
                    return Token.EXPONENT;
                }
                if (cCharAt == '*') {
                    if (charSequence.length() != parsePosition.getIndex() + 1) {
                        return charSequence.charAt(parsePosition.getIndex() + 1) == '*' ? Token.EXPONENT : Token.MULTIPLY;
                    }
                    throw new MeasurementParseException("unexpected token " + Token.EOF, charSequence, parsePosition.getIndex());
                }
                if (cCharAt == 183) {
                    return Token.MULTIPLY;
                }
                if (cCharAt == '/') {
                    return Token.DIVIDE;
                }
                if (cCharAt == '+') {
                    return Token.PLUS;
                }
                if (cCharAt == '-' || Character.isDigit(cCharAt)) {
                    int index = parsePosition.getIndex() + 1;
                    while (index < length && (Character.isDigit(cCharAt) || cCharAt == '-' || cCharAt == '.' || cCharAt == 'E')) {
                        int i = index + 1;
                        char cCharAt2 = charSequence.charAt(index);
                        if (cCharAt2 == '.') {
                            return Token.FLOAT;
                        }
                        cCharAt = cCharAt2;
                        index = i;
                    }
                    return Token.INTEGER;
                }
                parsePosition.setIndex(parsePosition.getIndex() + 1);
            }
            return Token.EOF;
        }

        private static double readDouble(CharSequence charSequence, ParsePosition parsePosition) {
            int length = charSequence.length();
            int index = parsePosition.getIndex();
            int i = index + 1;
            while (i < length && "0123456789+-.E".indexOf(charSequence.charAt(i)) >= 0) {
                i++;
            }
            parsePosition.setIndex(i + 1);
            return Double.parseDouble(charSequence.subSequence(index, i).toString());
        }

        private static Exponent readExponent(CharSequence charSequence, ParsePosition parsePosition) {
            boolean z;
            boolean z2;
            char cCharAt = charSequence.charAt(parsePosition.getIndex());
            if (cCharAt == '^') {
                parsePosition.setIndex(parsePosition.getIndex() + 1);
            } else if (cCharAt == '*') {
                parsePosition.setIndex(parsePosition.getIndex() + 2);
            }
            int length = charSequence.length();
            int i = 0;
            int i2 = 0;
            boolean z3 = false;
            while (true) {
                if (parsePosition.getIndex() < length) {
                    char cCharAt2 = charSequence.charAt(parsePosition.getIndex());
                    if (cCharAt2 == '-') {
                        z3 = true;
                    } else {
                        if (cCharAt2 == ':') {
                            z = true;
                            break;
                        }
                        if (cCharAt2 == 185) {
                            i2 = (i2 * 10) + 1;
                        } else if (cCharAt2 == 178) {
                            i2 = (i2 * 10) + 2;
                        } else if (cCharAt2 == 179) {
                            i2 = (i2 * 10) + 3;
                        } else if (cCharAt2 >= '0' && cCharAt2 <= '9') {
                            i2 = (i2 * 10) + (cCharAt2 - '0');
                        }
                    }
                    parsePosition.setIndex(parsePosition.getIndex() + 1);
                }
                z = false;
                break;
            }
            if (i2 == 0) {
                i2 = 1;
            }
            if (z) {
                parsePosition.setIndex(parsePosition.getIndex() + 1);
                z2 = false;
                while (parsePosition.getIndex() < length) {
                    char cCharAt3 = charSequence.charAt(parsePosition.getIndex());
                    if (cCharAt3 == '-') {
                        z2 = true;
                    } else if (cCharAt3 == 185) {
                        i = (i * 10) + 1;
                    } else if (cCharAt3 == 178) {
                        i = (i * 10) + 2;
                    } else if (cCharAt3 == 179) {
                        i = (i * 10) + 3;
                    } else {
                        if (cCharAt3 < '0' || cCharAt3 > '9') {
                            break;
                        }
                        i = (cCharAt3 - '0') + (i * 10);
                    }
                    parsePosition.setIndex(parsePosition.getIndex() + 1);
                }
            } else {
                z2 = false;
            }
            int i3 = i != 0 ? i : 1;
            if (z3) {
                i2 = -i2;
            }
            if (z2) {
                i3 = -i3;
            }
            return new Exponent(i2, i3);
        }

        private static String readIdentifier(CharSequence charSequence, ParsePosition parsePosition) {
            int length = charSequence.length();
            int index = parsePosition.getIndex();
            int i = index;
            do {
                i++;
                if (i >= length) {
                    break;
                }
            } while (isUnitIdentifierPart(charSequence.charAt(i)));
            parsePosition.setIndex(i);
            return charSequence.subSequence(index, i).toString();
        }

        private static long readLong(CharSequence charSequence, ParsePosition parsePosition) {
            int length = charSequence.length();
            int i = 0;
            boolean z = false;
            while (parsePosition.getIndex() < length) {
                char cCharAt = charSequence.charAt(parsePosition.getIndex());
                if (cCharAt == '-') {
                    z = true;
                } else {
                    if (cCharAt < '0' || cCharAt > '9') {
                        break;
                    }
                    i = (cCharAt - '0') + (i * 10);
                }
                parsePosition.setIndex(parsePosition.getIndex() + 1);
            }
            return z ? -i : i;
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat
        public void alias(Unit<?> unit, String str) {
            if (!isValidIdentifier(str)) {
                C1521v3.m18903j(z82.m21089v("Alias: ", str, " is not a valid identifier."));
            } else {
                synchronized (this) {
                    this.nameToUnit.put(str, unit);
                }
            }
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat, tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
        public Appendable format(Unit<?> unit, Appendable appendable) throws IOException {
            String strNameFor = nameFor(unit);
            if (strNameFor != null) {
                return appendable.append(strNameFor);
            }
            if (!(unit instanceof ProductUnit)) {
                C1521v3.m18903j("Cannot format given Object as a Unit");
                return null;
            }
            ProductUnit productUnit = (ProductUnit) unit;
            if (productUnit.getUnitCount() == 1 && (productUnit.getUnit(0) instanceof ProductUnit)) {
                ProductUnit productUnit2 = (ProductUnit) productUnit.getUnit(0);
                if (nameFor(productUnit2) == null) {
                    return format(ProductUnit.ofPow(productUnit2, productUnit.getUnitPow(0)), appendable);
                }
            }
            int i = 0;
            boolean z = true;
            for (int i2 = 0; i2 < productUnit.getUnitCount(); i2++) {
                int unitPow = productUnit.getUnitPow(i2);
                if (unitPow >= 0) {
                    if (!z) {
                        appendable.append(FormatConstants.MIDDLE_DOT);
                    }
                    append(appendable, nameFor(productUnit.getUnit(i2)), unitPow, productUnit.getUnitRoot(i2));
                    z = false;
                } else {
                    i++;
                }
            }
            if (i != 0) {
                if (z) {
                    appendable.append('1');
                }
                appendable.append('/');
                if (i > 1) {
                    appendable.append('(');
                }
                boolean z2 = true;
                for (int i3 = 0; i3 < productUnit.getUnitCount(); i3++) {
                    int unitPow2 = productUnit.getUnitPow(i3);
                    if (unitPow2 < 0) {
                        String strNameFor2 = nameFor(productUnit.getUnit(i3));
                        int unitRoot = productUnit.getUnitRoot(i3);
                        if (!z2) {
                            appendable.append(FormatConstants.MIDDLE_DOT);
                        }
                        append(appendable, strNameFor2, -unitPow2, unitRoot);
                        z2 = false;
                    }
                }
                if (i > 1) {
                    appendable.append(')');
                }
            }
            return appendable;
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat
        public boolean isValidIdentifier(String str) {
            if (str == null || str.length() == 0) {
                return false;
            }
            return isUnitIdentifierPart(str.charAt(0));
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat, tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
        public void label(Unit<?> unit, String str) {
            if (!isValidIdentifier(str)) {
                C1521v3.m18903j(z82.m21089v("Label: ", str, " is not a valid identifier."));
                return;
            }
            synchronized (this) {
                this.nameToUnit.put(str, unit);
                this.unitToName.put(unit, str);
            }
        }

        public String nameFor(Unit<?> unit) {
            String str = this.unitToName.get(unit);
            if (str != null) {
                return str;
            }
            if (unit instanceof BaseUnit) {
                return ((BaseUnit) unit).getSymbol();
            }
            if (unit instanceof AlternateUnit) {
                return ((AlternateUnit) unit).getSymbol();
            }
            if (!(unit instanceof TransformedUnit)) {
                if (!(unit instanceof AnnotatedUnit)) {
                    return null;
                }
                AnnotatedUnit annotatedUnit = (AnnotatedUnit) unit;
                StringBuilder sb = new StringBuilder(nameFor(annotatedUnit.getActualUnit()));
                if (annotatedUnit.getAnnotation() != null) {
                    sb.append('{');
                    sb.append(annotatedUnit.getAnnotation());
                    sb.append('}');
                }
                return sb.toString();
            }
            TransformedUnit transformedUnit = (TransformedUnit) unit;
            if (transformedUnit.getSymbol() != null) {
                return transformedUnit.getSymbol();
            }
            Unit parentUnit = transformedUnit.getParentUnit();
            UnitConverter converter = transformedUnit.getConverter();
            StringBuilder sb2 = new StringBuilder();
            String string = parentUnit.toString();
            String strPrefixFor = prefixFor(converter);
            if (string.indexOf(183) >= 0 || string.indexOf(42) >= 0 || string.indexOf(47) >= 0) {
                sb2.append('(');
                sb2.append(string);
                sb2.append(')');
            } else {
                sb2.append(string);
            }
            if (strPrefixFor != null) {
                sb2.insert(0, strPrefixFor);
            } else if (converter instanceof AddConverter) {
                sb2.append('+');
                sb2.append(((AddConverter) converter).getOffset());
            } else {
                if (!(converter instanceof MultiplyConverter)) {
                    return "[" + parentUnit + "?]";
                }
                Number numberM21792getFactor = ((MultiplyConverter) converter).m21792getFactor();
                if (numberM21792getFactor instanceof RationalNumber) {
                    RationalNumber rationalNumberReciprocal = ((RationalNumber) numberM21792getFactor).reciprocal();
                    if (rationalNumberReciprocal.isInteger()) {
                        sb2.append('/');
                        sb2.append(rationalNumberReciprocal.toString());
                    } else {
                        sb2.append('*');
                        sb2.append(numberM21792getFactor);
                    }
                } else {
                    sb2.append('*');
                    sb2.append(numberM21792getFactor);
                }
            }
            return sb2.toString();
        }

        @Override // tech.units.indriya.format.AbstractUnitFormat
        public Unit<?> parse(CharSequence charSequence, int i) {
            return parse(charSequence, new ParsePosition(i));
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat
        public Unit<? extends Quantity> parseProductUnit(CharSequence charSequence, ParsePosition parsePosition) {
            Unit singleUnit;
            boolean z;
            if (charSequence == null) {
                throw new MeasurementParseException("Cannot parse null", charSequence, parsePosition.getIndex());
            }
            Unit unitUnitFor = unitFor(charSequence.toString());
            if (unitUnitFor != null) {
                return unitUnitFor;
            }
            Unit unit = AbstractUnit.ONE;
            int i = C14342.f40111x242fa8fa[nextToken(charSequence, parsePosition).ordinal()];
            if (i == 1) {
                singleUnit = parseSingleUnit(charSequence, parsePosition);
            } else if (i == 2) {
                parsePosition.setIndex(parsePosition.getIndex() + 1);
                Unit productUnit = parseProductUnit(charSequence, parsePosition);
                if (nextToken(charSequence, parsePosition) == Token.CLOSE_PAREN) {
                    singleUnit = unit;
                    z = true;
                } else {
                    singleUnit = unit;
                    z = false;
                }
                check(z, "')' expected", charSequence, parsePosition.getIndex());
                parsePosition.setIndex(parsePosition.getIndex() + 1);
                singleUnit = productUnit;
            }
            singleUnit = unit;
            Token tokenNextToken = nextToken(charSequence, parsePosition);
            Unit unitRoot = singleUnit;
            while (true) {
                switch (C14342.f40111x242fa8fa[tokenNextToken.ordinal()]) {
                    case 3:
                        Exponent exponent = readExponent(charSequence, parsePosition);
                        int i2 = exponent.pow;
                        unitRoot = unitRoot;
                        if (i2 != 1) {
                            unitRoot = unitRoot.pow(i2);
                        }
                        int i3 = exponent.root;
                        if (i3 != 1) {
                            unitRoot = unitRoot.root(i3);
                        }
                        break;
                    case 4:
                        parsePosition.setIndex(parsePosition.getIndex() + 1);
                        Token tokenNextToken2 = nextToken(charSequence, parsePosition);
                        if (tokenNextToken2 == Token.INTEGER) {
                            long j = readLong(charSequence, parsePosition);
                            if (j != 1) {
                                unitRoot = unitRoot.multiply(j);
                            }
                        } else if (tokenNextToken2 != Token.FLOAT) {
                            unitRoot = unitRoot.multiply(parseProductUnit(charSequence, parsePosition));
                        } else {
                            double d = readDouble(charSequence, parsePosition);
                            if (d != 1.0d) {
                                unitRoot = unitRoot.multiply(d);
                            }
                        }
                        break;
                    case 5:
                        parsePosition.setIndex(parsePosition.getIndex() + 1);
                        Token tokenNextToken3 = nextToken(charSequence, parsePosition);
                        if (tokenNextToken3 == Token.INTEGER) {
                            long j2 = readLong(charSequence, parsePosition);
                            if (j2 != 1) {
                                unitRoot = unitRoot.divide(j2);
                            }
                        } else if (tokenNextToken3 != Token.FLOAT) {
                            unitRoot = unitRoot.divide(parseProductUnit(charSequence, parsePosition));
                        } else {
                            double d2 = readDouble(charSequence, parsePosition);
                            if (d2 != 1.0d) {
                                unitRoot = unitRoot.divide(d2);
                            }
                        }
                        break;
                    case 6:
                        parsePosition.setIndex(parsePosition.getIndex() + 1);
                        Token tokenNextToken4 = nextToken(charSequence, parsePosition);
                        if (tokenNextToken4 == Token.INTEGER) {
                            long j3 = readLong(charSequence, parsePosition);
                            if (j3 != 1) {
                                unitRoot = unitRoot.shift(j3);
                            }
                        } else {
                            if (tokenNextToken4 != Token.FLOAT) {
                                throw new MeasurementParseException("not a number", charSequence, parsePosition.getIndex());
                            }
                            double d3 = readDouble(charSequence, parsePosition);
                            if (d3 != 1.0d) {
                                unitRoot = unitRoot.shift(d3);
                            }
                        }
                        break;
                    case 7:
                    case 8:
                        return unitRoot;
                    default:
                        throw new MeasurementParseException("unexpected token " + tokenNextToken, charSequence, parsePosition.getIndex());
                }
                tokenNextToken = nextToken(charSequence, parsePosition);
                unitRoot = unitRoot;
            }
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat
        public Unit<? extends Quantity> parseSingleUnit(CharSequence charSequence, ParsePosition parsePosition) {
            int index = parsePosition.getIndex();
            String identifier = readIdentifier(charSequence, parsePosition);
            Unit unitUnitFor = unitFor(identifier);
            check(unitUnitFor != null, z82.m21088u(identifier, " not recognized"), charSequence, index);
            return unitUnitFor;
        }

        public String prefixFor(UnitConverter unitConverter) {
            int i = 0;
            int i2 = 0;
            while (true) {
                UnitConverter[] unitConverterArr = METRIC_PREFIX_CONVERTERS;
                if (i2 >= unitConverterArr.length) {
                    while (true) {
                        UnitConverter[] unitConverterArr2 = BINARY_PREFIX_CONVERTERS;
                        if (i >= unitConverterArr2.length) {
                            return null;
                        }
                        if (unitConverterArr2[i].equals(unitConverter)) {
                            return BINARY_PREFIX_SYMBOLS[i];
                        }
                        i++;
                    }
                } else {
                    if (unitConverterArr[i2].equals(unitConverter)) {
                        return METRIC_PREFIX_SYMBOLS[i2];
                    }
                    i2++;
                }
            }
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat
        public void removeAlias(Unit<?> unit, String str) {
            this.nameToUnit.remove(str);
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat
        public void removeAliases(final Unit<?> unit) {
            final String str = this.unitToName.get(unit);
            this.nameToUnit.entrySet().removeIf(new Predicate() { // from class: tech.units.indriya.format.b
                @Override // java.util.function.Predicate
                public final boolean test(Object obj) {
                    return SimpleUnitFormat.DefaultFormat.lambda$removeAliases$1(unit, str, (Map.Entry) obj);
                }
            });
        }

        @Override // tech.units.indriya.format.SimpleUnitFormat
        public void removeLabel(final Unit<?> unit) {
            this.unitToName.remove(unit);
            this.nameToUnit.entrySet().removeIf(new Predicate() { // from class: tech.units.indriya.format.a
                @Override // java.util.function.Predicate
                public final boolean test(Object obj) {
                    return SimpleUnitFormat.DefaultFormat.lambda$removeLabel$0(unit, (Map.Entry) obj);
                }
            });
        }

        public String toString() {
            return "SimpleUnitFormat";
        }

        public Unit<?> unitFor(String str) {
            Unit<?> unit = this.nameToUnit.get(str);
            return unit != null ? unit : this.symbolToUnit.get(str);
        }

        @Override // javax.measure.format.UnitFormat
        public Unit<?> parse(CharSequence charSequence) {
            return parse(charSequence, 0);
        }

        @Override // tech.units.indriya.format.AbstractUnitFormat, javax.measure.format.UnitFormat
        public Unit<?> parse(CharSequence charSequence, ParsePosition parsePosition) {
            return parseObject(charSequence.toString(), parsePosition);
        }
    }

    public static SimpleUnitFormat getInstance() {
        return getInstance(Flavor.DEFAULT);
    }

    public static SimpleUnitFormat getNewInstance() {
        return getNewInstance(Flavor.DEFAULT);
    }
}
