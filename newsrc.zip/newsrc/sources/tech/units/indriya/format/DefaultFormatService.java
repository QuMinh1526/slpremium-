package tech.units.indriya.format;

import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import javax.measure.format.QuantityFormat;
import javax.measure.format.UnitFormat;
import javax.measure.spi.FormatService;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class DefaultFormatService implements FormatService {
    private static final String ASCII_UNIT_FORMAT_NAME = "SIMPLE_ASCII";
    private static final String DEFAULT_QUANTITY_FORMAT_NAME = "SIMPLE";
    private static final String DEFAULT_UNIT_FORMAT_NAME = "SIMPLE_DEFAULT";
    private static final String EBNF_KEY = "EBNF";
    private static final NumberDelimiterQuantityFormat EBNF_QUANTITY_FORMAT = new NumberDelimiterQuantityFormat.Builder().setNumberFormat(NumberFormat.getInstance(Locale.ROOT)).setUnitFormat(EBNFUnitFormat.getInstance()).build();
    private static final String LOCAL_KEY = "LOCAL";
    private static final int PRIO = 1000;
    private static final String SIMPLE_KEY = "SIMPLE";
    private final Map<String, String> quantityFormatAliases;
    private final Map<String, QuantityFormat> quantityFormats;
    private final Map<String, String> unitFormatAliases;
    private final Map<String, UnitFormat> unitFormats;

    /* JADX INFO: renamed from: tech.units.indriya.format.DefaultFormatService$1 */
    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static /* synthetic */ class C14311 {
        static final /* synthetic */ int[] $SwitchMap$javax$measure$spi$FormatService$FormatType;

        static {
            int[] iArr = new int[FormatService.FormatType.values().length];
            $SwitchMap$javax$measure$spi$FormatService$FormatType = iArr;
            try {
                iArr[FormatService.FormatType.QUANTITY_FORMAT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    public DefaultFormatService() {
        HashMap map = new HashMap();
        this.quantityFormats = map;
        HashMap map2 = new HashMap();
        this.unitFormats = map2;
        HashMap map3 = new HashMap();
        this.unitFormatAliases = map3;
        HashMap map4 = new HashMap();
        this.quantityFormatAliases = map4;
        map2.put(DEFAULT_UNIT_FORMAT_NAME, SimpleUnitFormat.getInstance());
        map2.put(ASCII_UNIT_FORMAT_NAME, SimpleUnitFormat.getInstance(SimpleUnitFormat.Flavor.ASCII));
        map2.put(EBNF_KEY, EBNFUnitFormat.getInstance());
        map2.put(LOCAL_KEY, LocalUnitFormat.getInstance());
        map3.put("DEFAULT", DEFAULT_UNIT_FORMAT_NAME);
        map3.put("ASCII", ASCII_UNIT_FORMAT_NAME);
        map.put("SIMPLE", SimpleQuantityFormat.getInstance());
        map.put("NUMBERDELIMITER", NumberDelimiterQuantityFormat.getInstance());
        map.put(EBNF_KEY, EBNF_QUANTITY_FORMAT);
        map.put(LOCAL_KEY, NumberDelimiterQuantityFormat.getInstance(FormatBehavior.LOCALE_SENSITIVE));
        map4.put("NUMBERSPACE", "NUMBERDELIMITER");
    }

    @Override // javax.measure.spi.FormatService
    public Set<String> getAvailableFormatNames(FormatService.FormatType formatType) {
        return C14311.$SwitchMap$javax$measure$spi$FormatService$FormatType[formatType.ordinal()] != 1 ? this.unitFormats.keySet() : this.quantityFormats.keySet();
    }

    public int getPriority() {
        return PRIO;
    }

    @Override // javax.measure.spi.FormatService
    public QuantityFormat getQuantityFormat(String str) {
        Objects.requireNonNull(str, "Format name or alias required");
        String str2 = this.quantityFormatAliases.get(str.toUpperCase());
        return (str2 == null || str2.length() <= 0) ? this.quantityFormats.get(str.toUpperCase()) : this.quantityFormats.get(str2.toUpperCase());
    }

    @Override // javax.measure.spi.FormatService
    public UnitFormat getUnitFormat(String str) {
        Objects.requireNonNull(str, "Format name or alias required");
        String str2 = this.unitFormatAliases.get(str.toUpperCase());
        return (str2 == null || str2.length() <= 0) ? this.unitFormats.get(str.toUpperCase()) : this.unitFormats.get(str2);
    }

    @Override // javax.measure.spi.FormatService
    public UnitFormat getUnitFormat() {
        return getUnitFormat(DEFAULT_UNIT_FORMAT_NAME);
    }

    @Override // javax.measure.spi.FormatService
    public UnitFormat getUnitFormat(String str, String str2) {
        StringBuilder sb = new StringBuilder(str);
        if (str2 != null && !str2.isEmpty()) {
            sb.append("_");
            sb.append(str2);
        }
        return getUnitFormat(sb.toString());
    }

    @Override // javax.measure.spi.FormatService
    public QuantityFormat getQuantityFormat() {
        return getQuantityFormat("SIMPLE");
    }
}
