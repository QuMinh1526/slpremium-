package tech.units.indriya.format;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public enum UnitStyle {
    NAME,
    SYMBOL,
    LABEL,
    NAME_AND_SYMBOL,
    SYMBOL_AND_LABEL
}
