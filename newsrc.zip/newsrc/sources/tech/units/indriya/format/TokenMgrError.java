package tech.units.indriya.format;

import javax.measure.MeasurementError;
import p000.z23;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class TokenMgrError extends MeasurementError {
    public static final int INVALID_LEXICAL_STATE = 2;
    public static final int LEXICAL_ERROR = 0;
    public static final int LOOP_DETECTED = 3;
    public static final int STATIC_LEXER_ERROR = 1;
    private static final long serialVersionUID = -3348968864772188432L;

    public TokenMgrError(boolean z, int i, int i2, String str, char c, int i3) {
        this(lexicalError(z, i, i2, str, c), i3);
    }

    public static String addEscapes(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char cCharAt = str.charAt(i);
            if (cCharAt != 0) {
                if (cCharAt == '\"') {
                    sb.append("\\\"");
                } else if (cCharAt == '\'') {
                    sb.append("\\'");
                } else if (cCharAt == '\\') {
                    sb.append("\\\\");
                } else if (cCharAt == '\f') {
                    sb.append("\\f");
                } else if (cCharAt != '\r') {
                    switch (cCharAt) {
                        case '\b':
                            sb.append("\\b");
                            break;
                        case '\t':
                            sb.append("\\t");
                            break;
                        case '\n':
                            sb.append("\\n");
                            break;
                        default:
                            char cCharAt2 = str.charAt(i);
                            if (cCharAt2 < ' ' || cCharAt2 > '~') {
                                String str2 = "0000" + Integer.toString(cCharAt2, 16);
                                sb.append("\\u");
                                sb.append(str2.substring(str2.length() - 4, str2.length()));
                            } else {
                                sb.append(cCharAt2);
                            }
                            break;
                    }
                } else {
                    sb.append("\\r");
                }
            }
        }
        return sb.toString();
    }

    public static String lexicalError(boolean z, int i, int i2, String str, char c) {
        String str2;
        StringBuilder sbM20940v = z23.m20940v(i, i2, "Lexical error at line ", ", column ", ".  Encountered: ");
        if (z) {
            str2 = "<EOF> ";
        } else {
            str2 = "\"" + addEscapes(String.valueOf(c)) + "\" (" + ((int) c) + "), ";
        }
        sbM20940v.append(str2);
        sbM20940v.append("after : \"");
        sbM20940v.append(addEscapes(str));
        sbM20940v.append("\"");
        return sbM20940v.toString();
    }

    public TokenMgrError(String str) {
        super(str);
    }

    public TokenMgrError(String str, int i) {
        super(str);
    }

    public TokenMgrError() {
    }
}
