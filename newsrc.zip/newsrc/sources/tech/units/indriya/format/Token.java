package tech.units.indriya.format;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public final class Token {
    public int beginColumn;
    public int beginLine;
    public int endColumn;
    public int endLine;
    public String image;
    public int kind;
    public Token next;
    public Token specialToken;

    private Token(int i, String str) {
        this.kind = i;
        this.image = str;
    }

    /* JADX INFO: renamed from: of */
    public static Token m17666of(int i, String str) {
        return new Token(i, str);
    }

    public Object getValue() {
        return null;
    }

    public String toString() {
        return this.image;
    }

    /* JADX INFO: renamed from: of */
    public static Token m17665of(int i) {
        return m17666of(i, null);
    }

    public Token() {
    }
}
