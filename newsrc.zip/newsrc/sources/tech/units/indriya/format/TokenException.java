package tech.units.indriya.format;

import com.squareup.picasso.BuildConfig;
import javax.measure.format.MeasurementParseException;
import p000.bna;
import p000.z23;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public class TokenException extends MeasurementParseException {
    private static final long serialVersionUID = 2932151235799168061L;
    public Token currentToken;
    protected String eol;
    private int[][] expectedTokenSequences;
    private String[] tokenImage;

    public TokenException(Token token, int[][] iArr, String[] strArr) {
        super(initialise(token, iArr, strArr));
        this.eol = System.getProperty("line.separator", "\n");
        this.currentToken = token;
        this.expectedTokenSequences = iArr;
        this.tokenImage = strArr;
    }

    private static String add_escapes(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char cCharAt = str.charAt(i);
            if (cCharAt != 0) {
                if (cCharAt == '\"') {
                    sb.append("\\\"");
                } else if (cCharAt == '\'') {
                    sb.append("\\'");
                } else if (cCharAt == '\\') {
                    sb.append("\\\\");
                } else if (cCharAt == '\f') {
                    sb.append("\\f");
                } else if (cCharAt != '\r') {
                    switch (cCharAt) {
                        case '\b':
                            sb.append("\\b");
                            break;
                        case '\t':
                            sb.append("\\t");
                            break;
                        case '\n':
                            sb.append("\\n");
                            break;
                        default:
                            char cCharAt2 = str.charAt(i);
                            if (cCharAt2 < ' ' || cCharAt2 > '~') {
                                String str2 = "0000" + Integer.toString(cCharAt2, 16);
                                sb.append("\\u");
                                sb.append(str2.substring(str2.length() - 4, str2.length()));
                            } else {
                                sb.append(cCharAt2);
                            }
                            break;
                    }
                } else {
                    sb.append("\\r");
                }
            }
        }
        return sb.toString();
    }

    private static String initialise(Token token, int[][] iArr, String[] strArr) {
        String property = System.getProperty("line.separator", "\n");
        StringBuilder sb = new StringBuilder();
        int length = 0;
        for (int[] iArr2 : iArr) {
            if (length < iArr2.length) {
                length = iArr2.length;
            }
            for (int i : iArr2) {
                sb.append(strArr[i]);
                sb.append(' ');
            }
            if (iArr2[iArr2.length - 1] != 0) {
                sb.append("...");
            }
            sb.append(property);
            sb.append("    ");
        }
        Token token2 = token.next;
        String string = "Encountered \"";
        for (int i2 = 0; i2 < length; i2++) {
            if (i2 != 0) {
                string = string.concat(" ");
            }
            if (token2.kind == 0) {
                StringBuilder sbM20943y = z23.m20943y(string);
                sbM20943y.append(strArr[0]);
                string = sbM20943y.toString();
                break;
            }
            StringBuilder sbM20944z = z23.m20944z(string, " ");
            sbM20944z.append(strArr[token2.kind]);
            StringBuilder sbM20943y2 = z23.m20943y(sbM20944z.toString().concat(" \""));
            sbM20943y2.append(add_escapes(token2.image));
            string = sbM20943y2.toString().concat(" \"");
            token2 = token2.next;
        }
        StringBuilder sbM20944z2 = z23.m20944z(string, "\" at line ");
        sbM20944z2.append(token.next.beginLine);
        sbM20944z2.append(", column ");
        sbM20944z2.append(token.next.beginColumn);
        String strM2610g = bna.m2610g(sbM20944z2.toString(), ".", property);
        return (iArr.length == 1 ? bna.m2615l(strM2610g, "Was expecting:", property, "    ") : bna.m2615l(strM2610g, "Was expecting one of:", property, "    ")).concat(sb.toString());
    }

    public Token getToken() {
        return this.currentToken;
    }

    public TokenException() {
        super(BuildConfig.VERSION_NAME);
        this.eol = System.getProperty("line.separator", "\n");
    }

    public TokenException(String str) {
        super(str);
        this.eol = System.getProperty("line.separator", "\n");
    }
}
