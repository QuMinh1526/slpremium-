package tech.units.indriya.format;

import java.io.IOException;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import javax.measure.MeasurementException;
import javax.measure.Quantity;
import javax.measure.format.MeasurementParseException;
import javax.measure.format.QuantityFormat;
import p000.C1521v3;
import tech.units.indriya.ComparableQuantity;
import tech.units.indriya.quantity.MixedQuantity;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class AbstractQuantityFormat extends Format implements QuantityFormat {
    protected static final String DEFAULT_DELIMITER = " ";
    private static final long serialVersionUID = -4628006924354248662L;

    @Override // javax.measure.format.QuantityFormat
    public abstract Appendable format(Quantity<?> quantity, Appendable appendable);

    @Override // javax.measure.format.QuantityFormat
    public final String format(Quantity<?> quantity) {
        if (quantity instanceof ComparableQuantity) {
            return format((ComparableQuantity<?>) quantity, new StringBuffer()).toString();
        }
        try {
            return format(quantity, new StringBuffer()).toString();
        } catch (IOException e) {
            throw new MeasurementException(e);
        }
    }

    public abstract StringBuffer formatMixed(MixedQuantity<?> mixedQuantity, StringBuffer stringBuffer);

    @Override // 
    public abstract Quantity<?> parse(CharSequence charSequence);

    public abstract Quantity<?> parse(CharSequence charSequence, int i);

    @Override // javax.measure.format.QuantityFormat
    public abstract Quantity<?> parse(CharSequence charSequence, ParsePosition parsePosition);

    @Override // java.text.Format
    public final Quantity<?> parseObject(String str, ParsePosition parsePosition) {
        try {
            return parse(str, parsePosition);
        } catch (IllegalArgumentException | MeasurementParseException unused) {
            return null;
        }
    }

    @Override // java.text.Format
    public final StringBuffer format(Object obj, StringBuffer stringBuffer, FieldPosition fieldPosition) {
        if (obj instanceof MixedQuantity) {
            return formatMixed((MixedQuantity) obj, stringBuffer);
        }
        if (!(obj instanceof ComparableQuantity)) {
            C1521v3.m18903j("obj: Not an instance of Quantity");
            return null;
        }
        if (stringBuffer != null && fieldPosition != null) {
            return format((ComparableQuantity<?>) obj, stringBuffer);
        }
        throw null;
    }

    public final StringBuffer format(ComparableQuantity<?> comparableQuantity, StringBuffer stringBuffer) {
        try {
            return (StringBuffer) format((Quantity<?>) comparableQuantity, (Appendable) stringBuffer);
        } catch (IOException e) {
            throw new MeasurementException(e);
        }
    }
}
