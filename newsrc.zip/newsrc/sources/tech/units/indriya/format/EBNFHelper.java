package tech.units.indriya.format;

import androidx.appcompat.widget.ActivityChooserModel;
import java.io.IOException;
import java.util.Map;
import javax.measure.Unit;
import javax.measure.UnitConverter;
import org.p003jf.dexlib2.dexbacked.raw.HeaderItem;
import tech.units.indriya.AbstractUnit;
import tech.units.indriya.unit.AnnotatedUnit;
import tech.units.indriya.unit.BaseUnit;
import tech.units.indriya.unit.ProductUnit;
import tech.units.indriya.unit.TransformedUnit;
import tech.units.indriya.unit.Units;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes3.dex */
class EBNFHelper {
    private static void formatExponent(Unit<?> unit, int i, int i2, boolean z, Appendable appendable, SymbolMap symbolMap) throws IOException {
        if (z) {
            appendable.append(FormatConstants.MIDDLE_DOT);
        }
        StringBuilder sb = new StringBuilder();
        if (formatInternal(unit, sb, symbolMap) < 2) {
            sb.insert(0, '(');
            sb.append(')');
        }
        appendable.append(sb);
        if (i2 == 1 && i == 1) {
            return;
        }
        if (i2 != 1 || i <= 1) {
            if (i2 == 1) {
                appendable.append('^');
                appendable.append(String.valueOf(i));
                return;
            }
            appendable.append("^(");
            appendable.append(String.valueOf(i));
            appendable.append('/');
            appendable.append(String.valueOf(i2));
            appendable.append(')');
            return;
        }
        String string = Integer.toString(i);
        for (int i3 = 0; i3 < string.length(); i3++) {
            switch (string.charAt(i3)) {
                case '0':
                    appendable.append((char) 8304);
                    break;
                case '1':
                    appendable.append(FormatConstants.EXPONENT_1);
                    break;
                case ActivityChooserModel.DEFAULT_HISTORY_MAX_LENGTH /* 50 */:
                    appendable.append(FormatConstants.EXPONENT_2);
                    break;
                case '3':
                    appendable.append((char) 179);
                    break;
                case HeaderItem.MAP_OFFSET /* 52 */:
                    appendable.append((char) 8308);
                    break;
                case '5':
                    appendable.append((char) 8309);
                    break;
                case '6':
                    appendable.append((char) 8310);
                    break;
                case '7':
                    appendable.append((char) 8311);
                    break;
                case HeaderItem.STRING_COUNT_OFFSET /* 56 */:
                    appendable.append((char) 8312);
                    break;
                case '9':
                    appendable.append((char) 8313);
                    break;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static int formatInternal(Unit<?> unit, Appendable appendable, SymbolMap symbolMap) {
        if (unit instanceof AnnotatedUnit) {
            unit = ((AnnotatedUnit) unit).getActualUnit();
        }
        String symbol = symbolMap.getSymbol(unit);
        if (symbol != null) {
            return noopPrecedenceInternal(appendable, symbol);
        }
        if ((unit instanceof ProductUnit) && unit.getBaseUnits() != null) {
            return productPrecedenceInternal(unit, appendable, symbolMap);
        }
        if (unit instanceof BaseUnit) {
            return noopPrecedenceInternal(appendable, ((BaseUnit) unit).getSymbol());
        }
        if (unit.getSymbol() != null) {
            return noopPrecedenceInternal(appendable, unit.getSymbol());
        }
        StringBuilder sb = new StringBuilder();
        Unit systemUnit = unit.getSystemUnit();
        UnitConverter systemConverter = ((AbstractUnit) unit).getSystemConverter();
        if (Units.KILOGRAM.equals(systemUnit)) {
            systemUnit = Units.GRAM;
            if (unit.equals(systemUnit)) {
                appendable.append(symbolMap.getSymbol((Unit<?>) systemUnit));
                return Integer.MAX_VALUE;
            }
            systemConverter = unit instanceof TransformedUnit ? ((TransformedUnit) unit).getConverter() : unit.getConverterTo(systemUnit);
        } else if (!Units.CUBIC_METRE.equals(systemUnit)) {
            Units.METRE.equals(systemUnit);
        } else if (systemConverter != null) {
            systemUnit = Units.LITRE;
        }
        if (unit instanceof TransformedUnit) {
            TransformedUnit transformedUnit = (TransformedUnit) unit;
            if (systemUnit == null || transformedUnit.getParentUnit() != null) {
                systemUnit = transformedUnit.getParentUnit();
            }
            systemConverter = transformedUnit.getConverter();
        }
        int converter = ConverterFormatter.formatConverter(systemConverter, !systemUnit.equals(AbstractUnit.ONE), formatInternal(systemUnit, sb, symbolMap), sb, symbolMap);
        appendable.append(sb);
        return converter;
    }

    private static int noopPrecedenceInternal(Appendable appendable, String str) throws IOException {
        appendable.append(str);
        return Integer.MAX_VALUE;
    }

    private static int productPrecedenceInternal(Unit<?> unit, Appendable appendable, SymbolMap symbolMap) throws IOException {
        Map<? extends Unit<?>, Integer> baseUnits = unit.getBaseUnits();
        int i = 0;
        boolean z = true;
        for (Map.Entry<? extends Unit<?>, Integer> entry : baseUnits.entrySet()) {
            int iIntValue = entry.getValue().intValue();
            if (iIntValue >= 0) {
                formatExponent(entry.getKey(), iIntValue, 1, !z, appendable, symbolMap);
                z = false;
            } else {
                i++;
            }
        }
        if (i <= 0) {
            return 2;
        }
        if (z) {
            appendable.append('1');
        }
        appendable.append('/');
        if (i > 1) {
            appendable.append('(');
        }
        boolean z2 = true;
        for (Map.Entry<? extends Unit<?>, Integer> entry2 : baseUnits.entrySet()) {
            int iIntValue2 = entry2.getValue().intValue();
            if (iIntValue2 < 0) {
                formatExponent(entry2.getKey(), -iIntValue2, 1, !z2, appendable, symbolMap);
                z2 = false;
            }
        }
        if (i <= 1) {
            return 2;
        }
        appendable.append(')');
        return 2;
    }
}
