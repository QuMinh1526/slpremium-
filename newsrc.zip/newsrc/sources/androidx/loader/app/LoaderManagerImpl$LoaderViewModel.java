package androidx.loader.app;

import androidx.lifecycle.ViewModel;
import p000.b7a;
import p000.mcb;
import p000.ro6;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class LoaderManagerImpl$LoaderViewModel extends ViewModel {

    /* JADX INFO: renamed from: i */
    public static final mcb f1946i = new C01701();

    /* JADX INFO: renamed from: e */
    public final b7a f1947e = new b7a(0);

    /* JADX INFO: renamed from: androidx.loader.app.LoaderManagerImpl$LoaderViewModel$1 */
    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class C01701 implements mcb {
        @Override // p000.mcb
        /* JADX INFO: renamed from: a */
        public final ViewModel mo1064a(Class cls) {
            return new LoaderManagerImpl$LoaderViewModel();
        }
    }

    @Override // androidx.lifecycle.ViewModel
    public final void onCleared() {
        super.onCleared();
        b7a b7aVar = this.f1947e;
        if (b7aVar.m2150f() > 0) {
            b7aVar.m2151g(0).getClass();
            ro6.m16594d();
            return;
        }
        int i = b7aVar.f3455z;
        Object[] objArr = b7aVar.f3454y;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        b7aVar.f3455z = 0;
        b7aVar.f3452e = false;
    }
}
