package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import p000.bf7;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, m12198d2 = {"Landroidx/activity/result/IntentSenderRequest;", "Landroid/os/Parcelable;", "cp1", "activity"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
@SuppressLint({"BanParcelableUsage"})
public final class IntentSenderRequest implements Parcelable {

    @NotNull
    public static final Parcelable.Creator<IntentSenderRequest> CREATOR = new bf7(19);

    /* JADX INFO: renamed from: e */
    public final IntentSender f1113e;

    /* JADX INFO: renamed from: i */
    public final Intent f1114i;

    /* JADX INFO: renamed from: y */
    public final int f1115y;

    /* JADX INFO: renamed from: z */
    public final int f1116z;

    public IntentSenderRequest(IntentSender intentSender, Intent intent, int i, int i2) {
        intentSender.getClass();
        this.f1113e = intentSender;
        this.f1114i = intent;
        this.f1115y = i;
        this.f1116z = i2;
    }

    /* JADX INFO: renamed from: a, reason: from getter */
    public final Intent getF1114i() {
        return this.f1114i;
    }

    /* JADX INFO: renamed from: b, reason: from getter */
    public final int getF1115y() {
        return this.f1115y;
    }

    /* JADX INFO: renamed from: c, reason: from getter */
    public final int getF1116z() {
        return this.f1116z;
    }

    /* JADX INFO: renamed from: d, reason: from getter */
    public final IntentSender getF1113e() {
        return this.f1113e;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.getClass();
        parcel.writeParcelable(this.f1113e, i);
        parcel.writeParcelable(this.f1114i, i);
        parcel.writeInt(this.f1115y);
        parcel.writeInt(this.f1116z);
    }
}
