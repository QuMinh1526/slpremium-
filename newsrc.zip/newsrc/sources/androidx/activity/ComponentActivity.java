package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.ComponentActivity;
import androidx.annotation.CallSuper;
import androidx.annotation.LayoutRes;
import androidx.annotation.MainThread;
import androidx.annotation.RequiresApi;
import androidx.lifecycle.SavedStateViewModelFactory;
import androidx.lifecycle.ViewModelProvider$AndroidViewModelFactory;
import com.squareup.picasso.BuildConfig;
import ginlemon.flowerfree.R;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.p003jf.dexlib2.ValueType;
import p000.AbstractC0424dl;
import p000.AbstractC0622il;
import p000.AbstractC0902ol;
import p000.C0696km;
import p000.C1521v3;
import p000.InterfaceC0265cl;
import p000.InterfaceC1322ql;
import p000.a37;
import p000.aa6;
import p000.aja;
import p000.b37;
import p000.bp2;
import p000.er4;
import p000.fy6;
import p000.g28;
import p000.jh4;
import p000.jh7;
import p000.k42;
import p000.kj4;
import p000.lj4;
import p000.lp6;
import p000.ls8;
import p000.lu1;
import p000.m96;
import p000.mcb;
import p000.n96;
import p000.na9;
import p000.np6;
import p000.o96;
import p000.oa9;
import p000.ob2;
import p000.ocb;
import p000.og7;
import p000.ou1;
import p000.ou2;
import p000.p26;
import p000.pa9;
import p000.pcb;
import p000.pg7;
import p000.pu1;
import p000.py8;
import p000.qa9;
import p000.qg7;
import p000.r21;
import p000.r68;
import p000.ra9;
import p000.ru1;
import p000.ry8;
import p000.sg7;
import p000.tu1;
import p000.ul5;
import p000.uu1;
import p000.ux6;
import p000.vu1;
import p000.wg7;
import p000.wp6;
import p000.x96;
import p000.xg7;
import p000.xu1;
import p000.y62;
import p000.zza;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000Ì\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\b\u0016\u0018\u0000 Ã\u00012\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u00042\u00020\u00052\u00020\u00062\u00020\u00072\u00020\b2\u00020\t2\u00020\u00022\u00020\n2\u00020\u000b2\u00020\u00022\u00020\f2\u00020\r2\u00020\u00022\u00020\u000e2\u00020\u0002:\bÄ\u0001\u0083\u0001Å\u0001Æ\u0001J\u0017\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0010\u001a\u00020\u000fH\u0015¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0014\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0014\u0010\u0015J\u0011\u0010\u0016\u001a\u0004\u0018\u00010\u0002H\u0017¢\u0006\u0004\b\u0016\u0010\u0015J\u0019\u0010\u0019\u001a\u00020\u00112\b\u0010\u0018\u001a\u0004\u0018\u00010\u0017H\u0016¢\u0006\u0004\b\u0019\u0010\u001aJ\u000f\u0010\u001b\u001a\u00020\u0011H\u0017¢\u0006\u0004\b\u001b\u0010\u001cJ\u0011\u0010\u001e\u001a\u0004\u0018\u00010\u001dH\u0016¢\u0006\u0004\b\u001e\u0010\u001fJ\u0015\u0010\"\u001a\u00020\u00112\u0006\u0010!\u001a\u00020 ¢\u0006\u0004\b\"\u0010#J\u0015\u0010$\u001a\u00020\u00112\u0006\u0010!\u001a\u00020 ¢\u0006\u0004\b$\u0010#J)\u0010*\u001a\u00020)2\u0006\u0010&\u001a\u00020%2\b\u0010\u0018\u001a\u0004\u0018\u00010\u00172\u0006\u0010(\u001a\u00020'H\u0016¢\u0006\u0004\b*\u0010+J\u001f\u0010,\u001a\u00020)2\u0006\u0010&\u001a\u00020%2\u0006\u0010(\u001a\u00020'H\u0016¢\u0006\u0004\b,\u0010-J\u0017\u00100\u001a\u00020\u00112\u0006\u0010/\u001a\u00020.H\u0016¢\u0006\u0004\b0\u00101J\u001f\u00100\u001a\u00020\u00112\u0006\u0010/\u001a\u00020.2\u0006\u00102\u001a\u00020\u0003H\u0016¢\u0006\u0004\b0\u00103J'\u00100\u001a\u00020\u00112\u0006\u0010/\u001a\u00020.2\u0006\u00102\u001a\u00020\u00032\u0006\u00105\u001a\u000204H\u0017¢\u0006\u0004\b0\u00106J\u0017\u00107\u001a\u00020\u00112\u0006\u0010/\u001a\u00020.H\u0016¢\u0006\u0004\b7\u00101J\u000f\u00108\u001a\u00020\u0011H\u0016¢\u0006\u0004\b8\u0010\u001cJ\u000f\u00109\u001a\u00020\u0011H\u0017¢\u0006\u0004\b9\u0010\u001cJ\u001f\u0010=\u001a\u00020\u00112\u0006\u0010;\u001a\u00020:2\u0006\u0010<\u001a\u00020%H\u0017¢\u0006\u0004\b=\u0010>J)\u0010=\u001a\u00020\u00112\u0006\u0010;\u001a\u00020:2\u0006\u0010<\u001a\u00020%2\b\u0010?\u001a\u0004\u0018\u00010\u000fH\u0017¢\u0006\u0004\b=\u0010@JA\u0010F\u001a\u00020\u00112\u0006\u0010;\u001a\u00020A2\u0006\u0010<\u001a\u00020%2\b\u0010B\u001a\u0004\u0018\u00010:2\u0006\u0010C\u001a\u00020%2\u0006\u0010D\u001a\u00020%2\u0006\u0010E\u001a\u00020%H\u0017¢\u0006\u0004\bF\u0010GJK\u0010F\u001a\u00020\u00112\u0006\u0010;\u001a\u00020A2\u0006\u0010<\u001a\u00020%2\b\u0010B\u001a\u0004\u0018\u00010:2\u0006\u0010C\u001a\u00020%2\u0006\u0010D\u001a\u00020%2\u0006\u0010E\u001a\u00020%2\b\u0010?\u001a\u0004\u0018\u00010\u000fH\u0017¢\u0006\u0004\bF\u0010HJI\u0010R\u001a\b\u0012\u0004\u0012\u00028\u00000Q\"\u0004\b\u0000\u0010I\"\u0004\b\u0001\u0010J2\u0012\u0010L\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010K2\u0006\u0010N\u001a\u00020M2\f\u0010P\u001a\b\u0012\u0004\u0012\u00028\u00010O¢\u0006\u0004\bR\u0010SJA\u0010R\u001a\b\u0012\u0004\u0012\u00028\u00000Q\"\u0004\b\u0000\u0010I\"\u0004\b\u0001\u0010J2\u0012\u0010L\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010K2\f\u0010P\u001a\b\u0012\u0004\u0012\u00028\u00010O¢\u0006\u0004\bR\u0010TJ\u001b\u0010W\u001a\u00020\u00112\f\u0010!\u001a\b\u0012\u0004\u0012\u00020V0U¢\u0006\u0004\bW\u0010XJ\u001b\u0010Y\u001a\u00020\u00112\f\u0010!\u001a\b\u0012\u0004\u0012\u00020V0U¢\u0006\u0004\bY\u0010XJ\u0017\u0010[\u001a\u00020\u00112\u0006\u0010Z\u001a\u00020%H\u0017¢\u0006\u0004\b[\u0010\\J\u001b\u0010]\u001a\u00020\u00112\f\u0010!\u001a\b\u0012\u0004\u0012\u00020%0U¢\u0006\u0004\b]\u0010XJ\u001b\u0010^\u001a\u00020\u00112\f\u0010!\u001a\b\u0012\u0004\u0012\u00020%0U¢\u0006\u0004\b^\u0010XJ\u0017\u0010_\u001a\u00020\u00112\u0006\u0010;\u001a\u00020:H\u0015¢\u0006\u0004\b_\u0010`J\u001b\u0010a\u001a\u00020\u00112\f\u0010!\u001a\b\u0012\u0004\u0012\u00020:0U¢\u0006\u0004\ba\u0010XJ\u001b\u0010b\u001a\u00020\u00112\f\u0010!\u001a\b\u0012\u0004\u0012\u00020:0U¢\u0006\u0004\bb\u0010XJ\u0017\u0010d\u001a\u00020\u00112\u0006\u0010c\u001a\u00020)H\u0017¢\u0006\u0004\bd\u0010eJ\u001f\u0010d\u001a\u00020\u00112\u0006\u0010c\u001a\u00020)2\u0006\u0010f\u001a\u00020VH\u0017¢\u0006\u0004\bd\u0010gJ\u001b\u0010i\u001a\u00020\u00112\f\u0010!\u001a\b\u0012\u0004\u0012\u00020h0U¢\u0006\u0004\bi\u0010XJ\u001b\u0010j\u001a\u00020\u00112\f\u0010!\u001a\b\u0012\u0004\u0012\u00020h0U¢\u0006\u0004\bj\u0010XJ\u0017\u0010l\u001a\u00020\u00112\u0006\u0010k\u001a\u00020)H\u0017¢\u0006\u0004\bl\u0010eJ\u001f\u0010l\u001a\u00020\u00112\u0006\u0010k\u001a\u00020)2\u0006\u0010f\u001a\u00020VH\u0017¢\u0006\u0004\bl\u0010gJ\u001b\u0010n\u001a\u00020\u00112\f\u0010!\u001a\b\u0012\u0004\u0012\u00020m0U¢\u0006\u0004\bn\u0010XJ\u001b\u0010o\u001a\u00020\u00112\f\u0010!\u001a\b\u0012\u0004\u0012\u00020m0U¢\u0006\u0004\bo\u0010XJ\u000f\u0010p\u001a\u00020\u0011H\u0015¢\u0006\u0004\bp\u0010\u001cJ\u0015\u0010r\u001a\u00020\u00112\u0006\u0010!\u001a\u00020q¢\u0006\u0004\br\u0010sJ\u0015\u0010t\u001a\u00020\u00112\u0006\u0010!\u001a\u00020q¢\u0006\u0004\bt\u0010sJ\u000f\u0010u\u001a\u00020\u0011H\u0016¢\u0006\u0004\bu\u0010\u001cR\u0014\u0010w\u001a\u00020v8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bw\u0010xR\u0014\u0010z\u001a\u00020y8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bz\u0010{R\u001a\u0010}\u001a\u00020|8\u0002X\u0082\u0004¢\u0006\f\n\u0004\b}\u0010~\u0012\u0004\b\u007f\u0010\u001cR\u001c\u0010\u0081\u0001\u001a\u0005\u0018\u00010\u0080\u00018\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0081\u0001\u0010\u0082\u0001R\u0018\u0010\u0084\u0001\u001a\u00030\u0083\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u0084\u0001\u0010\u0085\u0001R!\u0010\u008b\u0001\u001a\u00030\u0086\u00018VX\u0096\u0084\u0002¢\u0006\u0010\n\u0006\b\u0087\u0001\u0010\u0088\u0001\u001a\u0006\b\u0089\u0001\u0010\u008a\u0001R\u0018\u0010\u008c\u0001\u001a\u00020%8\u0002@\u0002X\u0083\u000e¢\u0006\u0007\n\u0005\b\u008c\u0001\u0010IR\u0018\u0010\u008e\u0001\u001a\u00030\u008d\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u008e\u0001\u0010\u008f\u0001R\u001c\u0010\u0090\u0001\u001a\u00020M8\u0006¢\u0006\u0010\n\u0006\b\u0090\u0001\u0010\u0091\u0001\u001a\u0006\b\u0092\u0001\u0010\u0093\u0001R$\u0010\u0095\u0001\u001a\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020V0U0\u0094\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u0095\u0001\u0010\u0096\u0001R$\u0010\u0097\u0001\u001a\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0U0\u0094\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u0097\u0001\u0010\u0096\u0001R$\u0010\u0098\u0001\u001a\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020:0U0\u0094\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u0098\u0001\u0010\u0096\u0001R$\u0010\u0099\u0001\u001a\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020h0U0\u0094\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u0099\u0001\u0010\u0096\u0001R$\u0010\u009a\u0001\u001a\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020m0U0\u0094\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u009a\u0001\u0010\u0096\u0001R\u001e\u0010\u009b\u0001\u001a\t\u0012\u0004\u0012\u00020q0\u0094\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u009b\u0001\u0010\u0096\u0001R\u0019\u0010\u009c\u0001\u001a\u00020)8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u009c\u0001\u0010\u009d\u0001R\u0019\u0010\u009e\u0001\u001a\u00020)8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u009e\u0001\u0010\u009d\u0001R!\u0010£\u0001\u001a\u00030\u009f\u00018BX\u0082\u0084\u0002¢\u0006\u0010\n\u0006\b \u0001\u0010\u0088\u0001\u001a\u0006\b¡\u0001\u0010¢\u0001R!\u0010¨\u0001\u001a\u00030¤\u00018VX\u0096\u0084\u0002¢\u0006\u0010\n\u0006\b¥\u0001\u0010\u0088\u0001\u001a\u0006\b¦\u0001\u0010§\u0001R!\u0010\u00ad\u0001\u001a\u00030©\u00018FX\u0086\u0084\u0002¢\u0006\u0010\n\u0006\bª\u0001\u0010\u0088\u0001\u001a\u0006\b«\u0001\u0010¬\u0001R\u0018\u0010¯\u0001\u001a\u0004\u0018\u00010\u00028WX\u0096\u0004¢\u0006\u0007\u001a\u0005\b®\u0001\u0010\u0015R\u0018\u0010³\u0001\u001a\u00030°\u00018VX\u0096\u0004¢\u0006\b\u001a\u0006\b±\u0001\u0010²\u0001R\u0018\u0010¶\u0001\u001a\u00030\u0080\u00018VX\u0096\u0004¢\u0006\b\u001a\u0006\b´\u0001\u0010µ\u0001R\u0018\u0010º\u0001\u001a\u00030·\u00018WX\u0096\u0004¢\u0006\b\u001a\u0006\b¸\u0001\u0010¹\u0001R\u0018\u0010¾\u0001\u001a\u00030»\u00018VX\u0096\u0004¢\u0006\b\u001a\u0006\b¼\u0001\u0010½\u0001R\u0015\u0010Â\u0001\u001a\u00030¿\u00018F¢\u0006\b\u001a\u0006\bÀ\u0001\u0010Á\u0001¨\u0006Ç\u0001"}, m12198d2 = {"Landroidx/activity/ComponentActivity;", "Landroidx/core/app/ComponentActivity;", BuildConfig.VERSION_NAME, "Lx96;", "Lpcb;", "Ler4;", "Lra9;", "Lpg7;", "Lb37;", "Lql;", "Lqg7;", "Ljh7;", "Lwg7;", "Lxg7;", "Llp6;", "Landroid/os/Bundle;", "outState", "La5b;", "onSaveInstanceState", "(Landroid/os/Bundle;)V", "onRetainNonConfigurationInstance", "()Ljava/lang/Object;", "onRetainCustomNonConfigurationInstance", "Landroid/view/View;", "view", "setContentView", "(Landroid/view/View;)V", "initializeViewTreeOwners", "()V", "Landroid/content/Context;", "peekAvailableContext", "()Landroid/content/Context;", "Lsg7;", "listener", "addOnContextAvailableListener", "(Lsg7;)V", "removeOnContextAvailableListener", BuildConfig.VERSION_NAME, "featureId", "Landroid/view/Menu;", "menu", BuildConfig.VERSION_NAME, "onPreparePanel", "(ILandroid/view/View;Landroid/view/Menu;)Z", "onCreatePanelMenu", "(ILandroid/view/Menu;)Z", "Lwp6;", "provider", "addMenuProvider", "(Lwp6;)V", "owner", "(Lwp6;Lx96;)V", "Ln96;", "state", "(Lwp6;Lx96;Ln96;)V", "removeMenuProvider", "invalidateMenu", "onBackPressed", "Landroid/content/Intent;", "intent", "requestCode", "startActivityForResult", "(Landroid/content/Intent;I)V", "options", "(Landroid/content/Intent;ILandroid/os/Bundle;)V", "Landroid/content/IntentSender;", "fillInIntent", "flagsMask", "flagsValues", "extraFlags", "startIntentSenderForResult", "(Landroid/content/IntentSender;ILandroid/content/Intent;III)V", "(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V", "I", "O", "Ldl;", "contract", "Lol;", "registry", "Lcl;", "callback", "Lil;", "registerForActivityResult", "(Ldl;Lol;Lcl;)Lil;", "(Ldl;Lcl;)Lil;", "Lk42;", "Landroid/content/res/Configuration;", "addOnConfigurationChangedListener", "(Lk42;)V", "removeOnConfigurationChangedListener", "level", "onTrimMemory", "(I)V", "addOnTrimMemoryListener", "removeOnTrimMemoryListener", "onNewIntent", "(Landroid/content/Intent;)V", "addOnNewIntentListener", "removeOnNewIntentListener", "isInMultiWindowMode", "onMultiWindowModeChanged", "(Z)V", "newConfig", "(ZLandroid/content/res/Configuration;)V", "Lux6;", "addOnMultiWindowModeChangedListener", "removeOnMultiWindowModeChangedListener", "isInPictureInPictureMode", "onPictureInPictureModeChanged", "Lg28;", "addOnPictureInPictureModeChangedListener", "removeOnPictureInPictureModeChangedListener", "onUserLeaveHint", "Ljava/lang/Runnable;", "addOnUserLeaveHintListener", "(Ljava/lang/Runnable;)V", "removeOnUserLeaveHintListener", "reportFullyDrawn", "Ly62;", "contextAwareHelper", "Ly62;", "Lnp6;", "menuHostHelper", "Lnp6;", "Lpa9;", "savedStateRegistryController", "Lpa9;", "getSavedStateRegistryController$annotations", "Locb;", "_viewModelStore", "Locb;", "Luu1;", "reportFullyDrawnExecutor", "Luu1;", "Lkj4;", "fullyDrawnReporter$delegate", "Lp26;", "getFullyDrawnReporter", "()Lkj4;", "fullyDrawnReporter", "contentLayoutId", "Ljava/util/concurrent/atomic/AtomicInteger;", "nextLocalRequestCode", "Ljava/util/concurrent/atomic/AtomicInteger;", "activityResultRegistry", "Lol;", "getActivityResultRegistry", "()Lol;", "Ljava/util/concurrent/CopyOnWriteArrayList;", "onConfigurationChangedListeners", "Ljava/util/concurrent/CopyOnWriteArrayList;", "onTrimMemoryListeners", "onNewIntentListeners", "onMultiWindowModeChangedListeners", "onPictureInPictureModeChangedListeners", "onUserLeaveHintListeners", "dispatchingOnMultiWindowModeChanged", "Z", "dispatchingOnPictureInPictureModeChanged", "Lou2;", "onBackPressedInput$delegate", "getOnBackPressedInput", "()Lou2;", "onBackPressedInput", "Lmcb;", "defaultViewModelProviderFactory$delegate", "getDefaultViewModelProviderFactory", "()Lmcb;", "defaultViewModelProviderFactory", "Log7;", "onBackPressedDispatcher$delegate", "getOnBackPressedDispatcher", "()Log7;", "onBackPressedDispatcher", "getLastCustomNonConfigurationInstance", "lastCustomNonConfigurationInstance", "Lo96;", "getLifecycle", "()Lo96;", "lifecycle", "getViewModelStore", "()Locb;", "viewModelStore", "Lob2;", "getDefaultViewModelCreationExtras", "()Lob2;", "defaultViewModelCreationExtras", "La37;", "getNavigationEventDispatcher", "()La37;", "navigationEventDispatcher", "Lna9;", "getSavedStateRegistry", "()Lna9;", "savedStateRegistry", "Companion", "tu1", "vu1", "ru1", "activity"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public class ComponentActivity extends androidx.core.app.ComponentActivity implements pcb, er4, ra9, pg7, b37, InterfaceC1322ql, qg7, jh7, wg7, xg7, lp6 {

    @NotNull
    private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";

    @NotNull
    private static final ru1 Companion = new ru1();

    /* JADX INFO: renamed from: e */
    public static final /* synthetic */ int f1110e = 0;

    @Nullable
    private ocb _viewModelStore;

    @NotNull
    private final AbstractC0902ol activityResultRegistry;

    @LayoutRes
    private int contentLayoutId;

    @NotNull
    private final y62 contextAwareHelper;

    /* JADX INFO: renamed from: defaultViewModelProviderFactory$delegate, reason: from kotlin metadata */
    @NotNull
    private final p26 defaultViewModelProviderFactory;
    private boolean dispatchingOnMultiWindowModeChanged;
    private boolean dispatchingOnPictureInPictureModeChanged;

    /* JADX INFO: renamed from: fullyDrawnReporter$delegate, reason: from kotlin metadata */
    @NotNull
    private final p26 fullyDrawnReporter;

    @NotNull
    private final np6 menuHostHelper;

    @NotNull
    private final AtomicInteger nextLocalRequestCode;

    /* JADX INFO: renamed from: onBackPressedDispatcher$delegate, reason: from kotlin metadata */
    @NotNull
    private final p26 onBackPressedDispatcher;

    /* JADX INFO: renamed from: onBackPressedInput$delegate, reason: from kotlin metadata */
    @NotNull
    private final p26 onBackPressedInput;

    @NotNull
    private final CopyOnWriteArrayList<k42> onConfigurationChangedListeners;

    @NotNull
    private final CopyOnWriteArrayList<k42> onMultiWindowModeChangedListeners;

    @NotNull
    private final CopyOnWriteArrayList<k42> onNewIntentListeners;

    @NotNull
    private final CopyOnWriteArrayList<k42> onPictureInPictureModeChangedListeners;

    @NotNull
    private final CopyOnWriteArrayList<k42> onTrimMemoryListeners;

    @NotNull
    private final CopyOnWriteArrayList<Runnable> onUserLeaveHintListeners;

    @NotNull
    private final uu1 reportFullyDrawnExecutor;

    @NotNull
    private final pa9 savedStateRegistryController;

    public ComponentActivity() {
        this.contextAwareHelper = new y62();
        this.menuHostHelper = new np6(new lu1(this, 1));
        final int i = 0;
        qa9 qa9Var = new qa9(this, new oa9(this, i));
        this.savedStateRegistryController = new pa9(qa9Var);
        this.reportFullyDrawnExecutor = new vu1(this);
        this.fullyDrawnReporter = new aja(new lj4(this) { // from class: nu1

            /* JADX INFO: renamed from: i */
            public final /* synthetic */ ComponentActivity f30588i;

            {
                this.f30588i = this;
            }

            @Override // p000.lj4
            public final Object invoke() {
                int i2 = i;
                ComponentActivity componentActivity = this.f30588i;
                switch (i2) {
                    case 0:
                        return ComponentActivity.m737c(componentActivity);
                    case 1:
                        int i3 = ComponentActivity.f1110e;
                        ou2 ou2Var = new ou2();
                        componentActivity.getNavigationEventDispatcher().m79b(ou2Var);
                        return ou2Var;
                    case 2:
                        int i4 = ComponentActivity.f1110e;
                        return new SavedStateViewModelFactory(componentActivity.getApplication(), componentActivity, componentActivity.getIntent() != null ? componentActivity.getIntent().getExtras() : null);
                    default:
                        int i5 = ComponentActivity.f1110e;
                        og7 og7Var = new og7(new lu1(componentActivity, 0));
                        if (Build.VERSION.SDK_INT >= 33) {
                            if (ul5.m18482l(Looper.myLooper(), Looper.getMainLooper())) {
                                componentActivity.getLifecycle().mo244a(new mu1(og7Var, componentActivity));
                            } else {
                                new Handler(Looper.getMainLooper()).post(new ne1(1, componentActivity, og7Var));
                            }
                        }
                        return og7Var;
                }
            }
        });
        this.nextLocalRequestCode = new AtomicInteger();
        this.activityResultRegistry = new xu1(this);
        this.onConfigurationChangedListeners = new CopyOnWriteArrayList<>();
        this.onTrimMemoryListeners = new CopyOnWriteArrayList<>();
        this.onNewIntentListeners = new CopyOnWriteArrayList<>();
        this.onMultiWindowModeChangedListeners = new CopyOnWriteArrayList<>();
        this.onPictureInPictureModeChangedListeners = new CopyOnWriteArrayList<>();
        this.onUserLeaveHintListeners = new CopyOnWriteArrayList<>();
        final int i2 = 1;
        this.onBackPressedInput = new aja(new lj4(this) { // from class: nu1

            /* JADX INFO: renamed from: i */
            public final /* synthetic */ ComponentActivity f30588i;

            {
                this.f30588i = this;
            }

            @Override // p000.lj4
            public final Object invoke() {
                int i3 = i2;
                ComponentActivity componentActivity = this.f30588i;
                switch (i3) {
                    case 0:
                        return ComponentActivity.m737c(componentActivity);
                    case 1:
                        int i4 = ComponentActivity.f1110e;
                        ou2 ou2Var = new ou2();
                        componentActivity.getNavigationEventDispatcher().m79b(ou2Var);
                        return ou2Var;
                    case 2:
                        int i5 = ComponentActivity.f1110e;
                        return new SavedStateViewModelFactory(componentActivity.getApplication(), componentActivity, componentActivity.getIntent() != null ? componentActivity.getIntent().getExtras() : null);
                    default:
                        int i6 = ComponentActivity.f1110e;
                        og7 og7Var = new og7(new lu1(componentActivity, 0));
                        if (Build.VERSION.SDK_INT >= 33) {
                            if (ul5.m18482l(Looper.myLooper(), Looper.getMainLooper())) {
                                componentActivity.getLifecycle().mo244a(new mu1(og7Var, componentActivity));
                            } else {
                                new Handler(Looper.getMainLooper()).post(new ne1(1, componentActivity, og7Var));
                            }
                        }
                        return og7Var;
                }
            }
        });
        if (getLifecycle() == null) {
            C1521v3.m18909p("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
            throw null;
        }
        getLifecycle().mo244a(new ou1(this, 0));
        int i3 = 1;
        getLifecycle().mo244a(new ou1(this, i3));
        getLifecycle().mo244a(new ls8(this, i3));
        qa9Var.m15905a();
        r21.m16251p(this);
        getSavedStateRegistry().m14045c(ACTIVITY_RESULT_TAG, new pu1(this, 0));
        addOnContextAvailableListener(new sg7() { // from class: qu1
            @Override // p000.sg7
            public final void onContextAvailable(Context context) {
                ComponentActivity.m740g(this.f35501a, context);
            }
        });
        final int i4 = 2;
        this.defaultViewModelProviderFactory = new aja(new lj4(this) { // from class: nu1

            /* JADX INFO: renamed from: i */
            public final /* synthetic */ ComponentActivity f30588i;

            {
                this.f30588i = this;
            }

            @Override // p000.lj4
            public final Object invoke() {
                int i5 = i4;
                ComponentActivity componentActivity = this.f30588i;
                switch (i5) {
                    case 0:
                        return ComponentActivity.m737c(componentActivity);
                    case 1:
                        int i6 = ComponentActivity.f1110e;
                        ou2 ou2Var = new ou2();
                        componentActivity.getNavigationEventDispatcher().m79b(ou2Var);
                        return ou2Var;
                    case 2:
                        int i7 = ComponentActivity.f1110e;
                        return new SavedStateViewModelFactory(componentActivity.getApplication(), componentActivity, componentActivity.getIntent() != null ? componentActivity.getIntent().getExtras() : null);
                    default:
                        int i8 = ComponentActivity.f1110e;
                        og7 og7Var = new og7(new lu1(componentActivity, 0));
                        if (Build.VERSION.SDK_INT >= 33) {
                            if (ul5.m18482l(Looper.myLooper(), Looper.getMainLooper())) {
                                componentActivity.getLifecycle().mo244a(new mu1(og7Var, componentActivity));
                            } else {
                                new Handler(Looper.getMainLooper()).post(new ne1(1, componentActivity, og7Var));
                            }
                        }
                        return og7Var;
                }
            }
        });
        final int i5 = 3;
        this.onBackPressedDispatcher = new aja(new lj4(this) { // from class: nu1

            /* JADX INFO: renamed from: i */
            public final /* synthetic */ ComponentActivity f30588i;

            {
                this.f30588i = this;
            }

            @Override // p000.lj4
            public final Object invoke() {
                int i6 = i5;
                ComponentActivity componentActivity = this.f30588i;
                switch (i6) {
                    case 0:
                        return ComponentActivity.m737c(componentActivity);
                    case 1:
                        int i7 = ComponentActivity.f1110e;
                        ou2 ou2Var = new ou2();
                        componentActivity.getNavigationEventDispatcher().m79b(ou2Var);
                        return ou2Var;
                    case 2:
                        int i8 = ComponentActivity.f1110e;
                        return new SavedStateViewModelFactory(componentActivity.getApplication(), componentActivity, componentActivity.getIntent() != null ? componentActivity.getIntent().getExtras() : null);
                    default:
                        int i9 = ComponentActivity.f1110e;
                        og7 og7Var = new og7(new lu1(componentActivity, 0));
                        if (Build.VERSION.SDK_INT >= 33) {
                            if (ul5.m18482l(Looper.myLooper(), Looper.getMainLooper())) {
                                componentActivity.getLifecycle().mo244a(new mu1(og7Var, componentActivity));
                            } else {
                                new Handler(Looper.getMainLooper()).post(new ne1(1, componentActivity, og7Var));
                            }
                        }
                        return og7Var;
                }
            }
        });
    }

    public static final void access$ensureViewModelStore(ComponentActivity componentActivity) {
        if (componentActivity._viewModelStore == null) {
            tu1 tu1Var = (tu1) componentActivity.getLastNonConfigurationInstance();
            if (tu1Var != null) {
                componentActivity._viewModelStore = tu1Var.f40872b;
            }
            if (componentActivity._viewModelStore == null) {
                componentActivity._viewModelStore = new ocb();
            }
        }
    }

    /* JADX INFO: renamed from: b */
    public static Bundle m736b(ComponentActivity componentActivity) {
        Bundle bundle = new Bundle();
        AbstractC0902ol abstractC0902ol = componentActivity.activityResultRegistry;
        abstractC0902ol.getClass();
        LinkedHashMap linkedHashMap = abstractC0902ol.f31843b;
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(linkedHashMap.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(linkedHashMap.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(abstractC0902ol.f31845d));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", new Bundle(abstractC0902ol.f31848g));
        return bundle;
    }

    /* JADX INFO: renamed from: c */
    public static kj4 m737c(ComponentActivity componentActivity) {
        return new kj4(componentActivity.reportFullyDrawnExecutor, new C0696km(componentActivity, 13));
    }

    /* JADX INFO: renamed from: d */
    public static void m738d(ComponentActivity componentActivity, x96 x96Var, m96 m96Var) {
        if (m96Var == m96.ON_DESTROY) {
            componentActivity.contextAwareHelper.f48178b = null;
            if (!componentActivity.isChangingConfigurations()) {
                componentActivity.getViewModelStore().clear();
            }
            vu1 vu1Var = (vu1) componentActivity.reportFullyDrawnExecutor;
            ComponentActivity componentActivity2 = vu1Var.f44368z;
            componentActivity2.getWindow().getDecorView().removeCallbacks(vu1Var);
            componentActivity2.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(vu1Var);
        }
    }

    /* JADX INFO: renamed from: f */
    public static void m739f(ComponentActivity componentActivity) {
        try {
            super.onBackPressed();
        } catch (IllegalStateException e) {
            if (!ul5.m18482l(e.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                throw e;
            }
        } catch (NullPointerException e2) {
            if (!ul5.m18482l(e2.getMessage(), "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference")) {
                throw e2;
            }
        }
    }

    /* JADX INFO: renamed from: g */
    public static void m740g(ComponentActivity componentActivity, Context context) {
        context.getClass();
        Bundle bundleM14043a = componentActivity.getSavedStateRegistry().m14043a(ACTIVITY_RESULT_TAG);
        if (bundleM14043a != null) {
            AbstractC0902ol abstractC0902ol = componentActivity.activityResultRegistry;
            LinkedHashMap linkedHashMap = abstractC0902ol.f31843b;
            LinkedHashMap linkedHashMap2 = abstractC0902ol.f31842a;
            Bundle bundle = abstractC0902ol.f31848g;
            ArrayList<Integer> integerArrayList = bundleM14043a.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            ArrayList<String> stringArrayList = bundleM14043a.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if (stringArrayList == null || integerArrayList == null) {
                return;
            }
            ArrayList<String> stringArrayList2 = bundleM14043a.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
            if (stringArrayList2 != null) {
                abstractC0902ol.f31845d.addAll(stringArrayList2);
            }
            Bundle bundle2 = bundleM14043a.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
            if (bundle2 != null) {
                bundle.putAll(bundle2);
            }
            int size = stringArrayList.size();
            for (int i = 0; i < size; i++) {
                String str = stringArrayList.get(i);
                if (linkedHashMap.containsKey(str)) {
                    Integer num = (Integer) linkedHashMap.remove(str);
                    if (!bundle.containsKey(str)) {
                        zza.m21699n(linkedHashMap2).remove(num);
                    }
                }
                Integer num2 = integerArrayList.get(i);
                num2.getClass();
                int iIntValue = num2.intValue();
                String str2 = stringArrayList.get(i);
                str2.getClass();
                String str3 = str2;
                linkedHashMap2.put(Integer.valueOf(iIntValue), str3);
                abstractC0902ol.f31843b.put(str3, Integer.valueOf(iIntValue));
            }
        }
    }

    @Override // android.app.Activity
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        initializeViewTreeOwners();
        uu1 uu1Var = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ((vu1) uu1Var).m19270a(decorView);
        super.addContentView(view, layoutParams);
    }

    @Override // p000.lp6
    public void addMenuProvider(@NotNull wp6 provider) {
        provider.getClass();
        np6 np6Var = this.menuHostHelper;
        np6Var.f30433b.add(provider);
        np6Var.f30432a.run();
    }

    @Override // p000.qg7
    public final void addOnConfigurationChangedListener(@NotNull k42 listener) {
        listener.getClass();
        this.onConfigurationChangedListeners.add(listener);
    }

    public final void addOnContextAvailableListener(@NotNull sg7 listener) {
        listener.getClass();
        y62 y62Var = this.contextAwareHelper;
        y62Var.getClass();
        ComponentActivity componentActivity = y62Var.f48178b;
        if (componentActivity != null) {
            listener.onContextAvailable(componentActivity);
        }
        y62Var.f48177a.add(listener);
    }

    @Override // p000.wg7
    public final void addOnMultiWindowModeChangedListener(@NotNull k42 listener) {
        listener.getClass();
        this.onMultiWindowModeChangedListeners.add(listener);
    }

    public final void addOnNewIntentListener(@NotNull k42 listener) {
        listener.getClass();
        this.onNewIntentListeners.add(listener);
    }

    @Override // p000.xg7
    public final void addOnPictureInPictureModeChangedListener(@NotNull k42 listener) {
        listener.getClass();
        this.onPictureInPictureModeChangedListeners.add(listener);
    }

    @Override // p000.jh7
    public final void addOnTrimMemoryListener(@NotNull k42 listener) {
        listener.getClass();
        this.onTrimMemoryListeners.add(listener);
    }

    public final void addOnUserLeaveHintListener(@NotNull Runnable listener) {
        listener.getClass();
        this.onUserLeaveHintListeners.add(listener);
    }

    @Override // p000.InterfaceC1322ql
    @NotNull
    public final AbstractC0902ol getActivityResultRegistry() {
        return this.activityResultRegistry;
    }

    @Override // p000.er4
    @CallSuper
    @NotNull
    public ob2 getDefaultViewModelCreationExtras() {
        fy6 fy6Var = new fy6(0);
        Application application = getApplication();
        LinkedHashMap linkedHashMap = fy6Var.f31315a;
        if (application != null) {
            linkedHashMap.put(ViewModelProvider$AndroidViewModelFactory.f1941d, getApplication());
        }
        linkedHashMap.put(r21.f35831g, this);
        linkedHashMap.put(r21.f35832h, this);
        Intent intent = getIntent();
        Bundle extras = intent != null ? intent.getExtras() : null;
        if (extras != null) {
            linkedHashMap.put(r21.f35833i, extras);
        }
        return fy6Var;
    }

    @Override // p000.er4
    @NotNull
    public mcb getDefaultViewModelProviderFactory() {
        return (mcb) this.defaultViewModelProviderFactory.getValue();
    }

    @NotNull
    public kj4 getFullyDrawnReporter() {
        return (kj4) this.fullyDrawnReporter.getValue();
    }

    @bp2
    @Nullable
    public Object getLastCustomNonConfigurationInstance() {
        tu1 tu1Var = (tu1) getLastNonConfigurationInstance();
        if (tu1Var != null) {
            return tu1Var.f40871a;
        }
        return null;
    }

    @Override // androidx.core.app.ComponentActivity, p000.x96
    @NotNull
    public o96 getLifecycle() {
        return super.getLifecycle();
    }

    @Override // p000.b37
    @NotNull
    public a37 getNavigationEventDispatcher() {
        return getOnBackPressedDispatcher().m14704b().f28424c;
    }

    @Override // p000.pg7
    @NotNull
    public final og7 getOnBackPressedDispatcher() {
        return (og7) this.onBackPressedDispatcher.getValue();
    }

    @Override // p000.ra9
    @NotNull
    public final na9 getSavedStateRegistry() {
        return this.savedStateRegistryController.f32999b;
    }

    @Override // p000.pcb
    @NotNull
    public ocb getViewModelStore() {
        if (getApplication() == null) {
            C1521v3.m18909p("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
            return null;
        }
        if (this._viewModelStore == null) {
            tu1 tu1Var = (tu1) getLastNonConfigurationInstance();
            if (tu1Var != null) {
                this._viewModelStore = tu1Var.f40872b;
            }
            if (this._viewModelStore == null) {
                this._viewModelStore = new ocb();
            }
        }
        ocb ocbVar = this._viewModelStore;
        ocbVar.getClass();
        return ocbVar;
    }

    @CallSuper
    public void initializeViewTreeOwners() {
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.setTag(R.id.view_tree_lifecycle_owner, this);
        View decorView2 = getWindow().getDecorView();
        decorView2.getClass();
        decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        View decorView3 = getWindow().getDecorView();
        decorView3.getClass();
        decorView3.setTag(R.id.view_tree_saved_state_registry_owner, this);
        View decorView4 = getWindow().getDecorView();
        decorView4.getClass();
        decorView4.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, this);
        View decorView5 = getWindow().getDecorView();
        decorView5.getClass();
        decorView5.setTag(R.id.report_drawn, this);
        View decorView6 = getWindow().getDecorView();
        decorView6.getClass();
        decorView6.setTag(R.id.view_tree_navigation_event_dispatcher_owner, this);
    }

    public void invalidateMenu() {
        invalidateOptionsMenu();
    }

    @Override // android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        if (this.activityResultRegistry.m14783a(i, i2, intent)) {
            return;
        }
        super.onActivityResult(i, i2, intent);
    }

    @Override // android.app.Activity
    @bp2
    @CallSuper
    @MainThread
    public void onBackPressed() {
        ((ou2) this.onBackPressedInput.getValue()).m7237a();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        configuration.getClass();
        super.onConfigurationChanged(configuration);
        Iterator<k42> it = this.onConfigurationChangedListeners.iterator();
        it.getClass();
        while (it.hasNext()) {
            it.next().accept(configuration);
        }
    }

    @Override // androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        this.savedStateRegistryController.m15248a(bundle);
        y62 y62Var = this.contextAwareHelper;
        y62Var.getClass();
        y62Var.f48178b = this;
        Iterator it = y62Var.f48177a.iterator();
        while (it.hasNext()) {
            ((sg7) it.next()).onContextAvailable(this);
        }
        super.onCreate(bundle);
        int i = ry8.f37518i;
        py8.m15718b(this);
        int i2 = this.contentLayoutId;
        if (i2 != 0) {
            setContentView(i2);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onCreatePanelMenu(int featureId, @NotNull Menu menu) {
        menu.getClass();
        if (featureId != 0) {
            return true;
        }
        super.onCreatePanelMenu(featureId, menu);
        np6 np6Var = this.menuHostHelper;
        MenuInflater menuInflater = getMenuInflater();
        Iterator it = np6Var.f30433b.iterator();
        while (it.hasNext()) {
            ((jh4) ((wp6) it.next())).f23079a.m1152j(menu, menuInflater);
        }
        return true;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        menuItem.getClass();
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 0) {
            return this.menuHostHelper.m14277c(menuItem);
        }
        return false;
    }

    @Override // android.app.Activity
    @RequiresApi(api = ValueType.METHOD)
    @CallSuper
    public void onMultiWindowModeChanged(boolean isInMultiWindowMode, @NotNull Configuration newConfig) {
        newConfig.getClass();
        this.dispatchingOnMultiWindowModeChanged = true;
        try {
            super.onMultiWindowModeChanged(isInMultiWindowMode, newConfig);
            this.dispatchingOnMultiWindowModeChanged = false;
            Iterator<k42> it = this.onMultiWindowModeChangedListeners.iterator();
            it.getClass();
            while (it.hasNext()) {
                it.next().accept(new ux6(isInMultiWindowMode, newConfig));
            }
        } catch (Throwable th) {
            this.dispatchingOnMultiWindowModeChanged = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    @CallSuper
    public void onNewIntent(@NotNull Intent intent) {
        intent.getClass();
        super.onNewIntent(intent);
        Iterator<k42> it = this.onNewIntentListeners.iterator();
        it.getClass();
        while (it.hasNext()) {
            it.next().accept(intent);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i, Menu menu) {
        menu.getClass();
        Iterator it = this.menuHostHelper.f30433b.iterator();
        while (it.hasNext()) {
            ((jh4) ((wp6) it.next())).f23079a.m1158p(menu);
        }
        super.onPanelClosed(i, menu);
    }

    @Override // android.app.Activity
    @RequiresApi(api = ValueType.METHOD)
    @CallSuper
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, @NotNull Configuration newConfig) {
        newConfig.getClass();
        this.dispatchingOnPictureInPictureModeChanged = true;
        try {
            super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
            this.dispatchingOnPictureInPictureModeChanged = false;
            Iterator<k42> it = this.onPictureInPictureModeChangedListeners.iterator();
            it.getClass();
            while (it.hasNext()) {
                it.next().accept(new g28(isInPictureInPictureMode, newConfig));
            }
        } catch (Throwable th) {
            this.dispatchingOnPictureInPictureModeChanged = false;
            throw th;
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onPreparePanel(int featureId, @Nullable View view, @NotNull Menu menu) {
        menu.getClass();
        if (featureId != 0) {
            return true;
        }
        super.onPreparePanel(featureId, view, menu);
        Iterator it = this.menuHostHelper.f30433b.iterator();
        while (it.hasNext()) {
            ((jh4) ((wp6) it.next())).f23079a.m1161s(menu);
        }
        return true;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        strArr.getClass();
        iArr.getClass();
        if (this.activityResultRegistry.m14783a(i, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            return;
        }
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    @bp2
    @Nullable
    public Object onRetainCustomNonConfigurationInstance() {
        return null;
    }

    @Override // android.app.Activity
    @Nullable
    public final Object onRetainNonConfigurationInstance() {
        tu1 tu1Var;
        Object objOnRetainCustomNonConfigurationInstance = onRetainCustomNonConfigurationInstance();
        ocb ocbVar = this._viewModelStore;
        if (ocbVar == null && (tu1Var = (tu1) getLastNonConfigurationInstance()) != null) {
            ocbVar = tu1Var.f40872b;
        }
        if (ocbVar == null && objOnRetainCustomNonConfigurationInstance == null) {
            return null;
        }
        tu1 tu1Var2 = new tu1();
        tu1Var2.f40871a = objOnRetainCustomNonConfigurationInstance;
        tu1Var2.f40872b = ocbVar;
        return tu1Var2;
    }

    @Override // androidx.core.app.ComponentActivity, android.app.Activity
    @CallSuper
    public void onSaveInstanceState(@NotNull Bundle outState) {
        outState.getClass();
        if (getLifecycle() instanceof aa6) {
            o96 lifecycle = getLifecycle();
            lifecycle.getClass();
            ((aa6) lifecycle).m250g(n96.f29656y);
        }
        super.onSaveInstanceState(outState);
        this.savedStateRegistryController.m15249b(outState);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    @CallSuper
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Iterator<k42> it = this.onTrimMemoryListeners.iterator();
        it.getClass();
        while (it.hasNext()) {
            it.next().accept(Integer.valueOf(level));
        }
    }

    @Override // android.app.Activity
    @CallSuper
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        Iterator<Runnable> it = this.onUserLeaveHintListeners.iterator();
        it.getClass();
        while (it.hasNext()) {
            it.next().run();
        }
    }

    @Nullable
    public Context peekAvailableContext() {
        return this.contextAwareHelper.f48178b;
    }

    @NotNull
    public final <I, O> AbstractC0622il registerForActivityResult(@NotNull AbstractC0424dl contract, @NotNull AbstractC0902ol registry, @NotNull InterfaceC0265cl callback) {
        contract.getClass();
        registry.getClass();
        callback.getClass();
        return registry.m14785d("activity_rq#" + this.nextLocalRequestCode.getAndIncrement(), this, contract, callback);
    }

    @Override // p000.lp6
    public void removeMenuProvider(@NotNull wp6 provider) {
        provider.getClass();
        this.menuHostHelper.m14278d(provider);
    }

    @Override // p000.qg7
    public final void removeOnConfigurationChangedListener(@NotNull k42 listener) {
        listener.getClass();
        this.onConfigurationChangedListeners.remove(listener);
    }

    public final void removeOnContextAvailableListener(@NotNull sg7 listener) {
        listener.getClass();
        y62 y62Var = this.contextAwareHelper;
        y62Var.getClass();
        y62Var.f48177a.remove(listener);
    }

    @Override // p000.wg7
    public final void removeOnMultiWindowModeChangedListener(@NotNull k42 listener) {
        listener.getClass();
        this.onMultiWindowModeChangedListeners.remove(listener);
    }

    public final void removeOnNewIntentListener(@NotNull k42 listener) {
        listener.getClass();
        this.onNewIntentListeners.remove(listener);
    }

    @Override // p000.xg7
    public final void removeOnPictureInPictureModeChangedListener(@NotNull k42 listener) {
        listener.getClass();
        this.onPictureInPictureModeChangedListeners.remove(listener);
    }

    @Override // p000.jh7
    public final void removeOnTrimMemoryListener(@NotNull k42 listener) {
        listener.getClass();
        this.onTrimMemoryListeners.remove(listener);
    }

    public final void removeOnUserLeaveHintListener(@NotNull Runnable listener) {
        listener.getClass();
        this.onUserLeaveHintListeners.remove(listener);
    }

    @Override // android.app.Activity
    public void reportFullyDrawn() {
        try {
            if (r68.m16402s()) {
                Trace.beginSection(r68.m16386G("reportFullyDrawn() for ComponentActivity"));
            }
            super.reportFullyDrawn();
            getFullyDrawnReporter().m12095a();
        } finally {
            Trace.endSection();
        }
    }

    @Override // android.app.Activity
    public void setContentView(int i) {
        initializeViewTreeOwners();
        uu1 uu1Var = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ((vu1) uu1Var).m19270a(decorView);
        super.setContentView(i);
    }

    @Override // android.app.Activity
    @bp2
    public void startActivityForResult(@NotNull Intent intent, int requestCode) {
        intent.getClass();
        super.startActivityForResult(intent, requestCode);
    }

    @Override // android.app.Activity
    @bp2
    public void startIntentSenderForResult(@NotNull IntentSender intent, int requestCode, @Nullable Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags) throws IntentSender.SendIntentException {
        intent.getClass();
        super.startIntentSenderForResult(intent, requestCode, fillInIntent, flagsMask, flagsValues, extraFlags);
    }

    @Override // android.app.Activity
    @bp2
    public void startActivityForResult(@NotNull Intent intent, int requestCode, @Nullable Bundle options) {
        intent.getClass();
        super.startActivityForResult(intent, requestCode, options);
    }

    @Override // android.app.Activity
    @bp2
    public void startIntentSenderForResult(@NotNull IntentSender intent, int requestCode, @Nullable Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags, @Nullable Bundle options) {
        intent.getClass();
        super.startIntentSenderForResult(intent, requestCode, fillInIntent, flagsMask, flagsValues, extraFlags, options);
    }

    public void addMenuProvider(@NotNull wp6 provider, @NotNull x96 owner) {
        provider.getClass();
        owner.getClass();
        this.menuHostHelper.m14275a(provider, owner);
    }

    @SuppressLint({"LambdaLast"})
    public void addMenuProvider(@NotNull wp6 provider, @NotNull x96 owner, @NotNull n96 state) {
        provider.getClass();
        owner.getClass();
        state.getClass();
        this.menuHostHelper.m14276b(provider, owner, state);
    }

    @Override // android.app.Activity
    public void setContentView(@Nullable View view) {
        initializeViewTreeOwners();
        uu1 uu1Var = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ((vu1) uu1Var).m19270a(decorView);
        super.setContentView(view);
    }

    @Override // android.app.Activity
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        initializeViewTreeOwners();
        uu1 uu1Var = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ((vu1) uu1Var).m19270a(decorView);
        super.setContentView(view, layoutParams);
    }

    @NotNull
    public final <I, O> AbstractC0622il registerForActivityResult(@NotNull AbstractC0424dl contract, @NotNull InterfaceC0265cl callback) {
        contract.getClass();
        callback.getClass();
        return registerForActivityResult(contract, this.activityResultRegistry, callback);
    }

    @Override // android.app.Activity
    @bp2
    @CallSuper
    public void onMultiWindowModeChanged(boolean isInMultiWindowMode) {
        if (this.dispatchingOnMultiWindowModeChanged) {
            return;
        }
        Iterator<k42> it = this.onMultiWindowModeChangedListeners.iterator();
        it.getClass();
        while (it.hasNext()) {
            it.next().accept(new ux6(isInMultiWindowMode));
        }
    }

    @Override // android.app.Activity
    @bp2
    @CallSuper
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode) {
        if (this.dispatchingOnPictureInPictureModeChanged) {
            return;
        }
        Iterator<k42> it = this.onPictureInPictureModeChangedListeners.iterator();
        it.getClass();
        while (it.hasNext()) {
            it.next().accept(new g28(isInPictureInPictureMode));
        }
    }

    public ComponentActivity(int i) {
        this();
        this.contentLayoutId = i;
    }
}
