package androidx.slidingpanelayout.widget;

import android.R;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.RtlSpacingHelper;
import androidx.customview.view.AbsSavedState;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.ExecutorsKt;
import kotlinx.coroutines.Job;
import p000.C0767l;
import p000.b0c;
import p000.d2a;
import p000.dr4;
import p000.e2a;
import p000.gbb;
import p000.h72;
import p000.li5;
import p000.nh3;
import p000.o40;
import p000.obb;
import p000.pg3;
import p000.ro6;
import p000.ry0;
import p000.v21;
import p000.wbb;
import p000.wyb;
import p000.xyb;
import p000.ym9;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class SlidingPaneLayout extends ViewGroup {

    /* JADX INFO: renamed from: M */
    public static final boolean f2197M;

    /* JADX INFO: renamed from: A */
    public boolean f2198A;

    /* JADX INFO: renamed from: B */
    public float f2199B;

    /* JADX INFO: renamed from: C */
    public float f2200C;

    /* JADX INFO: renamed from: D */
    public final CopyOnWriteArrayList f2201D;

    /* JADX INFO: renamed from: E */
    public final wbb f2202E;

    /* JADX INFO: renamed from: F */
    public boolean f2203F;

    /* JADX INFO: renamed from: G */
    public boolean f2204G;

    /* JADX INFO: renamed from: H */
    public final Rect f2205H;

    /* JADX INFO: renamed from: I */
    public final ArrayList f2206I;

    /* JADX INFO: renamed from: J */
    public int f2207J;

    /* JADX INFO: renamed from: K */
    public dr4 f2208K;

    /* JADX INFO: renamed from: L */
    public final C0767l f2209L;

    /* JADX INFO: renamed from: e */
    public boolean f2210e;

    /* JADX INFO: renamed from: i */
    public View f2211i;

    /* JADX INFO: renamed from: y */
    public float f2212y;

    /* JADX INFO: renamed from: z */
    public int f2213z;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: d */
        public static final int[] f2214d = {R.attr.layout_weight};

        /* JADX INFO: renamed from: a */
        public float f2215a;

        /* JADX INFO: renamed from: b */
        public boolean f2216b;

        /* JADX INFO: renamed from: c */
        public boolean f2217c;

        public LayoutParams(@NonNull Context context, @Nullable AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2215a = 0.0f;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f2214d);
            this.f2215a = typedArrayObtainStyledAttributes.getFloat(0, 0.0f);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0191b();

        /* JADX INFO: renamed from: e */
        public boolean f2218e;

        /* JADX INFO: renamed from: i */
        public int f2219i;

        public SavedState(Parcel parcel) {
            super(parcel, null);
            this.f2218e = parcel.readInt() != 0;
            this.f2219i = parcel.readInt();
        }

        @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f2218e ? 1 : 0);
            parcel.writeInt(this.f2219i);
        }
    }

    static {
        f2197M = Build.VERSION.SDK_INT >= 29;
    }

    public SlidingPaneLayout(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2212y = 1.0f;
        this.f2201D = new CopyOnWriteArrayList();
        this.f2204G = true;
        this.f2205H = new Rect();
        this.f2206I = new ArrayList();
        ym9 ym9Var = new ym9(this, 6);
        float f = context.getResources().getDisplayMetrics().density;
        setWillNotDraw(false);
        obb.m14621n(this, new d2a(this));
        setImportantForAccessibility(1);
        wbb wbbVar = new wbb(getContext(), this, new C0190a(this));
        wbbVar.f45173b = (int) (2.0f * wbbVar.f45173b);
        this.f2202E = wbbVar;
        wbbVar.f45185n = f * 400.0f;
        xyb.f47862n.getClass();
        C0767l c0767l = new C0767l(wyb.m19850a(context), Build.VERSION.SDK_INT >= 28 ? o40.m14468d(context) : new ry0(new Handler(context.getMainLooper()), 2));
        this.f2209L = c0767l;
        c0767l.f25635A = ym9Var;
    }

    /* JADX INFO: renamed from: a */
    public final boolean m1526a() {
        if (!this.f2210e) {
            this.f2203F = false;
        }
        if (!this.f2204G && !m1530e(1.0f)) {
            return false;
        }
        this.f2203F = false;
        return true;
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() != 1) {
            super.addView(view, i, layoutParams);
            return;
        }
        e2a e2aVar = new e2a(view.getContext());
        e2aVar.addView(view);
        super.addView(e2aVar, i, layoutParams);
    }

    /* JADX INFO: renamed from: b */
    public final boolean m1527b(View view) {
        if (view == null) {
            return false;
        }
        return this.f2210e && ((LayoutParams) view.getLayoutParams()).f2217c && this.f2212y > 0.0f;
    }

    /* JADX INFO: renamed from: c */
    public final boolean m1528c() {
        WeakHashMap weakHashMap = obb.f31348a;
        return getLayoutDirection() == 1;
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public final void computeScroll() {
        wbb wbbVar = this.f2202E;
        if (wbbVar.m19468h()) {
            if (!this.f2210e) {
                wbbVar.m19461a();
            } else {
                WeakHashMap weakHashMap = obb.f31348a;
                postInvalidateOnAnimation();
            }
        }
    }

    /* JADX INFO: renamed from: d */
    public final boolean m1529d() {
        return !this.f2210e || this.f2212y == 0.0f;
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        super.draw(canvas);
        m1528c();
        if (getChildCount() > 1) {
            getChildAt(1);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j) {
        boolean zM1528c = m1528c() ^ m1529d();
        boolean z = f2197M;
        li5 li5VarMo18098k = null;
        wbb wbbVar = this.f2202E;
        if (zM1528c) {
            wbbVar.f45188q = 1;
            if (z) {
                WeakHashMap weakHashMap = obb.f31348a;
                b0c b0cVarM8928a = gbb.m8928a(this);
                if (b0cVarM8928a != null) {
                    li5VarMo18098k = b0cVarM8928a.f3168a.mo18098k();
                }
            }
            if (li5VarMo18098k != null) {
                wbbVar.f45186o = Math.max(wbbVar.f45187p, li5VarMo18098k.f26704a);
            }
        } else {
            wbbVar.f45188q = 2;
            if (z) {
                WeakHashMap weakHashMap2 = obb.f31348a;
                b0c b0cVarM8928a2 = gbb.m8928a(this);
                if (b0cVarM8928a2 != null) {
                    li5VarMo18098k = b0cVarM8928a2.f3168a.mo18098k();
                }
            }
            if (li5VarMo18098k != null) {
                wbbVar.f45186o = Math.max(wbbVar.f45187p, li5VarMo18098k.f26706c);
            }
        }
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int iSave = canvas.save();
        if (this.f2210e && !layoutParams.f2216b && this.f2211i != null) {
            Rect rect = this.f2205H;
            canvas.getClipBounds(rect);
            if (m1528c()) {
                rect.left = Math.max(rect.left, this.f2211i.getRight());
            } else {
                rect.right = Math.min(rect.right, this.f2211i.getLeft());
            }
            canvas.clipRect(rect);
        }
        boolean zDrawChild = super.drawChild(canvas, view, j);
        canvas.restoreToCount(iSave);
        return zDrawChild;
    }

    /* JADX INFO: renamed from: e */
    public final boolean m1530e(float f) {
        int paddingLeft;
        if (this.f2210e) {
            boolean zM1528c = m1528c();
            LayoutParams layoutParams = (LayoutParams) this.f2211i.getLayoutParams();
            if (zM1528c) {
                int paddingRight = getPaddingRight() + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
                paddingLeft = (int) (getWidth() - (((f * this.f2213z) + paddingRight) + this.f2211i.getWidth()));
            } else {
                paddingLeft = (int) ((f * this.f2213z) + getPaddingLeft() + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin);
            }
            View view = this.f2211i;
            if (this.f2202E.m19480u(view, paddingLeft, view.getTop())) {
                int childCount = getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View childAt = getChildAt(i);
                    if (childAt.getVisibility() == 4) {
                        childAt.setVisibility(0);
                    }
                }
                WeakHashMap weakHashMap = obb.f31348a;
                postInvalidateOnAnimation();
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: f */
    public final void m1531f(View view) {
        int left;
        int right;
        int top;
        int bottom;
        View view2 = view;
        boolean zM1528c = m1528c();
        int width = zM1528c ? getWidth() - getPaddingRight() : getPaddingLeft();
        int paddingLeft = zM1528c ? getPaddingLeft() : getWidth() - getPaddingRight();
        int paddingTop = getPaddingTop();
        int height = getHeight() - getPaddingBottom();
        if (view2 == null || !view2.isOpaque()) {
            left = 0;
            right = 0;
            top = 0;
            bottom = 0;
        } else {
            left = view2.getLeft();
            right = view2.getRight();
            top = view2.getTop();
            bottom = view2.getBottom();
        }
        int childCount = getChildCount();
        int i = 0;
        while (i < childCount) {
            View childAt = getChildAt(i);
            if (childAt == view2) {
                return;
            }
            if (childAt.getVisibility() != 8) {
                childAt.setVisibility((Math.max(zM1528c ? paddingLeft : width, childAt.getLeft()) < left || Math.max(paddingTop, childAt.getTop()) < top || Math.min(zM1528c ? width : paddingLeft, childAt.getRight()) > right || Math.min(height, childAt.getBottom()) > bottom) ? 0 : 4);
            }
            i++;
            view2 = view;
            zM1528c = zM1528c;
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        LayoutParams layoutParams = new LayoutParams(-1, -1);
        layoutParams.f2215a = 0.0f;
        return layoutParams;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            LayoutParams layoutParams2 = new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams);
            layoutParams2.f2215a = 0.0f;
            return layoutParams2;
        }
        LayoutParams layoutParams3 = new LayoutParams(layoutParams);
        layoutParams3.f2215a = 0.0f;
        return layoutParams3;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        h72 h72Var;
        Activity activity;
        super.onAttachedToWindow();
        this.f2204G = true;
        C0767l c0767l = this.f2209L;
        if (c0767l != null) {
            Context context = getContext();
            while (true) {
                h72Var = null;
                if (!(context instanceof ContextWrapper)) {
                    activity = null;
                    break;
                } else {
                    if (context instanceof Activity) {
                        activity = (Activity) context;
                        break;
                    }
                    context = ((ContextWrapper) context).getBaseContext();
                }
            }
            if (activity != null) {
                c0767l.getClass();
                Job job = (Job) c0767l.f25639z;
                if (job != null) {
                    Job.cancel$default(job, null, 1, null);
                }
                c0767l.f25639z = BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(ExecutorsKt.from((Executor) c0767l.f25638y)), null, null, new nh3(c0767l, activity, h72Var, 21), 3, null);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        Job job;
        super.onDetachedFromWindow();
        this.f2204G = true;
        C0767l c0767l = this.f2209L;
        if (c0767l != null && (job = (Job) c0767l.f25639z) != null) {
            Job.cancel$default(job, null, 1, null);
        }
        ArrayList arrayList = this.f2206I;
        if (arrayList.size() <= 0) {
            arrayList.clear();
        } else {
            arrayList.get(0).getClass();
            ro6.m16594d();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z;
        View childAt;
        int actionMasked = motionEvent.getActionMasked();
        boolean z2 = this.f2210e;
        wbb wbbVar = this.f2202E;
        if (!z2 && actionMasked == 0 && getChildCount() > 1 && (childAt = getChildAt(1)) != null) {
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            wbbVar.getClass();
            this.f2203F = wbb.m19460l(childAt, x, y);
        }
        if (!this.f2210e || (this.f2198A && actionMasked != 0)) {
            wbbVar.m19462b();
            return super.onInterceptTouchEvent(motionEvent);
        }
        if (actionMasked == 3 || actionMasked == 1) {
            wbbVar.m19462b();
            return false;
        }
        if (actionMasked == 0) {
            this.f2198A = false;
            float x2 = motionEvent.getX();
            float y2 = motionEvent.getY();
            this.f2199B = x2;
            this.f2200C = y2;
            wbbVar.getClass();
            if (wbb.m19460l(this.f2211i, (int) x2, (int) y2) && m1527b(this.f2211i)) {
                z = true;
            }
            return !wbbVar.m19479t(motionEvent) || z;
        }
        if (actionMasked == 2) {
            float x3 = motionEvent.getX();
            float y3 = motionEvent.getY();
            float fAbs = Math.abs(x3 - this.f2199B);
            float fAbs2 = Math.abs(y3 - this.f2200C);
            if (fAbs > wbbVar.f45173b && fAbs2 > fAbs) {
                wbbVar.m19462b();
                this.f2198A = true;
                return false;
            }
        }
        z = false;
        if (wbbVar.m19479t(motionEvent)) {
        }
    }

    /* JADX WARN: Code duplicated, block: B:48:0x00d1  */
    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        int iWidth;
        pg3 pg3Var = pg3.f33228C;
        boolean zM1528c = m1528c();
        int i8 = i3 - i;
        int paddingRight = zM1528c ? getPaddingRight() : getPaddingLeft();
        int paddingLeft = zM1528c ? getPaddingLeft() : getPaddingRight();
        int paddingTop = getPaddingTop();
        int childCount = getChildCount();
        if (this.f2204G) {
            this.f2212y = (this.f2210e && this.f2203F) ? 0.0f : 1.0f;
        }
        int i9 = paddingRight;
        int i10 = 0;
        while (i10 < childCount) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() == 8) {
                zM1528c = zM1528c;
            } else {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                if (layoutParams.f2216b) {
                    int i11 = i8 - paddingLeft;
                    int iMin = (Math.min(paddingRight, i11) - i9) - (((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin);
                    this.f2213z = iMin;
                    int i12 = zM1528c ? ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin : ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
                    layoutParams.f2217c = (measuredWidth / 2) + ((i9 + i12) + iMin) > i11;
                    float f = iMin;
                    int i13 = (int) (this.f2212y * f);
                    i5 = i12 + i13 + i9;
                    this.f2212y = i13 / f;
                } else {
                    i5 = paddingRight;
                }
                if (zM1528c != 0) {
                    i6 = i8 - i5;
                    i7 = i6 - measuredWidth;
                } else {
                    i6 = i5 + measuredWidth;
                    i7 = i5;
                }
                childAt.layout(i7, paddingTop, i6, childAt.getMeasuredHeight() + paddingTop);
                dr4 dr4Var = this.f2208K;
                if (dr4Var != null) {
                    v21 v21Var = dr4Var.f11299a;
                    if ((v21Var.m18894b() > v21Var.m18893a() ? pg3.f33229D : pg3Var) == pg3Var && this.f2208K.m7065a()) {
                        iWidth = this.f2208K.f11299a.m18895c().width();
                    } else {
                        iWidth = 0;
                    }
                } else {
                    iWidth = 0;
                }
                paddingRight = Math.abs(iWidth) + childAt.getWidth() + paddingRight;
                i9 = i5;
            }
            i10++;
            zM1528c = zM1528c;
        }
        if (this.f2204G) {
            m1531f(this.f2211i);
        }
        this.f2204G = false;
    }

    /* JADX WARN: Code duplicated, block: B:142:0x00ed A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:144:0x00ed A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:23:0x0089 A[PHI: r17
      0x0089: PHI (r17v3 float) = (r17v1 float), (r17v4 float) binds: [B:19:0x007f, B:21:0x0085] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:25:0x0099 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:26:0x009b  */
    /* JADX WARN: Code duplicated, block: B:27:0x009d  */
    /* JADX WARN: Code duplicated, block: B:29:0x00a4  */
    /* JADX WARN: Code duplicated, block: B:31:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:32:0x00ac  */
    /* JADX WARN: Code duplicated, block: B:35:0x00cf  */
    /* JADX WARN: Code duplicated, block: B:37:0x00d3  */
    /* JADX WARN: Code duplicated, block: B:38:0x00d8 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:39:0x00da  */
    /* JADX WARN: Code duplicated, block: B:43:0x00df A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:44:0x00e1  */
    /* JADX WARN: Code duplicated, block: B:45:0x00e4  */
    /* JADX WARN: Code duplicated, block: B:48:0x00eb  */
    /* JADX WARN: Code duplicated, block: B:94:0x01b6  */
    /* JADX WARN: Type inference failed for: r7v0 */
    /* JADX WARN: Type inference failed for: r7v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r7v30 */
    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        int paddingTop;
        int iMin;
        int i3;
        int iMax;
        int iMakeMeasureSpec;
        int i4;
        ArrayList arrayList;
        int i5;
        int i6;
        int minimumWidth;
        int iMax2;
        int i7;
        int iMakeMeasureSpec2;
        int measuredHeight;
        boolean z;
        int i8;
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        ?? r7 = 0;
        if (mode2 != Integer.MIN_VALUE) {
            iMin = mode2 != 1073741824 ? 0 : (size2 - getPaddingTop()) - getPaddingBottom();
            paddingTop = iMin;
        } else {
            paddingTop = (size2 - getPaddingTop()) - getPaddingBottom();
            iMin = 0;
        }
        int iMax3 = Math.max((size - getPaddingLeft()) - getPaddingRight(), 0);
        int childCount = getChildCount();
        if (childCount > 2) {
            Log.e("SlidingPaneLayout", "onMeasure: More than two child views are not supported.");
        }
        this.f2211i = null;
        int i9 = 0;
        boolean z2 = false;
        int i10 = iMax3;
        float f = 0.0f;
        while (true) {
            i3 = 8;
            if (i9 >= childCount) {
                break;
            }
            View childAt = getChildAt(i9);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if (childAt.getVisibility() == 8) {
                layoutParams.f2217c = r7;
            } else {
                float f2 = layoutParams.f2215a;
                if (f2 > 0.0f) {
                    f += f2;
                    if (((ViewGroup.MarginLayoutParams) layoutParams).width != 0) {
                        iMax2 = Math.max(iMax3 - (((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin), (int) r7);
                        i7 = ((ViewGroup.MarginLayoutParams) layoutParams).width;
                        if (i7 == -2) {
                            if (mode == 0) {
                                i8 = mode;
                            } else {
                                i8 = RtlSpacingHelper.UNDEFINED;
                            }
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMax2, i8);
                        } else if (i7 == -1) {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMax2, mode);
                        } else {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i7, 1073741824);
                        }
                        childAt.measure(iMakeMeasureSpec2, ViewGroup.getChildMeasureSpec(i2, getPaddingBottom() + getPaddingTop(), ((ViewGroup.MarginLayoutParams) layoutParams).height));
                        int measuredWidth = childAt.getMeasuredWidth();
                        measuredHeight = childAt.getMeasuredHeight();
                        if (measuredHeight > iMin) {
                            if (mode2 == Integer.MIN_VALUE) {
                                iMin = Math.min(measuredHeight, paddingTop);
                            } else if (mode2 == 0) {
                                iMin = measuredHeight;
                            }
                        }
                        i10 -= measuredWidth;
                        if (i9 != 0) {
                            if (i10 < 0) {
                                z = true;
                            } else {
                                z = false;
                            }
                            layoutParams.f2216b = z;
                            z2 |= z;
                            if (z) {
                                this.f2211i = childAt;
                            }
                        }
                    }
                } else {
                    iMax2 = Math.max(iMax3 - (((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin), (int) r7);
                    i7 = ((ViewGroup.MarginLayoutParams) layoutParams).width;
                    if (i7 == -2) {
                        if (mode == 0) {
                            i8 = mode;
                        } else {
                            i8 = RtlSpacingHelper.UNDEFINED;
                        }
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMax2, i8);
                    } else if (i7 == -1) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMax2, mode);
                    } else {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i7, 1073741824);
                    }
                    childAt.measure(iMakeMeasureSpec2, ViewGroup.getChildMeasureSpec(i2, getPaddingBottom() + getPaddingTop(), ((ViewGroup.MarginLayoutParams) layoutParams).height));
                    int measuredWidth2 = childAt.getMeasuredWidth();
                    measuredHeight = childAt.getMeasuredHeight();
                    if (measuredHeight > iMin) {
                        if (mode2 == Integer.MIN_VALUE) {
                            iMin = Math.min(measuredHeight, paddingTop);
                        } else if (mode2 == 0) {
                            iMin = measuredHeight;
                        }
                    }
                    i10 -= measuredWidth2;
                    if (i9 != 0) {
                        if (i10 < 0) {
                            z = true;
                        } else {
                            z = false;
                        }
                        layoutParams.f2216b = z;
                        z2 |= z;
                        if (z) {
                            this.f2211i = childAt;
                        }
                    }
                }
            }
            i9++;
            r7 = 0;
        }
        int i11 = 1;
        if (z2 || f > 0.0f) {
            int i12 = 0;
            while (i12 < childCount) {
                View childAt2 = getChildAt(i12);
                if (childAt2.getVisibility() == i3) {
                    i4 = i12;
                } else {
                    LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                    int measuredWidth3 = (((ViewGroup.MarginLayoutParams) layoutParams2).width != 0 || layoutParams2.f2215a <= 0.0f) ? childAt2.getMeasuredWidth() : 0;
                    if (z2) {
                        iMax = iMax3 - (((ViewGroup.MarginLayoutParams) layoutParams2).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).rightMargin);
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMax, 1073741824);
                    } else if (layoutParams2.f2215a > 0.0f) {
                        iMax = ((int) ((layoutParams2.f2215a * Math.max(0, i10)) / f)) + measuredWidth3;
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMax, 1073741824);
                    } else {
                        iMax = measuredWidth3;
                        iMakeMeasureSpec = 0;
                    }
                    int paddingBottom = getPaddingBottom() + getPaddingTop();
                    LayoutParams layoutParams3 = (LayoutParams) childAt2.getLayoutParams();
                    i4 = i12;
                    int iMakeMeasureSpec3 = (((ViewGroup.MarginLayoutParams) layoutParams3).width != 0 || layoutParams3.f2215a <= 0.0f) ? View.MeasureSpec.makeMeasureSpec(childAt2.getMeasuredHeight(), 1073741824) : ViewGroup.getChildMeasureSpec(i2, paddingBottom, ((ViewGroup.MarginLayoutParams) layoutParams3).height);
                    if (measuredWidth3 != iMax) {
                        childAt2.measure(iMakeMeasureSpec, iMakeMeasureSpec3);
                        int measuredHeight2 = childAt2.getMeasuredHeight();
                        if (measuredHeight2 > iMin) {
                            if (mode2 == Integer.MIN_VALUE) {
                                measuredHeight2 = Math.min(measuredHeight2, paddingTop);
                            } else if (mode2 == 0) {
                            }
                            iMin = measuredHeight2;
                        }
                    }
                }
                i12 = i4 + 1;
                i3 = 8;
            }
        }
        dr4 dr4Var = this.f2208K;
        if (dr4Var == null || !dr4Var.m7065a() || this.f2208K.f11299a.m18895c().left == 0 || this.f2208K.f11299a.m18895c().top != 0) {
            arrayList = null;
        } else {
            dr4 dr4Var2 = this.f2208K;
            int[] iArr = new int[2];
            getLocationInWindow(iArr);
            int i13 = iArr[0];
            Rect rect = new Rect(i13, iArr[1], getWidth() + i13, getWidth() + iArr[1]);
            Rect rect2 = new Rect(dr4Var2.f11299a.m18895c());
            boolean zIntersect = rect2.intersect(rect);
            if (!(rect2.width() == 0 && rect2.height() == 0) && zIntersect) {
                rect2.offset(-iArr[0], -iArr[1]);
            } else {
                rect2 = null;
            }
            if (rect2 == null) {
                arrayList = null;
            } else {
                Rect rect3 = new Rect(getPaddingLeft(), getPaddingTop(), Math.max(getPaddingLeft(), rect2.left), getHeight() - getPaddingBottom());
                int width = getWidth() - getPaddingRight();
                arrayList = new ArrayList(Arrays.asList(rect3, new Rect(Math.min(width, rect2.right), getPaddingTop(), width, getHeight() - getPaddingBottom())));
            }
        }
        if (arrayList != null && !z2) {
            int i14 = 0;
            while (i14 < childCount) {
                View childAt3 = getChildAt(i14);
                if (childAt3.getVisibility() != 8) {
                    Rect rect4 = (Rect) arrayList.get(i14);
                    LayoutParams layoutParams4 = (LayoutParams) childAt3.getLayoutParams();
                    int i15 = ((ViewGroup.MarginLayoutParams) layoutParams4).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams4).rightMargin;
                    int iMakeMeasureSpec4 = View.MeasureSpec.makeMeasureSpec(childAt3.getMeasuredHeight(), 1073741824);
                    childAt3.measure(View.MeasureSpec.makeMeasureSpec(rect4.width(), RtlSpacingHelper.UNDEFINED), iMakeMeasureSpec4);
                    if ((childAt3.getMeasuredWidthAndState() & 16777216) != i11) {
                        boolean z3 = childAt3 instanceof e2a;
                        if (z3) {
                            i6 = 0;
                            View childAt4 = ((e2a) childAt3).getChildAt(0);
                            WeakHashMap weakHashMap = obb.f31348a;
                            minimumWidth = childAt4.getMinimumWidth();
                        } else {
                            i6 = 0;
                            WeakHashMap weakHashMap2 = obb.f31348a;
                            minimumWidth = childAt3.getMinimumWidth();
                        }
                        if (minimumWidth != 0) {
                            if (rect4.width() < (z3 ? ((e2a) childAt3).getChildAt(i6).getMinimumWidth() : childAt3.getMinimumWidth())) {
                            }
                        }
                        childAt3.measure(View.MeasureSpec.makeMeasureSpec(rect4.width(), 1073741824), iMakeMeasureSpec4);
                    }
                    childAt3.measure(View.MeasureSpec.makeMeasureSpec(iMax3 - i15, 1073741824), iMakeMeasureSpec4);
                    if (i14 != 0) {
                        i5 = 1;
                        layoutParams4.f2216b = true;
                        this.f2211i = childAt3;
                        z2 = true;
                    }
                    i14++;
                    i11 = i5;
                }
                i5 = 1;
                i14++;
                i11 = i5;
            }
        }
        boolean z4 = z2;
        setMeasuredDimension(size, getPaddingBottom() + getPaddingTop() + iMin);
        this.f2210e = z4;
        wbb wbbVar = this.f2202E;
        if (wbbVar.f45172a == 0 || z4) {
            return;
        }
        wbbVar.m19461a();
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        if (savedState.f2218e) {
            if (!this.f2210e) {
                this.f2203F = true;
            }
            if (this.f2204G || m1530e(0.0f)) {
                this.f2203F = true;
            }
        } else {
            m1526a();
        }
        this.f2203F = savedState.f2218e;
        this.f2207J = savedState.f2219i;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f2218e = this.f2210e ? m1529d() : this.f2203F;
        savedState.f2219i = this.f2207J;
        return savedState;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3) {
            this.f2204G = true;
        }
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (!this.f2210e) {
            return super.onTouchEvent(motionEvent);
        }
        wbb wbbVar = this.f2202E;
        wbbVar.m19472m(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            this.f2199B = x;
            this.f2200C = y;
            return true;
        }
        if (actionMasked == 1 && m1527b(this.f2211i)) {
            float x2 = motionEvent.getX();
            float y2 = motionEvent.getY();
            float f = x2 - this.f2199B;
            float f2 = y2 - this.f2200C;
            int i = wbbVar.f45173b;
            if ((f2 * f2) + (f * f) < i * i && wbb.m19460l(this.f2211i, (int) x2, (int) y2)) {
                m1526a();
            }
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void removeView(View view) {
        if (view.getParent() instanceof e2a) {
            super.removeView((View) view.getParent());
        } else {
            super.removeView(view);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        if (isInTouchMode() || this.f2210e) {
            return;
        }
        this.f2203F = view == this.f2211i;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public SlidingPaneLayout(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}
