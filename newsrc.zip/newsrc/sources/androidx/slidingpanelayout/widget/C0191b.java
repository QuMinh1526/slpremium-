package androidx.slidingpanelayout.widget;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: renamed from: androidx.slidingpanelayout.widget.b */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public final class C0191b implements Parcelable.ClassLoaderCreator {
    @Override // android.os.Parcelable.ClassLoaderCreator
    public final Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return new SlidingPaneLayout.SavedState(parcel);
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i) {
        return new SlidingPaneLayout.SavedState[i];
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        return new SlidingPaneLayout.SavedState(parcel);
    }
}
