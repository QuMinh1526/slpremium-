package androidx.slidingpanelayout.widget;

import android.view.View;
import android.view.ViewGroup;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import p000.C0478f2;
import p000.v09;

/* JADX INFO: renamed from: androidx.slidingpanelayout.widget.a */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public final class C0190a extends v09 {

    /* JADX INFO: renamed from: a */
    public final /* synthetic */ SlidingPaneLayout f2220a;

    public C0190a(SlidingPaneLayout slidingPaneLayout) {
        this.f2220a = slidingPaneLayout;
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: F */
    public final void mo1042F(int i, int i2) {
        if (m1532Z()) {
            SlidingPaneLayout slidingPaneLayout = this.f2220a;
            slidingPaneLayout.f2202E.m19463c(i2, slidingPaneLayout.f2211i);
        }
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: G */
    public final void mo1043G(int i) {
        if (m1532Z()) {
            SlidingPaneLayout slidingPaneLayout = this.f2220a;
            slidingPaneLayout.f2202E.m19463c(i, slidingPaneLayout.f2211i);
        }
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: H */
    public final void mo1044H(int i, View view) {
        SlidingPaneLayout slidingPaneLayout = this.f2220a;
        int childCount = slidingPaneLayout.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = slidingPaneLayout.getChildAt(i2);
            if (childAt.getVisibility() == 4) {
                childAt.setVisibility(0);
            }
        }
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: I */
    public final void mo1045I(int i) {
        SlidingPaneLayout slidingPaneLayout = this.f2220a;
        CopyOnWriteArrayList<C0478f2> copyOnWriteArrayList = slidingPaneLayout.f2201D;
        if (slidingPaneLayout.f2202E.f45172a == 0) {
            float f = slidingPaneLayout.f2212y;
            View view = slidingPaneLayout.f2211i;
            if (f != 1.0f) {
                for (C0478f2 c0478f2 : copyOnWriteArrayList) {
                    c0478f2.getClass();
                    view.getClass();
                    c0478f2.m12054f(true);
                }
                slidingPaneLayout.sendAccessibilityEvent(32);
                slidingPaneLayout.f2203F = true;
                return;
            }
            slidingPaneLayout.m1531f(view);
            View view2 = slidingPaneLayout.f2211i;
            for (C0478f2 c0478f3 : copyOnWriteArrayList) {
                c0478f3.getClass();
                view2.getClass();
                c0478f3.m12054f(false);
            }
            slidingPaneLayout.sendAccessibilityEvent(32);
            slidingPaneLayout.f2203F = false;
        }
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: J */
    public final void mo1046J(View view, int i, int i2) {
        SlidingPaneLayout slidingPaneLayout = this.f2220a;
        if (slidingPaneLayout.f2211i == null) {
            slidingPaneLayout.f2212y = 0.0f;
        } else {
            boolean zM1528c = slidingPaneLayout.m1528c();
            SlidingPaneLayout.LayoutParams layoutParams = (SlidingPaneLayout.LayoutParams) slidingPaneLayout.f2211i.getLayoutParams();
            int width = slidingPaneLayout.f2211i.getWidth();
            if (zM1528c) {
                i = (slidingPaneLayout.getWidth() - i) - width;
            }
            slidingPaneLayout.f2212y = (i - ((zM1528c ? slidingPaneLayout.getPaddingRight() : slidingPaneLayout.getPaddingLeft()) + (zM1528c ? ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin : ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin))) / slidingPaneLayout.f2213z;
            View view2 = slidingPaneLayout.f2211i;
            Iterator it = slidingPaneLayout.f2201D.iterator();
            while (it.hasNext()) {
                ((C0478f2) it.next()).getClass();
                view2.getClass();
            }
        }
        slidingPaneLayout.invalidate();
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: K */
    public final void mo1047K(View view, float f, float f2) {
        int paddingLeft;
        SlidingPaneLayout.LayoutParams layoutParams = (SlidingPaneLayout.LayoutParams) view.getLayoutParams();
        SlidingPaneLayout slidingPaneLayout = this.f2220a;
        if (slidingPaneLayout.m1528c()) {
            int paddingRight = slidingPaneLayout.getPaddingRight() + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
            if (f < 0.0f || (f == 0.0f && slidingPaneLayout.f2212y > 0.5f)) {
                paddingRight += slidingPaneLayout.f2213z;
            }
            paddingLeft = (slidingPaneLayout.getWidth() - paddingRight) - slidingPaneLayout.f2211i.getWidth();
        } else {
            paddingLeft = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + slidingPaneLayout.getPaddingLeft();
            if (f > 0.0f || (f == 0.0f && slidingPaneLayout.f2212y > 0.5f)) {
                paddingLeft += slidingPaneLayout.f2213z;
            }
        }
        slidingPaneLayout.f2202E.m19478s(paddingLeft, view.getTop());
        slidingPaneLayout.invalidate();
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: V */
    public final boolean mo1048V(int i, View view) {
        if (m1532Z()) {
            return ((SlidingPaneLayout.LayoutParams) view.getLayoutParams()).f2216b;
        }
        return false;
    }

    /* JADX INFO: renamed from: Z */
    public final boolean m1532Z() {
        SlidingPaneLayout slidingPaneLayout = this.f2220a;
        if (slidingPaneLayout.f2198A || slidingPaneLayout.f2207J == 3) {
            return false;
        }
        if (slidingPaneLayout.m1529d() && slidingPaneLayout.f2207J == 1) {
            return false;
        }
        return slidingPaneLayout.m1529d() || slidingPaneLayout.f2207J != 2;
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: o */
    public final int mo1049o(int i, View view) {
        SlidingPaneLayout slidingPaneLayout = this.f2220a;
        SlidingPaneLayout.LayoutParams layoutParams = (SlidingPaneLayout.LayoutParams) slidingPaneLayout.f2211i.getLayoutParams();
        if (!slidingPaneLayout.m1528c()) {
            int paddingLeft = slidingPaneLayout.getPaddingLeft() + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
            return Math.min(Math.max(i, paddingLeft), slidingPaneLayout.f2213z + paddingLeft);
        }
        int width = slidingPaneLayout.getWidth() - (slidingPaneLayout.f2211i.getWidth() + (slidingPaneLayout.getPaddingRight() + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin));
        return Math.max(Math.min(i, width), width - slidingPaneLayout.f2213z);
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: p */
    public final int mo1050p(int i, View view) {
        return view.getTop();
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: z */
    public final int mo1051z(View view) {
        return this.f2220a.f2213z;
    }
}
