package androidx.appcompat.app;

import android.os.LocaleList;
import androidx.annotation.RequiresApi;
import java.util.LinkedHashSet;
import java.util.Locale;
import p000.mf6;
import p000.nf6;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@RequiresApi(24)
final class LocaleOverlayHelper {
    private LocaleOverlayHelper() {
    }

    private static mf6 combineLocales(mf6 mf6Var, mf6 mf6Var2) {
        Locale locale;
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        int i = 0;
        while (true) {
            nf6 nf6Var = mf6Var.f28395a;
            nf6 nf6Var2 = mf6Var.f28395a;
            if (i >= mf6Var2.f28395a.f29954a.size() + nf6Var.f29954a.size()) {
                return mf6.m13521b(new LocaleList((Locale[]) linkedHashSet.toArray(new Locale[linkedHashSet.size()])));
            }
            if (i < nf6Var2.f29954a.size()) {
                locale = nf6Var2.f29954a.get(i);
            } else {
                locale = mf6Var2.f28395a.f29954a.get(i - nf6Var2.f29954a.size());
            }
            if (locale != null) {
                linkedHashSet.add(locale);
            }
            i++;
        }
    }

    public static mf6 combineLocalesIfOverlayExists(LocaleList localeList, LocaleList localeList2) {
        return (localeList == null || localeList.isEmpty()) ? mf6.f28394b : combineLocales(mf6.m13521b(localeList), mf6.m13521b(localeList2));
    }

    public static mf6 combineLocalesIfOverlayExists(mf6 mf6Var, mf6 mf6Var2) {
        if (mf6Var != null && !mf6Var.f28395a.f29954a.isEmpty()) {
            return combineLocales(mf6Var, mf6Var2);
        }
        return mf6.f28394b;
    }
}
