package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.C0026R;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import p000.aj3;
import p000.j91;
import p000.lj3;
import p000.mj3;
import p000.o98;
import p000.oi3;
import p000.ui3;
import p000.xi3;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
class AppCompatEmojiEditTextHelper {

    @NonNull
    private final ui3 mEmojiEditTextHelper;

    @NonNull
    private final EditText mView;

    public AppCompatEmojiEditTextHelper(@NonNull EditText editText) {
        this.mView = editText;
        this.mEmojiEditTextHelper = new ui3(editText);
    }

    @Nullable
    public KeyListener getKeyListener(@Nullable KeyListener keyListener) {
        if (!isEmojiCapableKeyListener(keyListener)) {
            return keyListener;
        }
        this.mEmojiEditTextHelper.f42036a.getClass();
        if (keyListener instanceof aj3) {
            return keyListener;
        }
        if (keyListener == null) {
            return null;
        }
        return keyListener instanceof NumberKeyListener ? keyListener : new aj3(keyListener);
    }

    public boolean isEmojiCapableKeyListener(KeyListener keyListener) {
        return !(keyListener instanceof NumberKeyListener);
    }

    public boolean isEnabled() {
        return ((mj3) this.mEmojiEditTextHelper.f42036a.f22633i).f28528y;
    }

    public void loadFromAttributes(@Nullable AttributeSet attributeSet, int i) {
        TypedArray typedArrayObtainStyledAttributes = this.mView.getContext().obtainStyledAttributes(attributeSet, C0026R.styleable.AppCompatTextView, i, 0);
        try {
            boolean z = typedArrayObtainStyledAttributes.hasValue(C0026R.styleable.AppCompatTextView_emojiCompatEnabled) ? typedArrayObtainStyledAttributes.getBoolean(C0026R.styleable.AppCompatTextView_emojiCompatEnabled, true) : true;
            typedArrayObtainStyledAttributes.recycle();
            setEnabled(z);
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    @Nullable
    public InputConnection onCreateInputConnection(@Nullable InputConnection inputConnection, @NonNull EditorInfo editorInfo) {
        ui3 ui3Var = this.mEmojiEditTextHelper;
        if (inputConnection == null) {
            ui3Var.getClass();
            return null;
        }
        j91 j91Var = ui3Var.f42036a;
        j91Var.getClass();
        return inputConnection instanceof xi3 ? inputConnection : new xi3((EditText) j91Var.f22632e, inputConnection, editorInfo);
    }

    public void setEnabled(boolean z) {
        mj3 mj3Var = (mj3) this.mEmojiEditTextHelper.f42036a.f22633i;
        if (mj3Var.f28528y != z) {
            if (mj3Var.f28527i != null) {
                oi3 oi3VarM14710a = oi3.m14710a();
                lj3 lj3Var = mj3Var.f28527i;
                oi3VarM14710a.getClass();
                o98.m14573c(lj3Var, "initCallback cannot be null");
                ReentrantReadWriteLock reentrantReadWriteLock = oi3VarM14710a.f31660a;
                reentrantReadWriteLock.writeLock().lock();
                try {
                    oi3VarM14710a.f31661b.remove(lj3Var);
                    reentrantReadWriteLock.writeLock().unlock();
                } catch (Throwable th) {
                    reentrantReadWriteLock.writeLock().unlock();
                    throw th;
                }
            }
            mj3Var.f28528y = z;
            if (z) {
                mj3.m13545a(mj3Var.f28526e, oi3.m14710a().m14713c());
            }
        }
    }
}
