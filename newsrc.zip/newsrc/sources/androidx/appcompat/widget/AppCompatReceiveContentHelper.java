package androidx.appcompat.widget;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.text.Selection;
import android.text.Spannable;
import android.util.Log;
import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import p000.c62;
import p000.d62;
import p000.fw6;
import p000.obb;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
final class AppCompatReceiveContentHelper {
    private static final String LOG_TAG = "ReceiveContent";

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    @RequiresApi(24)
    public static final class OnDropApi24Impl {
        private OnDropApi24Impl() {
        }

        @DoNotInline
        public static boolean onDropForTextView(@NonNull DragEvent dragEvent, @NonNull TextView textView, @NonNull Activity activity) {
            c62 fw6Var;
            activity.requestDragAndDropPermissions(dragEvent);
            int offsetForPosition = textView.getOffsetForPosition(dragEvent.getX(), dragEvent.getY());
            textView.beginBatchEdit();
            try {
                Selection.setSelection((Spannable) textView.getText(), offsetForPosition);
                ClipData clipData = dragEvent.getClipData();
                if (Build.VERSION.SDK_INT >= 31) {
                    fw6Var = new fw6(clipData, 3);
                } else {
                    d62 d62Var = new d62();
                    d62Var.f10468i = clipData;
                    d62Var.f10469y = 3;
                    fw6Var = d62Var;
                }
                obb.m14617j(textView, fw6Var.build());
                return true;
            } finally {
                textView.endBatchEdit();
            }
        }

        @DoNotInline
        public static boolean onDropForView(@NonNull DragEvent dragEvent, @NonNull View view, @NonNull Activity activity) {
            c62 fw6Var;
            activity.requestDragAndDropPermissions(dragEvent);
            ClipData clipData = dragEvent.getClipData();
            if (Build.VERSION.SDK_INT >= 31) {
                fw6Var = new fw6(clipData, 3);
            } else {
                d62 d62Var = new d62();
                d62Var.f10468i = clipData;
                d62Var.f10469y = 3;
                fw6Var = d62Var;
            }
            obb.m14617j(view, fw6Var.build());
            return true;
        }
    }

    private AppCompatReceiveContentHelper() {
    }

    public static boolean maybeHandleDragEventViaPerformReceiveContent(@NonNull View view, @NonNull DragEvent dragEvent) {
        if (Build.VERSION.SDK_INT < 31 && dragEvent.getLocalState() == null && obb.m14614g(view) != null) {
            Activity activityTryGetActivity = tryGetActivity(view);
            if (activityTryGetActivity == null) {
                Log.i(LOG_TAG, "Can't handle drop: no activity: view=" + view);
                return false;
            }
            if (dragEvent.getAction() == 1) {
                return !(view instanceof TextView);
            }
            if (dragEvent.getAction() == 3) {
                return view instanceof TextView ? OnDropApi24Impl.onDropForTextView(dragEvent, (TextView) view, activityTryGetActivity) : OnDropApi24Impl.onDropForView(dragEvent, view, activityTryGetActivity);
            }
        }
        return false;
    }

    public static boolean maybeHandleMenuActionViaPerformReceiveContent(@NonNull TextView textView, int i) {
        d62 d62Var;
        c62 c62Var;
        fw6 fw6Var;
        int i2 = Build.VERSION.SDK_INT;
        int i3 = 0;
        if (i2 >= 31 || obb.m14614g(textView) == null || !(i == 16908322 || i == 16908337)) {
            return false;
        }
        ClipboardManager clipboardManager = (ClipboardManager) textView.getContext().getSystemService("clipboard");
        ClipData primaryClip = clipboardManager == null ? null : clipboardManager.getPrimaryClip();
        if (primaryClip != null && primaryClip.getItemCount() > 0) {
            if (i2 >= 31) {
                fw6Var = new fw6(primaryClip, 1);
            } else {
                d62Var = new d62();
                d62Var.f10468i = primaryClip;
                d62Var.f10469y = 1;
            }
            if (i != 16908322) {
                c62Var = d62Var;
                c62Var = fw6Var;
                i3 = 1;
            }
            c62Var = d62Var;
            c62Var = fw6Var;
            c62Var.mo2965m(i3);
            obb.m14617j(textView, c62Var.build());
        }
        return true;
    }

    @Nullable
    public static Activity tryGetActivity(@NonNull View view) {
        for (Context context = view.getContext(); context instanceof ContextWrapper; context = ((ContextWrapper) context).getBaseContext()) {
            if (context instanceof Activity) {
                return (Activity) context;
            }
        }
        return null;
    }
}
