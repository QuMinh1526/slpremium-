package androidx.appcompat.view;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.annotation.RestrictTo;
import java.util.ArrayList;
import java.util.Iterator;
import p000.jdb;
import p000.kdb;
import p000.ldb;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public class ViewPropertyAnimatorCompatSet {
    private Interpolator mInterpolator;
    private boolean mIsStarted;
    kdb mListener;
    private long mDuration = -1;
    private final ldb mProxyListener = new ldb() { // from class: androidx.appcompat.view.ViewPropertyAnimatorCompatSet.1
        private boolean mProxyStarted = false;
        private int mProxyEndCount = 0;

        @Override // p000.kdb
        public void onAnimationEnd(View view) {
            int i = this.mProxyEndCount + 1;
            this.mProxyEndCount = i;
            if (i == ViewPropertyAnimatorCompatSet.this.mAnimators.size()) {
                kdb kdbVar = ViewPropertyAnimatorCompatSet.this.mListener;
                if (kdbVar != null) {
                    kdbVar.onAnimationEnd(null);
                }
                onEnd();
            }
        }

        @Override // p000.ldb, p000.kdb
        public void onAnimationStart(View view) {
            if (this.mProxyStarted) {
                return;
            }
            this.mProxyStarted = true;
            kdb kdbVar = ViewPropertyAnimatorCompatSet.this.mListener;
            if (kdbVar != null) {
                kdbVar.onAnimationStart(null);
            }
        }

        public void onEnd() {
            this.mProxyEndCount = 0;
            this.mProxyStarted = false;
            ViewPropertyAnimatorCompatSet.this.onAnimationsEnded();
        }
    };
    final ArrayList<jdb> mAnimators = new ArrayList<>();

    public void cancel() {
        if (this.mIsStarted) {
            Iterator<jdb> it = this.mAnimators.iterator();
            while (it.hasNext()) {
                it.next().m11274b();
            }
            this.mIsStarted = false;
        }
    }

    public void onAnimationsEnded() {
        this.mIsStarted = false;
    }

    public ViewPropertyAnimatorCompatSet play(jdb jdbVar) {
        if (!this.mIsStarted) {
            this.mAnimators.add(jdbVar);
        }
        return this;
    }

    public ViewPropertyAnimatorCompatSet playSequentially(jdb jdbVar, jdb jdbVar2) {
        this.mAnimators.add(jdbVar);
        View view = (View) jdbVar.f22892a.get();
        long duration = view != null ? view.animate().getDuration() : 0L;
        View view2 = (View) jdbVar2.f22892a.get();
        if (view2 != null) {
            view2.animate().setStartDelay(duration);
        }
        this.mAnimators.add(jdbVar2);
        return this;
    }

    public ViewPropertyAnimatorCompatSet setDuration(long j) {
        if (!this.mIsStarted) {
            this.mDuration = j;
        }
        return this;
    }

    public ViewPropertyAnimatorCompatSet setInterpolator(Interpolator interpolator) {
        if (!this.mIsStarted) {
            this.mInterpolator = interpolator;
        }
        return this;
    }

    public ViewPropertyAnimatorCompatSet setListener(kdb kdbVar) {
        if (!this.mIsStarted) {
            this.mListener = kdbVar;
        }
        return this;
    }

    public void start() {
        View view;
        if (this.mIsStarted) {
            return;
        }
        for (jdb jdbVar : this.mAnimators) {
            long j = this.mDuration;
            if (j >= 0) {
                jdbVar.m11275c(j);
            }
            Interpolator interpolator = this.mInterpolator;
            if (interpolator != null && (view = (View) jdbVar.f22892a.get()) != null) {
                view.animate().setInterpolator(interpolator);
            }
            if (this.mListener != null) {
                jdbVar.m11276d(this.mProxyListener);
            }
            View view2 = (View) jdbVar.f22892a.get();
            if (view2 != null) {
                view2.animate().start();
            }
        }
        this.mIsStarted = true;
    }
}
