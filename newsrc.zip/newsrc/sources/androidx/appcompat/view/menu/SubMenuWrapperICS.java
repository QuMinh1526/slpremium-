package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.annotation.RestrictTo;
import p000.dha;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
class SubMenuWrapperICS extends MenuWrapperICS implements SubMenu {
    private final dha mSubMenu;

    public SubMenuWrapperICS(Context context, dha dhaVar) {
        super(context, dhaVar);
    }

    @Override // android.view.SubMenu
    public void clearHeader() {
        throw null;
    }

    @Override // android.view.SubMenu
    public MenuItem getItem() {
        throw null;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderIcon(int i) {
        throw null;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderTitle(int i) {
        throw null;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderView(View view) {
        throw null;
    }

    @Override // android.view.SubMenu
    public SubMenu setIcon(int i) {
        throw null;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderIcon(Drawable drawable) {
        throw null;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderTitle(CharSequence charSequence) {
        throw null;
    }

    @Override // android.view.SubMenu
    public SubMenu setIcon(Drawable drawable) {
        throw null;
    }
}
