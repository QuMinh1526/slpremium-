package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import p000.tga;
import p000.uy9;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
abstract class BaseMenuWrapper {
    final Context mContext;
    private uy9 mMenuItems;
    private uy9 mSubMenus;

    public BaseMenuWrapper(Context context) {
        this.mContext = context;
    }

    public final MenuItem getMenuItemWrapper(MenuItem menuItem) {
        if (!(menuItem instanceof tga)) {
            return menuItem;
        }
        tga tgaVar = (tga) menuItem;
        if (this.mMenuItems == null) {
            this.mMenuItems = new uy9(0);
        }
        MenuItem menuItem2 = (MenuItem) this.mMenuItems.get(tgaVar);
        if (menuItem2 != null) {
            return menuItem2;
        }
        MenuItemWrapperICS menuItemWrapperICS = new MenuItemWrapperICS(this.mContext, tgaVar);
        this.mMenuItems.put(tgaVar, menuItemWrapperICS);
        return menuItemWrapperICS;
    }

    public final void internalClear() {
        uy9 uy9Var = this.mMenuItems;
        if (uy9Var != null) {
            uy9Var.clear();
        }
        uy9 uy9Var2 = this.mSubMenus;
        if (uy9Var2 != null) {
            uy9Var2.clear();
        }
    }

    public final void internalRemoveGroup(int i) {
        if (this.mMenuItems == null) {
            return;
        }
        int i2 = 0;
        while (true) {
            uy9 uy9Var = this.mMenuItems;
            if (i2 >= uy9Var.f42820y) {
                return;
            }
            if (((tga) uy9Var.m18748f(i2)).getGroupId() == i) {
                this.mMenuItems.m18749g(i2);
                i2--;
            }
            i2++;
        }
    }

    public final void internalRemoveItem(int i) {
        if (this.mMenuItems == null) {
            return;
        }
        int i2 = 0;
        while (true) {
            uy9 uy9Var = this.mMenuItems;
            if (i2 >= uy9Var.f42820y) {
                return;
            }
            if (((tga) uy9Var.m18748f(i2)).getItemId() == i) {
                this.mMenuItems.m18749g(i2);
                return;
            }
            i2++;
        }
    }

    public final SubMenu getSubMenuWrapper(SubMenu subMenu) {
        return subMenu;
    }
}
