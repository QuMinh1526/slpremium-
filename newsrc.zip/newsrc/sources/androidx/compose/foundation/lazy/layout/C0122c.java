package androidx.compose.foundation.lazy.layout;

import p000.jl5;
import p000.ld5;
import p000.nh5;
import p000.nj4;
import p000.oz6;
import p000.sj5;
import p000.ty6;
import p000.ul5;
import p000.ve7;
import p000.z23;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.layout.c */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public final class C0122c {

    /* JADX INFO: renamed from: a */
    public final ty6 f1156a;

    /* JADX INFO: renamed from: b */
    public final Object[] f1157b;

    /* JADX INFO: renamed from: c */
    public final int f1158c;

    /* JADX WARN: Code duplicated, block: B:31:0x00cb  */
    public C0122c(sj5 sj5Var, AbstractC0121b abstractC0121b) {
        Object defaultLazyKey;
        ld5 ld5VarMo764b = abstractC0121b.mo764b();
        int i = sj5Var.f35051e;
        if (i < 0) {
            nh5.m14156c("negative nearestRange.first");
        }
        int iMin = Math.min(sj5Var.f35052i, ld5VarMo764b.f26461b - 1);
        if (iMin < i) {
            ty6 ty6Var = ve7.f43651a;
            ty6Var.getClass();
            this.f1156a = ty6Var;
            this.f1157b = new Object[0];
            this.f1158c = 0;
            return;
        }
        int i2 = (iMin - i) + 1;
        this.f1157b = new Object[i2];
        this.f1158c = i;
        ty6 ty6Var2 = new ty6(i2);
        oz6 oz6Var = (oz6) ld5VarMo764b.f26462c;
        if (i < 0 || i >= ld5VarMo764b.f26461b) {
            StringBuilder sbM20941w = z23.m20941w(i, "Index ", ", size ");
            sbM20941w.append(ld5VarMo764b.f26461b);
            nh5.m14158e(sbM20941w.toString());
        }
        if (iMin < 0 || iMin >= ld5VarMo764b.f26461b) {
            StringBuilder sbM20941w2 = z23.m20941w(iMin, "Index ", ", size ");
            sbM20941w2.append(ld5VarMo764b.f26461b);
            nh5.m14158e(sbM20941w2.toString());
        }
        if (iMin < i) {
            nh5.m14154a("toIndex (" + iMin + ") should be not smaller than fromIndex (" + i + ')');
        }
        int iM18474g = ul5.m18474g(i, oz6Var);
        int i3 = ((jl5) oz6Var.f32501e[iM18474g]).f23241a;
        while (i3 <= iMin) {
            jl5 jl5Var = (jl5) oz6Var.f32501e[iM18474g];
            nj4 key = jl5Var.f23243c.getKey();
            int i4 = jl5Var.f23241a;
            int iMax = Math.max(i, i4);
            int iMin2 = Math.min(iMin, (jl5Var.f23242b + i4) - 1);
            if (iMax <= iMin2) {
                while (true) {
                    if (key != null) {
                        defaultLazyKey = key.invoke(Integer.valueOf(iMax - i4));
                        defaultLazyKey = defaultLazyKey == null ? new DefaultLazyKey(iMax) : defaultLazyKey;
                    }
                    ty6Var2.m18011g(iMax, defaultLazyKey);
                    this.f1157b[iMax - this.f1158c] = defaultLazyKey;
                    iMax = iMax != iMin2 ? iMax + 1 : iMax;
                }
            }
            i3 += jl5Var.f23242b;
            iM18474g++;
        }
        this.f1156a = ty6Var2;
    }

    /* JADX INFO: renamed from: a */
    public final int m766a(Object obj) {
        ty6 ty6Var = this.f1156a;
        int iM18008d = ty6Var.m18008d(obj);
        if (iM18008d >= 0) {
            return ty6Var.f41074c[iM18008d];
        }
        return -1;
    }

    /* JADX INFO: renamed from: b */
    public final Object m767b(int i) {
        int i2 = i - this.f1158c;
        if (i2 < 0) {
            return null;
        }
        Object[] objArr = this.f1157b;
        if (i2 < objArr.length) {
            return objArr[i2];
        }
        return null;
    }
}
