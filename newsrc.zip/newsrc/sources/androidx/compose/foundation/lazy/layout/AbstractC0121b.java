package androidx.compose.foundation.lazy.layout;

import p000.jl5;
import p000.ld5;
import p000.nj4;

/* JADX INFO: renamed from: androidx.compose.foundation.lazy.layout.b */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0121b {
    /* JADX INFO: renamed from: a */
    public final Object m763a(int i) {
        jl5 jl5VarM12930d = mo764b().m12930d(i);
        return jl5VarM12930d.f23243c.getType().invoke(Integer.valueOf(i - jl5VarM12930d.f23241a));
    }

    /* JADX INFO: renamed from: b */
    public abstract ld5 mo764b();

    /* JADX INFO: renamed from: c */
    public final Object m765c(int i) {
        Object objInvoke;
        jl5 jl5VarM12930d = mo764b().m12930d(i);
        int i2 = i - jl5VarM12930d.f23241a;
        nj4 key = jl5VarM12930d.f23243c.getKey();
        return (key == null || (objInvoke = key.invoke(Integer.valueOf(i2))) == null) ? new DefaultLazyKey(i) : objInvoke;
    }
}
