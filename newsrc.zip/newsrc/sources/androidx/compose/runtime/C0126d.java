package androidx.compose.runtime;

import android.os.Parcel;
import android.os.Parcelable;
import p000.C1521v3;
import p000.i5a;
import p000.mp8;
import p000.rr4;
import p000.z23;

/* JADX INFO: renamed from: androidx.compose.runtime.d */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public final class C0126d implements Parcelable.ClassLoaderCreator {
    /* JADX INFO: renamed from: a */
    public static ParcelableSnapshotMutableState m791a(Parcel parcel, ClassLoader classLoader) {
        i5a i5aVar;
        if (classLoader == null) {
            classLoader = C0126d.class.getClassLoader();
        }
        Object value = parcel.readValue(classLoader);
        int i = parcel.readInt();
        if (i == 0) {
            i5aVar = rr4.f37180Y;
        } else if (i == 1) {
            i5aVar = mp8.f28796R;
        } else {
            if (i != 2) {
                C1521v3.m18909p(z23.m20930l(i, "Unsupported MutableState policy ", " was restored"));
                return null;
            }
            i5aVar = rr4.f37183b0;
        }
        return new ParcelableSnapshotMutableState(value, i5aVar);
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        return m791a(parcel, null);
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i) {
        return new ParcelableSnapshotMutableState[i];
    }

    @Override // android.os.Parcelable.ClassLoaderCreator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return m791a(parcel, classLoader);
    }
}
