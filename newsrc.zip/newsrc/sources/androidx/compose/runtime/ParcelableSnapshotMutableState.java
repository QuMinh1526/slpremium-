package androidx.compose.runtime;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import p000.C1521v3;
import p000.h5a;
import p000.i5a;
import p000.mp8;
import p000.rr4;
import p000.ul5;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0003\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000\u00022\u00020\u0003¨\u0006\u0004"}, m12198d2 = {"Landroidx/compose/runtime/ParcelableSnapshotMutableState;", "T", "Lh5a;", "Landroid/os/Parcelable;", "runtime"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
@SuppressLint({"BanParcelableUsage"})
final class ParcelableSnapshotMutableState<T> extends h5a implements Parcelable {

    @NotNull
    public static final Parcelable.Creator<ParcelableSnapshotMutableState<Object>> CREATOR = new C0126d();

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        int i2;
        parcel.writeValue(getValue());
        rr4 rr4Var = rr4.f37180Y;
        i5a i5aVar = this.f19205i;
        if (ul5.m18482l(i5aVar, rr4Var)) {
            i2 = 0;
        } else if (ul5.m18482l(i5aVar, mp8.f28796R)) {
            i2 = 1;
        } else {
            if (!ul5.m18482l(i5aVar, rr4.f37183b0)) {
                C1521v3.m18909p("Only known types of MutableState's SnapshotMutationPolicy are supported");
                return;
            }
            i2 = 2;
        }
        parcel.writeInt(i2);
    }
}
