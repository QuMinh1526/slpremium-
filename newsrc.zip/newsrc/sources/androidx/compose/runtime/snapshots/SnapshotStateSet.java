package androidx.compose.runtime.snapshots;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import com.squareup.picasso.BuildConfig;
import java.util.Collection;
import java.util.Iterator;
import java.util.RandomAccess;
import java.util.Set;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import p000.C1521v3;
import p000.kp1;
import p000.o4a;
import p000.p6c;
import p000.pba;
import p000.px7;
import p000.qx7;
import p000.rba;
import p000.uba;
import p000.v4a;
import p000.vba;
import p000.xr3;
import p000.yd0;
import p000.zs5;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010#\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u00022\u00020\u00032\b\u0012\u0004\u0012\u00028\u00000\u00042\u00060\u0005j\u0002`\u0006¨\u0006\u0007"}, m12198d2 = {"Landroidx/compose/runtime/snapshots/SnapshotStateSet;", "T", "Landroid/os/Parcelable;", "Lpba;", BuildConfig.VERSION_NAME, "Ljava/util/RandomAccess;", "Lkotlin/collections/RandomAccess;", "runtime"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
@SuppressLint({"BanParcelableUsage"})
public final class SnapshotStateSet<T> implements Parcelable, pba, Set<T>, RandomAccess, zs5 {

    @NotNull
    public static final Parcelable.Creator<SnapshotStateSet<Object>> CREATOR = new xr3(3);

    /* JADX INFO: renamed from: e */
    public vba f1169e;

    @Override // java.util.Set, java.util.Collection
    public final boolean add(Object obj) {
        int i;
        px7 px7Var;
        o4a o4aVarM18935j;
        boolean zM20501E;
        do {
            synchronized (yd0.f48580Z) {
                vba vbaVar = this.f1169e;
                vbaVar.getClass();
                vba vbaVar2 = (vba) v4a.m18933h(vbaVar);
                i = vbaVar2.f43539d;
                px7Var = vbaVar2.f43538c;
            }
            px7Var.getClass();
            px7 px7VarM15636f = px7Var.m15636f(obj);
            if (px7VarM15636f.equals(px7Var)) {
                return false;
            }
            vba vbaVar3 = this.f1169e;
            vbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM20501E = yd0.m20501E((vba) v4a.m18948w(vbaVar3, this, o4aVarM18935j), i, px7VarM15636f);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM20501E);
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean addAll(Collection collection) {
        int i;
        px7 px7Var;
        o4a o4aVarM18935j;
        boolean zM20501E;
        do {
            synchronized (yd0.f48580Z) {
                vba vbaVar = this.f1169e;
                vbaVar.getClass();
                vba vbaVar2 = (vba) v4a.m18933h(vbaVar);
                i = vbaVar2.f43539d;
                px7Var = vbaVar2.f43538c;
            }
            px7Var.getClass();
            qx7 qx7Var = new qx7(px7Var);
            qx7Var.addAll(collection);
            px7 px7VarM16150f = qx7Var.m16150f();
            if (px7VarM16150f.equals(px7Var)) {
                return false;
            }
            vba vbaVar3 = this.f1169e;
            vbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM20501E = yd0.m20501E((vba) v4a.m18948w(vbaVar3, this, o4aVarM18935j), i, px7VarM16150f);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM20501E);
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final void clear() {
        o4a o4aVarM18935j;
        vba vbaVar = this.f1169e;
        vbaVar.getClass();
        synchronized (v4a.f43127c) {
            o4aVarM18935j = v4a.m18935j();
            vba vbaVar2 = (vba) v4a.m18948w(vbaVar, this, o4aVarM18935j);
            synchronized (yd0.f48580Z) {
                vbaVar2.f43538c = px7.f34034z;
                vbaVar2.f43539d++;
            }
        }
        v4a.m18939n(o4aVarM18935j, this);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean contains(Object obj) {
        return yd0.m20504J(this).f43538c.contains(obj);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean containsAll(Collection collection) {
        return yd0.m20504J(this).f43538c.containsAll(collection);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // p000.pba
    /* JADX INFO: renamed from: e */
    public final rba mo141e() {
        return this.f1169e;
    }

    @Override // p000.pba
    /* JADX INFO: renamed from: g */
    public final void mo143g(rba rbaVar) {
        rbaVar.f36345b = this.f1169e;
        this.f1169e = (vba) rbaVar;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean isEmpty() {
        return yd0.m20504J(this).f43538c.isEmpty();
    }

    @Override // java.util.Set, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        return new uba(this, yd0.m20504J(this).f43538c.iterator());
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean remove(Object obj) {
        int i;
        px7 px7Var;
        o4a o4aVarM18935j;
        boolean zM20501E;
        do {
            synchronized (yd0.f48580Z) {
                vba vbaVar = this.f1169e;
                vbaVar.getClass();
                vba vbaVar2 = (vba) v4a.m18933h(vbaVar);
                i = vbaVar2.f43539d;
                px7Var = vbaVar2.f43538c;
            }
            px7Var.getClass();
            px7 px7VarM15637g = px7Var.m15637g(obj);
            if (px7VarM15637g.equals(px7Var)) {
                return false;
            }
            vba vbaVar3 = this.f1169e;
            vbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM20501E = yd0.m20501E((vba) v4a.m18948w(vbaVar3, this, o4aVarM18935j), i, px7VarM15637g);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM20501E);
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean removeAll(Collection collection) {
        int i;
        px7 px7Var;
        o4a o4aVarM18935j;
        boolean zM20501E;
        do {
            synchronized (yd0.f48580Z) {
                vba vbaVar = this.f1169e;
                vbaVar.getClass();
                vba vbaVar2 = (vba) v4a.m18933h(vbaVar);
                i = vbaVar2.f43539d;
                px7Var = vbaVar2.f43538c;
            }
            px7Var.getClass();
            qx7 qx7Var = new qx7(px7Var);
            qx7Var.removeAll(collection);
            px7 px7VarM16150f = qx7Var.m16150f();
            if (px7VarM16150f.equals(px7Var)) {
                return false;
            }
            vba vbaVar3 = this.f1169e;
            vbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM20501E = yd0.m20501E((vba) v4a.m18948w(vbaVar3, this, o4aVarM18935j), i, px7VarM16150f);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM20501E);
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean retainAll(Collection collection) {
        int i;
        px7 px7Var;
        boolean zRetainAll;
        o4a o4aVarM18935j;
        boolean zM20501E;
        do {
            synchronized (yd0.f48580Z) {
                vba vbaVar = this.f1169e;
                vbaVar.getClass();
                vba vbaVar2 = (vba) v4a.m18933h(vbaVar);
                i = vbaVar2.f43539d;
                px7Var = vbaVar2.f43538c;
            }
            if (px7Var == null) {
                C1521v3.m18909p("No set to mutate");
                return false;
            }
            qx7 qx7Var = new qx7(px7Var);
            zRetainAll = qx7Var.retainAll(kp1.m12301q1(collection));
            px7 px7VarM16150f = qx7Var.m16150f();
            if (px7VarM16150f.equals(px7Var)) {
                break;
            }
            vba vbaVar3 = this.f1169e;
            vbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM20501E = yd0.m20501E((vba) v4a.m18948w(vbaVar3, this, o4aVarM18935j), i, px7VarM16150f);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM20501E);
        return zRetainAll;
    }

    @Override // java.util.Set, java.util.Collection
    public final int size() {
        return yd0.m20504J(this).f43538c.size();
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray() {
        return p6c.m15177M(this);
    }

    public final String toString() {
        vba vbaVar = this.f1169e;
        vbaVar.getClass();
        return "SnapshotStateSet(value=" + ((vba) v4a.m18933h(vbaVar)).f43538c + ")@" + hashCode();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        px7 px7Var = yd0.m20504J(this).f43538c;
        parcel.writeInt(size());
        Iterator it = px7Var.iterator();
        if (it.hasNext()) {
            parcel.writeValue(it.next());
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        return p6c.m15178N(this, objArr);
    }
}
