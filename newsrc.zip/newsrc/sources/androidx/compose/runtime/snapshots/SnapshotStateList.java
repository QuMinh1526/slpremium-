package androidx.compose.runtime.snapshots;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import com.squareup.picasso.BuildConfig;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import p000.AbstractC1340r2;
import p000.C1303q2;
import p000.gba;
import p000.hfa;
import p000.id3;
import p000.l5a;
import p000.lba;
import p000.m2a;
import p000.ns5;
import p000.o4a;
import p000.p6c;
import p000.p98;
import p000.pba;
import p000.rba;
import p000.tx7;
import p000.ul5;
import p000.v4a;
import p000.yn4;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u00022\u00020\u00032\b\u0012\u0004\u0012\u00028\u00000\u00042\u00060\u0005j\u0002`\u0006¨\u0006\u0007"}, m12198d2 = {"Landroidx/compose/runtime/snapshots/SnapshotStateList;", "T", "Landroid/os/Parcelable;", "Lpba;", BuildConfig.VERSION_NAME, "Ljava/util/RandomAccess;", "Lkotlin/collections/RandomAccess;", "runtime"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
@SuppressLint({"BanParcelableUsage"})
public final class SnapshotStateList<T> implements Parcelable, pba, List<T>, RandomAccess, ns5 {

    @NotNull
    public static final Parcelable.Creator<SnapshotStateList<Object>> CREATOR = new l5a(0);

    /* JADX INFO: renamed from: e */
    public lba f1168e;

    public SnapshotStateList(AbstractC1340r2 abstractC1340r2) {
        o4a o4aVarM18935j = v4a.m18935j();
        lba lbaVar = new lba(o4aVarM18935j.mo9729g(), abstractC1340r2);
        if (!(o4aVarM18935j instanceof yn4)) {
            lbaVar.f36345b = new lba(1L, abstractC1340r2);
        }
        this.f1168e = lbaVar;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean add(Object obj) {
        int i;
        AbstractC1340r2 abstractC1340r2;
        o4a o4aVarM18935j;
        boolean zM15189k;
        do {
            synchronized (p6c.f32831e) {
                lba lbaVar = this.f1168e;
                lbaVar.getClass();
                lba lbaVar2 = (lba) v4a.m18933h(lbaVar);
                i = lbaVar2.f26417d;
                abstractC1340r2 = lbaVar2.f26416c;
            }
            abstractC1340r2.getClass();
            AbstractC1340r2 abstractC1340r2Mo13328g = abstractC1340r2.mo13328g(obj);
            if (abstractC1340r2Mo13328g.equals(abstractC1340r2)) {
                return false;
            }
            lba lbaVar3 = this.f1168e;
            lbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM15189k = p6c.m15189k((lba) v4a.m18948w(lbaVar3, this, o4aVarM18935j), i, abstractC1340r2Mo13328g, true);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM15189k);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean addAll(Collection collection) {
        int i;
        AbstractC1340r2 abstractC1340r2;
        o4a o4aVarM18935j;
        boolean zM15189k;
        do {
            synchronized (p6c.f32831e) {
                lba lbaVar = this.f1168e;
                lbaVar.getClass();
                lba lbaVar2 = (lba) v4a.m18933h(lbaVar);
                i = lbaVar2.f26417d;
                abstractC1340r2 = lbaVar2.f26416c;
            }
            abstractC1340r2.getClass();
            AbstractC1340r2 abstractC1340r2Mo13329i = abstractC1340r2.mo13329i(collection);
            if (ul5.m18482l(abstractC1340r2Mo13329i, abstractC1340r2)) {
                return false;
            }
            lba lbaVar3 = this.f1168e;
            lbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM15189k = p6c.m15189k((lba) v4a.m18948w(lbaVar3, this, o4aVarM18935j), i, abstractC1340r2Mo13329i, true);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM15189k);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public final void clear() {
        o4a o4aVarM18935j;
        lba lbaVar = this.f1168e;
        lbaVar.getClass();
        synchronized (v4a.f43127c) {
            o4aVarM18935j = v4a.m18935j();
            lba lbaVar2 = (lba) v4a.m18948w(lbaVar, this, o4aVarM18935j);
            synchronized (p6c.f32831e) {
                lbaVar2.f26416c = m2a.f27629i;
                lbaVar2.f26417d++;
                lbaVar2.f26418e++;
            }
        }
        v4a.m18939n(o4aVarM18935j, this);
    }

    @Override // java.util.List, java.util.Collection
    public final boolean contains(Object obj) {
        return p6c.m15169E(this).f26416c.contains(obj);
    }

    @Override // java.util.List, java.util.Collection
    public final boolean containsAll(Collection collection) {
        return p6c.m15169E(this).f26416c.containsAll(collection);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // p000.pba
    /* JADX INFO: renamed from: e */
    public final rba mo141e() {
        return this.f1168e;
    }

    @Override // p000.pba
    /* JADX INFO: renamed from: g */
    public final void mo143g(rba rbaVar) {
        rbaVar.f36345b = this.f1168e;
        this.f1168e = (lba) rbaVar;
    }

    @Override // java.util.List
    public final Object get(int i) {
        return p6c.m15169E(this).f26416c.get(i);
    }

    /* JADX INFO: renamed from: i */
    public final void m810i(int i, int i2) {
        int i3;
        AbstractC1340r2 abstractC1340r2;
        o4a o4aVarM18935j;
        boolean zM15189k;
        do {
            synchronized (p6c.f32831e) {
                lba lbaVar = this.f1168e;
                lbaVar.getClass();
                lba lbaVar2 = (lba) v4a.m18933h(lbaVar);
                i3 = lbaVar2.f26417d;
                abstractC1340r2 = lbaVar2.f26416c;
            }
            abstractC1340r2.getClass();
            tx7 tx7VarMo13330k = abstractC1340r2.mo13330k();
            tx7VarMo13330k.subList(i, i2).clear();
            AbstractC1340r2 abstractC1340r2M17985g = tx7VarMo13330k.m17985g();
            if (ul5.m18482l(abstractC1340r2M17985g, abstractC1340r2)) {
                return;
            }
            lba lbaVar3 = this.f1168e;
            lbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM15189k = p6c.m15189k((lba) v4a.m18948w(lbaVar3, this, o4aVarM18935j), i3, abstractC1340r2M17985g, true);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM15189k);
    }

    @Override // java.util.List
    public final int indexOf(Object obj) {
        return p6c.m15169E(this).f26416c.indexOf(obj);
    }

    @Override // java.util.List, java.util.Collection
    public final boolean isEmpty() {
        return p6c.m15169E(this).f26416c.isEmpty();
    }

    @Override // java.util.List, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        return listIterator();
    }

    @Override // java.util.List
    public final int lastIndexOf(Object obj) {
        return p6c.m15169E(this).f26416c.lastIndexOf(obj);
    }

    @Override // java.util.List
    public final ListIterator listIterator() {
        return new gba(this, 0);
    }

    @Override // java.util.List, java.util.Collection
    public final boolean remove(Object obj) {
        int i;
        AbstractC1340r2 abstractC1340r2;
        o4a o4aVarM18935j;
        boolean zM15189k;
        do {
            synchronized (p6c.f32831e) {
                lba lbaVar = this.f1168e;
                lbaVar.getClass();
                lba lbaVar2 = (lba) v4a.m18933h(lbaVar);
                i = lbaVar2.f26417d;
                abstractC1340r2 = lbaVar2.f26416c;
            }
            abstractC1340r2.getClass();
            int iIndexOf = abstractC1340r2.indexOf(obj);
            AbstractC1340r2 abstractC1340r2Mo13332n = iIndexOf != -1 ? abstractC1340r2.mo13332n(iIndexOf) : abstractC1340r2;
            if (abstractC1340r2Mo13332n.equals(abstractC1340r2)) {
                return false;
            }
            lba lbaVar3 = this.f1168e;
            lbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM15189k = p6c.m15189k((lba) v4a.m18948w(lbaVar3, this, o4aVarM18935j), i, abstractC1340r2Mo13332n, true);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM15189k);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean removeAll(Collection collection) {
        int i;
        AbstractC1340r2 abstractC1340r2;
        o4a o4aVarM18935j;
        boolean zM15189k;
        do {
            synchronized (p6c.f32831e) {
                lba lbaVar = this.f1168e;
                lbaVar.getClass();
                lba lbaVar2 = (lba) v4a.m18933h(lbaVar);
                i = lbaVar2.f26417d;
                abstractC1340r2 = lbaVar2.f26416c;
            }
            abstractC1340r2.getClass();
            AbstractC1340r2 abstractC1340r2Mo13331l = abstractC1340r2.mo13331l(new C1303q2(0, collection));
            if (ul5.m18482l(abstractC1340r2Mo13331l, abstractC1340r2)) {
                return false;
            }
            lba lbaVar3 = this.f1168e;
            lbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM15189k = p6c.m15189k((lba) v4a.m18948w(lbaVar3, this, o4aVarM18935j), i, abstractC1340r2Mo13331l, true);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM15189k);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean retainAll(Collection collection) {
        return p6c.m15175K(this, new C1303q2(2, collection));
    }

    @Override // java.util.List
    public final Object set(int i, Object obj) {
        int i2;
        AbstractC1340r2 abstractC1340r2;
        o4a o4aVarM18935j;
        boolean zM15189k;
        Object obj2 = get(i);
        do {
            synchronized (p6c.f32831e) {
                lba lbaVar = this.f1168e;
                lbaVar.getClass();
                lba lbaVar2 = (lba) v4a.m18933h(lbaVar);
                i2 = lbaVar2.f26417d;
                abstractC1340r2 = lbaVar2.f26416c;
            }
            abstractC1340r2.getClass();
            AbstractC1340r2 abstractC1340r2Mo13333o = abstractC1340r2.mo13333o(i, obj);
            if (abstractC1340r2Mo13333o.equals(abstractC1340r2)) {
                break;
            }
            lba lbaVar3 = this.f1168e;
            lbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM15189k = p6c.m15189k((lba) v4a.m18948w(lbaVar3, this, o4aVarM18935j), i2, abstractC1340r2Mo13333o, false);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM15189k);
        return obj2;
    }

    @Override // java.util.List, java.util.Collection
    public final int size() {
        return p6c.m15169E(this).f26416c.mo588e();
    }

    @Override // java.util.List
    public final List subList(int i, int i2) {
        if (!(i >= 0 && i <= i2 && i2 <= size())) {
            p98.m15244a("fromIndex or toIndex are out of bounds");
        }
        return new hfa(this, i, i2);
    }

    @Override // java.util.List, java.util.Collection
    public final Object[] toArray() {
        return p6c.m15177M(this);
    }

    public final String toString() {
        lba lbaVar = this.f1168e;
        lbaVar.getClass();
        return "SnapshotStateList(value=" + ((lba) v4a.m18933h(lbaVar)).f26416c + ")@" + hashCode();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        AbstractC1340r2 abstractC1340r2 = p6c.m15169E(this).f26416c;
        int iMo588e = abstractC1340r2.mo588e();
        parcel.writeInt(iMo588e);
        for (int i2 = 0; i2 < iMo588e; i2++) {
            parcel.writeValue(abstractC1340r2.get(i2));
        }
    }

    @Override // java.util.List, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        return p6c.m15178N(this, objArr);
    }

    @Override // java.util.List
    public final ListIterator listIterator(int i) {
        return new gba(this, i);
    }

    public SnapshotStateList() {
        this(m2a.f27629i);
    }

    @Override // java.util.List
    public final void add(int i, Object obj) {
        int i2;
        AbstractC1340r2 abstractC1340r2;
        o4a o4aVarM18935j;
        boolean zM15189k;
        do {
            synchronized (p6c.f32831e) {
                lba lbaVar = this.f1168e;
                lbaVar.getClass();
                lba lbaVar2 = (lba) v4a.m18933h(lbaVar);
                i2 = lbaVar2.f26417d;
                abstractC1340r2 = lbaVar2.f26416c;
            }
            abstractC1340r2.getClass();
            AbstractC1340r2 abstractC1340r2Mo13327f = abstractC1340r2.mo13327f(i, obj);
            if (abstractC1340r2Mo13327f.equals(abstractC1340r2)) {
                return;
            }
            lba lbaVar3 = this.f1168e;
            lbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM15189k = p6c.m15189k((lba) v4a.m18948w(lbaVar3, this, o4aVarM18935j), i2, abstractC1340r2Mo13327f, true);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM15189k);
    }

    @Override // java.util.List
    public final boolean addAll(int i, Collection collection) {
        return p6c.m15175K(this, new id3(i, collection, 6));
    }

    @Override // java.util.List
    public final Object remove(int i) {
        int i2;
        AbstractC1340r2 abstractC1340r2;
        o4a o4aVarM18935j;
        boolean zM15189k;
        Object obj = get(i);
        do {
            synchronized (p6c.f32831e) {
                lba lbaVar = this.f1168e;
                lbaVar.getClass();
                lba lbaVar2 = (lba) v4a.m18933h(lbaVar);
                i2 = lbaVar2.f26417d;
                abstractC1340r2 = lbaVar2.f26416c;
            }
            abstractC1340r2.getClass();
            AbstractC1340r2 abstractC1340r2Mo13332n = abstractC1340r2.mo13332n(i);
            if (abstractC1340r2Mo13332n.equals(abstractC1340r2)) {
                break;
            }
            lba lbaVar3 = this.f1168e;
            lbaVar3.getClass();
            synchronized (v4a.f43127c) {
                o4aVarM18935j = v4a.m18935j();
                zM15189k = p6c.m15189k((lba) v4a.m18948w(lbaVar3, this, o4aVarM18935j), i2, abstractC1340r2Mo13332n, true);
            }
            v4a.m18939n(o4aVarM18935j, this);
        } while (!zM15189k);
        return obj;
    }
}
