package androidx.compose.runtime;

import p000.f86;
import p000.fl8;
import p000.gca;
import p000.h5a;
import p000.i5a;
import p000.jg3;
import p000.lj4;
import p000.mp8;
import p000.q8b;
import p000.ul5;
import p000.wz1;

/* JADX INFO: renamed from: androidx.compose.runtime.f */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0128f {

    /* JADX INFO: renamed from: a */
    public final f86 f1167a;

    public AbstractC0128f(lj4 lj4Var) {
        this.f1167a = new f86(lj4Var);
    }

    /* JADX INFO: renamed from: a */
    public abstract fl8 mo807a(Object obj);

    /* JADX INFO: renamed from: b */
    public q8b mo808b() {
        return this.f1167a;
    }

    /* JADX INFO: renamed from: c */
    public final q8b m809c(fl8 fl8Var, q8b q8bVar) {
        jg3 jg3Var;
        q8b q8bVar2 = null;
        q8bVar2 = null;
        q8bVar2 = null;
        q8bVar2 = null;
        q8bVar2 = null;
        q8bVar2 = null;
        if (q8bVar instanceof jg3) {
            if (fl8Var.f14430d) {
                jg3Var = (jg3) q8bVar;
                ((h5a) jg3Var.f23029a).setValue(fl8Var.m8158a());
            }
        } else if (q8bVar instanceof gca) {
            if ((fl8Var.f14428b || fl8Var.f14431e != null) && !fl8Var.f14430d) {
                gca gcaVar = (gca) q8bVar;
                if (ul5.m18482l(fl8Var.m8158a(), gcaVar.f15644a)) {
                    q8bVar2 = gcaVar;
                }
            }
        } else if (q8bVar instanceof wz1) {
            fl8Var.getClass();
        }
        if (q8bVar2 != null) {
            q8bVar2 = jg3Var;
            return q8bVar2;
        }
        if (!fl8Var.f14430d) {
            q8bVar2 = jg3Var;
            return new gca(fl8Var.m8158a());
        }
        Object obj = fl8Var.f14431e;
        i5a i5aVar = fl8Var.f14429c;
        if (i5aVar == null) {
            q8bVar2 = jg3Var;
            i5aVar = mp8.f28796R;
        }
        q8bVar2 = jg3Var;
        return new jg3(new ParcelableSnapshotMutableState(obj, i5aVar));
    }
}
