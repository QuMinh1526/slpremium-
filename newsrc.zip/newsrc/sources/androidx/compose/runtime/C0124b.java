package androidx.compose.runtime;

import android.os.Parcel;
import android.os.Parcelable;
import p000.o4a;
import p000.v4a;
import p000.x4a;
import p000.yn4;

/* JADX INFO: renamed from: androidx.compose.runtime.b */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public final class C0124b implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        double d = parcel.readDouble();
        ParcelableSnapshotMutableDoubleState parcelableSnapshotMutableDoubleState = new ParcelableSnapshotMutableDoubleState();
        o4a o4aVarM18935j = v4a.m18935j();
        x4a x4aVar = new x4a(o4aVarM18935j.mo9729g(), d);
        if (!(o4aVarM18935j instanceof yn4)) {
            x4aVar.f36345b = new x4a(1L, d);
        }
        parcelableSnapshotMutableDoubleState.f48127i = x4aVar;
        return parcelableSnapshotMutableDoubleState;
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i) {
        return new ParcelableSnapshotMutableDoubleState[i];
    }
}
