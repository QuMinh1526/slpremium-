package androidx.compose.runtime;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import p000.C0509fx;
import p000.as8;
import p000.bk4;
import p000.by9;
import p000.c92;
import p000.cx7;
import p000.dd1;
import p000.ez1;
import p000.gz1;
import p000.h5a;
import p000.hz6;
import p000.lz6;
import p000.oz1;
import p000.rr4;
import p000.un4;
import p000.xw6;
import p000.yw6;
import p000.zy1;
import p000.zza;

/* JADX INFO: renamed from: androidx.compose.runtime.a */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public final class C0123a extends gz1 {

    /* JADX INFO: renamed from: a */
    public final long f1159a;

    /* JADX INFO: renamed from: b */
    public final boolean f1160b;

    /* JADX INFO: renamed from: c */
    public final boolean f1161c;

    /* JADX INFO: renamed from: d */
    public HashSet f1162d;

    /* JADX INFO: renamed from: e */
    public final LinkedHashSet f1163e = new LinkedHashSet();

    /* JADX INFO: renamed from: f */
    public final lz6 f1164f = new ParcelableSnapshotMutableState(cx7.f10088z, rr4.f37183b0);

    /* JADX INFO: renamed from: g */
    public final /* synthetic */ zy1 f1165g;

    public C0123a(zy1 zy1Var, long j, boolean z, boolean z2, un4 un4Var) {
        this.f1165g = zy1Var;
        this.f1159a = j;
        this.f1160b = z;
        this.f1161c = z2;
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: a */
    public final void mo768a(oz1 oz1Var, bk4 bk4Var) {
        this.f1165g.f51088b.mo768a(oz1Var, bk4Var);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: b */
    public final hz6 mo769b(oz1 oz1Var, by9 by9Var, bk4 bk4Var) {
        return this.f1165g.f51088b.mo769b(oz1Var, by9Var, bk4Var);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: c */
    public final void mo770c() {
        this.f1165g.f51066A--;
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: d */
    public final boolean mo771d() {
        return this.f1165g.f51088b.mo771d();
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: e */
    public final boolean mo772e() {
        return this.f1160b;
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: f */
    public final boolean mo773f() {
        return this.f1161c;
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: g */
    public final long mo774g() {
        return this.f1159a;
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: h */
    public final ez1 mo775h() {
        return this.f1165g.f51094h;
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: i */
    public final cx7 mo776i() {
        return (cx7) ((h5a) this.f1164f).getValue();
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: j */
    public final c92 mo777j() {
        return this.f1165g.f51088b.mo777j();
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: k */
    public final boolean mo778k() {
        return this.f1165g.f51088b.mo778k();
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: l */
    public final void mo779l(oz1 oz1Var) {
        zy1 zy1Var = this.f1165g;
        zy1Var.f51088b.mo779l(zy1Var.f51094h);
        zy1Var.f51088b.mo779l(oz1Var);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: m */
    public final xw6 mo780m(yw6 yw6Var) {
        return this.f1165g.f51088b.mo780m(yw6Var);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: n */
    public final hz6 mo781n(oz1 oz1Var, by9 by9Var, hz6 hz6Var) {
        return this.f1165g.f51088b.mo781n(oz1Var, by9Var, hz6Var);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: o */
    public final void mo782o(Set set) {
        HashSet hashSet = this.f1162d;
        if (hashSet == null) {
            hashSet = new HashSet();
            this.f1162d = hashSet;
        }
        hashSet.add(set);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: p */
    public final void mo783p(zy1 zy1Var) {
        this.f1163e.add(zy1Var);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: q */
    public final void mo784q(as8 as8Var) {
        this.f1165g.f51088b.mo784q(as8Var);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: r */
    public final void mo785r(oz1 oz1Var) {
        this.f1165g.f51088b.mo785r(oz1Var);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: s */
    public final dd1 mo786s(C0509fx c0509fx) {
        return this.f1165g.f51088b.mo786s(c0509fx);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: t */
    public final void mo787t() {
        this.f1165g.f51066A++;
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: u */
    public final void mo788u(zy1 zy1Var) {
        HashSet<Set> hashSet = this.f1162d;
        if (hashSet != null) {
            for (Set set : hashSet) {
                zy1Var.getClass();
                set.remove(zy1Var.m21651w());
            }
        }
        zza.m21698m(this.f1163e).remove(zy1Var);
    }

    @Override // p000.gz1
    /* JADX INFO: renamed from: v */
    public final void mo789v(oz1 oz1Var) {
        this.f1165g.f51088b.mo789v(oz1Var);
    }

    /* JADX INFO: renamed from: w */
    public final void m790w() {
        LinkedHashSet<zy1> linkedHashSet = this.f1163e;
        if (linkedHashSet.isEmpty()) {
            return;
        }
        HashSet hashSet = this.f1162d;
        if (hashSet != null) {
            for (zy1 zy1Var : linkedHashSet) {
                Iterator it = hashSet.iterator();
                while (it.hasNext()) {
                    ((Set) it.next()).remove(zy1Var.m21651w());
                }
            }
        }
        linkedHashSet.clear();
    }
}
