package androidx.compose.runtime;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import p000.d5a;
import p000.e5a;
import p000.o4a;
import p000.v4a;
import p000.yn4;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0003\u0018\u00002\u00020\u00012\u00020\u0002¨\u0006\u0003"}, m12198d2 = {"Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;", "Le5a;", "Landroid/os/Parcelable;", "runtime"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
@SuppressLint({"BanParcelableUsage"})
final class ParcelableSnapshotMutableLongState extends e5a implements Parcelable {

    @NotNull
    public static final Parcelable.Creator<ParcelableSnapshotMutableLongState> CREATOR = new C0125c(2);

    public ParcelableSnapshotMutableLongState(long j) {
        o4a o4aVarM18935j = v4a.m18935j();
        d5a d5aVar = new d5a(o4aVarM18935j.mo9729g(), j);
        if (!(o4aVarM18935j instanceof yn4)) {
            d5aVar.f36345b = new d5a(1L, j);
        }
        this.f11966i = d5aVar;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(m7280h());
    }
}
