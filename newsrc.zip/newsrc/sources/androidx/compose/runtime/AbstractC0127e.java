package androidx.compose.runtime;

import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.StateFlow;
import p000.C1327qq;
import p000.a5a;
import p000.a5b;
import p000.bk4;
import p000.c5a;
import p000.c92;
import p000.cf9;
import p000.e5a;
import p000.gp2;
import p000.h72;
import p000.hi0;
import p000.i5a;
import p000.j5a;
import p000.k5a;
import p000.lj4;
import p000.lz6;
import p000.mp8;
import p000.oz6;
import p000.pq9;
import p000.sb0;
import p000.uy1;
import p000.vh3;
import p000.vj3;
import p000.yy1;
import p000.z1b;
import p000.zy1;

/* JADX INFO: renamed from: androidx.compose.runtime.e */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0127e {
    /* JADX INFO: renamed from: a */
    public static final lz6 m792a(Flow flow, Object obj, c92 c92Var, zy1 zy1Var, int i, int i2) {
        if ((i2 & 2) != 0) {
            c92Var = vj3.f43864e;
        }
        Object obj2 = c92Var;
        boolean zM21632h = zy1Var.m21632h(obj2) | zy1Var.m21632h(flow);
        Object objM21604L = zy1Var.m21604L();
        if (zM21632h || objM21604L == uy1.f42791a) {
            objM21604L = new C1327qq(obj2, flow, (h72) null, 27);
            zy1Var.m21633h0(objM21604L);
        }
        return m804m(obj, flow, obj2, (bk4) objM21604L, zy1Var, ((i >> 3) & 14) | ((i << 3) & 112) | (i & 896));
    }

    /* JADX INFO: renamed from: b */
    public static final lz6 m793b(StateFlow stateFlow, zy1 zy1Var, int i) {
        return m792a(stateFlow, stateFlow.getValue(), vj3.f43864e, zy1Var, (i & 14) | ((i << 3) & 896), 0);
    }

    /* JADX INFO: renamed from: c */
    public static final oz6 m794c() {
        sb0 sb0Var = j5a.f22494b;
        oz6 oz6Var = (oz6) sb0Var.m16919m();
        if (oz6Var != null) {
            return oz6Var;
        }
        oz6 oz6Var2 = new oz6(new yy1[0]);
        sb0Var.m16905O(oz6Var2);
        return oz6Var2;
    }

    /* JADX INFO: renamed from: d */
    public static final gp2 m795d(lj4 lj4Var) {
        sb0 sb0Var = j5a.f22493a;
        return new gp2(lj4Var, null);
    }

    /* JADX INFO: renamed from: e */
    public static final gp2 m796e(lj4 lj4Var, i5a i5aVar) {
        sb0 sb0Var = j5a.f22493a;
        return new gp2(lj4Var, i5aVar);
    }

    /* JADX INFO: renamed from: f */
    public static final a5a m797f(float f) {
        return new ParcelableSnapshotMutableFloatState(f);
    }

    /* JADX INFO: renamed from: g */
    public static final c5a m798g(int i) {
        return new ParcelableSnapshotMutableIntState(i);
    }

    /* JADX INFO: renamed from: h */
    public static final e5a m799h(long j) {
        return new ParcelableSnapshotMutableLongState(j);
    }

    /* JADX INFO: renamed from: i */
    public static final lz6 m800i(Object obj, i5a i5aVar) {
        return new ParcelableSnapshotMutableState(obj, i5aVar);
    }

    /* JADX INFO: renamed from: j */
    public static lz6 m801j(Object obj) {
        return new ParcelableSnapshotMutableState(obj, mp8.f28796R);
    }

    /* JADX INFO: renamed from: k */
    public static final lz6 m802k(zy1 zy1Var, bk4 bk4Var, Object obj) {
        Object objM21604L = zy1Var.m21604L();
        hi0 hi0Var = uy1.f42791a;
        if (objM21604L == hi0Var) {
            objM21604L = m801j(obj);
            zy1Var.m21633h0(objM21604L);
        }
        lz6 lz6Var = (lz6) objM21604L;
        boolean zM21632h = zy1Var.m21632h(bk4Var);
        Object objM21604L2 = zy1Var.m21604L();
        if (zM21632h || objM21604L2 == hi0Var) {
            objM21604L2 = new k5a(bk4Var, lz6Var, null, 0);
            zy1Var.m21633h0(objM21604L2);
        }
        vh3.m19102d(zy1Var, (bk4) objM21604L2, a5b.f278a);
        return lz6Var;
    }

    /* JADX INFO: renamed from: l */
    public static final lz6 m803l(z1b z1bVar, Object obj, bk4 bk4Var, zy1 zy1Var, int i) {
        Object objM21604L = zy1Var.m21604L();
        hi0 hi0Var = uy1.f42791a;
        if (objM21604L == hi0Var) {
            objM21604L = m801j(z1bVar);
            zy1Var.m21633h0(objM21604L);
        }
        lz6 lz6Var = (lz6) objM21604L;
        boolean zM21632h = zy1Var.m21632h(bk4Var);
        Object objM21604L2 = zy1Var.m21604L();
        if (zM21632h || objM21604L2 == hi0Var) {
            objM21604L2 = new cf9(bk4Var, lz6Var, (h72) null);
            zy1Var.m21633h0(objM21604L2);
        }
        vh3.m19102d(zy1Var, (bk4) objM21604L2, obj);
        return lz6Var;
    }

    /* JADX INFO: renamed from: m */
    public static final lz6 m804m(Object obj, Object obj2, Object obj3, bk4 bk4Var, zy1 zy1Var, int i) {
        Object objM21604L = zy1Var.m21604L();
        hi0 hi0Var = uy1.f42791a;
        if (objM21604L == hi0Var) {
            objM21604L = m801j(obj);
            zy1Var.m21633h0(objM21604L);
        }
        lz6 lz6Var = (lz6) objM21604L;
        boolean zM21632h = zy1Var.m21632h(bk4Var);
        Object objM21604L2 = zy1Var.m21604L();
        if (zM21632h || objM21604L2 == hi0Var) {
            objM21604L2 = new k5a(bk4Var, lz6Var, null, 1);
            zy1Var.m21633h0(objM21604L2);
        }
        vh3.m19103e(obj2, obj3, (bk4) objM21604L2, zy1Var);
        return lz6Var;
    }

    /* JADX INFO: renamed from: n */
    public static final lz6 m805n(Object obj, zy1 zy1Var) {
        Object objM21604L = zy1Var.m21604L();
        if (objM21604L == uy1.f42791a) {
            objM21604L = m801j(obj);
            zy1Var.m21633h0(objM21604L);
        }
        lz6 lz6Var = (lz6) objM21604L;
        lz6Var.setValue(obj);
        return lz6Var;
    }

    /* JADX INFO: renamed from: o */
    public static final Flow m806o(lj4 lj4Var) {
        return FlowKt.flow(new pq9(lj4Var, null));
    }
}
