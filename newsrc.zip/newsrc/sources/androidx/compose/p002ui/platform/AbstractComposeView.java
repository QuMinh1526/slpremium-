package androidx.compose.p002ui.platform;

import android.content.Context;
import android.os.IBinder;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.compose.runtime.C0123a;
import com.squareup.picasso.BuildConfig;
import ginlemon.flowerfree.R;
import java.lang.ref.WeakReference;
import kotlin.Metadata;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.GlobalScope;
import kotlinx.coroutines.android.HandlerDispatcherKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p000.C0637j0;
import p000.C1298py;
import p000.C1372ry;
import p000.C1521v3;
import p000.ViewOnAttachStateChangeListenerC0762kv;
import p000.a1c;
import p000.aja;
import p000.c1c;
import p000.c92;
import p000.cs8;
import p000.fs8;
import p000.gz1;
import p000.kh5;
import p000.m4c;
import p000.m91;
import p000.mp8;
import p000.mt8;
import p000.o28;
import p000.o96;
import p000.p4c;
import p000.r53;
import p000.rr4;
import p000.sbb;
import p000.uv6;
import p000.v0c;
import p000.vb8;
import p000.vj3;
import p000.vv1;
import p000.vv6;
import p000.w0c;
import p000.x0c;
import p000.x96;
import p000.z18;
import p000.z78;
import p000.zy1;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\b'\u0018\u00002\u00020\u0001B'\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\t¨\u0006\n"}, m12198d2 = {"Landroidx/compose/ui/platform/AbstractComposeView;", "Landroid/view/ViewGroup;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", BuildConfig.VERSION_NAME, "defStyleAttr", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "ui"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public abstract class AbstractComposeView extends ViewGroup {

    /* JADX INFO: renamed from: A */
    public boolean f1170A;

    /* JADX INFO: renamed from: B */
    public boolean f1171B;

    /* JADX INFO: renamed from: e */
    public WeakReference f1172e;

    /* JADX INFO: renamed from: i */
    public IBinder f1173i;

    /* JADX INFO: renamed from: y */
    public m4c f1174y;

    /* JADX INFO: renamed from: z */
    public gz1 f1175z;

    public AbstractComposeView(@NotNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setClipChildren(false);
        setClipToPadding(false);
        setImportantForAccessibility(1);
        addOnAttachStateChangeListener(new ViewOnAttachStateChangeListenerC0762kv(this, 1));
        z78.m21047h(this).f427a.add(new sbb(this));
    }

    /* JADX INFO: renamed from: a */
    public abstract void mo811a(int i, zy1 zy1Var);

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        m812b();
        super.addView(view);
    }

    @Override // android.view.ViewGroup
    public final boolean addViewInLayout(View view, int i, ViewGroup.LayoutParams layoutParams) {
        m812b();
        return super.addViewInLayout(view, i, layoutParams);
    }

    /* JADX INFO: renamed from: b */
    public final void m812b() {
        if (this.f1170A) {
            return;
        }
        throw new UnsupportedOperationException("Cannot add views to " + getClass().getSimpleName() + "; only Compose content is supported");
    }

    /* JADX INFO: renamed from: c */
    public final void m813c() {
        if (this.f1175z != null || isAttachedToWindow()) {
            m815e();
        } else {
            C1521v3.m18909p("createComposition requires either a parent reference or the View to be attachedto a window. Attach the View or call setParentCompositionReference.");
        }
    }

    /* JADX INFO: renamed from: d */
    public final void m814d() {
        m4c m4cVar = this.f1174y;
        if (m4cVar != null) {
            m4cVar.m13347a();
        }
        this.f1174y = null;
        requestLayout();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: e */
    public final void m815e() {
        if (this.f1174y == null) {
            boolean z = false;
            Object[] objArr = 0;
            try {
                this.f1170A = true;
                this.f1174y = p4c.m15147a(this, m819i(), new vv1(new C0637j0((Object) this, (int) (objArr == true ? 1 : 0)), true, -656146368));
            } finally {
                this.f1170A = false;
            }
        }
    }

    /* JADX INFO: renamed from: f */
    public boolean getF1177D() {
        return true;
    }

    /* JADX INFO: renamed from: g */
    public void mo817g(boolean z, int i, int i2, int i3, int i4) {
        View childAt = getChildAt(0);
        if (childAt != null) {
            childAt.layout(getPaddingLeft(), getPaddingTop(), (i3 - i) - getPaddingRight(), (i4 - i2) - getPaddingBottom());
        }
    }

    /* JADX INFO: renamed from: h */
    public void mo818h(int i, int i2) {
        View childAt = getChildAt(0);
        if (childAt == null) {
            super.onMeasure(i, i2);
            return;
        }
        childAt.measure(View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - getPaddingLeft()) - getPaddingRight()), View.MeasureSpec.getMode(i)), View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i2) - getPaddingTop()) - getPaddingBottom()), View.MeasureSpec.getMode(i2)));
        setMeasuredDimension(getPaddingRight() + getPaddingLeft() + childAt.getMeasuredWidth(), getPaddingBottom() + getPaddingTop() + childAt.getMeasuredHeight());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: i */
    public final gz1 m819i() {
        fs8 fs8Var;
        c92 c92Var;
        C1372ry c1372ry;
        Object objM20894h;
        gz1 gz1VarM2842b = this.f1175z;
        if (gz1VarM2842b == null) {
            gz1VarM2842b = c1c.m2842b(this);
            if (gz1VarM2842b == null) {
                ViewParent parent = getParent();
                while (true) {
                    if (gz1VarM2842b != null || !(objM20894h instanceof View)) {
                        objM20894h = parent;
                        break;
                    }
                    objM20894h = parent;
                    View view = (View) objM20894h;
                    gz1VarM2842b = c1c.m2842b(view);
                    objM20894h = z18.m20894h(view);
                }
            }
            boolean z = false;
            if (gz1VarM2842b != null) {
                gz1 gz1Var = (!(gz1VarM2842b instanceof fs8) || ((cs8) ((fs8) gz1VarM2842b).f14730u.getValue()).compareTo(cs8.f9869i) > 0) ? gz1VarM2842b : null;
                if (gz1Var != null) {
                    this.f1172e = new WeakReference(gz1Var);
                }
            } else {
                gz1VarM2842b = null;
            }
            if (gz1VarM2842b == null) {
                WeakReference weakReference = this.f1172e;
                if (weakReference == null || (gz1VarM2842b = (gz1) weakReference.get()) == null || ((gz1VarM2842b instanceof fs8) && ((cs8) ((fs8) gz1VarM2842b).f14730u.getValue()).compareTo(cs8.f9869i) <= 0)) {
                    gz1VarM2842b = null;
                }
                if (gz1VarM2842b == null) {
                    if (!isAttachedToWindow()) {
                        kh5.m12062b("Cannot locate windowRecomposer; View " + this + " is not attached to a window");
                    }
                    View view2 = this;
                    Object parent2 = getParent();
                    while (parent2 instanceof View) {
                        View view3 = (View) parent2;
                        if (view3.getId() == 16908290) {
                            break;
                        }
                        view2 = view3;
                        parent2 = view3.getParent();
                    }
                    gz1 gz1VarM2842b2 = c1c.m2842b(view2);
                    if (gz1VarM2842b2 == null) {
                        ((v0c) x0c.f46351a.get()).getClass();
                        c92 c92Var2 = vj3.f43864e;
                        aja ajaVar = C1298py.f34043G;
                        if (Looper.myLooper() == Looper.getMainLooper()) {
                            c92Var = (c92) C1298py.f34043G.getValue();
                        } else {
                            c92Var = (c92) C1298py.f34044H.get();
                            if (c92Var == null) {
                                C1521v3.m18909p("no AndroidUiDispatcher for this thread");
                                return null;
                            }
                        }
                        c92 c92VarPlus = c92Var.plus(c92Var2);
                        C1372ry c1372ry2 = (C1372ry) c92VarPlus.get(rr4.f37179X);
                        if (c1372ry2 != null) {
                            c1372ry = new C1372ry(c1372ry2);
                            m91 m91Var = (m91) c1372ry.f37494y;
                            synchronized (m91Var.f27919b) {
                                m91Var.f27918a = false;
                            }
                        } else {
                            c1372ry = null;
                        }
                        mt8 mt8Var = new mt8();
                        c92 vv6Var = (uv6) c92VarPlus.get(mp8.f28789K);
                        if (vv6Var == null) {
                            vv6Var = new vv6();
                            mt8Var.f29024e = vv6Var;
                        }
                        if (c1372ry != null) {
                            c92Var2 = c1372ry;
                        }
                        c92 c92VarPlus2 = c92VarPlus.plus(c92Var2).plus(vv6Var);
                        fs8Var = new fs8(c92VarPlus2);
                        synchronized (fs8Var.f14712c) {
                            fs8Var.f14729t = true;
                        }
                        CoroutineScope CoroutineScope = CoroutineScopeKt.CoroutineScope(c92VarPlus2);
                        x96 x96VarM14446f = o28.m14446f(view2);
                        o96 lifecycle = x96VarM14446f != null ? x96VarM14446f.getLifecycle() : null;
                        if (lifecycle == null) {
                            kh5.m12063c("ViewTreeLifecycleOwner not found from " + view2);
                            C1521v3.m18913t();
                            return null;
                        }
                        view2.addOnAttachStateChangeListener(new r53(view2, fs8Var, 2));
                        lifecycle.mo244a(new a1c(CoroutineScope, c1372ry, fs8Var, mt8Var, view2));
                        view2.setTag(R.id.androidx_compose_ui_view_composition_context, fs8Var);
                        view2.addOnAttachStateChangeListener(new w0c(BuildersKt__Builders_commonKt.launch$default(GlobalScope.INSTANCE, HandlerDispatcherKt.from(view2.getHandler(), "windowRecomposer cleanup").getImmediate(), null, new vb8(fs8Var, view2, z ? 1 : 0, 10), 2, null)));
                    } else {
                        if (!(gz1VarM2842b2 instanceof fs8)) {
                            C1521v3.m18909p("root viewTreeParentCompositionContext is not a Recomposer");
                            return null;
                        }
                        fs8Var = (fs8) gz1VarM2842b2;
                    }
                    fs8 fs8Var2 = ((cs8) fs8Var.f14730u.getValue()).compareTo(cs8.f9869i) > 0 ? fs8Var : null;
                    if (fs8Var2 != null) {
                        this.f1172e = new WeakReference(fs8Var2);
                    }
                    return fs8Var;
                }
            }
        }
        return gz1VarM2842b;
    }

    @Override // android.view.ViewGroup
    public final boolean isTransitionGroup() {
        return !this.f1171B || super.isTransitionGroup();
    }

    /* JADX INFO: renamed from: j */
    public final void m820j(C0123a c0123a) {
        if (this.f1175z != c0123a) {
            this.f1175z = c0123a;
            if (c0123a != null) {
                this.f1172e = null;
            }
            m4c m4cVar = this.f1174y;
            if (m4cVar != null) {
                m4cVar.m13347a();
                this.f1174y = null;
                if (isAttachedToWindow()) {
                    m815e();
                }
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        IBinder windowToken = getWindowToken();
        if (this.f1173i != windowToken) {
            this.f1173i = windowToken;
            this.f1172e = null;
        }
        if (getF1177D()) {
            m815e();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        mo817g(z, i, i2, i3, i4);
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        m815e();
        mo818h(i, i2);
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
        View childAt = getChildAt(0);
        if (childAt != null) {
            childAt.setLayoutDirection(i);
        }
    }

    @Override // android.view.ViewGroup
    public final void setTransitionGroup(boolean z) {
        super.setTransitionGroup(z);
        this.f1171B = true;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i) {
        m812b();
        super.addView(view, i);
    }

    @Override // android.view.ViewGroup
    public final boolean addViewInLayout(View view, int i, ViewGroup.LayoutParams layoutParams, boolean z) {
        m812b();
        return super.addViewInLayout(view, i, layoutParams, z);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, int i2) {
        m812b();
        super.addView(view, i, i2);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        m812b();
        super.addView(view, layoutParams);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        m812b();
        super.addView(view, i, layoutParams);
    }

    public AbstractComposeView(@NotNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 4, 0);
    }

    public /* synthetic */ AbstractComposeView(Context context, AttributeSet attributeSet, int i, int i2) {
        this(context, (i & 2) != 0 ? null : attributeSet, 0);
    }
}
