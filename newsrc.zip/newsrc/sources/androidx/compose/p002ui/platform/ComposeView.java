package androidx.compose.p002ui.platform;

import android.content.Context;
import android.util.AttributeSet;
import androidx.compose.runtime.AbstractC0127e;
import com.squareup.picasso.BuildConfig;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p000.C0637j0;
import p000.as8;
import p000.bk4;
import p000.h5a;
import p000.lz6;
import p000.zy1;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B'\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\t¨\u0006\n"}, m12198d2 = {"Landroidx/compose/ui/platform/ComposeView;", "Landroidx/compose/ui/platform/AbstractComposeView;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", BuildConfig.VERSION_NAME, "defStyleAttr", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "ui"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public final class ComposeView extends AbstractComposeView {

    /* JADX INFO: renamed from: C */
    public final lz6 f1176C;

    /* JADX INFO: renamed from: D */
    public boolean f1177D;

    public /* synthetic */ ComposeView(Context context, AttributeSet attributeSet, int i, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    @Override // androidx.compose.p002ui.platform.AbstractComposeView
    /* JADX INFO: renamed from: a */
    public final void mo811a(int i, zy1 zy1Var) {
        zy1Var.m21617Z(420213850);
        int i2 = (zy1Var.m21632h(this) ? 4 : 2) | i;
        if (zy1Var.m21606O(i2 & 1, (i2 & 3) != 2)) {
            bk4 bk4Var = (bk4) ((h5a) this.f1176C).getValue();
            if (bk4Var == null) {
                zy1Var.m21615X(-1238823553);
            } else {
                zy1Var.m21615X(98585282);
                bk4Var.invoke(zy1Var, 0);
            }
            zy1Var.m21644p(false);
        } else {
            zy1Var.m21609R();
        }
        as8 as8VarM21646r = zy1Var.m21646r();
        if (as8VarM21646r != null) {
            as8VarM21646r.f2756d = new C0637j0(this, i);
        }
    }

    @Override // androidx.compose.p002ui.platform.AbstractComposeView
    /* JADX INFO: renamed from: f, reason: from getter */
    public final boolean getF1177D() {
        return this.f1177D;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final CharSequence getAccessibilityClassName() {
        return "androidx.compose.ui.platform.ComposeView";
    }

    /* JADX INFO: renamed from: k */
    public final void m821k(bk4 bk4Var) {
        this.f1177D = true;
        ((h5a) this.f1176C).setValue(bk4Var);
        if (isAttachedToWindow()) {
            m813c();
        }
    }

    public ComposeView(@NotNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
    }

    public ComposeView(@NotNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1176C = AbstractC0127e.m801j(null);
    }

    public ComposeView(Context context) {
        this(context, null, 0, 6, null);
    }
}
