package androidx.compose.p002ui.tooling;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import androidx.compose.p002ui.platform.ComposeView;
import com.squareup.picasso.BuildConfig;
import ginlemon.flowerfree.R;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import p000.C0788lk;
import p000.C1269p5;
import p000.C1632y3;
import p000.ae8;
import p000.alc;
import p000.as8;
import p000.b90;
import p000.bcb;
import p000.bf6;
import p000.dca;
import p000.eh4;
import p000.eq2;
import p000.fl8;
import p000.hq4;
import p000.iz1;
import p000.jz1;
import p000.k2a;
import p000.kp1;
import p000.ky1;
import p000.kz1;
import p000.lj4;
import p000.lp1;
import p000.lt1;
import p000.m20;
import p000.m51;
import p000.my1;
import p000.nc4;
import p000.nj4;
import p000.noa;
import p000.nw1;
import p000.nz1;
import p000.oy1;
import p000.py1;
import p000.q20;
import p000.qp1;
import p000.qy1;
import p000.r20;
import p000.ry1;
import p000.s8a;
import p000.sp1;
import p000.sy1;
import p000.sz1;
import p000.tea;
import p000.tj5;
import p000.ud6;
import p000.vv1;
import p000.vz1;
import p000.wj3;
import p000.yj3;
import p000.yw8;
import p000.zg8;
import p000.zy1;
import p000.zza;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\b\u0001\u0018\u00002\u00020\u0001B\u0019\b\u0016\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007B!\b\u0016\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\t\u001a\u00020\b¢\u0006\u0004\b\u0006\u0010\n¨\u0006\u000b"}, m12198d2 = {"Landroidx/compose/ui/tooling/ComposeViewAdapter;", "Landroid/widget/FrameLayout;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", BuildConfig.VERSION_NAME, "defStyleAttr", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "ui-tooling"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public final class ComposeViewAdapter extends FrameLayout {

    /* JADX INFO: renamed from: M */
    public static final /* synthetic */ int f1178M = 0;

    /* JADX INFO: renamed from: A */
    public final kz1 f1179A;

    /* JADX INFO: renamed from: B */
    public String f1180B;

    /* JADX INFO: renamed from: C */
    public final zg8 f1181C;

    /* JADX INFO: renamed from: D */
    public boolean f1182D;

    /* JADX INFO: renamed from: E */
    public String f1183E;

    /* JADX INFO: renamed from: F */
    public lj4 f1184F;

    /* JADX INFO: renamed from: G */
    public final Paint f1185G;

    /* JADX INFO: renamed from: H */
    public ae8 f1186H;

    /* JADX INFO: renamed from: I */
    public final qy1 f1187I;

    /* JADX INFO: renamed from: J */
    public final b90 f1188J;

    /* JADX INFO: renamed from: K */
    public final py1 f1189K;

    /* JADX INFO: renamed from: L */
    public final oy1 f1190L;

    /* JADX INFO: renamed from: e */
    public final ComposeView f1191e;

    /* JADX INFO: renamed from: i */
    public boolean f1192i;

    /* JADX INFO: renamed from: y */
    public boolean f1193y;

    /* JADX INFO: renamed from: z */
    public List f1194z;

    public ComposeViewAdapter(@NotNull Context context, @NotNull AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1191e = new ComposeView(getContext(), null, 0, 6, null);
        this.f1194z = yj3.f48828e;
        this.f1179A = new kz1();
        this.f1180B = BuildConfig.VERSION_NAME;
        this.f1181C = new zg8(16);
        this.f1183E = BuildConfig.VERSION_NAME;
        this.f1184F = new C1269p5(22);
        Paint paint = new Paint();
        paint.setPathEffect(new DashPathEffect(new float[]{5.0f, 10.0f, 15.0f, 20.0f}, 0.0f));
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(alc.m618V(sp1.f38649f));
        this.f1185G = paint;
        this.f1187I = new qy1();
        this.f1188J = new b90(1);
        this.f1189K = new py1(this);
        this.f1190L = new oy1();
        m825d(attributeSet);
    }

    /* JADX INFO: renamed from: c */
    public static boolean m822c(hq4 hq4Var) {
        Collection collection = hq4Var.f20151f;
        if ((collection instanceof Collection) && collection.isEmpty()) {
            return false;
        }
        for (Object obj : collection) {
            Method declaredMethod = null;
            if (obj != null) {
                try {
                    Class<?> cls = obj.getClass();
                    Class cls2 = Integer.TYPE;
                    declaredMethod = cls.getDeclaredMethod("getDesignInfo", cls2, cls2, String.class);
                } catch (NoSuchMethodException unused) {
                }
            }
            if (declaredMethod != null) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: a */
    public final void m823a(vv1 vv1Var, zy1 zy1Var, int i) {
        zy1Var.m21617Z(-265259911);
        int i2 = (zy1Var.m21632h(this) ? 32 : 16) | i;
        if (zy1Var.m21606O(i2 & 1, (i2 & 19) != 18)) {
            dca dcaVar = sz1.f39306j;
            getContext();
            fl8 fl8VarMo807a = dcaVar.mo807a(new eq2(22));
            fl8 fl8VarMo807a2 = sz1.f39307k.mo807a(nc4.m14056a(getContext()));
            vz1 vz1Var = bf6.f3919a;
            fl8 fl8VarMo807a3 = bf6.f3919a.mo807a(this.f1189K);
            vz1 vz1Var2 = ud6.f41820a;
            zza.m21692f(new fl8[]{fl8VarMo807a, fl8VarMo807a2, fl8VarMo807a3, ud6.f41820a.mo807a(this.f1190L)}, m51.m13360K(-874838087, new my1(this, vv1Var), zy1Var), zy1Var, 56);
        } else {
            zy1Var.m21609R();
        }
        as8 as8VarM21646r = zy1Var.m21646r();
        if (as8VarM21646r != null) {
            as8VarM21646r.f2756d = new my1(this, vv1Var, i);
        }
    }

    /* JADX INFO: renamed from: b */
    public final String m824b(hq4 hq4Var, tj5 tj5Var) {
        String str;
        Method declaredMethod;
        Iterator it = hq4Var.f20151f.iterator();
        do {
            str = null;
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            if (next != null) {
                int i = tj5Var.f40340a;
                int i2 = tj5Var.f40342c;
                try {
                    Class<?> cls = next.getClass();
                    Class cls2 = Integer.TYPE;
                    declaredMethod = cls.getDeclaredMethod("getDesignInfo", cls2, cls2, String.class);
                } catch (NoSuchMethodException unused) {
                    declaredMethod = null;
                }
                if (declaredMethod != null) {
                    try {
                        Object objInvoke = declaredMethod.invoke(next, Integer.valueOf(i), Integer.valueOf(i2), this.f1183E);
                        objInvoke.getClass();
                        String str2 = (String) objInvoke;
                        if (str2.length() != 0) {
                            str = str2;
                        }
                    } catch (Exception unused2) {
                    }
                }
            }
        } while (str == null);
        return str;
    }

    /* JADX INFO: renamed from: d */
    public final void m825d(AttributeSet attributeSet) {
        long j;
        Object obj = this.f1187I;
        setTag(R.id.view_tree_lifecycle_owner, obj);
        setTag(R.id.view_tree_saved_state_registry_owner, obj);
        setTag(R.id.view_tree_view_model_store_owner, this.f1188J);
        ComposeView composeView = this.f1191e;
        addView(composeView);
        String attributeValue = attributeSet.getAttributeValue("http://schemas.android.com/tools", "composableName");
        if (attributeValue == null) {
            return;
        }
        String strM17651w0 = tea.m17651w0(attributeValue, '.');
        String strM17647s0 = tea.m17647s0('.', attributeValue, attributeValue);
        int attributeIntValue = attributeSet.getAttributeIntValue("http://schemas.android.com/tools", "parameterProviderIndex", 0);
        String attributeValue2 = attributeSet.getAttributeValue("http://schemas.android.com/tools", "parameterProviderClass");
        Class clsM7486p = attributeValue2 != null ? eh4.m7486p(attributeValue2) : null;
        try {
            j = Long.parseLong(attributeSet.getAttributeValue("http://schemas.android.com/tools", "animationClockStartTime"));
        } catch (Exception unused) {
            j = -1;
        }
        long j2 = j;
        boolean attributeBooleanValue = attributeSet.getAttributeBooleanValue("http://schemas.android.com/tools", "paintBounds", this.f1193y);
        boolean attributeBooleanValue2 = attributeSet.getAttributeBooleanValue("http://schemas.android.com/tools", "printViewInfos", this.f1192i);
        boolean attributeBooleanValue3 = attributeSet.getAttributeBooleanValue("http://schemas.android.com/tools", "findDesignInfoProviders", this.f1182D);
        String attributeValue3 = attributeSet.getAttributeValue("http://schemas.android.com/tools", "designInfoProvidersArgument");
        C1269p5 c1269p5 = new C1269p5(22);
        C1269p5 c1269p6 = new C1269p5(22);
        this.f1193y = attributeBooleanValue;
        this.f1192i = attributeBooleanValue2;
        this.f1180B = strM17647s0;
        this.f1182D = attributeBooleanValue3;
        if (attributeValue3 == null) {
            attributeValue3 = BuildConfig.VERSION_NAME;
        }
        this.f1183E = attributeValue3;
        this.f1184F = c1269p6;
        composeView.m821k(new vv1(new ky1(c1269p5, this, strM17651w0, strM17647s0, clsM7486p, attributeIntValue, j2), true, -658298446));
        invalidate();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        this.f1184F.invoke();
        if (this.f1193y) {
            List<bcb> list = this.f1194z;
            ArrayList<bcb> arrayList = new ArrayList();
            for (bcb bcbVar : list) {
                qp1.m16062h0(arrayList, kp1.m12277V0(zza.m21671N(bcbVar), bcbVar.m2278a()));
            }
            for (bcb bcbVar2 : arrayList) {
                tj5 tj5Var = bcbVar2.f3735c;
                if (tj5Var.f40343d != 0 && tj5Var.f40342c != 0) {
                    tj5 tj5Var2 = bcbVar2.f3735c;
                    canvas.drawRect(new Rect(tj5Var2.f40340a, tj5Var2.f40341b, tj5Var2.f40342c, tj5Var2.f40343d), this.f1185G);
                }
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        View rootView = this.f1191e.getRootView();
        rootView.getClass();
        rootView.setTag(R.id.view_tree_lifecycle_owner, this.f1187I);
        super.onAttachedToWindow();
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        zg8 zg8Var = this.f1181C;
        synchronized (zg8Var.f50306y) {
            Throwable th = (Throwable) zg8Var.f50305i;
            if (th != null) {
                zg8Var.f50305i = null;
                throw th;
            }
        }
        boolean z2 = true;
        C0788lk c0788lk = new C0788lk(this.f1179A.f25603a, new lt1(20), new sy1(4, 0, ComposeViewAdapter.class, this, "toViewInfoFactory", "toViewInfoFactory(Landroidx/compose/runtime/tooling/CompositionGroup;Landroidx/compose/ui/tooling/data/SourceContext;Ljava/util/List;Ljava/util/List;)Landroidx/compose/ui/tooling/ViewInfo;"), new nw1(18), new s8a(1));
        LinkedHashSet linkedHashSet = (LinkedHashSet) c0788lk.f26784B;
        ArrayList arrayList = new ArrayList();
        Iterator it = linkedHashSet.iterator();
        while (it.hasNext()) {
            Object objM13040F = c0788lk.m13040F((jz1) it.next());
            if (objM13040F != null) {
                arrayList.add(objM13040F);
            }
        }
        this.f1194z = arrayList;
        if (this.f1192i) {
            yw8.m20764M(arrayList, 0, new noa(15));
        }
        if (this.f1180B.length() > 0) {
            Set<iz1> set = this.f1179A.f25603a;
            ArrayList<hq4> arrayList2 = new ArrayList(lp1.m13108d0(set, 10));
            for (iz1 iz1Var : set) {
                tj5 tj5Var = k2a.f23983a;
                nz1 nz1Var = (nz1) kp1.m12256A0(iz1Var.mo9817i());
                arrayList2.add(nz1Var != null ? k2a.m11726h(nz1Var, null) : wj3.f45541h);
            }
            boolean z3 = this.f1186H != null;
            r20 r20Var = new r20(new ry1(this, ComposeViewAdapter.class, "clock", "getClock$ui_tooling()Landroidx/compose/ui/tooling/animation/PreviewAnimationClock;", 0), new C1632y3(0, this, ComposeViewAdapter.class, "requestLayout", "requestLayout()V", 0, 4));
            if (arrayList2.isEmpty()) {
                z2 = false;
                break;
            }
            Iterator it2 = arrayList2.iterator();
            loop12: while (true) {
                if (!it2.hasNext()) {
                    z2 = false;
                    break;
                }
                hq4 hq4Var = (hq4) it2.next();
                ArrayList arrayList3 = new ArrayList();
                ArrayList arrayListM21675R = zza.m21675R(hq4Var);
                while (!arrayListM21675R.isEmpty()) {
                    hq4 hq4Var2 = (hq4) qp1.m16067m0(arrayListM21675R);
                    arrayList3.add(hq4Var2);
                    arrayListM21675R.addAll(hq4Var2.f20152g);
                }
                LinkedHashSet<q20> linkedHashSet2 = (LinkedHashSet) r20Var.f35822f;
                if (linkedHashSet2 == null || !linkedHashSet2.isEmpty()) {
                    for (q20 q20Var : linkedHashSet2) {
                        q20Var.getClass();
                        if (!arrayList3.isEmpty()) {
                            Iterator it3 = arrayList3.iterator();
                            while (it3.hasNext()) {
                                if (q20Var.mo13322b((hq4) it3.next())) {
                                    break loop12;
                                }
                            }
                        }
                    }
                }
            }
            if (z3 && z2) {
                m20 m20Var = (m20) r20Var.f35819c;
                for (hq4 hq4Var3 : arrayList2) {
                    ArrayList arrayList4 = new ArrayList();
                    ArrayList arrayListM21675R2 = zza.m21675R(hq4Var3);
                    while (!arrayListM21675R2.isEmpty()) {
                        hq4 hq4Var4 = (hq4) qp1.m16067m0(arrayListM21675R2);
                        arrayList4.add(hq4Var4);
                        arrayListM21675R2.addAll(hq4Var4.f20152g);
                    }
                    Iterator it4 = ((LinkedHashSet) r20Var.f35824h).iterator();
                    while (it4.hasNext()) {
                        ((q20) it4.next()).mo13321a(arrayList4);
                    }
                    m20Var.f34202b.removeAll(((m20) r20Var.f35821e).f34202b);
                    m20Var.f34202b.removeAll(((m20) r20Var.f35820d).f34202b);
                }
                for (q20 q20Var2 : (LinkedHashSet) r20Var.f35823g) {
                    List listM12279X0 = kp1.m12279X0(q20Var2.f34202b);
                    nj4 nj4Var = q20Var2.f34201a;
                    Iterator it5 = listM12279X0.iterator();
                    while (it5.hasNext()) {
                        nj4Var.invoke(it5.next());
                    }
                }
            }
            if (this.f1182D) {
                Set<iz1> set2 = this.f1179A.f25603a;
                ArrayList<hq4> arrayList5 = new ArrayList(lp1.m13108d0(set2, 10));
                for (iz1 iz1Var2 : set2) {
                    tj5 tj5Var2 = k2a.f23983a;
                    nz1 nz1Var2 = (nz1) kp1.m12256A0(iz1Var2.mo9817i());
                    arrayList5.add(nz1Var2 != null ? k2a.m11726h(nz1Var2, null) : wj3.f45541h);
                }
                ArrayList arrayList6 = new ArrayList();
                for (hq4 hq4Var5 : arrayList5) {
                    lt1 lt1Var = new lt1(this);
                    ArrayList<hq4> arrayList7 = new ArrayList();
                    ArrayList arrayListM21675R3 = zza.m21675R(hq4Var5);
                    while (!arrayListM21675R3.isEmpty()) {
                        hq4 hq4Var6 = (hq4) qp1.m16067m0(arrayListM21675R3);
                        if (((Boolean) lt1Var.invoke(hq4Var6)).booleanValue()) {
                            arrayList7.add(hq4Var6);
                        }
                        arrayListM21675R3.addAll(hq4Var6.f20152g);
                    }
                    ArrayList arrayList8 = new ArrayList();
                    for (hq4 hq4Var7 : arrayList7) {
                        String strM824b = m824b(hq4Var7, hq4Var7.f20150e);
                        if (strM824b == null) {
                            Iterator it6 = hq4Var7.f20152g.iterator();
                            while (true) {
                                if (!it6.hasNext()) {
                                    strM824b = null;
                                    break;
                                }
                                String strM824b2 = m824b((hq4) it6.next(), hq4Var7.f20150e);
                                if (strM824b2 != null) {
                                    strM824b = strM824b2;
                                    break;
                                }
                            }
                        }
                        if (strM824b != null) {
                            arrayList8.add(strM824b);
                        }
                    }
                    qp1.m16062h0(arrayList6, arrayList8);
                }
            }
        }
    }

    public ComposeViewAdapter(@NotNull Context context, @NotNull AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1191e = new ComposeView(getContext(), null, 0, 6, null);
        this.f1194z = yj3.f48828e;
        this.f1179A = new kz1();
        this.f1180B = BuildConfig.VERSION_NAME;
        this.f1181C = new zg8(16);
        this.f1183E = BuildConfig.VERSION_NAME;
        this.f1184F = new C1269p5(22);
        Paint paint = new Paint();
        paint.setPathEffect(new DashPathEffect(new float[]{5.0f, 10.0f, 15.0f, 20.0f}, 0.0f));
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(alc.m618V(sp1.f38649f));
        this.f1185G = paint;
        this.f1187I = new qy1();
        this.f1188J = new b90(1);
        this.f1189K = new py1(this);
        this.f1190L = new oy1();
        m825d(attributeSet);
    }
}
