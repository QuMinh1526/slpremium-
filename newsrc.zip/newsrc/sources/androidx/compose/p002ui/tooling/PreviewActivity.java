package androidx.compose.p002ui.tooling;

import android.content.Intent;
import android.os.Bundle;
import androidx.activity.ComponentActivity;
import kotlin.Metadata;
import p000.dq0;
import p000.eh4;
import p000.k75;
import p000.tea;
import p000.vv1;
import p000.yu1;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, m12198d2 = {"Landroidx/compose/ui/tooling/PreviewActivity;", "Landroidx/activity/ComponentActivity;", "<init>", "()V", "ui-tooling"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public final class PreviewActivity extends ComponentActivity {

    /* JADX INFO: renamed from: i */
    public static final /* synthetic */ int f1195i = 0;

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        String stringExtra;
        super.onCreate(bundle);
        if ((getApplicationInfo().flags & 2) == 0) {
            finish();
            return;
        }
        Intent intent = getIntent();
        if (intent == null || (stringExtra = intent.getStringExtra("composable")) == null) {
            return;
        }
        String strM17651w0 = tea.m17651w0(stringExtra, '.');
        String strM17647s0 = tea.m17647s0('.', stringExtra, stringExtra);
        String stringExtra2 = getIntent().getStringExtra("parameterProviderClassName");
        if (stringExtra2 != null) {
            yu1.m20697a(this, new vv1(new k75(strM17651w0, strM17647s0, eh4.m7456C(getIntent().getIntExtra("parameterProviderIndex", -1), eh4.m7486p(stringExtra2)), 21), true, -1901447514));
        } else {
            yu1.m20697a(this, new vv1(new dq0(1, strM17651w0, strM17647s0), true, -840626948));
        }
    }
}
