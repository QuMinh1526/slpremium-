package androidx.compose.p002ui.input.pointer;

import com.squareup.picasso.BuildConfig;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p000.e78;
import p000.h72;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bæ\u0080\u0001\u0018\u00002\u00020\u0001J\u0014\u0010\u0004\u001a\u00020\u0003*\u00020\u0002H¦B¢\u0006\u0004\b\u0004\u0010\u0005ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0006À\u0006\u0001"}, m12198d2 = {"Landroidx/compose/ui/input/pointer/PointerInputEventHandler;", BuildConfig.VERSION_NAME, "Le78;", "La5b;", "invoke", "(Le78;Lh72;)Ljava/lang/Object;", "ui"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public interface PointerInputEventHandler {
    @Nullable
    Object invoke(@NotNull e78 e78Var, @NotNull h72 h72Var);
}
