package androidx.emoji2.text;

import android.content.Context;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import p000.gh5;
import p000.h60;
import p000.o96;
import p000.oi3;
import p000.pi3;
import p000.qi3;
import p000.x96;
import p000.ze7;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class EmojiCompatInitializer implements gh5 {
    @Override // p000.gh5
    /* JADX INFO: renamed from: a */
    public final List mo1052a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // p000.gh5
    /* JADX INFO: renamed from: b */
    public final Object mo1053b(Context context) {
        Object objM21153q;
        qi3 qi3Var = new qi3(new h60(context, 4));
        qi3Var.f21417b = 1;
        if (oi3.f31659k == null) {
            synchronized (oi3.f31658j) {
                try {
                    if (oi3.f31659k == null) {
                        oi3.f31659k = new oi3(qi3Var);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        ze7 ze7VarM21130y = ze7.m21130y(context);
        ze7VarM21130y.getClass();
        synchronized (ze7.f50202B) {
            try {
                objM21153q = ((HashMap) ze7VarM21130y.f50208i).get(ProcessLifecycleInitializer.class);
                if (objM21153q == null) {
                    objM21153q = ze7VarM21130y.m21153q(ProcessLifecycleInitializer.class, new HashSet());
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        o96 lifecycle = ((x96) objM21153q).getLifecycle();
        lifecycle.mo244a(new pi3(this, lifecycle));
        return Boolean.TRUE;
    }
}
