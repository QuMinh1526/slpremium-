package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.util.LinkedHashMap;
import kotlin.Metadata;
import p000.hx6;
import p000.ix6;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, m12198d2 = {"Landroidx/room/MultiInstanceInvalidationService;", "Landroid/app/Service;", "<init>", "()V", "room-runtime"}, m12199k = 1, m12200mv = {2, 1, 0}, m12202xi = 48)
public final class MultiInstanceInvalidationService extends Service {

    /* JADX INFO: renamed from: e */
    public int f2193e;

    /* JADX INFO: renamed from: i */
    public final LinkedHashMap f2194i = new LinkedHashMap();

    /* JADX INFO: renamed from: y */
    public final ix6 f2195y = new ix6(this);

    /* JADX INFO: renamed from: z */
    public final hx6 f2196z = new hx6(this);

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        intent.getClass();
        return this.f2196z;
    }
}
