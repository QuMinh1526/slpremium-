package androidx.databinding.library.baseAdapters;

import android.util.SparseIntArray;
import p000.rg2;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class DataBinderMapperImpl extends rg2 {
    static {
        new SparseIntArray(0);
    }
}
