package androidx.databinding;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;
import p000.AbstractC1512uv;
import p000.bf7;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class ObservableFloat extends AbstractC1512uv implements Parcelable, Serializable {
    public static final Parcelable.Creator<ObservableFloat> CREATOR = new bf7(25);

    /* JADX INFO: renamed from: e */
    public float f1683e;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeFloat(this.f1683e);
    }
}
