package androidx.cardview.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import p000.d49;
import p000.di5;
import p000.e49;
import p000.fo8;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class CardView extends FrameLayout {

    /* JADX INFO: renamed from: B */
    public static final int[] f1149B = {R.attr.colorBackground};

    /* JADX INFO: renamed from: A */
    public final di5 f1150A;

    /* JADX INFO: renamed from: e */
    public final boolean f1151e;

    /* JADX INFO: renamed from: i */
    public final boolean f1152i;

    /* JADX INFO: renamed from: y */
    public final Rect f1153y;

    /* JADX INFO: renamed from: z */
    public final Rect f1154z;

    public CardView(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        ColorStateList colorStateListValueOf;
        super(context, attributeSet, i);
        Rect rect = new Rect();
        this.f1153y = rect;
        this.f1154z = new Rect();
        di5 di5Var = new di5();
        di5Var.f10920i = this;
        this.f1150A = di5Var;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, fo8.f14568a, i, ginlemon.flowerfree.R.style.CardView);
        if (typedArrayObtainStyledAttributes.hasValue(2)) {
            colorStateListValueOf = typedArrayObtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray typedArrayObtainStyledAttributes2 = getContext().obtainStyledAttributes(f1149B);
            int color = typedArrayObtainStyledAttributes2.getColor(0, 0);
            typedArrayObtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            colorStateListValueOf = ColorStateList.valueOf(fArr[2] > 0.5f ? getResources().getColor(ginlemon.flowerfree.R.color.cardview_light_background) : getResources().getColor(ginlemon.flowerfree.R.color.cardview_dark_background));
        }
        float dimension = typedArrayObtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = typedArrayObtainStyledAttributes.getDimension(4, 0.0f);
        float dimension3 = typedArrayObtainStyledAttributes.getDimension(5, 0.0f);
        boolean z = typedArrayObtainStyledAttributes.getBoolean(7, false);
        this.f1151e = z;
        boolean z2 = typedArrayObtainStyledAttributes.getBoolean(6, true);
        this.f1152i = z2;
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = typedArrayObtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = typedArrayObtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = typedArrayObtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = typedArrayObtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        dimension3 = dimension2 > dimension3 ? dimension2 : dimension3;
        typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.getDimensionPixelSize(1, 0);
        typedArrayObtainStyledAttributes.recycle();
        d49 d49Var = new d49(colorStateListValueOf, dimension);
        di5Var.f10919e = d49Var;
        setBackgroundDrawable(d49Var);
        setClipToOutline(true);
        setElevation(dimension2);
        d49 d49Var2 = (d49) di5Var.f10919e;
        if (dimension3 != d49Var2.f10383e || d49Var2.f10384f != z || d49Var2.f10385g != z2) {
            d49Var2.f10383e = dimension3;
            d49Var2.f10384f = z;
            d49Var2.f10385g = z2;
            d49Var2.m6752b(null);
            d49Var2.invalidateSelf();
        }
        if (!z) {
            di5Var.m6935c0(0, 0, 0, 0);
            return;
        }
        d49 d49Var3 = (d49) di5Var.f10919e;
        float f = d49Var3.f10383e;
        float f2 = d49Var3.f10379a;
        int iCeil = (int) Math.ceil(e49.m7264a(f, f2, z2));
        int iCeil2 = (int) Math.ceil(e49.m7265b(f, f2, z2));
        di5Var.m6935c0(iCeil, iCeil2, iCeil, iCeil2);
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
    }

    @Override // android.view.View
    public final void setPadding(int i, int i2, int i3, int i4) {
    }

    @Override // android.view.View
    public final void setPaddingRelative(int i, int i2, int i3, int i4) {
    }

    public CardView(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, ginlemon.flowerfree.R.attr.cardViewStyle);
    }
}
