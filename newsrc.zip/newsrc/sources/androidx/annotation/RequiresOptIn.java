package androidx.annotation;

import com.squareup.picasso.BuildConfig;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import p000.jm3;
import p000.p6c;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Target({ElementType.ANNOTATION_TYPE})
@Metadata(m12197d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u001b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\b\u0087\u0002\u0018\u00002\u00020\u0001:\u0001\bB\u0014\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005R\u000f\u0010\u0002\u001a\u00020\u0003¢\u0006\u0006\u001a\u0004\b\u0002\u0010\u0006R\u000f\u0010\u0004\u001a\u00020\u0005¢\u0006\u0006\u001a\u0004\b\u0004\u0010\u0007¨\u0006\t"}, m12198d2 = {"Landroidx/annotation/RequiresOptIn;", BuildConfig.VERSION_NAME, "level", "Landroidx/annotation/RequiresOptIn$Level;", "message", BuildConfig.VERSION_NAME, "()Landroidx/annotation/RequiresOptIn$Level;", "()Ljava/lang/String;", "Level", "annotation-experimental_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
@Retention(RetentionPolicy.CLASS)
public @interface RequiresOptIn {

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    @Metadata(m12197d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, m12198d2 = {"Landroidx/annotation/RequiresOptIn$Level;", BuildConfig.VERSION_NAME, "<init>", "(Ljava/lang/String;I)V", "WARNING", "ERROR", "annotation-experimental_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
    public enum Level {
        WARNING,
        ERROR;

        private static final /* synthetic */ jm3 $ENTRIES = p6c.m15196s(values());

        @NotNull
        public static jm3 getEntries() {
            return $ENTRIES;
        }
    }

    Level level() default Level.ERROR;

    String message() default "";
}
