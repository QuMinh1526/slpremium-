package androidx.annotation.experimental;

/* JADX INFO: renamed from: androidx.annotation.experimental.R */
/* JADX INFO: loaded from: classes2.dex */
public final class C0025R {
    private C0025R() {
    }
}
