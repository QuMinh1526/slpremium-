package androidx.annotation;

import com.squareup.picasso.BuildConfig;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Target({ElementType.TYPE, ElementType.METHOD})
@Metadata(m12197d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u001b\n\u0000\b\u0087\u0002\u0018\u00002\u00020\u0001B\u0000¨\u0006\u0002"}, m12198d2 = {"Landroidx/annotation/OpenForTesting;", BuildConfig.VERSION_NAME, "annotation"}, m12199k = 1, m12200mv = {2, 1, 0}, m12202xi = 48)
@Documented
@Retention(RetentionPolicy.CLASS)
public @interface OpenForTesting {
}
