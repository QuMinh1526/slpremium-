package androidx.lifecycle;

import kotlin.Metadata;
import p000.alc;
import p000.fy6;
import p000.mcb;
import p000.p6c;
import p000.sr5;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0016\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, m12198d2 = {"androidx/lifecycle/ViewModelProvider$NewInstanceFactory", "Lmcb;", "<init>", "()V", "lifecycle-viewmodel_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public class ViewModelProvider$NewInstanceFactory implements mcb {

    /* JADX INFO: renamed from: a */
    public static ViewModelProvider$NewInstanceFactory f1943a;

    @Override // p000.mcb
    /* JADX INFO: renamed from: a */
    public ViewModel mo1064a(Class cls) {
        return alc.m606F(cls);
    }

    @Override // p000.mcb
    /* JADX INFO: renamed from: b */
    public ViewModel mo1197b(Class cls, fy6 fy6Var) {
        return mo1064a(cls);
    }

    @Override // p000.mcb
    /* JADX INFO: renamed from: c */
    public final ViewModel mo1200c(sr5 sr5Var, fy6 fy6Var) {
        sr5Var.getClass();
        return mo1197b(p6c.m15165A(sr5Var), fy6Var);
    }
}
