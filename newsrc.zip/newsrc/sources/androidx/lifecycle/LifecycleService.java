package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import kotlin.Metadata;
import p000.aa6;
import p000.bl8;
import p000.m96;
import p000.o96;
import p000.x96;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0016\u0018\u00002\u00020\u00012\u00020\u0002¨\u0006\u0003"}, m12198d2 = {"Landroidx/lifecycle/LifecycleService;", "Landroid/app/Service;", "Lx96;", "lifecycle-service_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public class LifecycleService extends Service implements x96 {

    /* JADX INFO: renamed from: e */
    public final bl8 f1934e = new bl8(this);

    @Override // p000.x96
    public final o96 getLifecycle() {
        return (aa6) this.f1934e.f4275i;
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        intent.getClass();
        bl8 bl8Var = this.f1934e;
        bl8Var.getClass();
        bl8Var.m2559x(m96.ON_START);
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        bl8 bl8Var = this.f1934e;
        bl8Var.getClass();
        bl8Var.m2559x(m96.ON_CREATE);
        super.onCreate();
    }

    @Override // android.app.Service
    public void onDestroy() {
        bl8 bl8Var = this.f1934e;
        bl8Var.getClass();
        bl8Var.m2559x(m96.ON_STOP);
        bl8Var.m2559x(m96.ON_DESTROY);
        super.onDestroy();
    }

    @Override // android.app.Service
    public final void onStart(Intent intent, int i) {
        bl8 bl8Var = this.f1934e;
        bl8Var.getClass();
        bl8Var.m2559x(m96.ON_START);
        super.onStart(intent, i);
    }
}
