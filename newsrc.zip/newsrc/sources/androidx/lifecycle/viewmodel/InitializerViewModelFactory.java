package androidx.lifecycle.viewmodel;

import androidx.lifecycle.ViewModel;
import com.squareup.picasso.BuildConfig;
import java.util.Arrays;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import p000.fy6;
import p000.kcb;
import p000.mcb;
import p000.nj4;
import p000.ro6;
import p000.sr5;
import p000.ul5;
import p000.zu8;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u00002\u00020\u0001B#\u0012\u001a\u0010\u0004\u001a\u000e\u0012\n\b\u0001\u0012\u0006\u0012\u0002\b\u00030\u00030\u0002\"\u0006\u0012\u0002\b\u00030\u0003¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, m12198d2 = {"Landroidx/lifecycle/viewmodel/InitializerViewModelFactory;", "Lmcb;", BuildConfig.VERSION_NAME, "Lkcb;", "initializers", "<init>", "([Lkcb;)V", "lifecycle-viewmodel_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public final class InitializerViewModelFactory implements mcb {

    /* JADX INFO: renamed from: a */
    public final kcb[] f1944a;

    public InitializerViewModelFactory(@NotNull kcb... kcbVarArr) {
        kcbVarArr.getClass();
        this.f1944a = kcbVarArr;
    }

    @Override // p000.mcb
    /* JADX INFO: renamed from: b */
    public final ViewModel mo1197b(Class cls, fy6 fy6Var) {
        kcb kcbVar;
        nj4 nj4Var;
        sr5 sr5VarMo1868b = zu8.f50914a.mo1868b(cls);
        kcb[] kcbVarArr = this.f1944a;
        kcb[] kcbVarArr2 = (kcb[]) Arrays.copyOf(kcbVarArr, kcbVarArr.length);
        int length = kcbVarArr2.length;
        int i = 0;
        while (true) {
            if (i >= length) {
                kcbVar = null;
                break;
            }
            kcbVar = kcbVarArr2[i];
            if (ul5.m18482l(kcbVar.f24479a, sr5VarMo1868b)) {
                break;
            }
            i++;
        }
        ViewModel viewModel = (kcbVar == null || (nj4Var = kcbVar.f24480b) == null) ? null : (ViewModel) nj4Var.invoke(fy6Var);
        if (viewModel != null) {
            return viewModel;
        }
        ro6.m16610u(sr5VarMo1868b.mo17162a(), "No initializer set for given class ");
        return null;
    }
}
