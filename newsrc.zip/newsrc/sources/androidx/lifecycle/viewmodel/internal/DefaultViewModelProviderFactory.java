package androidx.lifecycle.viewmodel.internal;

import androidx.lifecycle.ViewModel;
import kotlin.Metadata;
import p000.alc;
import p000.fy6;
import p000.mcb;
import p000.p6c;
import p000.sr5;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bÀ\u0002\u0018\u00002\u00020\u0001¨\u0006\u0002"}, m12198d2 = {"Landroidx/lifecycle/viewmodel/internal/DefaultViewModelProviderFactory;", "Lmcb;", "lifecycle-viewmodel_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public final class DefaultViewModelProviderFactory implements mcb {

    /* JADX INFO: renamed from: a */
    public static final DefaultViewModelProviderFactory f1945a = new DefaultViewModelProviderFactory();

    @Override // p000.mcb
    /* JADX INFO: renamed from: c */
    public final ViewModel mo1200c(sr5 sr5Var, fy6 fy6Var) {
        sr5Var.getClass();
        return alc.m606F(p6c.m15165A(sr5Var));
    }
}
