package androidx.lifecycle;

import androidx.annotation.MainThread;
import com.squareup.picasso.BuildConfig;
import java.io.Closeable;
import java.util.Arrays;
import java.util.Iterator;
import kotlin.Metadata;
import kotlinx.coroutines.CoroutineScope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p000.bp2;
import p000.jcb;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0003\b&\u0018\u00002\u00020\u0001B\t\b\u0016¢\u0006\u0004\b\u0002\u0010\u0003B\u0011\b\u0016\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0002\u0010\u0006B%\b\u0016\u0012\u001a\u0010\n\u001a\u000e\u0012\n\b\u0001\u0012\u00060\bj\u0002`\t0\u0007\"\u00060\bj\u0002`\t¢\u0006\u0004\b\u0002\u0010\u000bB-\b\u0016\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u001a\u0010\n\u001a\u000e\u0012\n\b\u0001\u0012\u00060\bj\u0002`\t0\u0007\"\u00060\bj\u0002`\t¢\u0006\u0004\b\u0002\u0010\fB\u001d\b\u0017\u0012\u0012\u0010\n\u001a\n\u0012\u0006\b\u0001\u0012\u00020\r0\u0007\"\u00020\r¢\u0006\u0004\b\u0002\u0010\u000eJ\u000f\u0010\u0010\u001a\u00020\u000fH\u0014¢\u0006\u0004\b\u0010\u0010\u0003J\u000f\u0010\u0012\u001a\u00020\u000fH\u0001¢\u0006\u0004\b\u0011\u0010\u0003J!\u0010\u0016\u001a\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u00132\n\u0010\u0015\u001a\u00060\bj\u0002`\t¢\u0006\u0004\b\u0016\u0010\u0017J\u001b\u0010\u0016\u001a\u00020\u000f2\n\u0010\u0015\u001a\u00060\bj\u0002`\tH\u0016¢\u0006\u0004\b\u0016\u0010\u0018J\u0017\u0010\u0016\u001a\u00020\u000f2\u0006\u0010\u0015\u001a\u00020\rH\u0017¢\u0006\u0004\b\u0016\u0010\u0019J%\u0010\u001b\u001a\u0004\u0018\u00018\u0000\"\f\b\u0000\u0010\u001a*\u00060\bj\u0002`\t2\u0006\u0010\u0014\u001a\u00020\u0013¢\u0006\u0004\b\u001b\u0010\u001cR\u0016\u0010\u001e\u001a\u0004\u0018\u00010\u001d8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001e\u0010\u001f¨\u0006 "}, m12198d2 = {"Landroidx/lifecycle/ViewModel;", BuildConfig.VERSION_NAME, "<init>", "()V", "Lkotlinx/coroutines/CoroutineScope;", "viewModelScope", "(Lkotlinx/coroutines/CoroutineScope;)V", BuildConfig.VERSION_NAME, "Ljava/lang/AutoCloseable;", "Lkotlin/AutoCloseable;", "closeables", "([Ljava/lang/AutoCloseable;)V", "(Lkotlinx/coroutines/CoroutineScope;[Ljava/lang/AutoCloseable;)V", "Ljava/io/Closeable;", "([Ljava/io/Closeable;)V", "La5b;", "onCleared", "clear$lifecycle_viewmodel_release", "clear", BuildConfig.VERSION_NAME, "key", "closeable", "addCloseable", "(Ljava/lang/String;Ljava/lang/AutoCloseable;)V", "(Ljava/lang/AutoCloseable;)V", "(Ljava/io/Closeable;)V", "T", "getCloseable", "(Ljava/lang/String;)Ljava/lang/AutoCloseable;", "Ljcb;", "impl", "Ljcb;", "lifecycle-viewmodel_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public abstract class ViewModel {

    @Nullable
    private final jcb impl;

    public ViewModel(@NotNull CoroutineScope coroutineScope, @NotNull AutoCloseable... autoCloseableArr) {
        coroutineScope.getClass();
        autoCloseableArr.getClass();
        this.impl = new jcb(coroutineScope, (AutoCloseable[]) Arrays.copyOf(autoCloseableArr, autoCloseableArr.length));
    }

    public final void addCloseable(@NotNull String key, @NotNull AutoCloseable closeable) {
        key.getClass();
        closeable.getClass();
        jcb jcbVar = this.impl;
        if (jcbVar != null) {
            jcbVar.m11232b(key, closeable);
        }
    }

    @MainThread
    public final void clear$lifecycle_viewmodel_release() {
        jcb jcbVar = this.impl;
        if (jcbVar != null && !jcbVar.f22840d) {
            jcbVar.f22840d = true;
            synchronized (jcbVar.f22837a) {
                try {
                    Iterator it = jcbVar.f22838b.values().iterator();
                    while (it.hasNext()) {
                        jcb.m11230c((AutoCloseable) it.next());
                    }
                    Iterator it2 = jcbVar.f22839c.iterator();
                    while (it2.hasNext()) {
                        jcb.m11230c((AutoCloseable) it2.next());
                    }
                    jcbVar.f22839c.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        onCleared();
    }

    @Nullable
    public final <T extends AutoCloseable> T getCloseable(@NotNull String key) {
        T t;
        key.getClass();
        jcb jcbVar = this.impl;
        if (jcbVar == null) {
            return null;
        }
        synchronized (jcbVar.f22837a) {
            t = (T) jcbVar.f22838b.get(key);
        }
        return t;
    }

    public void addCloseable(@NotNull AutoCloseable closeable) {
        closeable.getClass();
        jcb jcbVar = this.impl;
        if (jcbVar != null) {
            jcbVar.m11231a(closeable);
        }
    }

    @bp2
    public /* synthetic */ void addCloseable(Closeable closeable) {
        closeable.getClass();
        jcb jcbVar = this.impl;
        if (jcbVar != null) {
            jcbVar.m11231a(closeable);
        }
    }

    public ViewModel(@NotNull CoroutineScope coroutineScope) {
        coroutineScope.getClass();
        this.impl = new jcb(coroutineScope);
    }

    public ViewModel(@NotNull AutoCloseable... autoCloseableArr) {
        autoCloseableArr.getClass();
        this.impl = new jcb((AutoCloseable[]) Arrays.copyOf(autoCloseableArr, autoCloseableArr.length));
    }

    public ViewModel() {
        this.impl = new jcb();
    }

    @bp2
    public /* synthetic */ ViewModel(Closeable... closeableArr) {
        closeableArr.getClass();
        this.impl = new jcb((AutoCloseable[]) Arrays.copyOf(closeableArr, closeableArr.length));
    }

    public void onCleared() {
    }
}
