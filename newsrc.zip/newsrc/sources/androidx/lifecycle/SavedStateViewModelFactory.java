package androidx.lifecycle;

import android.annotation.SuppressLint;
import android.app.Application;
import android.os.Bundle;
import java.lang.reflect.Constructor;
import java.util.LinkedHashMap;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p000.C0563gz;
import p000.C1521v3;
import p000.alc;
import p000.fy6;
import p000.ga9;
import p000.mcb;
import p000.na9;
import p000.ncb;
import p000.o96;
import p000.p6c;
import p000.qi4;
import p000.qk7;
import p000.r21;
import p000.ra9;
import p000.sa9;
import p000.sr5;
import p000.un4;
import p000.vf3;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u00012\u00020\u0002B\t\b\u0016¢\u0006\u0004\b\u0003\u0010\u0004B\u001b\b\u0016\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\u0003\u0010\tB%\b\u0017\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\n¢\u0006\u0004\b\u0003\u0010\f¨\u0006\r"}, m12198d2 = {"Landroidx/lifecycle/SavedStateViewModelFactory;", "Lncb;", "Lmcb;", "<init>", "()V", "Landroid/app/Application;", "application", "Lra9;", "owner", "(Landroid/app/Application;Lra9;)V", "Landroid/os/Bundle;", "defaultArgs", "(Landroid/app/Application;Lra9;Landroid/os/Bundle;)V", "lifecycle-viewmodel-savedstate_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public final class SavedStateViewModelFactory extends ncb implements mcb {

    /* JADX INFO: renamed from: a */
    public final Application f1935a;

    /* JADX INFO: renamed from: b */
    public final ViewModelProvider$AndroidViewModelFactory f1936b;

    /* JADX INFO: renamed from: c */
    public final Bundle f1937c;

    /* JADX INFO: renamed from: d */
    public final o96 f1938d;

    /* JADX INFO: renamed from: e */
    public final na9 f1939e;

    @SuppressLint({"LambdaLast"})
    public SavedStateViewModelFactory(@Nullable Application application, @NotNull ra9 ra9Var, @Nullable Bundle bundle) {
        ViewModelProvider$AndroidViewModelFactory viewModelProvider$AndroidViewModelFactory;
        ra9Var.getClass();
        this.f1939e = ra9Var.getSavedStateRegistry();
        this.f1938d = ra9Var.getLifecycle();
        this.f1937c = bundle;
        this.f1935a = application;
        if (application != null) {
            if (ViewModelProvider$AndroidViewModelFactory.f1940c == null) {
                ViewModelProvider$AndroidViewModelFactory.f1940c = new ViewModelProvider$AndroidViewModelFactory(application);
            }
            viewModelProvider$AndroidViewModelFactory = ViewModelProvider$AndroidViewModelFactory.f1940c;
            viewModelProvider$AndroidViewModelFactory.getClass();
        } else {
            viewModelProvider$AndroidViewModelFactory = new ViewModelProvider$AndroidViewModelFactory();
        }
        this.f1936b = viewModelProvider$AndroidViewModelFactory;
    }

    @Override // p000.mcb
    /* JADX INFO: renamed from: a */
    public final ViewModel mo1064a(Class cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return m1201e(cls, canonicalName);
        }
        C1521v3.m18903j("Local and anonymous classes can not be ViewModels");
        return null;
    }

    @Override // p000.mcb
    /* JADX INFO: renamed from: b */
    public final ViewModel mo1197b(Class cls, fy6 fy6Var) {
        qk7 qk7Var = un4.f42271B;
        LinkedHashMap linkedHashMap = fy6Var.f31315a;
        String str = (String) linkedHashMap.get(qk7Var);
        if (str == null) {
            C1521v3.m18909p("VIEW_MODEL_KEY must always be provided by ViewModelProvider");
            return null;
        }
        if (linkedHashMap.get(r21.f35831g) == null || linkedHashMap.get(r21.f35832h) == null) {
            if (this.f1938d != null) {
                return m1201e(cls, str);
            }
            C1521v3.m18909p("SAVED_STATE_REGISTRY_OWNER_KEY andVIEW_MODEL_STORE_OWNER_KEY must be provided in the creation extras tosuccessfully create a ViewModel.");
            return null;
        }
        Application application = (Application) linkedHashMap.get(ViewModelProvider$AndroidViewModelFactory.f1941d);
        boolean zIsAssignableFrom = C0563gz.class.isAssignableFrom(cls);
        Constructor constructorM16880c = (!zIsAssignableFrom || application == null) ? sa9.m16880c(cls, sa9.f38037b) : sa9.m16880c(cls, sa9.f38036a);
        if (constructorM16880c == null) {
            return this.f1936b.mo1197b(cls, fy6Var);
        }
        return (!zIsAssignableFrom || application == null) ? sa9.m16881d(cls, constructorM16880c, r21.m16248m(fy6Var)) : sa9.m16881d(cls, constructorM16880c, application, r21.m16248m(fy6Var));
    }

    @Override // p000.mcb
    /* JADX INFO: renamed from: c */
    public final ViewModel mo1200c(sr5 sr5Var, fy6 fy6Var) {
        sr5Var.getClass();
        return mo1197b(p6c.m15165A(sr5Var), fy6Var);
    }

    @Override // p000.ncb
    /* JADX INFO: renamed from: d */
    public final void mo1198d(ViewModel viewModel) {
        o96 o96Var = this.f1938d;
        if (o96Var != null) {
            na9 na9Var = this.f1939e;
            na9Var.getClass();
            qi4.m16003w(viewModel, na9Var, o96Var);
        }
    }

    /* JADX INFO: renamed from: e */
    public final ViewModel m1201e(Class cls, String str) {
        o96 o96Var = this.f1938d;
        if (o96Var == null) {
            vf3.m19097o("SavedStateViewModelFactory constructed with empty constructor supports only calls to create(modelClass: Class<T>, extras: CreationExtras).");
            return null;
        }
        boolean zIsAssignableFrom = C0563gz.class.isAssignableFrom(cls);
        Application application = this.f1935a;
        Constructor constructorM16880c = (!zIsAssignableFrom || application == null) ? sa9.m16880c(cls, sa9.f38037b) : sa9.m16880c(cls, sa9.f38036a);
        if (constructorM16880c == null) {
            if (application != null) {
                return this.f1936b.mo1064a(cls);
            }
            if (ViewModelProvider$NewInstanceFactory.f1943a == null) {
                ViewModelProvider$NewInstanceFactory.f1943a = new ViewModelProvider$NewInstanceFactory();
            }
            ViewModelProvider$NewInstanceFactory.f1943a.getClass();
            return alc.m606F(cls);
        }
        na9 na9Var = this.f1939e;
        na9Var.getClass();
        ga9 ga9VarM16006z = qi4.m16006z(na9Var, o96Var, str, this.f1937c);
        ViewModel viewModelM16881d = (!zIsAssignableFrom || application == null) ? sa9.m16881d(cls, constructorM16880c, ga9VarM16006z.m8925j()) : sa9.m16881d(cls, constructorM16880c, application, ga9VarM16006z.m8925j());
        viewModelM16881d.addCloseable("androidx.lifecycle.savedstate.vm.tag", ga9VarM16006z);
        return viewModelM16881d;
    }

    public SavedStateViewModelFactory() {
        this.f1936b = new ViewModelProvider$AndroidViewModelFactory();
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public SavedStateViewModelFactory(@Nullable Application application, @NotNull ra9 ra9Var) {
        this(application, ra9Var, null);
        ra9Var.getClass();
    }
}
