package androidx.lifecycle;

import android.os.Bundle;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p000.C1521v3;
import p000.bp2;
import p000.fy6;
import p000.ga9;
import p000.mcb;
import p000.na9;
import p000.ncb;
import p000.o96;
import p000.qi4;
import p000.r21;
import p000.ra9;
import p000.un4;
import p000.vf3;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@bp2
@Metadata(m12197d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\u00020\u00012\u00020\u0002B\t\b\u0016¢\u0006\u0004\b\u0003\u0010\u0004B\u001b\b\u0016\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0007¢\u0006\u0004\b\u0003\u0010\t¨\u0006\n"}, m12198d2 = {"Landroidx/lifecycle/AbstractSavedStateViewModelFactory;", "Lncb;", "Lmcb;", "<init>", "()V", "Lra9;", "owner", "Landroid/os/Bundle;", "defaultArgs", "(Lra9;Landroid/os/Bundle;)V", "lifecycle-viewmodel-savedstate_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public abstract class AbstractSavedStateViewModelFactory extends ncb implements mcb {

    /* JADX INFO: renamed from: a */
    public final na9 f1931a;

    /* JADX INFO: renamed from: b */
    public final o96 f1932b;

    /* JADX INFO: renamed from: c */
    public final Bundle f1933c;

    public AbstractSavedStateViewModelFactory(@NotNull ra9 ra9Var, @Nullable Bundle bundle) {
        ra9Var.getClass();
        this.f1931a = ra9Var.getSavedStateRegistry();
        this.f1932b = ra9Var.getLifecycle();
        this.f1933c = bundle;
    }

    @Override // p000.mcb
    /* JADX INFO: renamed from: a */
    public final ViewModel mo1064a(Class cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName == null) {
            C1521v3.m18903j("Local and anonymous classes can not be ViewModels");
            return null;
        }
        o96 o96Var = this.f1932b;
        if (o96Var == null) {
            vf3.m19097o("AbstractSavedStateViewModelFactory constructed with empty constructor supports only calls to create(modelClass: Class<T>, extras: CreationExtras).");
            return null;
        }
        na9 na9Var = this.f1931a;
        na9Var.getClass();
        o96Var.getClass();
        ga9 ga9VarM16006z = qi4.m16006z(na9Var, o96Var, canonicalName, this.f1933c);
        ViewModel viewModelM1199e = m1199e();
        viewModelM1199e.addCloseable("androidx.lifecycle.savedstate.vm.tag", ga9VarM16006z);
        return viewModelM1199e;
    }

    @Override // p000.mcb
    /* JADX INFO: renamed from: b */
    public final ViewModel mo1197b(Class cls, fy6 fy6Var) {
        String str = (String) fy6Var.f31315a.get(un4.f42271B);
        if (str == null) {
            C1521v3.m18909p("VIEW_MODEL_KEY must always be provided by ViewModelProvider");
            return null;
        }
        na9 na9Var = this.f1931a;
        if (na9Var == null) {
            r21.m16248m(fy6Var);
            return m1199e();
        }
        na9Var.getClass();
        o96 o96Var = this.f1932b;
        o96Var.getClass();
        ga9 ga9VarM16006z = qi4.m16006z(na9Var, o96Var, str, this.f1933c);
        ViewModel viewModelM1199e = m1199e();
        viewModelM1199e.addCloseable("androidx.lifecycle.savedstate.vm.tag", ga9VarM16006z);
        return viewModelM1199e;
    }

    @Override // p000.ncb
    /* JADX INFO: renamed from: d */
    public final void mo1198d(ViewModel viewModel) {
        na9 na9Var = this.f1931a;
        if (na9Var != null) {
            o96 o96Var = this.f1932b;
            o96Var.getClass();
            qi4.m16003w(viewModel, na9Var, o96Var);
        }
    }

    /* JADX INFO: renamed from: e */
    public abstract ViewModel m1199e();

    public AbstractSavedStateViewModelFactory() {
    }
}
