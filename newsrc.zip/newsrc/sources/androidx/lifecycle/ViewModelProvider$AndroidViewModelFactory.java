package androidx.lifecycle;

import android.app.Application;
import java.lang.reflect.InvocationTargetException;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import p000.C0563gz;
import p000.C1521v3;
import p000.alc;
import p000.fy6;
import p000.qk7;
import p000.ro6;
import p000.vf3;
import p000.z23;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(m12197d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0016\u0018\u00002\u00020\u0001B\t\b\u0016¢\u0006\u0004\b\u0002\u0010\u0003B\u0011\b\u0016\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0002\u0010\u0006¨\u0006\u0007"}, m12198d2 = {"androidx/lifecycle/ViewModelProvider$AndroidViewModelFactory", "Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;", "<init>", "()V", "Landroid/app/Application;", "application", "(Landroid/app/Application;)V", "lifecycle-viewmodel_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public class ViewModelProvider$AndroidViewModelFactory extends ViewModelProvider$NewInstanceFactory {

    /* JADX INFO: renamed from: c */
    public static ViewModelProvider$AndroidViewModelFactory f1940c;

    /* JADX INFO: renamed from: d */
    public static final qk7 f1941d = new qk7();

    /* JADX INFO: renamed from: b */
    public final Application f1942b;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public ViewModelProvider$AndroidViewModelFactory(@NotNull Application application) {
        this(application, 0);
        application.getClass();
    }

    @Override // androidx.lifecycle.ViewModelProvider$NewInstanceFactory, p000.mcb
    /* JADX INFO: renamed from: a */
    public final ViewModel mo1064a(Class cls) {
        Application application = this.f1942b;
        if (application != null) {
            return m1202d(cls, application);
        }
        vf3.m19097o("AndroidViewModelFactory constructed with empty constructor works only with create(modelClass: Class<T>, extras: CreationExtras).");
        return null;
    }

    @Override // androidx.lifecycle.ViewModelProvider$NewInstanceFactory, p000.mcb
    /* JADX INFO: renamed from: b */
    public final ViewModel mo1197b(Class cls, fy6 fy6Var) {
        if (this.f1942b != null) {
            return mo1064a(cls);
        }
        Application application = (Application) fy6Var.f31315a.get(f1941d);
        if (application != null) {
            return m1202d(cls, application);
        }
        if (!C0563gz.class.isAssignableFrom(cls)) {
            return alc.m606F(cls);
        }
        C1521v3.m18903j("CreationExtras must have an application by `APPLICATION_KEY`");
        return null;
    }

    /* JADX INFO: renamed from: d */
    public final ViewModel m1202d(Class cls, Application application) {
        if (!C0563gz.class.isAssignableFrom(cls)) {
            return alc.m606F(cls);
        }
        try {
            ViewModel viewModel = (ViewModel) cls.getConstructor(Application.class).newInstance(application);
            viewModel.getClass();
            return viewModel;
        } catch (IllegalAccessException e) {
            ro6.m16605p(z23.m20933o(cls, "Cannot create an instance of "), e);
            return null;
        } catch (InstantiationException e2) {
            ro6.m16605p(z23.m20933o(cls, "Cannot create an instance of "), e2);
            return null;
        } catch (NoSuchMethodException e3) {
            ro6.m16605p(z23.m20933o(cls, "Cannot create an instance of "), e3);
            return null;
        } catch (InvocationTargetException e4) {
            ro6.m16605p(z23.m20933o(cls, "Cannot create an instance of "), e4);
            return null;
        }
    }

    public ViewModelProvider$AndroidViewModelFactory() {
        this(null, 0);
    }

    public ViewModelProvider$AndroidViewModelFactory(Application application, int i) {
        this.f1942b = application;
    }
}
