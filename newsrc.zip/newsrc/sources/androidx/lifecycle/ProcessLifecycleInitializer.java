package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.HashSet;
import java.util.List;
import kotlin.Metadata;
import p000.C1521v3;
import p000.gh5;
import p000.m96;
import p000.q96;
import p000.r96;
import p000.sf8;
import p000.tf8;
import p000.yj3;
import p000.ze7;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, m12198d2 = {"Landroidx/lifecycle/ProcessLifecycleInitializer;", "Lgh5;", "Lx96;", "<init>", "()V", "lifecycle-process_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public final class ProcessLifecycleInitializer implements gh5 {
    @Override // p000.gh5
    /* JADX INFO: renamed from: a */
    public final List mo1052a() {
        return yj3.f48828e;
    }

    @Override // p000.gh5
    /* JADX INFO: renamed from: b */
    public final Object mo1053b(Context context) {
        context.getClass();
        ze7 ze7VarM21130y = ze7.m21130y(context);
        ze7VarM21130y.getClass();
        if (!((HashSet) ze7VarM21130y.f50209y).contains(ProcessLifecycleInitializer.class)) {
            C1521v3.m18909p("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
            return null;
        }
        if (!r96.f36201a.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            applicationContext.getClass();
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new q96());
        }
        tf8 tf8Var = tf8.f40152E;
        tf8Var.getClass();
        tf8Var.f40153A = new Handler();
        tf8Var.f40154B.m248e(m96.ON_CREATE);
        Context applicationContext2 = context.getApplicationContext();
        applicationContext2.getClass();
        ((Application) applicationContext2).registerActivityLifecycleCallbacks(new sf8(tf8Var));
        return tf8Var;
    }
}
