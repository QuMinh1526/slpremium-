package androidx.navigation.fragment;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.AbstractC0165v;
import androidx.fragment.app.AbstractComponentCallbacksC0156m;
import androidx.fragment.app.C0142a;
import androidx.fragment.app.FragmentContainerView;
import com.squareup.picasso.BuildConfig;
import ginlemon.flowerfree.R;
import kotlin.Metadata;
import p000.C1521v3;
import p000.aja;
import p000.ay3;
import p000.bo8;
import p000.do8;
import p000.pq6;
import p000.r17;
import p000.um9;
import p000.v07;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0016\u0018\u00002\u00020\u00012\u00020\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, m12198d2 = {"Landroidx/navigation/fragment/NavHostFragment;", "Landroidx/fragment/app/m;", BuildConfig.VERSION_NAME, "<init>", "()V", "navigation-fragment_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public class NavHostFragment extends AbstractComponentCallbacksC0156m {

    /* JADX INFO: renamed from: e */
    public final aja f1950e = new aja(new ay3(this, 25));

    /* JADX INFO: renamed from: i */
    public View f1951i;

    /* JADX INFO: renamed from: y */
    public int f1952y;

    /* JADX INFO: renamed from: z */
    public boolean f1953z;

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onAttach(Context context) {
        context.getClass();
        super.onAttach(context);
        if (this.f1953z) {
            AbstractC0165v parentFragmentManager = getParentFragmentManager();
            parentFragmentManager.getClass();
            C0142a c0142a = new C0142a(parentFragmentManager);
            c0142a.m1079p(this);
            c0142a.m1070g(false);
        }
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onCreate(Bundle bundle) {
        if (bundle != null && bundle.getBoolean("android-support-nav:fragment:defaultHost", false)) {
            this.f1953z = true;
            AbstractC0165v parentFragmentManager = getParentFragmentManager();
            parentFragmentManager.getClass();
            C0142a c0142a = new C0142a(parentFragmentManager);
            c0142a.m1079p(this);
            c0142a.m1070g(false);
        }
        super.onCreate(bundle);
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater.getClass();
        Context context = layoutInflater.getContext();
        context.getClass();
        FragmentContainerView fragmentContainerView = new FragmentContainerView(context);
        int id = getId();
        if (id == 0 || id == -1) {
            id = R.id.nav_host_fragment_container;
        }
        fragmentContainerView.setId(id);
        return fragmentContainerView;
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onDestroyView() {
        super.onDestroyView();
        View view = this.f1951i;
        if (view != null) {
            v07 v07Var = (v07) um9.m18510u(um9.m18503B(um9.m18513x(view, new pq6(24)), new pq6(25)));
            if (v07Var == null) {
                C1521v3.m18912s(view, "View ", " does not have a NavController set");
                return;
            } else if (v07Var == ((r17) this.f1950e.getValue())) {
                view.setTag(R.id.nav_controller_view_tag, null);
            }
        }
        this.f1951i = null;
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onInflate(Context context, AttributeSet attributeSet, Bundle bundle) {
        context.getClass();
        attributeSet.getClass();
        super.onInflate(context, attributeSet, bundle);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, bo8.f4379b);
        typedArrayObtainStyledAttributes.getClass();
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            this.f1952y = resourceId;
        }
        typedArrayObtainStyledAttributes.recycle();
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, do8.f11165c);
        typedArrayObtainStyledAttributes2.getClass();
        if (typedArrayObtainStyledAttributes2.getBoolean(0, false)) {
            this.f1953z = true;
        }
        typedArrayObtainStyledAttributes2.recycle();
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onSaveInstanceState(Bundle bundle) {
        bundle.getClass();
        if (this.f1953z) {
            bundle.putBoolean("android-support-nav:fragment:defaultHost", true);
        }
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onViewCreated(View view, Bundle bundle) {
        view.getClass();
        super.onViewCreated(view, bundle);
        if (!(view instanceof ViewGroup)) {
            C1521v3.m18908o(view, "created host view ", " is not a ViewGroup");
            return;
        }
        aja ajaVar = this.f1950e;
        view.setTag(R.id.nav_controller_view_tag, (r17) ajaVar.getValue());
        ViewGroup viewGroup = (ViewGroup) view;
        if (viewGroup.getParent() != null) {
            Object parent = viewGroup.getParent();
            parent.getClass();
            View view2 = (View) parent;
            this.f1951i = view2;
            if (view2.getId() == getId()) {
                View view3 = this.f1951i;
                view3.getClass();
                view3.setTag(R.id.nav_controller_view_tag, (r17) ajaVar.getValue());
            }
        }
    }
}
