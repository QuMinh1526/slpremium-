package androidx.navigation.fragment;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.AbstractC0165v;
import androidx.fragment.app.AbstractComponentCallbacksC0156m;
import androidx.fragment.app.C0142a;
import androidx.fragment.app.FragmentContainerView;
import androidx.slidingpanelayout.widget.SlidingPaneLayout;
import ginlemon.flowerfree.R;
import kotlin.Metadata;
import p000.C0478f2;
import p000.ViewOnLayoutChangeListenerC0515g2;
import p000.bo8;
import p000.og7;
import p000.ul5;
import p000.x96;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b&\u0018\u00002\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, m12198d2 = {"Landroidx/navigation/fragment/AbstractListDetailFragment;", "Landroidx/fragment/app/m;", "<init>", "()V", "f2", "navigation-fragment_release"}, m12199k = 1, m12200mv = {2, 0, 0}, m12202xi = 48)
public abstract class AbstractListDetailFragment extends AbstractComponentCallbacksC0156m {

    /* JADX INFO: renamed from: e */
    public C0478f2 f1948e;

    /* JADX INFO: renamed from: i */
    public int f1949i;

    /* JADX INFO: renamed from: j */
    public abstract View m1203j();

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        NavHostFragment navHostFragment;
        Bundle bundle2;
        layoutInflater.getClass();
        if (bundle != null) {
            this.f1949i = bundle.getInt("android-support-nav:fragment:graphId");
        }
        SlidingPaneLayout slidingPaneLayout = new SlidingPaneLayout(layoutInflater.getContext(), null);
        slidingPaneLayout.setId(R.id.sliding_pane_layout);
        View viewM1203j = m1203j();
        if (!ul5.m18482l(viewM1203j, slidingPaneLayout) && !ul5.m18482l(viewM1203j.getParent(), slidingPaneLayout)) {
            slidingPaneLayout.addView(viewM1203j);
        }
        Context context = layoutInflater.getContext();
        context.getClass();
        FragmentContainerView fragmentContainerView = new FragmentContainerView(context);
        fragmentContainerView.setId(R.id.sliding_pane_detail_container);
        SlidingPaneLayout.LayoutParams layoutParams = new SlidingPaneLayout.LayoutParams(layoutInflater.getContext().getResources().getDimensionPixelSize(R.dimen.sliding_pane_detail_pane_width), -1);
        layoutParams.f2215a = 1.0f;
        slidingPaneLayout.addView(fragmentContainerView, layoutParams);
        AbstractComponentCallbacksC0156m abstractComponentCallbacksC0156mM1120B = getChildFragmentManager().m1120B(R.id.sliding_pane_detail_container);
        boolean z = false;
        if (abstractComponentCallbacksC0156mM1120B != null) {
        } else {
            int i = this.f1949i;
            if (i != 0) {
                if (i != 0) {
                    bundle2 = new Bundle();
                    bundle2.putInt("android-support-nav:fragment:graphId", i);
                } else {
                    bundle2 = null;
                }
                navHostFragment = new NavHostFragment();
                if (bundle2 != null) {
                    navHostFragment.setArguments(bundle2);
                }
            } else {
                navHostFragment = new NavHostFragment();
            }
            AbstractC0165v childFragmentManager = getChildFragmentManager();
            childFragmentManager.getClass();
            C0142a c0142a = new C0142a(childFragmentManager);
            c0142a.f1928p = true;
            c0142a.mo1068d(R.id.sliding_pane_detail_container, navHostFragment, null, 1);
            c0142a.m1070g(false);
        }
        this.f1948e = new C0478f2(slidingPaneLayout);
        if (!slidingPaneLayout.isLaidOut() || slidingPaneLayout.isLayoutRequested()) {
            slidingPaneLayout.addOnLayoutChangeListener(new ViewOnLayoutChangeListenerC0515g2(this, slidingPaneLayout));
        } else {
            C0478f2 c0478f2 = this.f1948e;
            c0478f2.getClass();
            if (slidingPaneLayout.f2210e && slidingPaneLayout.m1529d()) {
                z = true;
            }
            c0478f2.m12054f(z);
        }
        og7 onBackPressedDispatcher = requireActivity().getOnBackPressedDispatcher();
        x96 viewLifecycleOwner = getViewLifecycleOwner();
        viewLifecycleOwner.getClass();
        C0478f2 c0478f3 = this.f1948e;
        c0478f3.getClass();
        onBackPressedDispatcher.m14703a(viewLifecycleOwner, c0478f3);
        return slidingPaneLayout;
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onInflate(Context context, AttributeSet attributeSet, Bundle bundle) {
        context.getClass();
        attributeSet.getClass();
        super.onInflate(context, attributeSet, bundle);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, bo8.f4379b);
        typedArrayObtainStyledAttributes.getClass();
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            this.f1949i = resourceId;
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onSaveInstanceState(Bundle bundle) {
        bundle.getClass();
        int i = this.f1949i;
        if (i != 0) {
            bundle.putInt("android-support-nav:fragment:graphId", i);
        }
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onViewCreated(View view, Bundle bundle) {
        view.getClass();
        super.onViewCreated(view, bundle);
        View viewRequireView = requireView();
        viewRequireView.getClass();
        ((SlidingPaneLayout) viewRequireView).getChildAt(0).getClass();
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0026  */
    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onViewStateRestored(Bundle bundle) {
        boolean z;
        super.onViewStateRestored(bundle);
        C0478f2 c0478f2 = this.f1948e;
        c0478f2.getClass();
        View viewRequireView = requireView();
        viewRequireView.getClass();
        if (((SlidingPaneLayout) viewRequireView).f2210e) {
            View viewRequireView2 = requireView();
            viewRequireView2.getClass();
            if (((SlidingPaneLayout) viewRequireView2).m1529d()) {
                z = true;
            } else {
                z = false;
            }
        } else {
            z = false;
        }
        c0478f2.m12054f(z);
    }
}
