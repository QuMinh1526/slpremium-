package androidx.drawerlayout.widget;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.customview.view.AbsSavedState;
import java.util.ArrayList;
import java.util.WeakHashMap;
import p000.C0446e7;
import p000.C1521v3;
import p000.b0c;
import p000.fbb;
import p000.fu0;
import p000.li5;
import p000.m73;
import p000.n73;
import p000.nxa;
import p000.o73;
import p000.obb;
import p000.oj2;
import p000.wbb;
import p000.zn8;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class DrawerLayout extends ViewGroup {

    /* JADX INFO: renamed from: a0 */
    public static final int[] f1688a0 = {R.attr.colorPrimaryDark};

    /* JADX INFO: renamed from: b0 */
    public static final int[] f1689b0 = {R.attr.layout_gravity};

    /* JADX INFO: renamed from: c0 */
    public static final boolean f1690c0;

    /* JADX INFO: renamed from: A */
    public final Paint f1691A;

    /* JADX INFO: renamed from: B */
    public final wbb f1692B;

    /* JADX INFO: renamed from: C */
    public final wbb f1693C;

    /* JADX INFO: renamed from: D */
    public final C0140b f1694D;

    /* JADX INFO: renamed from: E */
    public final C0140b f1695E;

    /* JADX INFO: renamed from: F */
    public int f1696F;

    /* JADX INFO: renamed from: G */
    public boolean f1697G;

    /* JADX INFO: renamed from: H */
    public boolean f1698H;

    /* JADX INFO: renamed from: I */
    public int f1699I;

    /* JADX INFO: renamed from: J */
    public int f1700J;

    /* JADX INFO: renamed from: K */
    public int f1701K;

    /* JADX INFO: renamed from: L */
    public int f1702L;

    /* JADX INFO: renamed from: M */
    public boolean f1703M;

    /* JADX INFO: renamed from: N */
    public ArrayList f1704N;

    /* JADX INFO: renamed from: O */
    public float f1705O;

    /* JADX INFO: renamed from: P */
    public float f1706P;

    /* JADX INFO: renamed from: Q */
    public final Drawable f1707Q;

    /* JADX INFO: renamed from: R */
    public WindowInsets f1708R;

    /* JADX INFO: renamed from: S */
    public boolean f1709S;

    /* JADX INFO: renamed from: T */
    public final ArrayList f1710T;

    /* JADX INFO: renamed from: U */
    public Rect f1711U;

    /* JADX INFO: renamed from: V */
    public Matrix f1712V;

    /* JADX INFO: renamed from: W */
    public final oj2 f1713W;

    /* JADX INFO: renamed from: e */
    public final float f1714e;

    /* JADX INFO: renamed from: i */
    public final int f1715i;

    /* JADX INFO: renamed from: y */
    public int f1716y;

    /* JADX INFO: renamed from: z */
    public float f1717z;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: a */
        public int f1718a;

        /* JADX INFO: renamed from: b */
        public float f1719b;

        /* JADX INFO: renamed from: c */
        public boolean f1720c;

        /* JADX INFO: renamed from: d */
        public int f1721d;

        public LayoutParams(@NonNull Context context, @Nullable AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f1718a = 0;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, DrawerLayout.f1689b0);
            this.f1718a = typedArrayObtainStyledAttributes.getInt(0, 0);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0139a();

        /* JADX INFO: renamed from: A */
        public int f1722A;

        /* JADX INFO: renamed from: e */
        public int f1723e;

        /* JADX INFO: renamed from: i */
        public int f1724i;

        /* JADX INFO: renamed from: y */
        public int f1725y;

        /* JADX INFO: renamed from: z */
        public int f1726z;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f1723e = 0;
            this.f1723e = parcel.readInt();
            this.f1724i = parcel.readInt();
            this.f1725y = parcel.readInt();
            this.f1726z = parcel.readInt();
            this.f1722A = parcel.readInt();
        }

        @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f1723e);
            parcel.writeInt(this.f1724i);
            parcel.writeInt(this.f1725y);
            parcel.writeInt(this.f1726z);
            parcel.writeInt(this.f1722A);
        }
    }

    static {
        f1690c0 = Build.VERSION.SDK_INT >= 29;
    }

    public DrawerLayout(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        new n73(0);
        this.f1716y = -1728053248;
        this.f1691A = new Paint();
        this.f1698H = true;
        this.f1699I = 3;
        this.f1700J = 3;
        this.f1701K = 3;
        this.f1702L = 3;
        this.f1713W = new oj2(this, 9);
        setDescendantFocusability(262144);
        float f = getResources().getDisplayMetrics().density;
        this.f1715i = (int) ((64.0f * f) + 0.5f);
        float f2 = f * 400.0f;
        C0140b c0140b = new C0140b(this, 3);
        this.f1694D = c0140b;
        C0140b c0140b2 = new C0140b(this, 5);
        this.f1695E = c0140b2;
        wbb wbbVar = new wbb(getContext(), this, c0140b);
        wbbVar.f45173b = (int) (wbbVar.f45173b * 1.0f);
        this.f1692B = wbbVar;
        wbbVar.f45188q = 1;
        wbbVar.f45185n = f2;
        c0140b.f1728b = wbbVar;
        wbb wbbVar2 = new wbb(getContext(), this, c0140b2);
        wbbVar2.f45173b = (int) (1.0f * wbbVar2.f45173b);
        this.f1693C = wbbVar2;
        wbbVar2.f45188q = 2;
        wbbVar2.f45185n = f2;
        c0140b2.f1728b = wbbVar2;
        setFocusableInTouchMode(true);
        WeakHashMap weakHashMap = obb.f31348a;
        setImportantForAccessibility(1);
        obb.m14621n(this, new fu0(this));
        setMotionEventSplittingEnabled(false);
        if (getFitsSystemWindows()) {
            setOnApplyWindowInsetsListener(new m73());
            setSystemUiVisibility(1280);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(f1688a0);
            try {
                this.f1707Q = typedArrayObtainStyledAttributes.getDrawable(0);
                typedArrayObtainStyledAttributes.recycle();
            } catch (Throwable th) {
                typedArrayObtainStyledAttributes.recycle();
                throw th;
            }
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, zn8.f50587a, i, 0);
        try {
            if (typedArrayObtainStyledAttributes2.hasValue(0)) {
                this.f1714e = typedArrayObtainStyledAttributes2.getDimension(0, 0.0f);
            } else {
                this.f1714e = getResources().getDimension(ginlemon.flowerfree.R.dimen.def_drawer_elevation);
            }
            typedArrayObtainStyledAttributes2.recycle();
            this.f1710T = new ArrayList();
        } catch (Throwable th2) {
            typedArrayObtainStyledAttributes2.recycle();
            throw th2;
        }
    }

    /* JADX INFO: renamed from: i */
    public static String m1023i(int i) {
        if ((i & 3) == 3) {
            return "LEFT";
        }
        return (i & 5) == 5 ? "RIGHT" : Integer.toHexString(i);
    }

    /* JADX INFO: renamed from: j */
    public static boolean m1024j(View view) {
        return ((LayoutParams) view.getLayoutParams()).f1718a == 0;
    }

    /* JADX INFO: renamed from: k */
    public static boolean m1025k(View view) {
        if (m1026l(view)) {
            return (((LayoutParams) view.getLayoutParams()).f1721d & 1) == 1;
        }
        nxa.m14382h(view, "View ", " is not a drawer");
        return false;
    }

    /* JADX INFO: renamed from: l */
    public static boolean m1026l(View view) {
        int i = ((LayoutParams) view.getLayoutParams()).f1718a;
        WeakHashMap weakHashMap = obb.f31348a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i, view.getLayoutDirection());
        return ((absoluteGravity & 3) == 0 && (absoluteGravity & 5) == 0) ? false : true;
    }

    /* JADX INFO: renamed from: m */
    public static boolean m1027m(View view) {
        if (m1026l(view)) {
            return ((LayoutParams) view.getLayoutParams()).f1719b > 0.0f;
        }
        nxa.m14382h(view, "View ", " is not a drawer");
        return false;
    }

    /* JADX INFO: renamed from: a */
    public final boolean m1028a(int i, View view) {
        return (m1035h(view) & i) == i;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i, int i2) {
        ArrayList arrayList2;
        if (getDescendantFocusability() == 393216) {
            return;
        }
        int childCount = getChildCount();
        int i3 = 0;
        boolean z = false;
        while (true) {
            arrayList2 = this.f1710T;
            if (i3 >= childCount) {
                break;
            }
            View childAt = getChildAt(i3);
            if (!m1026l(childAt)) {
                arrayList2.add(childAt);
            } else if (m1025k(childAt)) {
                childAt.addFocusables(arrayList, i, i2);
                z = true;
            }
            i3++;
        }
        if (!z) {
            int size = arrayList2.size();
            for (int i4 = 0; i4 < size; i4++) {
                View view = (View) arrayList2.get(i4);
                if (view.getVisibility() == 0) {
                    view.addFocusables(arrayList, i, i2);
                }
            }
        }
        arrayList2.clear();
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        View childAt;
        super.addView(view, i, layoutParams);
        int childCount = getChildCount();
        int i2 = 0;
        while (true) {
            if (i2 >= childCount) {
                childAt = null;
                break;
            }
            childAt = getChildAt(i2);
            if ((((LayoutParams) childAt.getLayoutParams()).f1721d & 1) == 1) {
                break;
            } else {
                i2++;
            }
        }
        if (childAt != null || m1026l(view)) {
            WeakHashMap weakHashMap = obb.f31348a;
            view.setImportantForAccessibility(4);
        } else {
            WeakHashMap weakHashMap2 = obb.f31348a;
            view.setImportantForAccessibility(1);
        }
    }

    /* JADX INFO: renamed from: b */
    public final void m1029b(View view, boolean z) {
        if (!m1026l(view)) {
            nxa.m14382h(view, "View ", " is not a sliding drawer");
            return;
        }
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (this.f1698H) {
            layoutParams.f1719b = 0.0f;
            layoutParams.f1721d = 0;
        } else if (z) {
            layoutParams.f1721d |= 4;
            if (m1028a(3, view)) {
                this.f1692B.m19480u(view, -view.getWidth(), view.getTop());
            } else {
                this.f1693C.m19480u(view, getWidth(), view.getTop());
            }
        } else {
            float f = ((LayoutParams) view.getLayoutParams()).f1719b;
            float width = view.getWidth();
            int i = ((int) (width * 0.0f)) - ((int) (f * width));
            if (!m1028a(3, view)) {
                i = -i;
            }
            view.offsetLeftAndRight(i);
            m1038p(view, 0.0f);
            m1041s(0, view);
            view.setVisibility(4);
        }
        invalidate();
    }

    /* JADX INFO: renamed from: c */
    public final void m1030c(boolean z) {
        int childCount = getChildCount();
        boolean zM19480u = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if (m1026l(childAt) && (!z || layoutParams.f1720c)) {
                zM19480u |= m1028a(3, childAt) ? this.f1692B.m19480u(childAt, -childAt.getWidth(), childAt.getTop()) : this.f1693C.m19480u(childAt, getWidth(), childAt.getTop());
                layoutParams.f1720c = false;
            }
        }
        C0140b c0140b = this.f1694D;
        c0140b.f1730d.removeCallbacks(c0140b.f1729c);
        C0140b c0140b2 = this.f1695E;
        c0140b2.f1730d.removeCallbacks(c0140b2.f1729c);
        if (zM19480u) {
            invalidate();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public final void computeScroll() {
        int childCount = getChildCount();
        float fMax = 0.0f;
        for (int i = 0; i < childCount; i++) {
            fMax = Math.max(fMax, ((LayoutParams) getChildAt(i).getLayoutParams()).f1719b);
        }
        this.f1717z = fMax;
        boolean zM19468h = this.f1692B.m19468h();
        boolean zM19468h2 = this.f1693C.m19468h();
        if (zM19468h || zM19468h2) {
            WeakHashMap weakHashMap = obb.f31348a;
            postInvalidateOnAnimation();
        }
    }

    /* JADX INFO: renamed from: d */
    public final View m1031d(int i) {
        WeakHashMap weakHashMap = obb.f31348a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection()) & 7;
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if ((m1035h(childAt) & 7) == absoluteGravity) {
                return childAt;
            }
        }
        return null;
    }

    @Override // android.view.View
    public final boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        boolean zDispatchGenericMotionEvent;
        if ((motionEvent.getSource() & 2) == 0 || motionEvent.getAction() == 10 || this.f1717z <= 0.0f) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        int childCount = getChildCount();
        if (childCount == 0) {
            return false;
        }
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        for (int i = childCount - 1; i >= 0; i--) {
            View childAt = getChildAt(i);
            if (this.f1711U == null) {
                this.f1711U = new Rect();
            }
            childAt.getHitRect(this.f1711U);
            if (this.f1711U.contains((int) x, (int) y) && !m1024j(childAt)) {
                if (childAt.getMatrix().isIdentity()) {
                    float scrollX = getScrollX() - childAt.getLeft();
                    float scrollY = getScrollY() - childAt.getTop();
                    motionEvent.offsetLocation(scrollX, scrollY);
                    zDispatchGenericMotionEvent = childAt.dispatchGenericMotionEvent(motionEvent);
                    motionEvent.offsetLocation(-scrollX, -scrollY);
                } else {
                    float scrollX2 = getScrollX() - childAt.getLeft();
                    float scrollY2 = getScrollY() - childAt.getTop();
                    MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                    motionEventObtain.offsetLocation(scrollX2, scrollY2);
                    Matrix matrix = childAt.getMatrix();
                    if (!matrix.isIdentity()) {
                        if (this.f1712V == null) {
                            this.f1712V = new Matrix();
                        }
                        matrix.invert(this.f1712V);
                        motionEventObtain.transform(this.f1712V);
                    }
                    zDispatchGenericMotionEvent = childAt.dispatchGenericMotionEvent(motionEventObtain);
                    motionEventObtain.recycle();
                }
                if (zDispatchGenericMotionEvent) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j) {
        Drawable background;
        int height = getHeight();
        boolean zM1024j = m1024j(view);
        int width = getWidth();
        int iSave = canvas.save();
        int i = 0;
        if (zM1024j) {
            int childCount = getChildCount();
            int i2 = 0;
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                if (childAt != view && childAt.getVisibility() == 0 && (background = childAt.getBackground()) != null && background.getOpacity() == -1 && m1026l(childAt) && childAt.getHeight() >= height) {
                    if (m1028a(3, childAt)) {
                        int right = childAt.getRight();
                        if (right > i2) {
                            i2 = right;
                        }
                    } else {
                        int left = childAt.getLeft();
                        if (left < width) {
                            width = left;
                        }
                    }
                }
            }
            canvas.clipRect(i2, 0, width, getHeight());
            i = i2;
        }
        boolean zDrawChild = super.drawChild(canvas, view, j);
        canvas.restoreToCount(iSave);
        float f = this.f1717z;
        if (f > 0.0f && zM1024j) {
            int i4 = this.f1716y;
            Paint paint = this.f1691A;
            paint.setColor((((int) ((((-16777216) & i4) >>> 24) * f)) << 24) | (i4 & 16777215));
            canvas.drawRect(i, 0.0f, width, getHeight(), paint);
        }
        return zDrawChild;
    }

    /* JADX INFO: renamed from: e */
    public final View m1032e() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (m1026l(childAt) && m1027m(childAt)) {
                return childAt;
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: f */
    public final int m1033f(int i) {
        WeakHashMap weakHashMap = obb.f31348a;
        int layoutDirection = getLayoutDirection();
        if (i == 3) {
            int i2 = this.f1699I;
            if (i2 != 3) {
                return i2;
            }
            int i3 = layoutDirection == 0 ? this.f1701K : this.f1702L;
            if (i3 != 3) {
                return i3;
            }
            return 0;
        }
        if (i == 5) {
            int i4 = this.f1700J;
            if (i4 != 3) {
                return i4;
            }
            int i5 = layoutDirection == 0 ? this.f1702L : this.f1701K;
            if (i5 != 3) {
                return i5;
            }
            return 0;
        }
        if (i == 8388611) {
            int i6 = this.f1701K;
            if (i6 != 3) {
                return i6;
            }
            int i7 = layoutDirection == 0 ? this.f1699I : this.f1700J;
            if (i7 != 3) {
                return i7;
            }
            return 0;
        }
        if (i != 8388613) {
            return 0;
        }
        int i8 = this.f1702L;
        if (i8 != 3) {
            return i8;
        }
        int i9 = layoutDirection == 0 ? this.f1700J : this.f1699I;
        if (i9 != 3) {
            return i9;
        }
        return 0;
    }

    /* JADX INFO: renamed from: g */
    public final int m1034g(View view) {
        if (m1026l(view)) {
            return m1033f(((LayoutParams) view.getLayoutParams()).f1718a);
        }
        nxa.m14382h(view, "View ", " is not a drawer");
        return 0;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        LayoutParams layoutParams = new LayoutParams(-1, -1);
        layoutParams.f1718a = 0;
        return layoutParams;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof LayoutParams) {
            LayoutParams layoutParams2 = (LayoutParams) layoutParams;
            LayoutParams layoutParams3 = new LayoutParams(layoutParams2);
            layoutParams3.f1718a = 0;
            layoutParams3.f1718a = layoutParams2.f1718a;
            return layoutParams3;
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            LayoutParams layoutParams4 = new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams);
            layoutParams4.f1718a = 0;
            return layoutParams4;
        }
        LayoutParams layoutParams5 = new LayoutParams(layoutParams);
        layoutParams5.f1718a = 0;
        return layoutParams5;
    }

    /* JADX INFO: renamed from: h */
    public final int m1035h(View view) {
        int i = ((LayoutParams) view.getLayoutParams()).f1718a;
        WeakHashMap weakHashMap = obb.f31348a;
        return Gravity.getAbsoluteGravity(i, getLayoutDirection());
    }

    /* JADX INFO: renamed from: n */
    public final void m1036n(View view) {
        if (!m1026l(view)) {
            nxa.m14382h(view, "View ", " is not a sliding drawer");
            return;
        }
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (this.f1698H) {
            layoutParams.f1719b = 1.0f;
            layoutParams.f1721d = 1;
            m1040r(view, true);
            m1039q(view);
        } else {
            layoutParams.f1721d |= 2;
            if (m1028a(3, view)) {
                this.f1692B.m19480u(view, 0, view.getTop());
            } else {
                this.f1693C.m19480u(view, getWidth() - view.getWidth(), view.getTop());
            }
        }
        invalidate();
    }

    /* JADX INFO: renamed from: o */
    public final void m1037o(int i, int i2) {
        View viewM1031d;
        WeakHashMap weakHashMap = obb.f31348a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, getLayoutDirection());
        if (i2 == 3) {
            this.f1699I = i;
        } else if (i2 == 5) {
            this.f1700J = i;
        } else if (i2 == 8388611) {
            this.f1701K = i;
        } else if (i2 == 8388613) {
            this.f1702L = i;
        }
        if (i != 0) {
            (absoluteGravity == 3 ? this.f1692B : this.f1693C).m19462b();
        }
        if (i != 1) {
            if (i == 2 && (viewM1031d = m1031d(absoluteGravity)) != null) {
                m1036n(viewM1031d);
                return;
            }
            return;
        }
        View viewM1031d2 = m1031d(absoluteGravity);
        if (viewM1031d2 != null) {
            m1029b(viewM1031d2, true);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1698H = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f1698H = true;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        Drawable drawable;
        super.onDraw(canvas);
        if (!this.f1709S || (drawable = this.f1707Q) == null) {
            return;
        }
        WindowInsets windowInsets = this.f1708R;
        int systemWindowInsetTop = windowInsets != null ? windowInsets.getSystemWindowInsetTop() : 0;
        if (systemWindowInsetTop > 0) {
            drawable.setBounds(0, 0, getWidth(), systemWindowInsetTop);
            drawable.draw(canvas);
        }
    }

    /* JADX WARN: Code duplicated, block: B:18:0x005e  */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z;
        View viewM19469i;
        int actionMasked = motionEvent.getActionMasked();
        wbb wbbVar = this.f1692B;
        boolean zM19479t = wbbVar.m19479t(motionEvent) | this.f1693C.m19479t(motionEvent);
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                m1030c(true);
                this.f1703M = false;
            } else if (actionMasked == 2) {
                int length = wbbVar.f45175d.length;
                for (int i = 0; i < length; i++) {
                    if ((wbbVar.f45182k & (1 << i)) != 0) {
                        float f = wbbVar.f45177f[i] - wbbVar.f45175d[i];
                        float f2 = wbbVar.f45178g[i] - wbbVar.f45176e[i];
                        float f3 = (f2 * f2) + (f * f);
                        int i2 = wbbVar.f45173b;
                        if (f3 > i2 * i2) {
                            C0140b c0140b = this.f1694D;
                            c0140b.f1730d.removeCallbacks(c0140b.f1729c);
                            C0140b c0140b2 = this.f1695E;
                            c0140b2.f1730d.removeCallbacks(c0140b2.f1729c);
                            break;
                        }
                    }
                }
            } else if (actionMasked == 3) {
                m1030c(true);
                this.f1703M = false;
            }
            z = false;
        } else {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            this.f1705O = x;
            this.f1706P = y;
            z = this.f1717z > 0.0f && (viewM19469i = wbbVar.m19469i((int) x, (int) y)) != null && m1024j(viewM19469i);
            this.f1703M = false;
        }
        if (!zM19479t && !z) {
            int childCount = getChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                if (!((LayoutParams) getChildAt(i3).getLayoutParams()).f1720c) {
                }
            }
            if (!this.f1703M) {
                return false;
            }
        }
        return true;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || m1032e() == null) {
            return super.onKeyDown(i, keyEvent);
        }
        keyEvent.startTracking();
        return true;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return super.onKeyUp(i, keyEvent);
        }
        View viewM1032e = m1032e();
        if (viewM1032e != null && m1034g(viewM1032e) == 0) {
            m1030c(false);
        }
        return viewM1032e != null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        WindowInsets rootWindowInsets;
        float f;
        int i5;
        boolean z2 = true;
        this.f1697G = true;
        int i6 = i3 - i;
        int childCount = getChildCount();
        int i7 = 0;
        while (i7 < childCount) {
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (m1024j(childAt)) {
                    int i8 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
                    childAt.layout(i8, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, childAt.getMeasuredWidth() + i8, childAt.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin);
                } else {
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (m1028a(3, childAt)) {
                        float f2 = measuredWidth;
                        i5 = (-measuredWidth) + ((int) (layoutParams.f1719b * f2));
                        f = (measuredWidth + i5) / f2;
                    } else {
                        float f3 = measuredWidth;
                        int i9 = i6 - ((int) (layoutParams.f1719b * f3));
                        f = (i6 - i9) / f3;
                        i5 = i9;
                    }
                    boolean z3 = f != layoutParams.f1719b ? z2 : false;
                    int i10 = layoutParams.f1718a & 112;
                    if (i10 == 16) {
                        int i11 = i4 - i2;
                        int i12 = (i11 - measuredHeight) / 2;
                        int i13 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
                        if (i12 < i13) {
                            i12 = i13;
                        } else {
                            int i14 = i12 + measuredHeight;
                            int i15 = i11 - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
                            if (i14 > i15) {
                                i12 = i15 - measuredHeight;
                            }
                        }
                        childAt.layout(i5, i12, measuredWidth + i5, measuredHeight + i12);
                    } else if (i10 != 80) {
                        int i16 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
                        childAt.layout(i5, i16, measuredWidth + i5, measuredHeight + i16);
                    } else {
                        int i17 = i4 - i2;
                        childAt.layout(i5, (i17 - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin) - childAt.getMeasuredHeight(), measuredWidth + i5, i17 - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin);
                    }
                    if (z3) {
                        m1038p(childAt, f);
                    }
                    int i18 = layoutParams.f1719b > 0.0f ? 0 : 4;
                    if (childAt.getVisibility() != i18) {
                        childAt.setVisibility(i18);
                    }
                }
            }
            i7++;
            z2 = true;
        }
        if (f1690c0 && (rootWindowInsets = getRootWindowInsets()) != null) {
            li5 li5VarMo18098k = b0c.m1950h(rootWindowInsets, null).f3168a.mo18098k();
            wbb wbbVar = this.f1692B;
            wbbVar.f45186o = Math.max(wbbVar.f45187p, li5VarMo18098k.f26704a);
            wbb wbbVar2 = this.f1693C;
            wbbVar2.f45186o = Math.max(wbbVar2.f45187p, li5VarMo18098k.f26706c);
        }
        this.f1697G = false;
        this.f1698H = false;
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0038  */
    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        boolean z;
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i);
        int size2 = View.MeasureSpec.getSize(i2);
        if (mode != 1073741824 || mode2 != 1073741824) {
            if (!isInEditMode()) {
                C1521v3.m18903j("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
                return;
            }
            if (mode == 0) {
                size = 300;
            }
            if (mode2 == 0) {
                size2 = 300;
            }
        }
        setMeasuredDimension(size, size2);
        if (this.f1708R != null) {
            WeakHashMap weakHashMap = obb.f31348a;
            if (getFitsSystemWindows()) {
                z = true;
            } else {
                z = false;
            }
        } else {
            z = false;
        }
        WeakHashMap weakHashMap2 = obb.f31348a;
        int layoutDirection = getLayoutDirection();
        int childCount = getChildCount();
        boolean z2 = false;
        boolean z3 = false;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (z) {
                    int absoluteGravity = Gravity.getAbsoluteGravity(layoutParams.f1718a, layoutDirection);
                    boolean fitsSystemWindows = childAt.getFitsSystemWindows();
                    WindowInsets windowInsetsReplaceSystemWindowInsets = this.f1708R;
                    if (fitsSystemWindows) {
                        if (absoluteGravity == 3) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetLeft(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), 0, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        } else if (absoluteGravity == 5) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(0, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetRight(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        }
                        childAt.dispatchApplyWindowInsets(windowInsetsReplaceSystemWindowInsets);
                    } else {
                        if (absoluteGravity == 3) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetLeft(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), 0, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        } else if (absoluteGravity == 5) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(0, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetRight(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        }
                        ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetLeft();
                        ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop();
                        ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin = windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetRight();
                        ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin = windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom();
                    }
                }
                if (m1024j(childAt)) {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec((size - ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin) - ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, 1073741824), View.MeasureSpec.makeMeasureSpec((size2 - ((ViewGroup.MarginLayoutParams) layoutParams).topMargin) - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, 1073741824));
                } else {
                    if (!m1026l(childAt)) {
                        throw new IllegalStateException("Child " + childAt + " at index " + i3 + " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
                    }
                    float fM8058e = fbb.m8058e(childAt);
                    float f = this.f1714e;
                    if (fM8058e != f) {
                        fbb.m8064k(childAt, f);
                    }
                    int iM1035h = m1035h(childAt) & 7;
                    boolean z4 = iM1035h == 3;
                    if ((z4 && z2) || (!z4 && z3)) {
                        C1521v3.m18902i(m1023i(iM1035h), "Child drawer has absolute gravity ", " but this DrawerLayout already has a drawer view along that edge");
                        return;
                    }
                    if (z4) {
                        z2 = true;
                    } else {
                        z3 = true;
                    }
                    childAt.measure(ViewGroup.getChildMeasureSpec(i, this.f1715i + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, ((ViewGroup.MarginLayoutParams) layoutParams).width), ViewGroup.getChildMeasureSpec(i2, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, ((ViewGroup.MarginLayoutParams) layoutParams).height));
                }
            }
        }
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        View viewM1031d;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        int i = savedState.f1723e;
        if (i != 0 && (viewM1031d = m1031d(i)) != null) {
            m1036n(viewM1031d);
        }
        int i2 = savedState.f1724i;
        if (i2 != 3) {
            m1037o(i2, 3);
        }
        int i3 = savedState.f1725y;
        if (i3 != 3) {
            m1037o(i3, 5);
        }
        int i4 = savedState.f1726z;
        if (i4 != 3) {
            m1037o(i4, 8388611);
        }
        int i5 = savedState.f1722A;
        if (i5 != 3) {
            m1037o(i5, 8388613);
        }
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f1723e = 0;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            LayoutParams layoutParams = (LayoutParams) getChildAt(i).getLayoutParams();
            int i2 = layoutParams.f1721d;
            boolean z = i2 == 1;
            boolean z2 = i2 == 2;
            if (z || z2) {
                savedState.f1723e = layoutParams.f1718a;
                break;
            }
        }
        savedState.f1724i = this.f1699I;
        savedState.f1725y = this.f1700J;
        savedState.f1726z = this.f1701K;
        savedState.f1722A = this.f1702L;
        return savedState;
    }

    /* JADX WARN: Code duplicated, block: B:26:0x006b  */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z;
        View childAt;
        wbb wbbVar = this.f1692B;
        wbbVar.m19472m(motionEvent);
        this.f1693C.m19472m(motionEvent);
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            this.f1705O = x;
            this.f1706P = y;
            this.f1703M = false;
            return true;
        }
        if (action != 1) {
            if (action != 3) {
                return true;
            }
            m1030c(true);
            this.f1703M = false;
            return true;
        }
        float x2 = motionEvent.getX();
        float y2 = motionEvent.getY();
        View viewM19469i = wbbVar.m19469i((int) x2, (int) y2);
        if (viewM19469i != null && m1024j(viewM19469i)) {
            float f = x2 - this.f1705O;
            float f2 = y2 - this.f1706P;
            int i = wbbVar.f45173b;
            if ((f2 * f2) + (f * f) < i * i) {
                int childCount = getChildCount();
                int i2 = 0;
                while (true) {
                    if (i2 >= childCount) {
                        childAt = null;
                        break;
                    }
                    childAt = getChildAt(i2);
                    if ((((LayoutParams) childAt.getLayoutParams()).f1721d & 1) == 1) {
                        break;
                    }
                    i2++;
                }
                z = childAt == null || m1034g(childAt) == 2;
            }
        }
        m1030c(z);
        return true;
    }

    /* JADX INFO: renamed from: p */
    public final void m1038p(View view, float f) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (f == layoutParams.f1719b) {
            return;
        }
        layoutParams.f1719b = f;
        ArrayList arrayList = this.f1704N;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((o73) this.f1704N.get(size)).onDrawerSlide(view, f);
            }
        }
    }

    /* JADX INFO: renamed from: q */
    public final void m1039q(View view) {
        C0446e7 c0446e7 = C0446e7.f12024n;
        obb.m14618k(c0446e7.m7322a(), view);
        obb.m14615h(0, view);
        if (!m1025k(view) || m1034g(view) == 2) {
            return;
        }
        obb.m14619l(view, c0446e7, null, this.f1713W);
    }

    /* JADX INFO: renamed from: r */
    public final void m1040r(View view, boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if ((z || m1026l(childAt)) && !(z && childAt == view)) {
                WeakHashMap weakHashMap = obb.f31348a;
                childAt.setImportantForAccessibility(4);
            } else {
                WeakHashMap weakHashMap2 = obb.f31348a;
                childAt.setImportantForAccessibility(1);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        if (z) {
            m1030c(true);
        }
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.f1697G) {
            return;
        }
        super.requestLayout();
    }

    /* JADX INFO: renamed from: s */
    public final void m1041s(int i, View view) {
        int i2;
        View rootView;
        int i3 = this.f1692B.f45172a;
        int i4 = this.f1693C.f45172a;
        if (i3 == 1 || i4 == 1) {
            i2 = 1;
        } else {
            i2 = 2;
            if (i3 != 2 && i4 != 2) {
                i2 = 0;
            }
        }
        if (view != null && i == 0) {
            float f = ((LayoutParams) view.getLayoutParams()).f1719b;
            if (f == 0.0f) {
                LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
                if ((layoutParams.f1721d & 1) == 1) {
                    layoutParams.f1721d = 0;
                    ArrayList arrayList = this.f1704N;
                    if (arrayList != null) {
                        for (int size = arrayList.size() - 1; size >= 0; size--) {
                            ((o73) this.f1704N.get(size)).onDrawerClosed(view);
                        }
                    }
                    m1040r(view, false);
                    m1039q(view);
                    if (hasWindowFocus() && (rootView = getRootView()) != null) {
                        rootView.sendAccessibilityEvent(32);
                    }
                }
            } else if (f == 1.0f) {
                LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
                if ((layoutParams2.f1721d & 1) == 0) {
                    layoutParams2.f1721d = 1;
                    ArrayList arrayList2 = this.f1704N;
                    if (arrayList2 != null) {
                        for (int size2 = arrayList2.size() - 1; size2 >= 0; size2--) {
                            ((o73) this.f1704N.get(size2)).onDrawerOpened(view);
                        }
                    }
                    m1040r(view, true);
                    m1039q(view);
                    if (hasWindowFocus()) {
                        sendAccessibilityEvent(32);
                    }
                }
            }
        }
        if (i2 != this.f1696F) {
            this.f1696F = i2;
            ArrayList arrayList3 = this.f1704N;
            if (arrayList3 != null) {
                for (int size3 = arrayList3.size() - 1; size3 >= 0; size3--) {
                    ((o73) this.f1704N.get(size3)).onDrawerStateChanged(i2);
                }
            }
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public DrawerLayout(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, ginlemon.flowerfree.R.attr.drawerLayoutStyle);
    }
}
