package androidx.drawerlayout.widget;

import android.view.View;
import p000.v09;
import p000.wbb;
import p000.wi0;

/* JADX INFO: renamed from: androidx.drawerlayout.widget.b */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public final class C0140b extends v09 {

    /* JADX INFO: renamed from: a */
    public final int f1727a;

    /* JADX INFO: renamed from: b */
    public wbb f1728b;

    /* JADX INFO: renamed from: c */
    public final wi0 f1729c = new wi0(this, 6);

    /* JADX INFO: renamed from: d */
    public final /* synthetic */ DrawerLayout f1730d;

    public C0140b(DrawerLayout drawerLayout, int i) {
        this.f1730d = drawerLayout;
        this.f1727a = i;
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: F */
    public final void mo1042F(int i, int i2) {
        int i3 = i & 1;
        DrawerLayout drawerLayout = this.f1730d;
        View viewM1031d = i3 == 1 ? drawerLayout.m1031d(3) : drawerLayout.m1031d(5);
        if (viewM1031d == null || drawerLayout.m1034g(viewM1031d) != 0) {
            return;
        }
        this.f1728b.m19463c(i2, viewM1031d);
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: G */
    public final void mo1043G(int i) {
        this.f1730d.postDelayed(this.f1729c, 160L);
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: H */
    public final void mo1044H(int i, View view) {
        ((DrawerLayout.LayoutParams) view.getLayoutParams()).f1720c = false;
        int i2 = this.f1727a == 3 ? 5 : 3;
        DrawerLayout drawerLayout = this.f1730d;
        View viewM1031d = drawerLayout.m1031d(i2);
        if (viewM1031d != null) {
            drawerLayout.m1029b(viewM1031d, true);
        }
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: I */
    public final void mo1045I(int i) {
        this.f1730d.m1041s(i, this.f1728b.f45191t);
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: J */
    public final void mo1046J(View view, int i, int i2) {
        int width = view.getWidth();
        DrawerLayout drawerLayout = this.f1730d;
        float width2 = (drawerLayout.m1028a(3, view) ? i + width : drawerLayout.getWidth() - i) / width;
        drawerLayout.m1038p(view, width2);
        view.setVisibility(width2 == 0.0f ? 4 : 0);
        drawerLayout.invalidate();
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: K */
    public final void mo1047K(View view, float f, float f2) {
        int i;
        int[] iArr = DrawerLayout.f1688a0;
        float f3 = ((DrawerLayout.LayoutParams) view.getLayoutParams()).f1719b;
        int width = view.getWidth();
        DrawerLayout drawerLayout = this.f1730d;
        if (drawerLayout.m1028a(3, view)) {
            i = (f > 0.0f || (f == 0.0f && f3 > 0.5f)) ? 0 : -width;
        } else {
            int width2 = drawerLayout.getWidth();
            if (f < 0.0f || (f == 0.0f && f3 > 0.5f)) {
                width2 -= width;
            }
            i = width2;
        }
        this.f1728b.m19478s(i, view.getTop());
        drawerLayout.invalidate();
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: V */
    public final boolean mo1048V(int i, View view) {
        if (!DrawerLayout.m1026l(view)) {
            return false;
        }
        int i2 = this.f1727a;
        DrawerLayout drawerLayout = this.f1730d;
        return drawerLayout.m1028a(i2, view) && drawerLayout.m1034g(view) == 0;
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: o */
    public final int mo1049o(int i, View view) {
        DrawerLayout drawerLayout = this.f1730d;
        if (drawerLayout.m1028a(3, view)) {
            return Math.max(-view.getWidth(), Math.min(i, 0));
        }
        int width = drawerLayout.getWidth();
        return Math.max(width - view.getWidth(), Math.min(i, width));
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: p */
    public final int mo1050p(int i, View view) {
        return view.getTop();
    }

    @Override // p000.v09
    /* JADX INFO: renamed from: z */
    public final int mo1051z(View view) {
        if (DrawerLayout.m1026l(view)) {
            return view.getWidth();
        }
        return 0;
    }
}
