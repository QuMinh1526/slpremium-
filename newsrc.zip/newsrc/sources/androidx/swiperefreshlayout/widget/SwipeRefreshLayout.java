package androidx.swiperefreshlayout.widget;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ListView;
import java.util.WeakHashMap;
import p000.C1477tx;
import p000.RunnableC0827mk;
import p000.fbb;
import p000.ih1;
import p000.mia;
import p000.nia;
import p000.obb;
import p000.oia;
import p000.pn8;
import p000.qh1;
import p000.rh1;
import p000.s47;
import p000.t47;
import p000.u47;
import p000.v47;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class SwipeRefreshLayout extends ViewGroup implements u47, t47, s47 {

    /* JADX INFO: renamed from: f0 */
    public static final int[] f2221f0 = {R.attr.enabled};

    /* JADX INFO: renamed from: A */
    public float f2222A;

    /* JADX INFO: renamed from: B */
    public final v47 f2223B;

    /* JADX INFO: renamed from: C */
    public final C1477tx f2224C;

    /* JADX INFO: renamed from: D */
    public final int[] f2225D;

    /* JADX INFO: renamed from: E */
    public final int[] f2226E;

    /* JADX INFO: renamed from: F */
    public final int[] f2227F;

    /* JADX INFO: renamed from: G */
    public boolean f2228G;

    /* JADX INFO: renamed from: H */
    public final int f2229H;

    /* JADX INFO: renamed from: I */
    public int f2230I;

    /* JADX INFO: renamed from: J */
    public float f2231J;

    /* JADX INFO: renamed from: K */
    public float f2232K;

    /* JADX INFO: renamed from: L */
    public boolean f2233L;

    /* JADX INFO: renamed from: M */
    public int f2234M;

    /* JADX INFO: renamed from: N */
    public final DecelerateInterpolator f2235N;

    /* JADX INFO: renamed from: O */
    public final ih1 f2236O;

    /* JADX INFO: renamed from: P */
    public int f2237P;

    /* JADX INFO: renamed from: Q */
    public int f2238Q;

    /* JADX INFO: renamed from: R */
    public final int f2239R;

    /* JADX INFO: renamed from: S */
    public final int f2240S;

    /* JADX INFO: renamed from: T */
    public final rh1 f2241T;

    /* JADX INFO: renamed from: U */
    public nia f2242U;

    /* JADX INFO: renamed from: V */
    public nia f2243V;

    /* JADX INFO: renamed from: W */
    public oia f2244W;

    /* JADX INFO: renamed from: a0 */
    public oia f2245a0;

    /* JADX INFO: renamed from: b0 */
    public final int f2246b0;

    /* JADX INFO: renamed from: c0 */
    public final mia f2247c0;

    /* JADX INFO: renamed from: d0 */
    public final nia f2248d0;

    /* JADX INFO: renamed from: e */
    public View f2249e;

    /* JADX INFO: renamed from: e0 */
    public final nia f2250e0;

    /* JADX INFO: renamed from: i */
    public boolean f2251i;

    /* JADX INFO: renamed from: y */
    public final int f2252y;

    /* JADX INFO: renamed from: z */
    public final float f2253z;

    public SwipeRefreshLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f2251i = false;
        this.f2253z = -1.0f;
        this.f2225D = new int[2];
        this.f2226E = new int[2];
        this.f2227F = new int[2];
        this.f2234M = -1;
        this.f2237P = -1;
        this.f2247c0 = new mia(this, 0);
        this.f2248d0 = new nia(this, 2);
        this.f2250e0 = new nia(this, 3);
        this.f2252y = ViewConfiguration.get(context).getScaledTouchSlop();
        this.f2229H = getResources().getInteger(R.integer.config_mediumAnimTime);
        setWillNotDraw(false);
        this.f2235N = new DecelerateInterpolator(2.0f);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        int i = (int) (displayMetrics.density * 40.0f);
        this.f2246b0 = i;
        ih1 ih1Var = new ih1(getContext());
        float f = ih1Var.getContext().getResources().getDisplayMetrics().density;
        TypedArray typedArrayObtainStyledAttributes = ih1Var.getContext().obtainStyledAttributes(pn8.f33600a);
        ih1Var.f21373i = typedArrayObtainStyledAttributes.getColor(0, -328966);
        typedArrayObtainStyledAttributes.recycle();
        ShapeDrawable shapeDrawable = new ShapeDrawable(new OvalShape());
        WeakHashMap weakHashMap = obb.f31348a;
        fbb.m8064k(ih1Var, f * 4.0f);
        shapeDrawable.getPaint().setColor(ih1Var.f21373i);
        ih1Var.setBackground(shapeDrawable);
        this.f2236O = ih1Var;
        rh1 rh1Var = new rh1(getContext());
        this.f2241T = rh1Var;
        float f2 = rh1Var.f36536y.getDisplayMetrics().density;
        float f3 = 2.5f * f2;
        qh1 qh1Var = rh1Var.f36534e;
        qh1Var.f34985h = f3;
        qh1Var.f34979b.setStrokeWidth(f3);
        qh1Var.f34994q = 7.5f * f2;
        qh1Var.f34987j = 0;
        qh1Var.f34998u = qh1Var.f34986i[0];
        qh1Var.f34995r = (int) (10.0f * f2);
        qh1Var.f34996s = (int) (5.0f * f2);
        rh1Var.invalidateSelf();
        this.f2236O.setImageDrawable(this.f2241T);
        this.f2236O.setVisibility(8);
        addView(this.f2236O);
        setChildrenDrawingOrderEnabled(true);
        int i2 = (int) (displayMetrics.density * 64.0f);
        this.f2240S = i2;
        this.f2253z = i2;
        this.f2223B = new v47();
        this.f2224C = new C1477tx(this);
        setNestedScrollingEnabled(true);
        int i3 = -i;
        this.f2230I = i3;
        this.f2239R = i3;
        m1537e(1.0f);
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, f2221f0);
        setEnabled(typedArrayObtainStyledAttributes2.getBoolean(0, true));
        typedArrayObtainStyledAttributes2.recycle();
    }

    /* JADX INFO: renamed from: a */
    public final boolean m1533a() {
        View view = this.f2249e;
        return view instanceof ListView ? ((ListView) view).canScrollList(-1) : view.canScrollVertically(-1);
    }

    /* JADX INFO: renamed from: b */
    public final void m1534b() {
        if (this.f2249e == null) {
            for (int i = 0; i < getChildCount(); i++) {
                View childAt = getChildAt(i);
                if (!childAt.equals(this.f2236O)) {
                    this.f2249e = childAt;
                    return;
                }
            }
        }
    }

    /* JADX INFO: renamed from: c */
    public final void m1535c(float f) {
        int i = 1;
        if (f > this.f2253z) {
            m1539g(true, true);
            return;
        }
        this.f2251i = false;
        rh1 rh1Var = this.f2241T;
        qh1 qh1Var = rh1Var.f36534e;
        qh1Var.f34982e = 0.0f;
        qh1Var.f34983f = 0.0f;
        rh1Var.invalidateSelf();
        mia miaVar = new mia(this, i);
        this.f2238Q = this.f2230I;
        nia niaVar = this.f2250e0;
        niaVar.reset();
        niaVar.setDuration(200L);
        niaVar.setInterpolator(this.f2235N);
        ih1 ih1Var = this.f2236O;
        ih1Var.f21372e = miaVar;
        ih1Var.clearAnimation();
        ih1Var.startAnimation(niaVar);
        qh1 qh1Var2 = rh1Var.f36534e;
        if (qh1Var2.f34991n) {
            qh1Var2.f34991n = false;
        }
        rh1Var.invalidateSelf();
    }

    /* JADX INFO: renamed from: d */
    public final void m1536d(float f) {
        oia oiaVar;
        oia oiaVar2;
        rh1 rh1Var = this.f2241T;
        qh1 qh1Var = rh1Var.f36534e;
        if (!qh1Var.f34991n) {
            qh1Var.f34991n = true;
        }
        rh1Var.invalidateSelf();
        float f2 = this.f2253z;
        float fMin = Math.min(1.0f, Math.abs(f / f2));
        float fMax = (((float) Math.max(((double) fMin) - 0.4d, 0.0d)) * 5.0f) / 3.0f;
        float fAbs = Math.abs(f) - f2;
        float f3 = this.f2240S;
        double dMax = Math.max(0.0f, Math.min(fAbs, f3 * 2.0f) / f3) / 4.0f;
        float fPow = ((float) (dMax - Math.pow(dMax, 2.0d))) * 2.0f;
        int i = this.f2239R + ((int) ((f3 * fMin) + (f3 * fPow * 2.0f)));
        ih1 ih1Var = this.f2236O;
        if (ih1Var.getVisibility() != 0) {
            ih1Var.setVisibility(0);
        }
        ih1Var.setScaleX(1.0f);
        ih1Var.setScaleY(1.0f);
        if (f < f2) {
            if (rh1Var.f36534e.f34997t > 76 && ((oiaVar2 = this.f2244W) == null || !oiaVar2.hasStarted() || oiaVar2.hasEnded())) {
                oia oiaVar3 = new oia(this, rh1Var.f36534e.f34997t, 76);
                oiaVar3.setDuration(300L);
                ih1Var.f21372e = null;
                ih1Var.clearAnimation();
                ih1Var.startAnimation(oiaVar3);
                this.f2244W = oiaVar3;
            }
        } else if (rh1Var.f36534e.f34997t < 255 && ((oiaVar = this.f2245a0) == null || !oiaVar.hasStarted() || oiaVar.hasEnded())) {
            oia oiaVar4 = new oia(this, rh1Var.f36534e.f34997t, 255);
            oiaVar4.setDuration(300L);
            ih1Var.f21372e = null;
            ih1Var.clearAnimation();
            ih1Var.startAnimation(oiaVar4);
            this.f2245a0 = oiaVar4;
        }
        float fMin2 = Math.min(0.8f, fMax * 0.8f);
        qh1 qh1Var2 = rh1Var.f36534e;
        qh1Var2.f34982e = 0.0f;
        qh1Var2.f34983f = fMin2;
        rh1Var.invalidateSelf();
        float fMin3 = Math.min(1.0f, fMax);
        qh1 qh1Var3 = rh1Var.f36534e;
        if (fMin3 != qh1Var3.f34993p) {
            qh1Var3.f34993p = fMin3;
        }
        rh1Var.invalidateSelf();
        rh1Var.f36534e.f34984g = ((fPow * 2.0f) + ((fMax * 0.4f) - 0.25f)) * 0.5f;
        rh1Var.invalidateSelf();
        m1541i(i - this.f2230I);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent == null || keyEvent.getAction() != 1 || keyEvent.getKeyCode() != 285) {
            return super.dispatchKeyEvent(keyEvent);
        }
        m1540h(true, true);
        return true;
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.f2224C.m17957a(f, f2, z);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f2) {
        return this.f2224C.m17958b(f, f2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return this.f2224C.m17959c(i, i2, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.f2224C.m17960d(i, i2, i3, i4, iArr, 0, null);
    }

    /* JADX INFO: renamed from: e */
    public final void m1537e(float f) {
        int i = this.f2238Q;
        m1541i((i + ((int) ((this.f2239R - i) * f))) - this.f2236O.getTop());
    }

    /* JADX INFO: renamed from: f */
    public final void m1538f() {
        this.f2236O.clearAnimation();
        this.f2241T.stop();
        this.f2236O.setVisibility(8);
        this.f2236O.getBackground().setAlpha(255);
        this.f2241T.setAlpha(255);
        m1541i(this.f2239R - this.f2230I);
        this.f2230I = this.f2236O.getTop();
    }

    /* JADX INFO: renamed from: g */
    public final void m1539g(boolean z, boolean z2) {
        if (this.f2251i != z) {
            m1534b();
            this.f2251i = z;
            ih1 ih1Var = this.f2236O;
            mia miaVar = this.f2247c0;
            if (!z) {
                nia niaVar = new nia(this, 1);
                this.f2243V = niaVar;
                niaVar.setDuration(150L);
                ih1Var.f21372e = miaVar;
                ih1Var.clearAnimation();
                ih1Var.startAnimation(this.f2243V);
                return;
            }
            this.f2238Q = this.f2230I;
            nia niaVar2 = this.f2248d0;
            niaVar2.reset();
            niaVar2.setDuration(200L);
            niaVar2.setInterpolator(this.f2235N);
            if (miaVar != null) {
                ih1Var.f21372e = miaVar;
            }
            ih1Var.clearAnimation();
            ih1Var.startAnimation(niaVar2);
        }
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i, int i2) {
        int i3 = this.f2237P;
        if (i3 < 0) {
            return i2;
        }
        if (i2 == i - 1) {
            return i3;
        }
        return i2 >= i3 ? i2 + 1 : i2;
    }

    @Override // android.view.ViewGroup
    public final int getNestedScrollAxes() {
        return this.f2223B.m18919a();
    }

    /* JADX INFO: renamed from: h */
    public final void m1540h(boolean z, boolean z2) {
        if (!z || this.f2251i == z) {
            m1539g(z, false);
            return;
        }
        this.f2251i = z;
        m1541i((this.f2240S + this.f2239R) - this.f2230I);
        ih1 ih1Var = this.f2236O;
        ih1Var.setVisibility(0);
        this.f2241T.setAlpha(255);
        nia niaVar = new nia(this, 0);
        this.f2242U = niaVar;
        niaVar.setDuration(this.f2229H);
        mia miaVar = this.f2247c0;
        if (miaVar != null) {
            ih1Var.f21372e = miaVar;
        }
        ih1Var.clearAnimation();
        ih1Var.startAnimation(this.f2242U);
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.f2224C.m17962f(0);
    }

    /* JADX INFO: renamed from: i */
    public final void m1541i(int i) {
        ih1 ih1Var = this.f2236O;
        ih1Var.bringToFront();
        WeakHashMap weakHashMap = obb.f31348a;
        ih1Var.offsetTopAndBottom(i);
        this.f2230I = ih1Var.getTop();
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.f2224C.f41017a;
    }

    /* JADX INFO: renamed from: j */
    public final void m1542j(float f) {
        float f2 = this.f2232K;
        float f3 = f - f2;
        float f4 = this.f2252y;
        if (f3 <= f4 || this.f2233L) {
            return;
        }
        this.f2231J = f2 + f4;
        this.f2233L = true;
        this.f2241T.setAlpha(76);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        m1538f();
    }

    /* JADX WARN: Code duplicated, block: B:34:0x005f  */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        m1534b();
        int actionMasked = motionEvent.getActionMasked();
        if (isEnabled() && !m1533a() && !this.f2251i && !this.f2228G) {
            if (actionMasked != 0) {
                if (actionMasked == 1) {
                    this.f2233L = false;
                    this.f2234M = -1;
                } else if (actionMasked == 2) {
                    int i = this.f2234M;
                    if (i == -1) {
                        Log.e("SwipeRefreshLayout", "Got ACTION_MOVE event but don't have an active pointer id.");
                        return false;
                    }
                    int iFindPointerIndex = motionEvent.findPointerIndex(i);
                    if (iFindPointerIndex >= 0) {
                        m1542j(motionEvent.getY(iFindPointerIndex));
                    }
                } else if (actionMasked == 3) {
                    this.f2233L = false;
                    this.f2234M = -1;
                } else if (actionMasked == 6) {
                    int actionIndex = motionEvent.getActionIndex();
                    if (motionEvent.getPointerId(actionIndex) == this.f2234M) {
                        this.f2234M = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
                    }
                }
                return this.f2233L;
            }
            m1541i(this.f2239R - this.f2236O.getTop());
            int pointerId = motionEvent.getPointerId(0);
            this.f2234M = pointerId;
            this.f2233L = false;
            int iFindPointerIndex2 = motionEvent.findPointerIndex(pointerId);
            if (iFindPointerIndex2 >= 0) {
                this.f2232K = motionEvent.getY(iFindPointerIndex2);
                return this.f2233L;
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (getChildCount() == 0) {
            return;
        }
        if (this.f2249e == null) {
            m1534b();
        }
        View view = this.f2249e;
        if (view == null) {
            return;
        }
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        view.layout(paddingLeft, paddingTop, ((measuredWidth - getPaddingLeft()) - getPaddingRight()) + paddingLeft, ((measuredHeight - getPaddingTop()) - getPaddingBottom()) + paddingTop);
        int measuredWidth2 = this.f2236O.getMeasuredWidth();
        int measuredHeight2 = this.f2236O.getMeasuredHeight();
        int i5 = measuredWidth / 2;
        int i6 = measuredWidth2 / 2;
        int i7 = this.f2230I;
        this.f2236O.layout(i5 - i6, i7, i5 + i6, measuredHeight2 + i7);
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f2249e == null) {
            m1534b();
        }
        View view = this.f2249e;
        if (view == null) {
            return;
        }
        view.measure(View.MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 1073741824));
        int i3 = this.f2246b0;
        this.f2236O.measure(View.MeasureSpec.makeMeasureSpec(i3, 1073741824), View.MeasureSpec.makeMeasureSpec(i3, 1073741824));
        this.f2237P = -1;
        for (int i4 = 0; i4 < getChildCount(); i4++) {
            if (getChildAt(i4) == this.f2236O) {
                this.f2237P = i4;
                return;
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        return this.f2224C.m17957a(f, f2, z);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        return this.f2224C.m17958b(f, f2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        if (i2 > 0) {
            float f = this.f2222A;
            if (f > 0.0f) {
                float f2 = i2;
                if (f2 > f) {
                    iArr[1] = (int) f;
                    this.f2222A = 0.0f;
                } else {
                    this.f2222A = f - f2;
                    iArr[1] = i2;
                }
                m1536d(this.f2222A);
            }
        }
        int i3 = i - iArr[0];
        int i4 = i2 - iArr[1];
        int[] iArr2 = this.f2225D;
        if (dispatchNestedPreScroll(i3, i4, iArr2, null)) {
            iArr[0] = iArr[0] + iArr2[0];
            iArr[1] = iArr[1] + iArr2[1];
        }
    }

    @Override // p000.u47
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        if (i5 != 0) {
            return;
        }
        int i6 = iArr[1];
        if (i5 == 0) {
            this.f2224C.m17960d(i, i2, i3, i4, this.f2226E, i5, iArr);
        }
        int i7 = i4 - (iArr[1] - i6);
        int i8 = i7 == 0 ? this.f2226E[1] + i4 : i7;
        if (i8 >= 0 || m1533a()) {
            return;
        }
        float fAbs = this.f2222A + Math.abs(i8);
        this.f2222A = fAbs;
        m1536d(fAbs);
        iArr[1] = iArr[1] + i7;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        this.f2223B.f43121a = i;
        startNestedScroll(i & 2);
        this.f2222A = 0.0f;
        this.f2228G = true;
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        m1540h(savedState.f2254e, false);
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        return new SavedState(super.onSaveInstanceState(), this.f2251i);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        return (!isEnabled() || this.f2251i || (i & 2) == 0) ? false : true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        this.f2223B.f43121a = 0;
        this.f2228G = false;
        float f = this.f2222A;
        if (f > 0.0f) {
            m1535c(f);
            this.f2222A = 0.0f;
        } else {
            post(new RunnableC0827mk(this, 29));
        }
        stopNestedScroll();
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (isEnabled() && !m1533a() && !this.f2251i && !this.f2228G) {
            if (actionMasked == 0) {
                this.f2234M = motionEvent.getPointerId(0);
                this.f2233L = false;
                return true;
            }
            if (actionMasked == 1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f2234M);
                if (iFindPointerIndex < 0) {
                    Log.e("SwipeRefreshLayout", "Got ACTION_UP event but don't have an active pointer id.");
                    return false;
                }
                if (this.f2233L) {
                    float y = (motionEvent.getY(iFindPointerIndex) - this.f2231J) * 0.5f;
                    this.f2233L = false;
                    m1535c(y);
                }
                this.f2234M = -1;
                return false;
            }
            if (actionMasked == 2) {
                int iFindPointerIndex2 = motionEvent.findPointerIndex(this.f2234M);
                if (iFindPointerIndex2 < 0) {
                    Log.e("SwipeRefreshLayout", "Got ACTION_MOVE event but have an invalid active pointer id.");
                    return false;
                }
                float y2 = motionEvent.getY(iFindPointerIndex2);
                m1542j(y2);
                if (this.f2233L) {
                    float f = (y2 - this.f2231J) * 0.5f;
                    if (f > 0.0f) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                        m1536d(f);
                    }
                }
                return true;
            }
            if (actionMasked != 3) {
                if (actionMasked != 5) {
                    if (actionMasked == 6) {
                        int actionIndex = motionEvent.getActionIndex();
                        if (motionEvent.getPointerId(actionIndex) == this.f2234M) {
                            this.f2234M = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
                            return true;
                        }
                    }
                    return true;
                }
                int actionIndex2 = motionEvent.getActionIndex();
                if (actionIndex2 < 0) {
                    Log.e("SwipeRefreshLayout", "Got ACTION_POINTER_DOWN event but have an invalid action index.");
                    return false;
                }
                this.f2234M = motionEvent.getPointerId(actionIndex2);
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public final void setEnabled(boolean z) {
        super.setEnabled(z);
        if (z) {
            return;
        }
        m1538f();
    }

    @Override // android.view.View
    public final void setNestedScrollingEnabled(boolean z) {
        C1477tx c1477tx = this.f2224C;
        if (c1477tx.f41017a) {
            ViewGroup viewGroup = (ViewGroup) c1477tx.f41020d;
            WeakHashMap weakHashMap = obb.f31348a;
            fbb.m8068o(viewGroup);
        }
        c1477tx.f41017a = z;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        return this.f2224C.m17965i(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        this.f2224C.m17966j(0);
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0192a();

        /* JADX INFO: renamed from: e */
        public final boolean f2254e;

        public SavedState(Parcel parcel) {
            super(parcel);
            this.f2254e = parcel.readByte() != 0;
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeByte(this.f2254e ? (byte) 1 : (byte) 0);
        }

        public SavedState(Parcelable parcelable, boolean z) {
            super(parcelable);
            this.f2254e = z;
        }
    }

    @Override // p000.t47
    public final void onNestedScrollAccepted(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    @Override // p000.t47
    public final boolean onStartNestedScroll(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            return onStartNestedScroll(view, view2, i);
        }
        return false;
    }

    @Override // p000.t47
    public final void onStopNestedScroll(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // p000.t47
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr, int i3) {
        if (i3 == 0) {
            onNestedPreScroll(view, i, i2, iArr);
        }
    }

    @Override // p000.t47
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5) {
        onNestedScroll(view, i, i2, i3, i4, i5, this.f2227F);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        onNestedScroll(view, i, i2, i3, i4, 0, this.f2227F);
    }
}
