package androidx.biometric;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.biometrics.BiometricPrompt;
import android.hardware.biometrics.BiometricPrompt$AuthenticationCallback;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.security.identity.IdentityCredential;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.RestrictTo;
import androidx.fragment.app.AbstractC0165v;
import androidx.fragment.app.AbstractComponentCallbacksC0156m;
import androidx.fragment.app.C0142a;
import androidx.fragment.app.FragmentActivity;
import com.squareup.picasso.BuildConfig;
import ginlemon.flowerfree.R;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import p000.AbstractC1295pv;
import p000.AbstractC1297px;
import p000.C0767l;
import p000.C1521v3;
import p000.az0;
import p000.cc2;
import p000.dbc;
import p000.dc2;
import p000.di5;
import p000.el4;
import p000.fd1;
import p000.fo9;
import p000.gd1;
import p000.gn7;
import p000.ky0;
import p000.ly0;
import p000.mcb;
import p000.ny0;
import p000.ny6;
import p000.ob2;
import p000.ocb;
import p000.og0;
import p000.oy0;
import p000.py0;
import p000.qg0;
import p000.qy0;
import p000.ry0;
import p000.sr5;
import p000.sy0;
import p000.vy0;
import p000.wy0;
import p000.x44;
import p000.yv5;
import p000.yy0;
import p000.ze7;
import p000.zu8;
import p000.zy0;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@RestrictTo({RestrictTo.Scope.LIBRARY})
public class BiometricFragment extends AbstractComponentCallbacksC0156m {

    /* JADX INFO: renamed from: e */
    public final Handler f1138e = new Handler(Looper.getMainLooper());

    /* JADX INFO: renamed from: i */
    public az0 f1139i;

    public final void dismiss() {
        this.f1139i.f3071E = false;
        m752k();
        if (!this.f1139i.f3073G && isAdded()) {
            AbstractC0165v parentFragmentManager = getParentFragmentManager();
            parentFragmentManager.getClass();
            C0142a c0142a = new C0142a(parentFragmentManager);
            c0142a.m1078o(this);
            c0142a.m1070g(true);
        }
        Context context = getContext();
        if (context != null) {
            String str = Build.MODEL;
            if (Build.VERSION.SDK_INT == 29 && str != null) {
                for (String str2 : context.getResources().getStringArray(R.array.delay_showing_prompt_models)) {
                    if (str.equals(str2)) {
                        az0 az0Var = this.f1139i;
                        az0Var.f3074H = true;
                        this.f1138e.postDelayed(new sy0(az0Var, 1), 600L);
                        return;
                    }
                }
            }
        }
    }

    /* JADX INFO: renamed from: j */
    public final void m751j(int i) {
        if (i == 3 || !this.f1139i.f3075I) {
            if (m754m()) {
                this.f1139i.f3070D = i;
                if (i == 1) {
                    m757p(10, AbstractC1297px.m15585Q(getContext(), 10));
                }
            }
            az0 az0Var = this.f1139i;
            if (az0Var.f3067A == null) {
                az0Var.f3067A = new di5((byte) 0);
            }
            di5 di5Var = az0Var.f3067A;
            CancellationSignal cancellationSignal = (CancellationSignal) di5Var.f10919e;
            if (cancellationSignal != null) {
                try {
                    gd1.m8932a(cancellationSignal);
                } catch (NullPointerException e) {
                    Log.e("CancelSignalProvider", "Got NPE while canceling biometric authentication.", e);
                }
                di5Var.f10919e = null;
            }
            fd1 fd1Var = (fd1) di5Var.f10920i;
            if (fd1Var != null) {
                try {
                    fd1Var.m8076a();
                } catch (NullPointerException e2) {
                    Log.e("CancelSignalProvider", "Got NPE while canceling fingerprint authentication.", e2);
                }
                di5Var.f10920i = null;
            }
        }
    }

    /* JADX INFO: renamed from: k */
    public final void m752k() {
        this.f1139i.f3071E = false;
        if (isAdded()) {
            AbstractC0165v parentFragmentManager = getParentFragmentManager();
            FingerprintDialogFragment fingerprintDialogFragment = (FingerprintDialogFragment) parentFragmentManager.m1121C("androidx.biometric.FingerprintDialogFragment");
            if (fingerprintDialogFragment != null) {
                if (fingerprintDialogFragment.isAdded()) {
                    fingerprintDialogFragment.dismissAllowingStateLoss();
                    return;
                }
                C0142a c0142a = new C0142a(parentFragmentManager);
                c0142a.m1078o(fingerprintDialogFragment);
                c0142a.m1070g(true);
            }
        }
    }

    /* JADX INFO: renamed from: l */
    public final boolean m753l() {
        return Build.VERSION.SDK_INT <= 28 && AbstractC1295pv.m15510Z(this.f1139i.m1913x());
    }

    /* JADX INFO: renamed from: m */
    public final boolean m754m() {
        int i = Build.VERSION.SDK_INT;
        if (i >= 28) {
            FragmentActivity activity = getActivity();
            if (activity != null && this.f1139i.f3088y != null) {
                String str = Build.MANUFACTURER;
                String str2 = Build.MODEL;
                if (i == 28) {
                    if (str != null) {
                        for (String str3 : activity.getResources().getStringArray(R.array.crypto_fingerprint_fallback_vendors)) {
                            if (!str.equalsIgnoreCase(str3)) {
                            }
                        }
                    }
                    String str4 = Build.MODEL;
                    if (str4 != null) {
                        for (String str5 : activity.getResources().getStringArray(R.array.crypto_fingerprint_fallback_prefixes)) {
                            if (!str4.startsWith(str5)) {
                            }
                        }
                    }
                }
            }
            if (Build.VERSION.SDK_INT != 28) {
                return false;
            }
            Context context = getContext();
            return context == null || context.getPackageManager() == null || !gn7.m9618a(context.getPackageManager());
        }
        return true;
    }

    /* JADX INFO: renamed from: n */
    public final void m755n() {
        FragmentActivity activity = getActivity();
        if (activity == null) {
            Log.e("BiometricFragment", "Failed to check device credential. Client FragmentActivity not found.");
            return;
        }
        KeyguardManager keyguardManagerM20715a = yv5.m20715a(activity);
        if (keyguardManagerM20715a == null) {
            m756o(12, getString(R.string.generic_error_no_keyguard));
            return;
        }
        az0 az0Var = this.f1139i;
        wy0 wy0Var = az0Var.f3087i;
        CharSequence charSequence = wy0Var != null ? wy0Var.f46213a : null;
        az0Var.getClass();
        wy0 wy0Var2 = this.f1139i.f3087i;
        Intent intentM14383a = ny0.m14383a(keyguardManagerM20715a, charSequence, wy0Var2 != null ? wy0Var2.f46214b : null);
        if (intentM14383a == null) {
            m756o(14, getString(R.string.generic_error_no_device_credential));
            return;
        }
        this.f1139i.f3073G = true;
        if (m754m()) {
            m752k();
        }
        intentM14383a.setFlags(134742016);
        startActivityForResult(intentM14383a, 1);
    }

    /* JADX INFO: renamed from: o */
    public final void m756o(int i, CharSequence charSequence) {
        m757p(i, charSequence);
        dismiss();
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1) {
            this.f1139i.f3073G = false;
            if (i2 == -1) {
                m758q(new vy0(null, 1));
            } else {
                m756o(10, getString(R.string.generic_error_user_canceled));
            }
        }
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getActivity() == null) {
            return;
        }
        FragmentActivity activity = getActivity();
        activity.getClass();
        ocb viewModelStore = activity.getViewModelStore();
        mcb defaultViewModelProviderFactory = activity.getDefaultViewModelProviderFactory();
        ob2 defaultViewModelCreationExtras = activity.getDefaultViewModelCreationExtras();
        viewModelStore.getClass();
        defaultViewModelProviderFactory.getClass();
        defaultViewModelCreationExtras.getClass();
        fo9 fo9Var = new fo9(viewModelStore, defaultViewModelProviderFactory, defaultViewModelCreationExtras);
        sr5 sr5VarMo1868b = zu8.f50914a.mo1868b(az0.class);
        String strMo17162a = sr5VarMo1868b.mo17162a();
        if (strMo17162a == null) {
            C1521v3.m18903j("Local and anonymous classes can not be ViewModels");
            return;
        }
        az0 az0Var = (az0) fo9Var.m8228t(sr5VarMo1868b, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strMo17162a));
        this.f1139i = az0Var;
        if (az0Var.f3076J == null) {
            az0Var.f3076J = new ny6();
        }
        az0Var.f3076J.mo1943d(this, new ly0(this, 0));
        az0 az0Var2 = this.f1139i;
        if (az0Var2.f3077K == null) {
            az0Var2.f3077K = new ny6();
        }
        az0Var2.f3077K.mo1943d(this, new ly0(this, 1));
        az0 az0Var3 = this.f1139i;
        if (az0Var3.f3078L == null) {
            az0Var3.f3078L = new ny6();
        }
        az0Var3.f3078L.mo1943d(this, new ly0(this, 2));
        az0 az0Var4 = this.f1139i;
        if (az0Var4.f3079M == null) {
            az0Var4.f3079M = new ny6();
        }
        az0Var4.f3079M.mo1943d(this, new ly0(this, 3));
        az0 az0Var5 = this.f1139i;
        if (az0Var5.f3080N == null) {
            az0Var5.f3080N = new ny6();
        }
        az0Var5.f3080N.mo1943d(this, new ly0(this, 4));
        az0 az0Var6 = this.f1139i;
        if (az0Var6.f3082P == null) {
            az0Var6.f3082P = new ny6();
        }
        az0Var6.f3082P.mo1943d(this, new ly0(this, 5));
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onStart() {
        super.onStart();
        if (Build.VERSION.SDK_INT == 29 && AbstractC1295pv.m15510Z(this.f1139i.m1913x())) {
            az0 az0Var = this.f1139i;
            az0Var.f3075I = true;
            this.f1138e.postDelayed(new sy0(az0Var, 2), 250L);
        }
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onStop() {
        super.onStop();
        if (Build.VERSION.SDK_INT >= 29 || this.f1139i.f3073G) {
            return;
        }
        FragmentActivity activity = getActivity();
        if (activity == null || !activity.isChangingConfigurations()) {
            m751j(0);
        }
    }

    /* JADX INFO: renamed from: p */
    public final void m757p(int i, CharSequence charSequence) {
        az0 az0Var = this.f1139i;
        if (az0Var.f3073G) {
            return;
        }
        if (!az0Var.f3072F) {
            Log.w("BiometricFragment", "Error not sent to client. Client is not awaiting a result.");
        } else {
            az0Var.f3072F = false;
            new Handler(Looper.getMainLooper()).post(new dbc(this, i, charSequence));
        }
    }

    /* JADX INFO: renamed from: q */
    public final void m758q(vy0 vy0Var) {
        az0 az0Var = this.f1139i;
        if (az0Var.f3072F) {
            az0Var.f3072F = false;
            new Handler(Looper.getMainLooper()).post(new el4(3, this, vy0Var, false));
        } else {
            Log.w("BiometricFragment", "Success not sent to client. Client is not awaiting a result.");
        }
        dismiss();
    }

    /* JADX INFO: renamed from: r */
    public final void m759r(CharSequence charSequence) {
        if (charSequence == null) {
            charSequence = getString(R.string.default_error_msg);
        }
        this.f1139i.m1911A(2);
        this.f1139i.m1915z(charSequence);
    }

    /* JADX INFO: renamed from: s */
    public final void m760s() {
        IdentityCredential identityCredential;
        int i;
        if (this.f1139i.f3071E) {
            return;
        }
        if (getContext() == null) {
            Log.w("BiometricFragment", "Not showing biometric prompt. Context is null.");
            return;
        }
        az0 az0Var = this.f1139i;
        int i2 = 1;
        az0Var.f3071E = true;
        az0Var.f3072F = true;
        byte b = 0;
        BiometricPrompt.CryptoObject cryptoObjectM6857a = null;
        ze7Var = null;
        ze7Var = null;
        ze7Var = null;
        ze7 ze7Var = null;
        cryptoObjectM6857a = null;
        cryptoObjectM6857a = null;
        if (m754m()) {
            Context applicationContext = requireContext().getApplicationContext();
            x44 x44Var = new x44(applicationContext);
            FingerprintManager fingerprintManagerM19903b = x44.m19903b(applicationContext);
            if (fingerprintManagerM19903b == null || !fingerprintManagerM19903b.isHardwareDetected()) {
                i = 12;
            } else {
                FingerprintManager fingerprintManagerM19903b2 = x44.m19903b(applicationContext);
                i = (fingerprintManagerM19903b2 == null || !fingerprintManagerM19903b2.hasEnrolledFingerprints()) ? 11 : 0;
            }
            if (i != 0) {
                m756o(i, AbstractC1297px.m15585Q(applicationContext, i));
                return;
            }
            if (isAdded()) {
                this.f1139i.f3081O = true;
                String str = Build.MODEL;
                if (Build.VERSION.SDK_INT != 28 || str == null) {
                    this.f1138e.postDelayed(new ky0(this, i2), 500L);
                    new FingerprintDialogFragment().show(getParentFragmentManager(), "androidx.biometric.FingerprintDialogFragment");
                    break;
                }
                String[] stringArray = applicationContext.getResources().getStringArray(R.array.hide_fingerprint_instantly_prefixes);
                int length = stringArray.length;
                int i3 = 0;
                while (true) {
                    if (i3 >= length) {
                        this.f1138e.postDelayed(new ky0(this, i2), 500L);
                        new FingerprintDialogFragment().show(getParentFragmentManager(), "androidx.biometric.FingerprintDialogFragment");
                        break;
                    } else if (str.startsWith(stringArray[i3])) {
                        break;
                    } else {
                        i3++;
                    }
                }
                az0 az0Var2 = this.f1139i;
                az0Var2.f3070D = 0;
                C0767l c0767l = az0Var2.f3088y;
                if (c0767l != null) {
                    Cipher cipher = (Cipher) c0767l.f25638y;
                    if (cipher != null) {
                        ze7Var = new ze7(cipher);
                    } else {
                        Signature signature = (Signature) c0767l.f25637i;
                        if (signature != null) {
                            ze7Var = new ze7(signature);
                        } else {
                            Mac mac = (Mac) c0767l.f25639z;
                            if (mac != null) {
                                ze7Var = new ze7(mac);
                            } else if (Build.VERSION.SDK_INT >= 30 && ((IdentityCredential) c0767l.f25635A) != null) {
                                Log.e("CryptoObjectUtils", "Identity credential is not supported by FingerprintManager.");
                            }
                        }
                    }
                }
                az0 az0Var3 = this.f1139i;
                if (az0Var3.f3067A == null) {
                    az0Var3.f3067A = new di5(b);
                }
                di5 di5Var = az0Var3.f3067A;
                if (((fd1) di5Var.f10920i) == null) {
                    di5Var.f10920i = new fd1();
                }
                fd1 fd1Var = (fd1) di5Var.f10920i;
                az0 az0Var4 = this.f1139i;
                if (az0Var4.f3089z == null) {
                    az0Var4.f3089z = new ze7(new yy0(az0Var4));
                }
                ze7 ze7Var2 = az0Var4.f3089z;
                if (((og0) ze7Var2.f50209y) == null) {
                    ze7Var2.f50209y = new og0(ze7Var2, b);
                }
                try {
                    x44Var.m19904a(ze7Var, fd1Var, (og0) ze7Var2.f50209y);
                    return;
                } catch (NullPointerException e) {
                    Log.e("BiometricFragment", "Got NPE while authenticating with fingerprint.", e);
                    m756o(1, AbstractC1297px.m15585Q(applicationContext, 1));
                    return;
                }
            }
            return;
        }
        BiometricPrompt.Builder builderM15027d = oy0.m15027d(requireContext().getApplicationContext());
        az0 az0Var5 = this.f1139i;
        wy0 wy0Var = az0Var5.f3087i;
        CharSequence charSequence = wy0Var != null ? wy0Var.f46213a : null;
        az0Var5.getClass();
        wy0 wy0Var2 = this.f1139i.f3087i;
        CharSequence charSequence2 = wy0Var2 != null ? wy0Var2.f46214b : null;
        if (charSequence != null) {
            oy0.m15030g(builderM15027d, charSequence);
        }
        if (charSequence2 != null) {
            oy0.m15028e(builderM15027d, charSequence2);
        }
        az0 az0Var6 = this.f1139i;
        CharSequence charSequence3 = az0Var6.f3069C;
        String string = BuildConfig.VERSION_NAME;
        if (charSequence3 == null) {
            wy0 wy0Var3 = az0Var6.f3087i;
            if (wy0Var3 != null) {
                charSequence3 = wy0Var3.f46215c;
                if (charSequence3 == null) {
                    charSequence3 = BuildConfig.VERSION_NAME;
                }
            } else {
                charSequence3 = null;
            }
        }
        if (!TextUtils.isEmpty(charSequence3)) {
            this.f1139i.getClass();
            ry0 ry0Var = new ry0(1);
            az0 az0Var7 = this.f1139i;
            if (az0Var7.f3068B == null) {
                az0Var7.f3068B = new zy0(az0Var7);
            }
            oy0.m15029f(builderM15027d, charSequence3, ry0Var, az0Var7.f3068B);
        }
        int i4 = Build.VERSION.SDK_INT;
        if (i4 >= 29) {
            wy0 wy0Var4 = this.f1139i.f3087i;
            py0.m15708a(builderM15027d, true);
        }
        int iM1913x = this.f1139i.m1913x();
        if (i4 >= 30) {
            qy0.m16153a(builderM15027d, iM1913x);
        } else if (i4 >= 29) {
            py0.m15709b(builderM15027d, AbstractC1295pv.m15510Z(iM1913x));
        }
        BiometricPrompt biometricPromptM15026c = oy0.m15026c(builderM15027d);
        Context context = getContext();
        C0767l c0767l2 = this.f1139i.f3088y;
        if (c0767l2 != null) {
            Cipher cipher2 = (Cipher) c0767l2.f25638y;
            if (cipher2 != null) {
                cryptoObjectM6857a = cc2.m3142b(cipher2);
            } else {
                Signature signature2 = (Signature) c0767l2.f25637i;
                if (signature2 != null) {
                    cryptoObjectM6857a = cc2.m3141a(signature2);
                } else {
                    Mac mac2 = (Mac) c0767l2.f25639z;
                    if (mac2 != null) {
                        cryptoObjectM6857a = cc2.m3143c(mac2);
                    } else if (Build.VERSION.SDK_INT >= 30 && (identityCredential = (IdentityCredential) c0767l2.f25635A) != null) {
                        cryptoObjectM6857a = dc2.m6857a(identityCredential);
                    }
                }
            }
        }
        az0 az0Var8 = this.f1139i;
        if (az0Var8.f3067A == null) {
            az0Var8.f3067A = new di5(b);
        }
        di5 di5Var2 = az0Var8.f3067A;
        if (((CancellationSignal) di5Var2.f10919e) == null) {
            di5Var2.f10919e = gd1.m8933b();
        }
        CancellationSignal cancellationSignal = (CancellationSignal) di5Var2.f10919e;
        ry0 ry0Var2 = new ry0(0);
        az0 az0Var9 = this.f1139i;
        if (az0Var9.f3089z == null) {
            az0Var9.f3089z = new ze7(new yy0(az0Var9));
        }
        ze7 ze7Var3 = az0Var9.f3089z;
        if (((BiometricPrompt$AuthenticationCallback) ze7Var3.f50208i) == null) {
            ze7Var3.f50208i = qg0.m15947a((yy0) ze7Var3.f50210z);
        }
        BiometricPrompt$AuthenticationCallback biometricPrompt$AuthenticationCallback = (BiometricPrompt$AuthenticationCallback) ze7Var3.f50208i;
        try {
            if (cryptoObjectM6857a == null) {
                oy0.m15025b(biometricPromptM15026c, cancellationSignal, ry0Var2, biometricPrompt$AuthenticationCallback);
            } else {
                oy0.m15024a(biometricPromptM15026c, cryptoObjectM6857a, cancellationSignal, ry0Var2, biometricPrompt$AuthenticationCallback);
            }
        } catch (NullPointerException e2) {
            Log.e("BiometricFragment", "Got NPE while authenticating with biometric prompt.", e2);
            if (context != null) {
                string = context.getString(R.string.default_error_msg);
            }
            m756o(1, string);
        }
    }
}
