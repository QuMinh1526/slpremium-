package androidx.biometric;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.RestrictTo;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import com.squareup.picasso.BuildConfig;
import ginlemon.flowerfree.R;
import p000.AbstractC1295pv;
import p000.C1521v3;
import p000.az0;
import p000.fo9;
import p000.mcb;
import p000.ny6;
import p000.ob2;
import p000.ocb;
import p000.sr5;
import p000.t44;
import p000.v44;
import p000.wi0;
import p000.wy0;
import p000.zu8;
import p000.zy0;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@RestrictTo({RestrictTo.Scope.LIBRARY})
public class FingerprintDialogFragment extends DialogFragment {

    /* JADX INFO: renamed from: A */
    public int f1140A;

    /* JADX INFO: renamed from: B */
    public ImageView f1141B;

    /* JADX INFO: renamed from: C */
    public TextView f1142C;

    /* JADX INFO: renamed from: e */
    public final Handler f1143e = new Handler(Looper.getMainLooper());

    /* JADX INFO: renamed from: i */
    public final wi0 f1144i = new wi0(this, 8);

    /* JADX INFO: renamed from: y */
    public az0 f1145y;

    /* JADX INFO: renamed from: z */
    public int f1146z;

    /* JADX INFO: renamed from: k */
    public final int m761k(int i) {
        Context context = getContext();
        FragmentActivity activity = getActivity();
        if (context == null || activity == null) {
            Log.w("FingerprintFragment", "Unable to get themed color. Context or activity is null.");
            return 0;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(i, typedValue, true);
        TypedArray typedArrayObtainStyledAttributes = activity.obtainStyledAttributes(typedValue.data, new int[]{i});
        int color = typedArrayObtainStyledAttributes.getColor(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        return color;
    }

    @Override // androidx.fragment.app.DialogFragment, android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        super.onCancel(dialogInterface);
        az0 az0Var = this.f1145y;
        if (az0Var.f3082P == null) {
            az0Var.f3082P = new ny6();
        }
        az0.m1910C(az0Var.f3082P, Boolean.TRUE);
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        FragmentActivity activity = getActivity();
        int i = 0;
        if (activity != null) {
            ocb viewModelStore = activity.getViewModelStore();
            mcb defaultViewModelProviderFactory = activity.getDefaultViewModelProviderFactory();
            ob2 defaultViewModelCreationExtras = activity.getDefaultViewModelCreationExtras();
            viewModelStore.getClass();
            defaultViewModelProviderFactory.getClass();
            defaultViewModelCreationExtras.getClass();
            fo9 fo9Var = new fo9(viewModelStore, defaultViewModelProviderFactory, defaultViewModelCreationExtras);
            sr5 sr5VarMo1868b = zu8.f50914a.mo1868b(az0.class);
            String strMo17162a = sr5VarMo1868b.mo17162a();
            if (strMo17162a == null) {
                C1521v3.m18903j("Local and anonymous classes can not be ViewModels");
                return;
            }
            az0 az0Var = (az0) fo9Var.m8228t(sr5VarMo1868b, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strMo17162a));
            this.f1145y = az0Var;
            if (az0Var.f3084R == null) {
                az0Var.f3084R = new ny6();
            }
            az0Var.f3084R.mo1943d(this, new t44(this, i));
            az0 az0Var2 = this.f1145y;
            if (az0Var2.f3085S == null) {
                az0Var2.f3085S = new ny6();
            }
            az0Var2.f3085S.mo1943d(this, new t44(this, 1));
        }
        if (Build.VERSION.SDK_INT >= 26) {
            this.f1146z = m761k(v44.m18918a());
        } else {
            Context context = getContext();
            this.f1146z = context != null ? context.getColor(R.color.biometric_error_color) : 0;
        }
        this.f1140A = m761k(android.R.attr.textColorSecondary);
    }

    @Override // androidx.fragment.app.DialogFragment
    public final Dialog onCreateDialog(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        wy0 wy0Var = this.f1145y.f3087i;
        CharSequence string = null;
        builder.setTitle(wy0Var != null ? wy0Var.f46213a : null);
        View viewInflate = LayoutInflater.from(builder.getContext()).inflate(R.layout.fingerprint_dialog_layout, (ViewGroup) null);
        TextView textView = (TextView) viewInflate.findViewById(R.id.fingerprint_subtitle);
        if (textView != null) {
            this.f1145y.getClass();
            if (TextUtils.isEmpty(null)) {
                textView.setVisibility(8);
            } else {
                textView.setVisibility(0);
                textView.setText((CharSequence) null);
            }
        }
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.fingerprint_description);
        if (textView2 != null) {
            wy0 wy0Var2 = this.f1145y.f3087i;
            CharSequence charSequence = wy0Var2 != null ? wy0Var2.f46214b : null;
            if (TextUtils.isEmpty(charSequence)) {
                textView2.setVisibility(8);
            } else {
                textView2.setVisibility(0);
                textView2.setText(charSequence);
            }
        }
        this.f1141B = (ImageView) viewInflate.findViewById(R.id.fingerprint_icon);
        this.f1142C = (TextView) viewInflate.findViewById(R.id.fingerprint_error);
        if (AbstractC1295pv.m15510Z(this.f1145y.m1913x())) {
            string = getString(R.string.confirm_device_credential_password);
        } else {
            az0 az0Var = this.f1145y;
            String str = az0Var.f3069C;
            if (str != null) {
                string = str;
            } else {
                wy0 wy0Var3 = az0Var.f3087i;
                if (wy0Var3 != null && (string = wy0Var3.f46215c) == null) {
                    string = BuildConfig.VERSION_NAME;
                }
            }
        }
        builder.setNegativeButton(string, new zy0(this, 1));
        builder.setView(viewInflate);
        AlertDialog alertDialogCreate = builder.create();
        alertDialogCreate.setCanceledOnTouchOutside(false);
        return alertDialogCreate;
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onPause() {
        super.onPause();
        this.f1143e.removeCallbacksAndMessages(null);
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC0156m
    public final void onResume() {
        super.onResume();
        az0 az0Var = this.f1145y;
        az0Var.f3083Q = 0;
        az0Var.m1911A(1);
        this.f1145y.m1915z(getString(R.string.fingerprint_dialog_touch_sensor));
    }
}
