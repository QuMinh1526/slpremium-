package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: renamed from: androidx.recyclerview.widget.r */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public final class C0188r implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        StaggeredGridLayoutManager.SavedState savedState = new StaggeredGridLayoutManager.SavedState();
        savedState.f2107e = parcel.readInt();
        savedState.f2108i = parcel.readInt();
        int i = parcel.readInt();
        savedState.f2109y = i;
        if (i > 0) {
            int[] iArr = new int[i];
            savedState.f2110z = iArr;
            parcel.readIntArray(iArr);
        }
        int i2 = parcel.readInt();
        savedState.f2101A = i2;
        if (i2 > 0) {
            int[] iArr2 = new int[i2];
            savedState.f2102B = iArr2;
            parcel.readIntArray(iArr2);
        }
        savedState.f2104D = parcel.readInt() == 1;
        savedState.f2105E = parcel.readInt() == 1;
        savedState.f2106F = parcel.readInt() == 1;
        savedState.f2103C = parcel.readArrayList(StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem.class.getClassLoader());
        return savedState;
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i) {
        return new StaggeredGridLayoutManager.SavedState[i];
    }
}
