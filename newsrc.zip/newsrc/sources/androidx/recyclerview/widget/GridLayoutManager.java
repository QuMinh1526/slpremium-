package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.WeakHashMap;
import p000.C0446e7;
import p000.C0644j7;
import p000.C0681k7;
import p000.C1521v3;
import p000.ab6;
import p000.et8;
import p000.hj4;
import p000.mn0;
import p000.obb;
import p000.rp4;
import p000.vf3;
import p000.z23;
import p000.z82;
import p000.zo1;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {

    /* JADX INFO: renamed from: P */
    public static final Set f1954P = Collections.unmodifiableSet(new HashSet(Arrays.asList(17, 66, 33, 130)));

    /* JADX INFO: renamed from: E */
    public boolean f1955E;

    /* JADX INFO: renamed from: F */
    public int f1956F;

    /* JADX INFO: renamed from: G */
    public int[] f1957G;

    /* JADX INFO: renamed from: H */
    public View[] f1958H;

    /* JADX INFO: renamed from: I */
    public final SparseIntArray f1959I;

    /* JADX INFO: renamed from: J */
    public final SparseIntArray f1960J;

    /* JADX INFO: renamed from: K */
    public mn0 f1961K;

    /* JADX INFO: renamed from: L */
    public final Rect f1962L;

    /* JADX INFO: renamed from: M */
    public int f1963M;

    /* JADX INFO: renamed from: N */
    public int f1964N;

    /* JADX INFO: renamed from: O */
    public int f1965O;

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.f1955E = false;
        this.f1956F = -1;
        this.f1959I = new SparseIntArray();
        this.f1960J = new SparseIntArray();
        this.f1961K = new rp4();
        this.f1962L = new Rect();
        this.f1963M = -1;
        this.f1964N = -1;
        this.f1965O = -1;
        m1243w1(AbstractC0181k.m1442I(context, attributeSet, i, i2).f44284b);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: F0 */
    public final boolean mo1204F0() {
        return this.f1982z == null && !this.f1955E;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    /* JADX INFO: renamed from: H0 */
    public final void mo1205H0(et8 et8Var, C0172b c0172b, zo1 zo1Var) {
        int i;
        int iMo13577c = this.f1956F;
        for (int i2 = 0; i2 < this.f1956F && (i = c0172b.f2119d) >= 0 && i < et8Var.m7762b() && iMo13577c > 0; i2++) {
            int i3 = c0172b.f2119d;
            zo1Var.m21325a(i3, Math.max(0, c0172b.f2122g));
            iMo13577c -= this.f1961K.mo13577c(i3);
            c0172b.f2119d += c0172b.f2120e;
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: J */
    public final int mo1206J(C0182l c0182l, et8 et8Var) {
        if (this.f1972p == 0) {
            return Math.min(this.f1956F, m1448C());
        }
        if (et8Var.m7762b() < 1) {
            return 0;
        }
        return m1236s1(et8Var.m7762b() - 1, et8Var, c0182l) + 1;
    }

    /* JADX WARN: Code restructure failed: missing block: B:62:0x00e2, code lost:
    
        if (r13 == (r2 > r15)) goto L57;
     */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: U */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.view.View mo1207U(android.view.View r23, int r24, androidx.recyclerview.widget.C0182l r25, p000.et8 r26) {
        /*
            Method dump skipped, instruction units count: 323
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.mo1207U(android.view.View, int, androidx.recyclerview.widget.l, et8):android.view.View");
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    /* JADX INFO: renamed from: U0 */
    public final View mo1208U0(C0182l c0182l, et8 et8Var, boolean z, boolean z2) {
        int i;
        int iM1471w;
        int iM1471w2 = m1471w();
        int i2 = 1;
        if (z2) {
            iM1471w = m1471w() - 1;
            i = -1;
            i2 = -1;
        } else {
            i = iM1471w2;
            iM1471w = 0;
        }
        int iM7762b = et8Var.m7762b();
        m1256M0();
        int iMo1417k = this.f1974r.mo1417k();
        int iMo1413g = this.f1974r.mo1413g();
        View view = null;
        View view2 = null;
        while (iM1471w != i) {
            View viewM1469v = m1469v(iM1471w);
            int iM1441H = AbstractC0181k.m1441H(viewM1469v);
            if (iM1441H >= 0 && iM1441H < iM7762b && m1238t1(iM1441H, et8Var, c0182l) == 0) {
                if (((RecyclerView.LayoutParams) viewM1469v.getLayoutParams()).f2069a.m1505j()) {
                    if (view2 == null) {
                        view2 = viewM1469v;
                    }
                } else {
                    if (this.f1974r.mo1411e(viewM1469v) < iMo1413g && this.f1974r.mo1408b(viewM1469v) >= iMo1417k) {
                        return viewM1469v;
                    }
                    if (view == null) {
                        view = viewM1469v;
                    }
                }
            }
            iM1471w += i2;
        }
        return view != null ? view : view2;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: W */
    public final void mo1209W(C0182l c0182l, et8 et8Var, C0681k7 c0681k7) {
        super.mo1209W(c0182l, et8Var, c0681k7);
        c0681k7.m11852j(GridView.class.getName());
        AbstractC0177g abstractC0177g = this.f2142b.f2009I;
        if (abstractC0177g == null || abstractC0177g.mo1422a() <= 1) {
            return;
        }
        c0681k7.m11845b(C0446e7.f12031u);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: Y */
    public final void mo1210Y(C0182l c0182l, et8 et8Var, View view, C0681k7 c0681k7) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof LayoutParams)) {
            m1457X(view, c0681k7);
            return;
        }
        LayoutParams layoutParams2 = (LayoutParams) layoutParams;
        int iM1236s1 = m1236s1(layoutParams2.f2069a.m1499d(), et8Var, c0182l);
        int i = this.f1972p;
        int i2 = layoutParams2.f1966e;
        int i3 = layoutParams2.f1967f;
        if (i == 0) {
            c0681k7.m11854l(C0644j7.m11151a(i2, i3, iM1236s1, 1, false, false));
        } else {
            c0681k7.m11854l(C0644j7.m11151a(iM1236s1, 1, i2, i3, false, false));
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: Z */
    public final void mo1211Z(int i, int i2) {
        this.f1961K.m13578d();
        ((SparseIntArray) this.f1961K.f28683b).clear();
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: a0 */
    public final void mo1212a0() {
        this.f1961K.m13578d();
        ((SparseIntArray) this.f1961K.f28683b).clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    /* JADX INFO: renamed from: a1 */
    public final void mo1213a1(C0182l c0182l, et8 et8Var, C0172b c0172b, ab6 ab6Var) {
        int i;
        int i2;
        int i3;
        int iMo1410d;
        int iM1451E;
        int iM1446x;
        int iM1446x2;
        boolean z;
        int i4;
        View viewM1400b;
        int iMo1416j = this.f1974r.mo1416j();
        boolean z2 = iMo1416j != 1073741824;
        int i5 = m1471w() > 0 ? this.f1957G[this.f1956F] : 0;
        if (z2) {
            m1245x1();
        }
        boolean z3 = c0172b.f2120e == 1;
        int iM1238t1 = this.f1956F;
        if (!z3) {
            iM1238t1 = m1238t1(c0172b.f2119d, et8Var, c0182l) + m1241u1(c0172b.f2119d, et8Var, c0182l);
        }
        int i6 = 0;
        while (i6 < this.f1956F && (i4 = c0172b.f2119d) >= 0 && i4 < et8Var.m7762b() && iM1238t1 > 0) {
            int i7 = c0172b.f2119d;
            int iM1241u1 = m1241u1(i7, et8Var, c0182l);
            if (iM1241u1 > this.f1956F) {
                C1521v3.m18903j(z23.m20931m(this.f1956F, " spans.", z23.m20940v(i7, iM1241u1, "Item at position ", " requires ", " spans but GridLayoutManager has only ")));
                return;
            }
            iM1238t1 -= iM1241u1;
            if (iM1238t1 < 0 || (viewM1400b = c0172b.m1400b(c0182l)) == null) {
                break;
            }
            this.f1958H[i6] = viewM1400b;
            i6++;
        }
        if (i6 == 0) {
            ab6Var.f570b = true;
            return;
        }
        if (z3) {
            i3 = 1;
            i2 = i6;
            i = 0;
        } else {
            i = i6 - 1;
            i2 = -1;
            i3 = -1;
        }
        int i8 = 0;
        while (i != i2) {
            View view = this.f1958H[i];
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            int iM1241u2 = m1241u1(AbstractC0181k.m1441H(view), et8Var, c0182l);
            layoutParams.f1967f = iM1241u2;
            layoutParams.f1966e = i8;
            i8 += iM1241u2;
            i += i3;
        }
        float f = 0.0f;
        int i9 = 0;
        for (int i10 = 0; i10 < i6; i10++) {
            View view2 = this.f1958H[i10];
            if (c0172b.f2126k != null) {
                z = false;
                if (z3) {
                    m1458b(view2, -1, true);
                } else {
                    m1458b(view2, 0, true);
                }
            } else if (z3) {
                z = false;
                m1458b(view2, -1, false);
            } else {
                z = false;
                m1458b(view2, 0, false);
            }
            m1459d(view2, this.f1962L);
            m1242v1(view2, iMo1416j, z);
            int iMo1409c = this.f1974r.mo1409c(view2);
            if (iMo1409c > i9) {
                i9 = iMo1409c;
            }
            float fMo1410d = (this.f1974r.mo1410d(view2) * 1.0f) / ((LayoutParams) view2.getLayoutParams()).f1967f;
            if (fMo1410d > f) {
                f = fMo1410d;
            }
        }
        if (z2) {
            m1224l1(Math.max(Math.round(f * this.f1956F), i5));
            i9 = 0;
            for (int i11 = 0; i11 < i6; i11++) {
                View view3 = this.f1958H[i11];
                m1242v1(view3, 1073741824, true);
                int iMo1409c2 = this.f1974r.mo1409c(view3);
                if (iMo1409c2 > i9) {
                    i9 = iMo1409c2;
                }
            }
        }
        for (int i12 = 0; i12 < i6; i12++) {
            View view4 = this.f1958H[i12];
            if (this.f1974r.mo1409c(view4) != i9) {
                LayoutParams layoutParams2 = (LayoutParams) view4.getLayoutParams();
                Rect rect = layoutParams2.f2070b;
                int i13 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin;
                int i14 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) layoutParams2).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).rightMargin;
                int iM1233r1 = m1233r1(layoutParams2.f1966e, layoutParams2.f1967f);
                if (this.f1972p == 1) {
                    iM1446x2 = AbstractC0181k.m1446x(false, iM1233r1, 1073741824, i14, ((ViewGroup.MarginLayoutParams) layoutParams2).width);
                    iM1446x = View.MeasureSpec.makeMeasureSpec(i9 - i13, 1073741824);
                } else {
                    int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i9 - i14, 1073741824);
                    iM1446x = AbstractC0181k.m1446x(false, iM1233r1, 1073741824, i13, ((ViewGroup.MarginLayoutParams) layoutParams2).height);
                    iM1446x2 = iMakeMeasureSpec;
                }
                if (m1449C0(view4, iM1446x2, iM1446x, (RecyclerView.LayoutParams) view4.getLayoutParams())) {
                    view4.measure(iM1446x2, iM1446x);
                }
            }
        }
        int iM1454G = 0;
        ab6Var.f569a = i9;
        int i15 = this.f1972p;
        int i16 = c0172b.f2121f;
        int iMo1410d2 = c0172b.f2117b;
        if (i15 != 1) {
            if (i16 == -1) {
                iM1451E = iMo1410d2 - i9;
                iMo1410d = iMo1410d2;
            } else {
                iMo1410d = iMo1410d2 + i9;
                iM1451E = iMo1410d2;
            }
            iMo1410d2 = iM1454G;
        } else if (i16 == -1) {
            iM1454G = iMo1410d2 - i9;
            iM1451E = 0;
            iMo1410d = 0;
        } else {
            iMo1410d = 0;
            iM1454G = iMo1410d2;
            iMo1410d2 += i9;
            iM1451E = 0;
        }
        int i17 = 0;
        while (true) {
            View[] viewArr = this.f1958H;
            if (i17 >= i6) {
                Arrays.fill(viewArr, (Object) null);
                return;
            }
            View view5 = viewArr[i17];
            LayoutParams layoutParams3 = (LayoutParams) view5.getLayoutParams();
            if (this.f1972p != 1) {
                iM1454G = m1454G() + this.f1957G[layoutParams3.f1966e];
                iMo1410d2 = this.f1974r.mo1410d(view5) + iM1454G;
            } else if (mo1270Z0()) {
                int iM1451E2 = m1451E() + this.f1957G[this.f1956F - layoutParams3.f1966e];
                iMo1410d = iM1451E2;
                iM1451E = iM1451E2 - this.f1974r.mo1410d(view5);
            } else {
                iM1451E = m1451E() + this.f1957G[layoutParams3.f1966e];
                iMo1410d = this.f1974r.mo1410d(view5) + iM1451E;
            }
            AbstractC0181k.m1444O(view5, iM1451E, iM1454G, iMo1410d, iMo1410d2);
            if (layoutParams3.f2069a.m1505j() || layoutParams3.f2069a.m1508m()) {
                ab6Var.f571c = true;
            }
            ab6Var.f572d = view5.hasFocusable() | ab6Var.f572d;
            i17++;
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: b0 */
    public final void mo1214b0(int i, int i2) {
        this.f1961K.m13578d();
        ((SparseIntArray) this.f1961K.f28683b).clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    /* JADX INFO: renamed from: b1 */
    public final void mo1215b1(C0182l c0182l, et8 et8Var, C0171a c0171a, int i) {
        m1245x1();
        if (et8Var.m7762b() > 0 && !et8Var.f13104g) {
            boolean z = i == 1;
            int iM1238t1 = m1238t1(c0171a.f2112b, et8Var, c0182l);
            if (z) {
                while (iM1238t1 > 0) {
                    int i2 = c0171a.f2112b;
                    if (i2 <= 0) {
                        break;
                    }
                    int i3 = i2 - 1;
                    c0171a.f2112b = i3;
                    iM1238t1 = m1238t1(i3, et8Var, c0182l);
                }
            } else {
                int iM7762b = et8Var.m7762b() - 1;
                int i4 = c0171a.f2112b;
                while (i4 < iM7762b) {
                    int i5 = i4 + 1;
                    int iM1238t2 = m1238t1(i5, et8Var, c0182l);
                    if (iM1238t2 <= iM1238t1) {
                        break;
                    }
                    i4 = i5;
                    iM1238t1 = iM1238t2;
                }
                c0171a.f2112b = i4;
            }
        }
        m1226m1();
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: c0 */
    public final void mo1216c0(int i, int i2) {
        this.f1961K.m13578d();
        ((SparseIntArray) this.f1961K.f28683b).clear();
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: d0 */
    public final void mo1217d0(int i, int i2) {
        this.f1961K.m13578d();
        ((SparseIntArray) this.f1961K.f28683b).clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: e0 */
    public final void mo1218e0(C0182l c0182l, et8 et8Var) {
        boolean z = et8Var.f13104g;
        SparseIntArray sparseIntArray = this.f1960J;
        SparseIntArray sparseIntArray2 = this.f1959I;
        if (z) {
            int iM1471w = m1471w();
            for (int i = 0; i < iM1471w; i++) {
                LayoutParams layoutParams = (LayoutParams) m1469v(i).getLayoutParams();
                int iM1499d = layoutParams.f2069a.m1499d();
                sparseIntArray2.put(iM1499d, layoutParams.f1967f);
                sparseIntArray.put(iM1499d, layoutParams.f1966e);
            }
        }
        super.mo1218e0(c0182l, et8Var);
        sparseIntArray2.clear();
        sparseIntArray.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: f0 */
    public final void mo1219f0(et8 et8Var) {
        View viewMo1289r;
        super.mo1219f0(et8Var);
        this.f1955E = false;
        int i = this.f1963M;
        if (i == -1 || (viewMo1289r = mo1289r(i)) == null) {
            return;
        }
        viewMo1289r.sendAccessibilityEvent(67108864);
        this.f1963M = -1;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: g */
    public final boolean mo1220g(RecyclerView.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    /* JADX INFO: renamed from: h1 */
    public final void mo1221h1(boolean z) {
        if (z) {
            vf3.m19097o("GridLayoutManager does not support stack from end. Consider using reverse layout");
        } else {
            super.mo1221h1(false);
        }
    }

    /* JADX WARN: Code duplicated, block: B:118:0x01a1  */
    /* JADX WARN: Code duplicated, block: B:121:0x01a7  */
    /* JADX WARN: Code duplicated, block: B:122:0x01a9 A[EDGE_INSN: B:122:0x01a9->B:166:0x027c BREAK  A[LOOP:2: B:126:0x01b9->B:135:0x01e2, LOOP_LABEL: LOOP:2: B:126:0x01b9->B:135:0x01e2]] */
    /* JADX WARN: Code duplicated, block: B:123:0x01ac A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:128:0x01bf  */
    /* JADX WARN: Code duplicated, block: B:131:0x01cd  */
    /* JADX WARN: Code duplicated, block: B:134:0x01da A[LOOP:3: B:129:0x01c7->B:134:0x01da, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:139:0x01f3  */
    /* JADX WARN: Code duplicated, block: B:142:0x0213  */
    /* JADX WARN: Code duplicated, block: B:143:0x0215  */
    /* JADX WARN: Code duplicated, block: B:145:0x0218 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:150:0x0227  */
    /* JADX WARN: Code duplicated, block: B:153:0x0235  */
    /* JADX WARN: Code duplicated, block: B:156:0x0243  */
    /* JADX WARN: Code duplicated, block: B:163:0x0262  */
    /* JADX WARN: Code duplicated, block: B:167:0x027e  */
    /* JADX WARN: Code duplicated, block: B:209:0x01a9 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:210:0x01e5 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:211:0x01e2 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:212:0x01a9 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:213:0x01ff A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:214:? A[LOOP:4: B:137:0x01ed->B:214:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:215:0x0254 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:216:0x01a9 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:217:0x0251 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:218:0x0249 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:220:0x022f A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:222:0x01a9 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:223:0x026e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:224:? A[LOOP:7: B:161:0x025c->B:224:?, LOOP_END, SYNTHETIC] */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: j0 */
    public final boolean mo1222j0(int i, Bundle bundle) {
        View viewM1469v;
        AbstractC0185o abstractC0185oM1311L;
        int iIntValue;
        int i2;
        TreeMap treeMap;
        int i3;
        Iterator it;
        Integer num;
        int iIntValue2;
        Iterator it2;
        Integer num2;
        TreeMap treeMap2;
        int i4;
        Iterator it3;
        Integer num3;
        int iIntValue3;
        Iterator it4;
        Integer num4;
        if (i == C0446e7.f12031u.m7322a() && i != -1) {
            int i5 = 0;
            while (true) {
                if (i5 >= m1471w()) {
                    viewM1469v = null;
                    break;
                }
                View viewM1469v2 = m1469v(i5);
                Objects.requireNonNull(viewM1469v2);
                if (hj4.m10174U(viewM1469v2)) {
                    viewM1469v = m1469v(i5);
                    break;
                }
                i5++;
            }
            if (viewM1469v != null && bundle != null) {
                int i6 = bundle.getInt("android.view.accessibility.action.ARGUMENT_DIRECTION_INT", -1);
                if (f1954P.contains(Integer.valueOf(i6)) && (abstractC0185oM1311L = this.f2142b.m1311L(viewM1469v)) != null) {
                    int iM1497b = abstractC0185oM1311L.m1497b();
                    int iM1229o1 = m1229o1(iM1497b);
                    int iM1227n1 = m1227n1(iM1497b);
                    if (iM1229o1 >= 0 && iM1227n1 >= 0) {
                        if (!m1231p1(iM1497b).contains(Integer.valueOf(this.f1964N)) || !m1232q1(m1227n1(iM1497b), iM1497b).contains(Integer.valueOf(this.f1965O))) {
                            this.f1964N = iM1229o1;
                            this.f1965O = iM1227n1;
                        }
                        int i7 = this.f1964N;
                        if (i7 == -1) {
                            i7 = iM1229o1;
                        }
                        int i8 = this.f1965O;
                        if (i8 != -1) {
                            iM1227n1 = i8;
                        }
                        if (i6 == 17) {
                            iIntValue = iM1497b - 1;
                            while (true) {
                                if (iIntValue >= 0) {
                                    int iM1229o2 = m1229o1(iIntValue);
                                    int iM1227n2 = m1227n1(iIntValue);
                                    if (iM1229o2 >= 0 && iM1227n2 >= 0) {
                                        if (this.f1972p != 1) {
                                            if (m1231p1(iIntValue).contains(Integer.valueOf(i7)) && iM1227n2 < iM1227n1) {
                                                this.f1965O = iM1227n2;
                                                break;
                                            }
                                            iIntValue--;
                                        } else {
                                            if ((iM1229o2 == i7 && iM1227n2 < iM1227n1) || iM1229o2 < i7) {
                                                this.f1964N = iM1229o2;
                                                this.f1965O = iM1227n2;
                                                break;
                                            }
                                            iIntValue--;
                                        }
                                    }
                                }
                                iIntValue = -1;
                                break;
                            }
                            if (iIntValue == -1) {
                                if (i6 == 17) {
                                    if (i6 == 66) {
                                        if (iM1229o1 < 0) {
                                            treeMap = new TreeMap();
                                            i3 = 0;
                                            loop5: while (true) {
                                                if (i3 < m1448C()) {
                                                    it2 = m1231p1(i3).iterator();
                                                    while (true) {
                                                        if (it2.hasNext()) {
                                                            num2 = (Integer) it2.next();
                                                            if (num2.intValue() < 0) {
                                                                if (!treeMap.containsKey(num2)) {
                                                                    treeMap.put(num2, Integer.valueOf(i3));
                                                                }
                                                            }
                                                        } else {
                                                            i3++;
                                                        }
                                                    }
                                                } else {
                                                    it = treeMap.keySet().iterator();
                                                    while (true) {
                                                        if (it.hasNext()) {
                                                            num = (Integer) it.next();
                                                            iIntValue2 = num.intValue();
                                                            if (iIntValue2 > iM1229o1) {
                                                                iIntValue = ((Integer) treeMap.get(num)).intValue();
                                                                this.f1964N = iIntValue2;
                                                                this.f1965O = 0;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                iIntValue = -1;
                                                break loop2;
                                            }
                                        }
                                        iIntValue = -1;
                                        break loop2;
                                    }
                                } else {
                                    if (iM1229o1 < 0) {
                                        treeMap2 = new TreeMap(Collections.reverseOrder());
                                        i4 = 0;
                                        loop2: while (true) {
                                            if (i4 < m1448C()) {
                                                it4 = m1231p1(i4).iterator();
                                                while (true) {
                                                    if (it4.hasNext()) {
                                                        num4 = (Integer) it4.next();
                                                        if (num4.intValue() < 0) {
                                                            treeMap2.put(num4, Integer.valueOf(i4));
                                                        }
                                                    } else {
                                                        i4++;
                                                    }
                                                }
                                            } else {
                                                it3 = treeMap2.keySet().iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        num3 = (Integer) it3.next();
                                                        iIntValue3 = num3.intValue();
                                                        if (iIntValue3 < iM1229o1) {
                                                            iIntValue = ((Integer) treeMap2.get(num3)).intValue();
                                                            this.f1964N = iIntValue3;
                                                            this.f1965O = m1227n1(iIntValue);
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            iIntValue = -1;
                                            break loop2;
                                        }
                                    }
                                    iIntValue = -1;
                                    break loop2;
                                }
                            }
                            if (iIntValue != -1) {
                                mo1290t0(iIntValue);
                                this.f1963M = iIntValue;
                                return true;
                            }
                        } else if (i6 == 33) {
                            iIntValue = iM1497b - 1;
                            while (true) {
                                if (iIntValue >= 0) {
                                    int iM1229o3 = m1229o1(iIntValue);
                                    int iM1227n3 = m1227n1(iIntValue);
                                    if (iM1229o3 >= 0 && iM1227n3 >= 0) {
                                        if (this.f1972p != 1) {
                                            if (iM1229o3 < i7 && iM1227n3 == iM1227n1) {
                                                this.f1964N = ((Integer) Collections.max(m1231p1(iIntValue))).intValue();
                                                break;
                                            }
                                            iIntValue--;
                                        } else {
                                            if (iM1229o3 < i7 && m1232q1(m1227n1(iIntValue), iIntValue).contains(Integer.valueOf(iM1227n1))) {
                                                this.f1964N = iM1229o3;
                                                break;
                                            }
                                            iIntValue--;
                                        }
                                    }
                                }
                                iIntValue = -1;
                                break;
                            }
                            if (iIntValue == -1) {
                                if (i6 == 17) {
                                    if (i6 == 66) {
                                        if (iM1229o1 < 0) {
                                            treeMap = new TreeMap();
                                            i3 = 0;
                                            loop5: while (true) {
                                                if (i3 < m1448C()) {
                                                    it2 = m1231p1(i3).iterator();
                                                    while (true) {
                                                        if (it2.hasNext()) {
                                                            num2 = (Integer) it2.next();
                                                            if (num2.intValue() < 0) {
                                                                if (!treeMap.containsKey(num2)) {
                                                                    treeMap.put(num2, Integer.valueOf(i3));
                                                                }
                                                            }
                                                        } else {
                                                            i3++;
                                                        }
                                                    }
                                                } else {
                                                    it = treeMap.keySet().iterator();
                                                    while (true) {
                                                        if (it.hasNext()) {
                                                            num = (Integer) it.next();
                                                            iIntValue2 = num.intValue();
                                                            if (iIntValue2 > iM1229o1) {
                                                                iIntValue = ((Integer) treeMap.get(num)).intValue();
                                                                this.f1964N = iIntValue2;
                                                                this.f1965O = 0;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                iIntValue = -1;
                                                break loop2;
                                            }
                                        }
                                        iIntValue = -1;
                                        break loop2;
                                    }
                                } else {
                                    if (iM1229o1 < 0) {
                                        treeMap2 = new TreeMap(Collections.reverseOrder());
                                        i4 = 0;
                                        loop2: while (true) {
                                            if (i4 < m1448C()) {
                                                it4 = m1231p1(i4).iterator();
                                                while (true) {
                                                    if (it4.hasNext()) {
                                                        num4 = (Integer) it4.next();
                                                        if (num4.intValue() < 0) {
                                                            treeMap2.put(num4, Integer.valueOf(i4));
                                                        }
                                                    } else {
                                                        i4++;
                                                    }
                                                }
                                            } else {
                                                it3 = treeMap2.keySet().iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        num3 = (Integer) it3.next();
                                                        iIntValue3 = num3.intValue();
                                                        if (iIntValue3 < iM1229o1) {
                                                            iIntValue = ((Integer) treeMap2.get(num3)).intValue();
                                                            this.f1964N = iIntValue3;
                                                            this.f1965O = m1227n1(iIntValue);
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            iIntValue = -1;
                                            break loop2;
                                        }
                                    }
                                    iIntValue = -1;
                                    break loop2;
                                }
                            }
                            if (iIntValue != -1) {
                                mo1290t0(iIntValue);
                                this.f1963M = iIntValue;
                                return true;
                            }
                        } else if (i6 == 66) {
                            iIntValue = iM1497b + 1;
                            while (true) {
                                if (iIntValue < m1448C()) {
                                    int iM1229o4 = m1229o1(iIntValue);
                                    int iM1227n4 = m1227n1(iIntValue);
                                    if (iM1229o4 >= 0 && iM1227n4 >= 0) {
                                        if (this.f1972p != 1) {
                                            if (iM1227n4 > iM1227n1 && m1231p1(iIntValue).contains(Integer.valueOf(i7))) {
                                                this.f1965O = iM1227n4;
                                                break;
                                            }
                                            iIntValue++;
                                        } else {
                                            if ((iM1229o4 == i7 && iM1227n4 > iM1227n1) || iM1229o4 > i7) {
                                                this.f1964N = iM1229o4;
                                                this.f1965O = iM1227n4;
                                                break;
                                            }
                                            iIntValue++;
                                        }
                                    }
                                }
                                iIntValue = -1;
                                break;
                            }
                            if (iIntValue == -1) {
                                if (i6 == 17) {
                                    if (i6 == 66) {
                                        if (iM1229o1 < 0) {
                                            treeMap = new TreeMap();
                                            i3 = 0;
                                            loop5: while (true) {
                                                if (i3 < m1448C()) {
                                                    it2 = m1231p1(i3).iterator();
                                                    while (true) {
                                                        if (it2.hasNext()) {
                                                            num2 = (Integer) it2.next();
                                                            if (num2.intValue() < 0) {
                                                                if (!treeMap.containsKey(num2)) {
                                                                    treeMap.put(num2, Integer.valueOf(i3));
                                                                }
                                                            }
                                                        } else {
                                                            i3++;
                                                        }
                                                    }
                                                } else {
                                                    it = treeMap.keySet().iterator();
                                                    while (true) {
                                                        if (it.hasNext()) {
                                                            num = (Integer) it.next();
                                                            iIntValue2 = num.intValue();
                                                            if (iIntValue2 > iM1229o1) {
                                                                iIntValue = ((Integer) treeMap.get(num)).intValue();
                                                                this.f1964N = iIntValue2;
                                                                this.f1965O = 0;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                iIntValue = -1;
                                                break loop2;
                                            }
                                        }
                                        iIntValue = -1;
                                        break loop2;
                                    }
                                } else {
                                    if (iM1229o1 < 0) {
                                        treeMap2 = new TreeMap(Collections.reverseOrder());
                                        i4 = 0;
                                        loop2: while (true) {
                                            if (i4 < m1448C()) {
                                                it4 = m1231p1(i4).iterator();
                                                while (true) {
                                                    if (it4.hasNext()) {
                                                        num4 = (Integer) it4.next();
                                                        if (num4.intValue() < 0) {
                                                            treeMap2.put(num4, Integer.valueOf(i4));
                                                        }
                                                    } else {
                                                        i4++;
                                                    }
                                                }
                                            } else {
                                                it3 = treeMap2.keySet().iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        num3 = (Integer) it3.next();
                                                        iIntValue3 = num3.intValue();
                                                        if (iIntValue3 < iM1229o1) {
                                                            iIntValue = ((Integer) treeMap2.get(num3)).intValue();
                                                            this.f1964N = iIntValue3;
                                                            this.f1965O = m1227n1(iIntValue);
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            iIntValue = -1;
                                            break loop2;
                                        }
                                    }
                                    iIntValue = -1;
                                    break loop2;
                                }
                            }
                            if (iIntValue != -1) {
                                mo1290t0(iIntValue);
                                this.f1963M = iIntValue;
                                return true;
                            }
                        } else if (i6 == 130) {
                            iIntValue = iM1497b + 1;
                            while (true) {
                                if (iIntValue < m1448C()) {
                                    int iM1229o5 = m1229o1(iIntValue);
                                    int iM1227n5 = m1227n1(iIntValue);
                                    if (iM1229o5 >= 0 && iM1227n5 >= 0) {
                                        if (this.f1972p != 1) {
                                            if (iM1229o5 > i7 && iM1227n5 == iM1227n1) {
                                                this.f1964N = m1229o1(iIntValue);
                                                break;
                                            }
                                            iIntValue++;
                                        } else {
                                            if (iM1229o5 > i7 && (iM1227n5 == iM1227n1 || m1232q1(m1227n1(iIntValue), iIntValue).contains(Integer.valueOf(iM1227n1)))) {
                                                this.f1964N = iM1229o5;
                                                break;
                                            }
                                            iIntValue++;
                                        }
                                    }
                                }
                                iIntValue = -1;
                                break;
                            }
                            if (iIntValue == -1 && (i2 = this.f1972p) == 0) {
                                if (i6 == 17) {
                                    if (i6 == 66) {
                                        if (iM1229o1 < 0 || i2 == 1) {
                                            iIntValue = -1;
                                            break loop2;
                                        }
                                        treeMap = new TreeMap();
                                        i3 = 0;
                                        loop5: while (true) {
                                            if (i3 < m1448C()) {
                                                it2 = m1231p1(i3).iterator();
                                                while (true) {
                                                    if (it2.hasNext()) {
                                                        num2 = (Integer) it2.next();
                                                        if (num2.intValue() < 0) {
                                                            if (!treeMap.containsKey(num2)) {
                                                                treeMap.put(num2, Integer.valueOf(i3));
                                                            }
                                                        }
                                                    } else {
                                                        i3++;
                                                    }
                                                }
                                            } else {
                                                it = treeMap.keySet().iterator();
                                                while (true) {
                                                    if (it.hasNext()) {
                                                        num = (Integer) it.next();
                                                        iIntValue2 = num.intValue();
                                                        if (iIntValue2 > iM1229o1) {
                                                            iIntValue = ((Integer) treeMap.get(num)).intValue();
                                                            this.f1964N = iIntValue2;
                                                            this.f1965O = 0;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            iIntValue = -1;
                                            break loop2;
                                        }
                                    }
                                } else {
                                    if (iM1229o1 < 0 || i2 == 1) {
                                        iIntValue = -1;
                                        break loop2;
                                    }
                                    treeMap2 = new TreeMap(Collections.reverseOrder());
                                    i4 = 0;
                                    loop2: while (true) {
                                        if (i4 < m1448C()) {
                                            it4 = m1231p1(i4).iterator();
                                            while (true) {
                                                if (it4.hasNext()) {
                                                    num4 = (Integer) it4.next();
                                                    if (num4.intValue() < 0) {
                                                        treeMap2.put(num4, Integer.valueOf(i4));
                                                    }
                                                } else {
                                                    i4++;
                                                }
                                            }
                                        } else {
                                            it3 = treeMap2.keySet().iterator();
                                            while (true) {
                                                if (it3.hasNext()) {
                                                    num3 = (Integer) it3.next();
                                                    iIntValue3 = num3.intValue();
                                                    if (iIntValue3 < iM1229o1) {
                                                        iIntValue = ((Integer) treeMap2.get(num3)).intValue();
                                                        this.f1964N = iIntValue3;
                                                        this.f1965O = m1227n1(iIntValue);
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        iIntValue = -1;
                                        break loop2;
                                    }
                                }
                            }
                            if (iIntValue != -1) {
                                mo1290t0(iIntValue);
                                this.f1963M = iIntValue;
                                return true;
                            }
                        }
                    }
                }
            }
        } else {
            if (i != 16908343 || bundle == null) {
                return super.mo1222j0(i, bundle);
            }
            int i9 = bundle.getInt("android.view.accessibility.action.ARGUMENT_ROW_INT", -1);
            int i10 = bundle.getInt("android.view.accessibility.action.ARGUMENT_COLUMN_INT", -1);
            if (i9 != -1 && i10 != -1) {
                int iMo1422a = this.f2142b.f2009I.mo1422a();
                int i11 = 0;
                while (true) {
                    if (i11 >= iMo1422a) {
                        i11 = -1;
                        break;
                    }
                    RecyclerView recyclerView = this.f2142b;
                    int iM1238t1 = m1238t1(i11, recyclerView.f2000D0, recyclerView.f2065y);
                    RecyclerView recyclerView2 = this.f2142b;
                    int iM1236s1 = m1236s1(i11, recyclerView2.f2000D0, recyclerView2.f2065y);
                    if (this.f1972p != 1) {
                        if (iM1238t1 == i9 && iM1236s1 == i10) {
                            break;
                        }
                        i11++;
                    } else {
                        if (iM1238t1 == i10 && iM1236s1 == i9) {
                            break;
                        }
                        i11++;
                    }
                }
                if (i11 > -1) {
                    this.f1980x = i11;
                    this.f1981y = 0;
                    LinearLayoutManager.SavedState savedState = this.f1982z;
                    if (savedState != null) {
                        savedState.f1983e = -1;
                    }
                    m1468r0();
                    return true;
                }
            }
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: l */
    public final int mo1223l(et8 et8Var) {
        return m1251J0(et8Var);
    }

    /* JADX INFO: renamed from: l1 */
    public final void m1224l1(int i) {
        int i2;
        int[] iArr = this.f1957G;
        int i3 = this.f1956F;
        if (iArr == null || iArr.length != i3 + 1 || iArr[iArr.length - 1] != i) {
            iArr = new int[i3 + 1];
        }
        int i4 = 0;
        iArr[0] = 0;
        int i5 = i / i3;
        int i6 = i % i3;
        int i7 = 0;
        for (int i8 = 1; i8 <= i3; i8++) {
            i4 += i6;
            if (i4 <= 0 || i3 - i4 >= i6) {
                i2 = i5;
            } else {
                i2 = i5 + 1;
                i4 -= i3;
            }
            i7 += i2;
            iArr[i8] = i7;
        }
        this.f1957G = iArr;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: m */
    public final int mo1225m(et8 et8Var) {
        return m1252K0(et8Var);
    }

    /* JADX INFO: renamed from: m1 */
    public final void m1226m1() {
        View[] viewArr = this.f1958H;
        if (viewArr == null || viewArr.length != this.f1956F) {
            this.f1958H = new View[this.f1956F];
        }
    }

    /* JADX INFO: renamed from: n1 */
    public final int m1227n1(int i) {
        int i2 = this.f1972p;
        RecyclerView recyclerView = this.f2142b;
        if (i2 == 0) {
            return m1236s1(i, recyclerView.f2000D0, recyclerView.f2065y);
        }
        return m1238t1(i, recyclerView.f2000D0, recyclerView.f2065y);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: o */
    public int mo1228o(et8 et8Var) {
        return m1251J0(et8Var);
    }

    /* JADX INFO: renamed from: o1 */
    public final int m1229o1(int i) {
        int i2 = this.f1972p;
        RecyclerView recyclerView = this.f2142b;
        if (i2 == 1) {
            return m1236s1(i, recyclerView.f2000D0, recyclerView.f2065y);
        }
        return m1238t1(i, recyclerView.f2000D0, recyclerView.f2065y);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: p */
    public int mo1230p(et8 et8Var) {
        return m1252K0(et8Var);
    }

    /* JADX INFO: renamed from: p1 */
    public final HashSet m1231p1(int i) {
        return m1232q1(m1229o1(i), i);
    }

    /* JADX INFO: renamed from: q1 */
    public final HashSet m1232q1(int i, int i2) {
        HashSet hashSet = new HashSet();
        RecyclerView recyclerView = this.f2142b;
        int iM1241u1 = m1241u1(i2, recyclerView.f2000D0, recyclerView.f2065y);
        for (int i3 = i; i3 < i + iM1241u1; i3++) {
            hashSet.add(Integer.valueOf(i3));
        }
        return hashSet;
    }

    /* JADX INFO: renamed from: r1 */
    public final int m1233r1(int i, int i2) {
        if (this.f1972p != 1 || !mo1270Z0()) {
            int[] iArr = this.f1957G;
            return iArr[i2 + i] - iArr[i];
        }
        int[] iArr2 = this.f1957G;
        int i3 = this.f1956F;
        return iArr2[i3 - i] - iArr2[(i3 - i) - i2];
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: s */
    public final RecyclerView.LayoutParams mo1234s() {
        return this.f1972p == 0 ? new LayoutParams(-2, -1) : new LayoutParams(-1, -2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: s0 */
    public final int mo1235s0(int i, et8 et8Var, C0182l c0182l) {
        m1245x1();
        m1226m1();
        return super.mo1235s0(i, et8Var, c0182l);
    }

    /* JADX INFO: renamed from: s1 */
    public final int m1236s1(int i, et8 et8Var, C0182l c0182l) {
        if (!et8Var.f13104g) {
            return this.f1961K.m13575a(i, this.f1956F);
        }
        int iM1477b = c0182l.m1477b(i);
        if (iM1477b != -1) {
            return this.f1961K.m13575a(iM1477b, this.f1956F);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i);
        return 0;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: t */
    public final RecyclerView.LayoutParams mo1237t(Context context, AttributeSet attributeSet) {
        return new LayoutParams(context, attributeSet);
    }

    /* JADX INFO: renamed from: t1 */
    public final int m1238t1(int i, et8 et8Var, C0182l c0182l) {
        if (!et8Var.f13104g) {
            return this.f1961K.mo13576b(i, this.f1956F);
        }
        int i2 = this.f1960J.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int iM1477b = c0182l.m1477b(i);
        if (iM1477b != -1) {
            return this.f1961K.mo13576b(iM1477b, this.f1956F);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
        return 0;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: u */
    public final RecyclerView.LayoutParams mo1239u(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            LayoutParams layoutParams2 = new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams);
            layoutParams2.f1966e = -1;
            layoutParams2.f1967f = 0;
            return layoutParams2;
        }
        LayoutParams layoutParams3 = new LayoutParams(layoutParams);
        layoutParams3.f1966e = -1;
        layoutParams3.f1967f = 0;
        return layoutParams3;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: u0 */
    public final int mo1240u0(int i, et8 et8Var, C0182l c0182l) {
        m1245x1();
        m1226m1();
        return super.mo1240u0(i, et8Var, c0182l);
    }

    /* JADX INFO: renamed from: u1 */
    public final int m1241u1(int i, et8 et8Var, C0182l c0182l) {
        if (!et8Var.f13104g) {
            return this.f1961K.mo13577c(i);
        }
        int i2 = this.f1959I.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int iM1477b = c0182l.m1477b(i);
        if (iM1477b != -1) {
            return this.f1961K.mo13577c(iM1477b);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
        return 1;
    }

    /* JADX INFO: renamed from: v1 */
    public final void m1242v1(View view, int i, boolean z) {
        int iM1446x;
        int iM1446x2;
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        Rect rect = layoutParams.f2070b;
        int i2 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
        int i3 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
        int iM1233r1 = m1233r1(layoutParams.f1966e, layoutParams.f1967f);
        if (this.f1972p == 1) {
            iM1446x2 = AbstractC0181k.m1446x(false, iM1233r1, i, i3, ((ViewGroup.MarginLayoutParams) layoutParams).width);
            iM1446x = AbstractC0181k.m1446x(true, this.f1974r.mo1418l(), this.f2153m, i2, ((ViewGroup.MarginLayoutParams) layoutParams).height);
        } else {
            int iM1446x3 = AbstractC0181k.m1446x(false, iM1233r1, i, i2, ((ViewGroup.MarginLayoutParams) layoutParams).height);
            int iM1446x4 = AbstractC0181k.m1446x(true, this.f1974r.mo1418l(), this.f2152l, i3, ((ViewGroup.MarginLayoutParams) layoutParams).width);
            iM1446x = iM1446x3;
            iM1446x2 = iM1446x4;
        }
        RecyclerView.LayoutParams layoutParams2 = (RecyclerView.LayoutParams) view.getLayoutParams();
        if (z ? m1449C0(view, iM1446x2, iM1446x, layoutParams2) : m1447A0(view, iM1446x2, iM1446x, layoutParams2)) {
            view.measure(iM1446x2, iM1446x);
        }
    }

    /* JADX INFO: renamed from: w1 */
    public final void m1243w1(int i) {
        if (i == this.f1956F) {
            return;
        }
        this.f1955E = true;
        if (i < 1) {
            C1521v3.m18903j(z82.m21085r(i, "Span count should be at least 1. Provided "));
            return;
        }
        this.f1956F = i;
        this.f1961K.m13578d();
        m1468r0();
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: x0 */
    public final void mo1244x0(Rect rect, int i, int i2) {
        int iM1445h;
        int iM1445h2;
        if (this.f1957G == null) {
            super.mo1244x0(rect, i, i2);
        }
        int iM1453F = m1453F() + m1451E();
        int iM1450D = m1450D() + m1454G();
        if (this.f1972p == 1) {
            int iHeight = rect.height() + iM1450D;
            RecyclerView recyclerView = this.f2142b;
            WeakHashMap weakHashMap = obb.f31348a;
            iM1445h2 = AbstractC0181k.m1445h(i2, iHeight, recyclerView.getMinimumHeight());
            int[] iArr = this.f1957G;
            iM1445h = AbstractC0181k.m1445h(i, iArr[iArr.length - 1] + iM1453F, this.f2142b.getMinimumWidth());
        } else {
            int iWidth = rect.width() + iM1453F;
            RecyclerView recyclerView2 = this.f2142b;
            WeakHashMap weakHashMap2 = obb.f31348a;
            iM1445h = AbstractC0181k.m1445h(i, iWidth, recyclerView2.getMinimumWidth());
            int[] iArr2 = this.f1957G;
            iM1445h2 = AbstractC0181k.m1445h(i2, iArr2[iArr2.length - 1] + iM1450D, this.f2142b.getMinimumHeight());
        }
        this.f2142b.setMeasuredDimension(iM1445h, iM1445h2);
    }

    /* JADX INFO: renamed from: x1 */
    public final void m1245x1() {
        int iM1450D;
        int iM1454G;
        if (this.f1972p == 1) {
            iM1450D = this.f2154n - m1453F();
            iM1454G = m1451E();
        } else {
            iM1450D = this.f2155o - m1450D();
            iM1454G = m1454G();
        }
        m1224l1(iM1450D - iM1454G);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: y */
    public final int mo1246y(C0182l c0182l, et8 et8Var) {
        if (this.f1972p == 1) {
            return Math.min(this.f1956F, m1448C());
        }
        if (et8Var.m7762b() < 1) {
            return 0;
        }
        return m1236s1(et8Var.m7762b() - 1, et8Var, c0182l) + 1;
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class LayoutParams extends RecyclerView.LayoutParams {

        /* JADX INFO: renamed from: e */
        public int f1966e;

        /* JADX INFO: renamed from: f */
        public int f1967f;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f1966e = -1;
            this.f1967f = 0;
        }

        public LayoutParams(int i, int i2) {
            super(i, i2);
            this.f1966e = -1;
            this.f1967f = 0;
        }
    }

    public GridLayoutManager(Context context, int i) {
        super(context);
        this.f1955E = false;
        this.f1956F = -1;
        this.f1959I = new SparseIntArray();
        this.f1960J = new SparseIntArray();
        this.f1961K = new rp4();
        this.f1962L = new Rect();
        this.f1963M = -1;
        this.f1964N = -1;
        this.f1965O = -1;
        m1243w1(i);
    }

    public GridLayoutManager(ContextThemeWrapper contextThemeWrapper, int i) {
        super(contextThemeWrapper, 1, false);
        this.f1955E = false;
        this.f1956F = -1;
        this.f1959I = new SparseIntArray();
        this.f1960J = new SparseIntArray();
        this.f1961K = new rp4();
        this.f1962L = new Rect();
        this.f1963M = -1;
        this.f1964N = -1;
        this.f1965O = -1;
        m1243w1(i);
    }
}
