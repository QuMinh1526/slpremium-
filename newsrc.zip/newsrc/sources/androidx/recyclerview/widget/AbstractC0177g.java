package androidx.recyclerview.widget;

import android.view.ViewGroup;
import java.util.List;
import p000.C1521v3;
import p000.ss8;

/* JADX INFO: renamed from: androidx.recyclerview.widget.g */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0177g {

    /* JADX INFO: renamed from: a */
    public final ss8 f2136a = new ss8();

    /* JADX INFO: renamed from: b */
    public boolean f2137b = false;

    /* JADX INFO: renamed from: c */
    public final int f2138c = 1;

    /* JADX INFO: renamed from: a */
    public abstract int mo1422a();

    /* JADX INFO: renamed from: b */
    public long mo1423b(int i) {
        return -1L;
    }

    /* JADX INFO: renamed from: c */
    public int mo1424c(int i) {
        return 0;
    }

    /* JADX INFO: renamed from: d */
    public final void m1425d() {
        this.f2136a.m17295b();
    }

    /* JADX INFO: renamed from: e */
    public abstract void mo1426e(AbstractC0185o abstractC0185o, int i);

    /* JADX INFO: renamed from: f */
    public void mo1427f(AbstractC0185o abstractC0185o, int i, List list) {
        mo1426e(abstractC0185o, i);
    }

    /* JADX INFO: renamed from: g */
    public abstract AbstractC0185o mo1428g(ViewGroup viewGroup, int i);

    /* JADX INFO: renamed from: i */
    public final void m1430i() {
        if (this.f2136a.m17294a()) {
            C1521v3.m18909p("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
        } else {
            this.f2137b = true;
        }
    }

    /* JADX INFO: renamed from: h */
    public void mo1429h(AbstractC0185o abstractC0185o) {
    }
}
