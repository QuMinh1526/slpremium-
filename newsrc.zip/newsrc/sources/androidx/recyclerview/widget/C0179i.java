package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewGroup;
import p000.zab;

/* JADX INFO: renamed from: androidx.recyclerview.widget.i */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public final class C0179i implements zab {

    /* JADX INFO: renamed from: a */
    public final /* synthetic */ AbstractC0181k f2139a;

    public C0179i(AbstractC0181k abstractC0181k) {
        this.f2139a = abstractC0181k;
    }

    @Override // p000.zab
    /* JADX INFO: renamed from: a */
    public final int mo1434a(View view) {
        return (view.getLeft() - ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b.left) - ((ViewGroup.MarginLayoutParams) ((RecyclerView.LayoutParams) view.getLayoutParams())).leftMargin;
    }

    @Override // p000.zab
    /* JADX INFO: renamed from: b */
    public final int mo1435b() {
        return this.f2139a.m1451E();
    }

    @Override // p000.zab
    /* JADX INFO: renamed from: c */
    public final int mo1436c() {
        AbstractC0181k abstractC0181k = this.f2139a;
        return abstractC0181k.f2154n - abstractC0181k.m1453F();
    }

    @Override // p000.zab
    /* JADX INFO: renamed from: d */
    public final View mo1437d(int i) {
        return this.f2139a.m1469v(i);
    }

    @Override // p000.zab
    /* JADX INFO: renamed from: e */
    public final int mo1438e(View view) {
        return view.getRight() + ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b.right + ((ViewGroup.MarginLayoutParams) ((RecyclerView.LayoutParams) view.getLayoutParams())).rightMargin;
    }
}
