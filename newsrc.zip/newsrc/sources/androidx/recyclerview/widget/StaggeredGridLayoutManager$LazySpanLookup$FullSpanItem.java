package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@SuppressLint({"BanParcelableUsage"})
class StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem implements Parcelable {
    public static final Parcelable.Creator<StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem> CREATOR = new C0186p();

    /* JADX INFO: renamed from: e */
    public int f2097e;

    /* JADX INFO: renamed from: i */
    public int f2098i;

    /* JADX INFO: renamed from: y */
    public int[] f2099y;

    /* JADX INFO: renamed from: z */
    public boolean f2100z;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return "FullSpanItem{mPosition=" + this.f2097e + ", mGapDir=" + this.f2098i + ", mHasUnwantedGapAfter=" + this.f2100z + ", mGapPerSpan=" + Arrays.toString(this.f2099y) + '}';
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f2097e);
        parcel.writeInt(this.f2098i);
        parcel.writeInt(this.f2100z ? 1 : 0);
        int[] iArr = this.f2099y;
        if (iArr == null || iArr.length <= 0) {
            parcel.writeInt(0);
        } else {
            parcel.writeInt(iArr.length);
            parcel.writeIntArray(this.f2099y);
        }
    }
}
