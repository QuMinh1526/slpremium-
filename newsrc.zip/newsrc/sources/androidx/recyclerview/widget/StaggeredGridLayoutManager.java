package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.annotation.RestrictTo;
import androidx.appcompat.widget.RtlSpacingHelper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.WeakHashMap;
import p000.C0644j7;
import p000.C0681k7;
import p000.C1521v3;
import p000.ct8;
import p000.et8;
import p000.fy8;
import p000.haa;
import p000.m26;
import p000.nl7;
import p000.obb;
import p000.vs8;
import p000.wi0;
import p000.z82;
import p000.zo1;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class StaggeredGridLayoutManager extends AbstractC0181k implements ct8 {

    /* JADX INFO: renamed from: A */
    public int f2074A;

    /* JADX INFO: renamed from: B */
    public final C0187q f2075B;

    /* JADX INFO: renamed from: C */
    public final int f2076C;

    /* JADX INFO: renamed from: D */
    public boolean f2077D;

    /* JADX INFO: renamed from: E */
    public boolean f2078E;

    /* JADX INFO: renamed from: F */
    public SavedState f2079F;

    /* JADX INFO: renamed from: G */
    public final Rect f2080G;

    /* JADX INFO: renamed from: H */
    public final haa f2081H;

    /* JADX INFO: renamed from: I */
    public final boolean f2082I;

    /* JADX INFO: renamed from: J */
    public int[] f2083J;

    /* JADX INFO: renamed from: K */
    public final wi0 f2084K;

    /* JADX INFO: renamed from: p */
    public int f2085p;

    /* JADX INFO: renamed from: q */
    public C0189s[] f2086q;

    /* JADX INFO: renamed from: r */
    public final nl7 f2087r;

    /* JADX INFO: renamed from: s */
    public final nl7 f2088s;

    /* JADX INFO: renamed from: t */
    public final int f2089t;

    /* JADX INFO: renamed from: u */
    public int f2090u;

    /* JADX INFO: renamed from: v */
    public final m26 f2091v;

    /* JADX INFO: renamed from: w */
    public boolean f2092w;

    /* JADX INFO: renamed from: x */
    public boolean f2093x;

    /* JADX INFO: renamed from: y */
    public BitSet f2094y;

    /* JADX INFO: renamed from: z */
    public int f2095z;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class LayoutParams extends RecyclerView.LayoutParams {

        /* JADX INFO: renamed from: e */
        public C0189s f2096e;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    @SuppressLint({"BanParcelableUsage"})
    @RestrictTo({RestrictTo.Scope.LIBRARY})
    public static class SavedState implements Parcelable {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0188r();

        /* JADX INFO: renamed from: A */
        public int f2101A;

        /* JADX INFO: renamed from: B */
        public int[] f2102B;

        /* JADX INFO: renamed from: C */
        public ArrayList f2103C;

        /* JADX INFO: renamed from: D */
        public boolean f2104D;

        /* JADX INFO: renamed from: E */
        public boolean f2105E;

        /* JADX INFO: renamed from: F */
        public boolean f2106F;

        /* JADX INFO: renamed from: e */
        public int f2107e;

        /* JADX INFO: renamed from: i */
        public int f2108i;

        /* JADX INFO: renamed from: y */
        public int f2109y;

        /* JADX INFO: renamed from: z */
        public int[] f2110z;

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f2107e);
            parcel.writeInt(this.f2108i);
            parcel.writeInt(this.f2109y);
            if (this.f2109y > 0) {
                parcel.writeIntArray(this.f2110z);
            }
            parcel.writeInt(this.f2101A);
            if (this.f2101A > 0) {
                parcel.writeIntArray(this.f2102B);
            }
            parcel.writeInt(this.f2104D ? 1 : 0);
            parcel.writeInt(this.f2105E ? 1 : 0);
            parcel.writeInt(this.f2106F ? 1 : 0);
            parcel.writeList(this.f2103C);
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        this.f2085p = -1;
        this.f2092w = false;
        this.f2093x = false;
        this.f2095z = -1;
        this.f2074A = RtlSpacingHelper.UNDEFINED;
        this.f2075B = new C0187q();
        this.f2076C = 2;
        this.f2080G = new Rect();
        this.f2081H = new haa(this);
        this.f2082I = true;
        this.f2084K = new wi0(this, 18);
        vs8 vs8VarM1442I = AbstractC0181k.m1442I(context, attributeSet, i, i2);
        int i3 = vs8VarM1442I.f44283a;
        if (i3 != 0 && i3 != 1) {
            C1521v3.m18903j("invalid orientation.");
            throw null;
        }
        mo1272c(null);
        if (i3 != this.f2089t) {
            this.f2089t = i3;
            nl7 nl7Var = this.f2087r;
            this.f2087r = this.f2088s;
            this.f2088s = nl7Var;
            m1468r0();
        }
        m1392e1(vs8VarM1442I.f44284b);
        boolean z = vs8VarM1442I.f44285c;
        mo1272c(null);
        SavedState savedState = this.f2079F;
        if (savedState != null && savedState.f2104D != z) {
            savedState.f2104D = z;
        }
        this.f2092w = z;
        m1468r0();
        this.f2091v = new m26();
        this.f2087r = nl7.m14206a(this, this.f2089t);
        this.f2088s = nl7.m14206a(this, 1 - this.f2089t);
    }

    /* JADX INFO: renamed from: h1 */
    public static int m1364h1(int i, int i2, int i3) {
        int mode;
        return (!(i2 == 0 && i3 == 0) && ((mode = View.MeasureSpec.getMode(i)) == Integer.MIN_VALUE || mode == 1073741824)) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - i2) - i3), mode) : i;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: D0 */
    public final void mo1248D0(RecyclerView recyclerView, int i) {
        C0174d c0174d = new C0174d(recyclerView.getContext());
        c0174d.f11405a = i;
        m1452E0(c0174d);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: F0 */
    public final boolean mo1204F0() {
        return this.f2079F == null;
    }

    /* JADX INFO: renamed from: G0 */
    public final boolean m1365G0() {
        int iM1372N0;
        if (m1471w() != 0 && this.f2076C != 0 && this.f2147g) {
            if (this.f2093x) {
                iM1372N0 = m1373O0();
                m1372N0();
            } else {
                iM1372N0 = m1372N0();
                m1373O0();
            }
            if (iM1372N0 == 0 && m1380S0() != null) {
                this.f2075B.m1514a();
                this.f2146f = true;
                m1468r0();
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: H0 */
    public final int m1366H0(et8 et8Var) {
        if (m1471w() == 0) {
            return 0;
        }
        boolean z = !this.f2082I;
        return fy8.m8535V(et8Var, this.f2087r, m1369K0(z), m1368J0(z), this, this.f2082I, this.f2093x);
    }

    /* JADX WARN: Type inference failed for: r8v1 */
    /* JADX WARN: Type inference failed for: r8v12 */
    /* JADX WARN: Type inference failed for: r8v2, types: [boolean, int] */
    /* JADX INFO: renamed from: I0 */
    public final int m1367I0(C0182l c0182l, m26 m26Var, et8 et8Var) {
        C0189s c0189s;
        ?? r8;
        int iM1525h;
        int iMo1409c;
        int iMo1409c2;
        int iMo1413g;
        int i;
        int i2;
        int i3;
        C0182l c0182l2 = c0182l;
        int i4 = 0;
        int i5 = 1;
        this.f2094y.set(0, this.f2085p, true);
        m26 m26Var2 = this.f2091v;
        int i6 = m26Var2.f27615i ? m26Var.f27611e == 1 ? Integer.MAX_VALUE : RtlSpacingHelper.UNDEFINED : m26Var.f27611e == 1 ? m26Var.f27613g + m26Var.f27608b : m26Var.f27612f - m26Var.f27608b;
        int i7 = m26Var.f27611e;
        for (int i8 = 0; i8 < this.f2085p; i8++) {
            if (!this.f2086q[i8].f2187a.isEmpty()) {
                m1394g1(this.f2086q[i8], i7, i6);
            }
        }
        boolean z = this.f2093x;
        nl7 nl7Var = this.f2087r;
        int iMo1413g2 = z ? nl7Var.mo1413g() : nl7Var.mo1417k();
        boolean z2 = false;
        while (true) {
            int i9 = m26Var.f27609c;
            if (i9 < 0 || i9 >= et8Var.m7762b() || (!m26Var2.f27615i && this.f2094y.isEmpty())) {
                break;
            }
            View viewM1479d = c0182l2.m1479d(m26Var.f27609c);
            m26Var.f27609c += m26Var.f27610d;
            LayoutParams layoutParams = (LayoutParams) viewM1479d.getLayoutParams();
            int iM1499d = layoutParams.f2069a.m1499d();
            C0187q c0187q = this.f2075B;
            int[] iArr = c0187q.f2185a;
            int i10 = (iArr == null || iM1499d >= iArr.length) ? -1 : iArr[iM1499d];
            if (i10 == -1) {
                boolean zM1384W0 = m1384W0(m26Var.f27611e);
                int i11 = this.f2085p;
                if (zM1384W0) {
                    i3 = i11 - 1;
                    i2 = -1;
                    i = -1;
                } else {
                    i = i5;
                    i2 = i11;
                    i3 = i4;
                }
                C0189s c0189s2 = null;
                if (m26Var.f27611e == i5) {
                    int iMo1417k = nl7Var.mo1417k();
                    int i12 = Integer.MAX_VALUE;
                    while (i3 != i2) {
                        C0189s c0189s3 = this.f2086q[i3];
                        int i13 = i3;
                        int iM1523f = c0189s3.m1523f(iMo1417k);
                        if (iM1523f < i12) {
                            c0189s2 = c0189s3;
                            i12 = iM1523f;
                        }
                        i3 = i13 + i;
                    }
                } else {
                    int iMo1413g3 = nl7Var.mo1413g();
                    int i14 = RtlSpacingHelper.UNDEFINED;
                    while (i3 != i2) {
                        C0189s c0189s4 = this.f2086q[i3];
                        int i15 = i2;
                        int iM1525h2 = c0189s4.m1525h(iMo1413g3);
                        if (iM1525h2 > i14) {
                            i14 = iM1525h2;
                            c0189s2 = c0189s4;
                        }
                        i3 += i;
                        i2 = i15;
                    }
                }
                c0189s = c0189s2;
                c0187q.m1515b(iM1499d);
                c0187q.f2185a[iM1499d] = c0189s.f2191e;
            } else {
                c0189s = this.f2086q[i10];
            }
            layoutParams.f2096e = c0189s;
            if (m26Var.f27611e == 1) {
                r8 = 0;
                m1458b(viewM1479d, -1, false);
            } else {
                r8 = 0;
                m1458b(viewM1479d, 0, false);
            }
            int i16 = this.f2089t;
            if (i16 == 1) {
                m1382U0(viewM1479d, AbstractC0181k.m1446x(r8, this.f2090u, this.f2152l, r8, ((ViewGroup.MarginLayoutParams) layoutParams).width), AbstractC0181k.m1446x(true, this.f2155o, this.f2153m, m1450D() + m1454G(), ((ViewGroup.MarginLayoutParams) layoutParams).height));
            } else {
                m1382U0(viewM1479d, AbstractC0181k.m1446x(true, this.f2154n, this.f2152l, m1453F() + m1451E(), ((ViewGroup.MarginLayoutParams) layoutParams).width), AbstractC0181k.m1446x(false, this.f2090u, this.f2153m, 0, ((ViewGroup.MarginLayoutParams) layoutParams).height));
            }
            if (m26Var.f27611e == 1) {
                iMo1409c = c0189s.m1523f(iMo1413g2);
                iM1525h = nl7Var.mo1409c(viewM1479d) + iMo1409c;
            } else {
                iM1525h = c0189s.m1525h(iMo1413g2);
                iMo1409c = iM1525h - nl7Var.mo1409c(viewM1479d);
            }
            int i17 = m26Var.f27611e;
            C0189s c0189s5 = layoutParams.f2096e;
            if (i17 == 1) {
                c0189s5.getClass();
                LayoutParams layoutParams2 = (LayoutParams) viewM1479d.getLayoutParams();
                layoutParams2.f2096e = c0189s5;
                ArrayList arrayList = c0189s5.f2187a;
                arrayList.add(viewM1479d);
                c0189s5.f2189c = RtlSpacingHelper.UNDEFINED;
                if (arrayList.size() == 1) {
                    c0189s5.f2188b = RtlSpacingHelper.UNDEFINED;
                }
                if (layoutParams2.f2069a.m1505j() || layoutParams2.f2069a.m1508m()) {
                    c0189s5.f2190d = c0189s5.f2192f.f2087r.mo1409c(viewM1479d) + c0189s5.f2190d;
                }
            } else {
                c0189s5.getClass();
                LayoutParams layoutParams3 = (LayoutParams) viewM1479d.getLayoutParams();
                layoutParams3.f2096e = c0189s5;
                ArrayList arrayList2 = c0189s5.f2187a;
                arrayList2.add(0, viewM1479d);
                c0189s5.f2188b = RtlSpacingHelper.UNDEFINED;
                if (arrayList2.size() == 1) {
                    c0189s5.f2189c = RtlSpacingHelper.UNDEFINED;
                }
                if (layoutParams3.f2069a.m1505j() || layoutParams3.f2069a.m1508m()) {
                    c0189s5.f2190d = c0189s5.f2192f.f2087r.mo1409c(viewM1479d) + c0189s5.f2190d;
                }
            }
            boolean zM1381T0 = m1381T0();
            nl7 nl7Var2 = this.f2088s;
            if (zM1381T0 && i16 == 1) {
                iMo1413g = nl7Var2.mo1413g() - (((this.f2085p - 1) - c0189s.f2191e) * this.f2090u);
                iMo1409c2 = iMo1413g - nl7Var2.mo1409c(viewM1479d);
            } else {
                int iMo1417k2 = (c0189s.f2191e * this.f2090u) + nl7Var2.mo1417k();
                int iMo1409c3 = nl7Var2.mo1409c(viewM1479d) + iMo1417k2;
                iMo1409c2 = iMo1417k2;
                iMo1413g = iMo1409c3;
            }
            if (i16 == 1) {
                AbstractC0181k.m1444O(viewM1479d, iMo1409c2, iMo1409c, iMo1413g, iM1525h);
            } else {
                AbstractC0181k.m1444O(viewM1479d, iMo1409c, iMo1409c2, iM1525h, iMo1413g);
            }
            m1394g1(c0189s, m26Var2.f27611e, i6);
            c0182l2 = c0182l;
            m1386Y0(c0182l2, m26Var2);
            if (m26Var2.f27614h && viewM1479d.hasFocusable()) {
                this.f2094y.set(c0189s.f2191e, false);
            }
            i5 = 1;
            z2 = true;
            i4 = 0;
        }
        if (!z2) {
            m1386Y0(c0182l2, m26Var2);
        }
        int iMo1417k3 = m26Var2.f27611e == -1 ? nl7Var.mo1417k() - m1377Q0(nl7Var.mo1417k()) : m1375P0(nl7Var.mo1413g()) - nl7Var.mo1413g();
        if (iMo1417k3 > 0) {
            return Math.min(m26Var.f27608b, iMo1417k3);
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: J */
    public final int mo1206J(C0182l c0182l, et8 et8Var) {
        if (this.f2089t == 0) {
            return Math.min(this.f2085p, et8Var.m7762b());
        }
        return -1;
    }

    /* JADX INFO: renamed from: J0 */
    public final View m1368J0(boolean z) {
        nl7 nl7Var = this.f2087r;
        int iMo1417k = nl7Var.mo1417k();
        int iMo1413g = nl7Var.mo1413g();
        View view = null;
        for (int iM1471w = m1471w() - 1; iM1471w >= 0; iM1471w--) {
            View viewM1469v = m1469v(iM1471w);
            int iMo1411e = nl7Var.mo1411e(viewM1469v);
            int iMo1408b = nl7Var.mo1408b(viewM1469v);
            if (iMo1408b > iMo1417k && iMo1411e < iMo1413g) {
                if (iMo1408b <= iMo1413g || !z) {
                    return viewM1469v;
                }
                if (view == null) {
                    view = viewM1469v;
                }
            }
        }
        return view;
    }

    /* JADX INFO: renamed from: K0 */
    public final View m1369K0(boolean z) {
        nl7 nl7Var = this.f2087r;
        int iMo1417k = nl7Var.mo1417k();
        int iMo1413g = nl7Var.mo1413g();
        int iM1471w = m1471w();
        View view = null;
        for (int i = 0; i < iM1471w; i++) {
            View viewM1469v = m1469v(i);
            int iMo1411e = nl7Var.mo1411e(viewM1469v);
            if (nl7Var.mo1408b(viewM1469v) > iMo1417k && iMo1411e < iMo1413g) {
                if (iMo1411e >= iMo1417k || !z) {
                    return viewM1469v;
                }
                if (view == null) {
                    view = viewM1469v;
                }
            }
        }
        return view;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: L */
    public final boolean mo1253L() {
        return this.f2076C != 0;
    }

    /* JADX INFO: renamed from: L0 */
    public final void m1370L0(C0182l c0182l, et8 et8Var, boolean z) {
        int iMo1413g;
        int iM1375P0 = m1375P0(RtlSpacingHelper.UNDEFINED);
        if (iM1375P0 != Integer.MIN_VALUE && (iMo1413g = this.f2087r.mo1413g() - iM1375P0) > 0) {
            int i = iMo1413g - (-m1390c1(-iMo1413g, et8Var, c0182l));
            if (!z || i <= 0) {
                return;
            }
            this.f2087r.mo1421o(i);
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: M */
    public final boolean mo1255M() {
        return this.f2092w;
    }

    /* JADX INFO: renamed from: M0 */
    public final void m1371M0(C0182l c0182l, et8 et8Var, boolean z) {
        int iMo1417k;
        int iM1377Q0 = m1377Q0(Integer.MAX_VALUE);
        if (iM1377Q0 != Integer.MAX_VALUE && (iMo1417k = iM1377Q0 - this.f2087r.mo1417k()) > 0) {
            int iM1390c1 = iMo1417k - m1390c1(iMo1417k, et8Var, c0182l);
            if (!z || iM1390c1 <= 0) {
                return;
            }
            this.f2087r.mo1421o(-iM1390c1);
        }
    }

    /* JADX INFO: renamed from: N0 */
    public final int m1372N0() {
        if (m1471w() == 0) {
            return 0;
        }
        return AbstractC0181k.m1441H(m1469v(0));
    }

    /* JADX INFO: renamed from: O0 */
    public final int m1373O0() {
        int iM1471w = m1471w();
        if (iM1471w == 0) {
            return 0;
        }
        return AbstractC0181k.m1441H(m1469v(iM1471w - 1));
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: P */
    public final void mo1374P(int i) {
        super.mo1374P(i);
        for (int i2 = 0; i2 < this.f2085p; i2++) {
            C0189s c0189s = this.f2086q[i2];
            int i3 = c0189s.f2188b;
            if (i3 != Integer.MIN_VALUE) {
                c0189s.f2188b = i3 + i;
            }
            int i4 = c0189s.f2189c;
            if (i4 != Integer.MIN_VALUE) {
                c0189s.f2189c = i4 + i;
            }
        }
    }

    /* JADX INFO: renamed from: P0 */
    public final int m1375P0(int i) {
        int iM1523f = this.f2086q[0].m1523f(i);
        for (int i2 = 1; i2 < this.f2085p; i2++) {
            int iM1523f2 = this.f2086q[i2].m1523f(i);
            if (iM1523f2 > iM1523f) {
                iM1523f = iM1523f2;
            }
        }
        return iM1523f;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: Q */
    public final void mo1376Q(int i) {
        super.mo1376Q(i);
        for (int i2 = 0; i2 < this.f2085p; i2++) {
            C0189s c0189s = this.f2086q[i2];
            int i3 = c0189s.f2188b;
            if (i3 != Integer.MIN_VALUE) {
                c0189s.f2188b = i3 + i;
            }
            int i4 = c0189s.f2189c;
            if (i4 != Integer.MIN_VALUE) {
                c0189s.f2189c = i4 + i;
            }
        }
    }

    /* JADX INFO: renamed from: Q0 */
    public final int m1377Q0(int i) {
        int iM1525h = this.f2086q[0].m1525h(i);
        for (int i2 = 1; i2 < this.f2085p; i2++) {
            int iM1525h2 = this.f2086q[i2].m1525h(i);
            if (iM1525h2 < iM1525h) {
                iM1525h = iM1525h2;
            }
        }
        return iM1525h;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: R */
    public final void mo1378R(AbstractC0177g abstractC0177g) {
        this.f2075B.m1514a();
        for (int i = 0; i < this.f2085p; i++) {
            this.f2086q[i].m1519b();
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0031  */
    /* JADX WARN: Code duplicated, block: B:22:0x0033  */
    /* JADX WARN: Code duplicated, block: B:24:0x003a  */
    /* JADX WARN: Code duplicated, block: B:27:0x0047 A[LOOP:0: B:23:0x0038->B:27:0x0047, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:30:0x004d  */
    /* JADX WARN: Code duplicated, block: B:33:0x005b  */
    /* JADX WARN: Code duplicated, block: B:36:0x0068 A[LOOP:1: B:32:0x0059->B:36:0x0068, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:39:0x006e  */
    /* JADX WARN: Code duplicated, block: B:42:0x0081  */
    /* JADX WARN: Code duplicated, block: B:43:0x0089  */
    /* JADX WARN: Code duplicated, block: B:45:0x0096  */
    /* JADX WARN: Code duplicated, block: B:47:0x0099 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:49:0x009c  */
    /* JADX WARN: Code duplicated, block: B:50:0x00a3  */
    /* JADX WARN: Code duplicated, block: B:51:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:54:0x00ad  */
    /* JADX WARN: Code duplicated, block: B:56:0x00b1  */
    /* JADX WARN: Code duplicated, block: B:57:0x00b6  */
    /* JADX WARN: Code duplicated, block: B:59:0x00bc  */
    /* JADX WARN: Code duplicated, block: B:61:0x004a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:62:0x004b A[EDGE_INSN: B:62:0x004b->B:29:0x004b BREAK  A[LOOP:0: B:23:0x0038->B:27:0x0047], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:63:0x006b A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:64:0x006c A[EDGE_INSN: B:64:0x006c->B:38:0x006c BREAK  A[LOOP:1: B:32:0x0059->B:36:0x0068], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:65:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:66:? A[RETURN, SYNTHETIC] */
    /* JADX INFO: renamed from: R0 */
    public final void m1379R0(int i, int i2, int i3) {
        int i4;
        int i5;
        C0187q c0187q;
        int[] iArr;
        int iM1373O0;
        ArrayList arrayList;
        int size;
        StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem staggeredGridLayoutManager$LazySpanLookup$FullSpanItem;
        int size2;
        int i6;
        int i7;
        int[] iArr2;
        int iM1373O1 = this.f2093x ? m1373O0() : m1372N0();
        if (i3 == 8) {
            if (i < i2) {
                i4 = i2 + 1;
            } else {
                i4 = i + 1;
                i5 = i2;
            }
            c0187q = this.f2075B;
            iArr = c0187q.f2185a;
            if (iArr != null && i5 < iArr.length) {
                arrayList = c0187q.f2186b;
                if (arrayList == null) {
                    i7 = -1;
                } else {
                    size = arrayList.size() - 1;
                    while (true) {
                        if (size >= 0) {
                            staggeredGridLayoutManager$LazySpanLookup$FullSpanItem = null;
                            break;
                        }
                        staggeredGridLayoutManager$LazySpanLookup$FullSpanItem = (StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem) c0187q.f2186b.get(size);
                        if (staggeredGridLayoutManager$LazySpanLookup$FullSpanItem.f2097e == i5) {
                            break;
                        } else {
                            size--;
                        }
                    }
                    if (staggeredGridLayoutManager$LazySpanLookup$FullSpanItem != null) {
                        c0187q.f2186b.remove(staggeredGridLayoutManager$LazySpanLookup$FullSpanItem);
                    }
                    size2 = c0187q.f2186b.size();
                    i6 = 0;
                    while (true) {
                        if (i6 < size2) {
                            i6 = -1;
                            break;
                        } else if (((StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem) c0187q.f2186b.get(i6)).f2097e >= i5) {
                            break;
                        } else {
                            i6++;
                        }
                    }
                    if (i6 != -1) {
                        StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem staggeredGridLayoutManager$LazySpanLookup$FullSpanItem2 = (StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem) c0187q.f2186b.get(i6);
                        c0187q.f2186b.remove(i6);
                        i7 = staggeredGridLayoutManager$LazySpanLookup$FullSpanItem2.f2097e;
                    } else {
                        i7 = -1;
                    }
                }
                iArr2 = c0187q.f2185a;
                if (i7 == -1) {
                    Arrays.fill(iArr2, i5, iArr2.length, -1);
                    int length = c0187q.f2185a.length;
                } else {
                    Arrays.fill(c0187q.f2185a, i5, Math.min(i7 + 1, iArr2.length), -1);
                }
            }
            if (i3 != 1) {
                c0187q.m1516c(i, i2);
            } else if (i3 != 2) {
                c0187q.m1517d(i, i2);
            } else if (i3 == 8) {
                c0187q.m1517d(i, 1);
                c0187q.m1516c(i2, 1);
            }
            if (i4 <= iM1373O1) {
                return;
            }
            if (this.f2093x) {
                iM1373O0 = m1372N0();
            } else {
                iM1373O0 = m1373O0();
            }
            if (i5 <= iM1373O0) {
                m1468r0();
            }
        }
        i4 = i + i2;
        i5 = i;
        c0187q = this.f2075B;
        iArr = c0187q.f2185a;
        if (iArr != null) {
            arrayList = c0187q.f2186b;
            if (arrayList == null) {
                i7 = -1;
            } else {
                size = arrayList.size() - 1;
                while (true) {
                    if (size >= 0) {
                        staggeredGridLayoutManager$LazySpanLookup$FullSpanItem = null;
                        break;
                    }
                    staggeredGridLayoutManager$LazySpanLookup$FullSpanItem = (StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem) c0187q.f2186b.get(size);
                    if (staggeredGridLayoutManager$LazySpanLookup$FullSpanItem.f2097e == i5) {
                        break;
                        break;
                    }
                    size--;
                }
                if (staggeredGridLayoutManager$LazySpanLookup$FullSpanItem != null) {
                    c0187q.f2186b.remove(staggeredGridLayoutManager$LazySpanLookup$FullSpanItem);
                }
                size2 = c0187q.f2186b.size();
                i6 = 0;
                while (true) {
                    if (i6 < size2) {
                        i6 = -1;
                        break;
                    } else {
                        if (((StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem) c0187q.f2186b.get(i6)).f2097e >= i5) {
                            break;
                            break;
                        }
                        i6++;
                    }
                }
                if (i6 != -1) {
                    StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem staggeredGridLayoutManager$LazySpanLookup$FullSpanItem3 = (StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem) c0187q.f2186b.get(i6);
                    c0187q.f2186b.remove(i6);
                    i7 = staggeredGridLayoutManager$LazySpanLookup$FullSpanItem3.f2097e;
                } else {
                    i7 = -1;
                }
            }
            iArr2 = c0187q.f2185a;
            if (i7 == -1) {
                Arrays.fill(iArr2, i5, iArr2.length, -1);
                int length2 = c0187q.f2185a.length;
            } else {
                Arrays.fill(c0187q.f2185a, i5, Math.min(i7 + 1, iArr2.length), -1);
            }
        }
        if (i3 != 1) {
            c0187q.m1516c(i, i2);
        } else if (i3 != 2) {
            c0187q.m1517d(i, i2);
        } else if (i3 == 8) {
            c0187q.m1517d(i, 1);
            c0187q.m1516c(i2, 1);
        }
        if (i4 <= iM1373O1) {
            return;
        }
        if (this.f2093x) {
            iM1373O0 = m1372N0();
        } else {
            iM1373O0 = m1373O0();
        }
        if (i5 <= iM1373O0) {
            m1468r0();
        }
    }

    /* JADX WARN: Code duplicated, block: B:51:0x00e4  */
    /* JADX WARN: Code duplicated, block: B:52:0x00e6  */
    /* JADX WARN: Code duplicated, block: B:54:0x00e9  */
    /* JADX WARN: Code duplicated, block: B:55:0x00eb  */
    /* JADX WARN: Code duplicated, block: B:68:0x00ee A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:74:0x002c A[SYNTHETIC] */
    /* JADX INFO: renamed from: S0 */
    public final View m1380S0() {
        boolean z;
        boolean z2;
        int iM1471w = m1471w();
        int i = iM1471w - 1;
        BitSet bitSet = new BitSet(this.f2085p);
        bitSet.set(0, this.f2085p, true);
        byte b = (this.f2089t == 1 && m1381T0()) ? (byte) 1 : (byte) -1;
        if (this.f2093x) {
            iM1471w = -1;
        } else {
            i = 0;
        }
        int i2 = i < iM1471w ? 1 : -1;
        while (i != iM1471w) {
            View viewM1469v = m1469v(i);
            LayoutParams layoutParams = (LayoutParams) viewM1469v.getLayoutParams();
            boolean z3 = bitSet.get(layoutParams.f2096e.f2191e);
            nl7 nl7Var = this.f2087r;
            if (z3) {
                C0189s c0189s = layoutParams.f2096e;
                if (this.f2093x) {
                    int i3 = c0189s.f2189c;
                    if (i3 == Integer.MIN_VALUE) {
                        c0189s.m1518a();
                        i3 = c0189s.f2189c;
                    }
                    if (i3 < nl7Var.mo1413g()) {
                        ((LayoutParams) ((View) z82.m21083p(c0189s.f2187a, 1)).getLayoutParams()).getClass();
                        return viewM1469v;
                    }
                } else {
                    int i4 = c0189s.f2188b;
                    ArrayList arrayList = c0189s.f2187a;
                    if (i4 == Integer.MIN_VALUE) {
                        View view = (View) arrayList.get(0);
                        LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
                        c0189s.f2188b = c0189s.f2192f.f2087r.mo1411e(view);
                        layoutParams2.getClass();
                        i4 = c0189s.f2188b;
                    }
                    if (i4 > nl7Var.mo1417k()) {
                        ((LayoutParams) ((View) arrayList.get(0)).getLayoutParams()).getClass();
                        return viewM1469v;
                    }
                }
                bitSet.clear(layoutParams.f2096e.f2191e);
            }
            i += i2;
            if (i != iM1471w) {
                View viewM1469v2 = m1469v(i);
                if (this.f2093x) {
                    int iMo1408b = nl7Var.mo1408b(viewM1469v);
                    int iMo1408b2 = nl7Var.mo1408b(viewM1469v2);
                    if (iMo1408b >= iMo1408b2) {
                        if (iMo1408b == iMo1408b2) {
                            if (layoutParams.f2096e.f2191e - ((LayoutParams) viewM1469v2.getLayoutParams()).f2096e.f2191e < 0) {
                                z = true;
                            } else {
                                z = false;
                            }
                            if (b < 0) {
                                z2 = true;
                            } else {
                                z2 = false;
                            }
                            if (z != z2) {
                            }
                        } else {
                            continue;
                        }
                    }
                    return viewM1469v;
                }
                int iMo1411e = nl7Var.mo1411e(viewM1469v);
                int iMo1411e2 = nl7Var.mo1411e(viewM1469v2);
                if (iMo1411e <= iMo1411e2) {
                    if (iMo1411e == iMo1411e2) {
                        if (layoutParams.f2096e.f2191e - ((LayoutParams) viewM1469v2.getLayoutParams()).f2096e.f2191e < 0) {
                            z = true;
                        } else {
                            z = false;
                        }
                        if (b < 0) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                        if (z != z2) {
                        }
                    } else {
                        continue;
                    }
                }
                return viewM1469v;
            }
        }
        return null;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: T */
    public final void mo1263T(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f2142b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(this.f2084K);
        }
        for (int i = 0; i < this.f2085p; i++) {
            this.f2086q[i].m1519b();
        }
        recyclerView.requestLayout();
    }

    /* JADX INFO: renamed from: T0 */
    public final boolean m1381T0() {
        return this.f2142b.getLayoutDirection() == 1;
    }

    /* JADX WARN: Code duplicated, block: B:30:0x0048  */
    /* JADX WARN: Code duplicated, block: B:34:0x004f  */
    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: U */
    public final View mo1207U(View view, int i, C0182l c0182l, et8 et8Var) {
        View viewM1304D;
        int i2;
        if (m1471w() != 0) {
            RecyclerView recyclerView = this.f2142b;
            if (recyclerView == null || (viewM1304D = recyclerView.m1304D(view)) == null || ((ArrayList) this.f2141a.f36499e).contains(viewM1304D)) {
                viewM1304D = null;
            }
            if (viewM1304D != null) {
                m1389b1();
                int i3 = this.f2089t;
                if (i != 1) {
                    if (i != 2) {
                        if (i != 17) {
                            if (i != 33) {
                                if (i == 66 ? i3 == 0 : !(i != 130 || i3 != 1)) {
                                    i2 = 1;
                                }
                            } else if (i3 == 1) {
                                i2 = -1;
                            }
                            i2 = Integer.MIN_VALUE;
                        } else if (i3 == 0) {
                            i2 = -1;
                        } else {
                            i2 = Integer.MIN_VALUE;
                        }
                    } else if (i3 != 1 && m1381T0()) {
                        i2 = -1;
                    } else {
                        i2 = 1;
                    }
                } else if (i3 != 1 && m1381T0()) {
                    i2 = 1;
                } else {
                    i2 = -1;
                }
                if (i2 != Integer.MIN_VALUE) {
                    LayoutParams layoutParams = (LayoutParams) viewM1304D.getLayoutParams();
                    layoutParams.getClass();
                    C0189s c0189s = layoutParams.f2096e;
                    int iM1373O0 = i2 == 1 ? m1373O0() : m1372N0();
                    m1393f1(iM1373O0, et8Var);
                    m1391d1(i2);
                    m26 m26Var = this.f2091v;
                    m26Var.f27609c = m26Var.f27610d + iM1373O0;
                    m26Var.f27608b = (int) (this.f2087r.mo1418l() * 0.33333334f);
                    m26Var.f27614h = true;
                    m26Var.f27607a = false;
                    m1367I0(c0182l, m26Var, et8Var);
                    this.f2077D = this.f2093x;
                    View viewM1524g = c0189s.m1524g(iM1373O0, i2);
                    if (viewM1524g != null && viewM1524g != viewM1304D) {
                        return viewM1524g;
                    }
                    if (m1384W0(i2)) {
                        for (int i4 = this.f2085p - 1; i4 >= 0; i4--) {
                            View viewM1524g2 = this.f2086q[i4].m1524g(iM1373O0, i2);
                            if (viewM1524g2 != null && viewM1524g2 != viewM1304D) {
                                return viewM1524g2;
                            }
                        }
                    } else {
                        for (int i5 = 0; i5 < this.f2085p; i5++) {
                            View viewM1524g3 = this.f2086q[i5].m1524g(iM1373O0, i2);
                            if (viewM1524g3 != null && viewM1524g3 != viewM1304D) {
                                return viewM1524g3;
                            }
                        }
                    }
                    boolean z = (this.f2092w ^ true) == (i2 == -1);
                    View viewMo1289r = mo1289r(z ? c0189s.m1520c() : c0189s.m1521d());
                    if (viewMo1289r != null && viewMo1289r != viewM1304D) {
                        return viewMo1289r;
                    }
                    if (m1384W0(i2)) {
                        for (int i6 = this.f2085p - 1; i6 >= 0; i6--) {
                            if (i6 != c0189s.f2191e) {
                                C0189s[] c0189sArr = this.f2086q;
                                View viewMo1289r2 = mo1289r(z ? c0189sArr[i6].m1520c() : c0189sArr[i6].m1521d());
                                if (viewMo1289r2 != null && viewMo1289r2 != viewM1304D) {
                                    return viewMo1289r2;
                                }
                            }
                        }
                    } else {
                        for (int i7 = 0; i7 < this.f2085p; i7++) {
                            C0189s[] c0189sArr2 = this.f2086q;
                            View viewMo1289r3 = mo1289r(z ? c0189sArr2[i7].m1520c() : c0189sArr2[i7].m1521d());
                            if (viewMo1289r3 != null && viewMo1289r3 != viewM1304D) {
                                return viewMo1289r3;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: U0 */
    public final void m1382U0(View view, int i, int i2) {
        Rect rect = this.f2080G;
        m1459d(view, rect);
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int iM1364h1 = m1364h1(i, ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + rect.left, ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin + rect.right);
        int iM1364h2 = m1364h1(i2, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + rect.top, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin + rect.bottom);
        if (m1447A0(view, iM1364h1, iM1364h2, layoutParams)) {
            view.measure(iM1364h1, iM1364h2);
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: V */
    public final void mo1265V(AccessibilityEvent accessibilityEvent) {
        super.mo1265V(accessibilityEvent);
        if (m1471w() > 0) {
            View viewM1369K0 = m1369K0(false);
            View viewM1368J0 = m1368J0(false);
            if (viewM1369K0 == null || viewM1368J0 == null) {
                return;
            }
            int iM1441H = AbstractC0181k.m1441H(viewM1369K0);
            int iM1441H2 = AbstractC0181k.m1441H(viewM1368J0);
            if (iM1441H < iM1441H2) {
                accessibilityEvent.setFromIndex(iM1441H);
                accessibilityEvent.setToIndex(iM1441H2);
            } else {
                accessibilityEvent.setFromIndex(iM1441H2);
                accessibilityEvent.setToIndex(iM1441H);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:108:0x018e  */
    /* JADX WARN: Code duplicated, block: B:109:0x0190  */
    /* JADX WARN: Code duplicated, block: B:123:0x01c3  */
    /* JADX WARN: Code duplicated, block: B:125:0x01ce  */
    /* JADX WARN: Code duplicated, block: B:131:0x01e0  */
    /* JADX WARN: Code duplicated, block: B:133:0x01eb  */
    /* JADX WARN: Code duplicated, block: B:253:0x03e9  */
    /* JADX WARN: Code duplicated, block: B:264:0x01de A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:268:0x01de A[SYNTHETIC] */
    /* JADX INFO: renamed from: V0 */
    public final void m1383V0(C0182l c0182l, et8 et8Var, boolean z) {
        boolean z2;
        SavedState savedState;
        C0189s[] c0189sArr;
        int iM1471w;
        int i;
        int iM1441H;
        int iM1441H2;
        int iM1471w2;
        int i2;
        boolean z3;
        SavedState savedState2 = this.f2079F;
        haa haaVar = this.f2081H;
        if (!(savedState2 == null && this.f2095z == -1) && et8Var.m7762b() == 0) {
            m1462m0(c0182l);
            haaVar.m10025a();
            return;
        }
        boolean z4 = haaVar.f19420e;
        StaggeredGridLayoutManager staggeredGridLayoutManager = haaVar.f19422g;
        boolean z5 = (z4 && this.f2095z == -1 && this.f2079F == null) ? false : true;
        C0187q c0187q = this.f2075B;
        if (z5) {
            haaVar.m10025a();
            SavedState savedState3 = this.f2079F;
            nl7 nl7Var = this.f2087r;
            if (savedState3 != null) {
                int i3 = savedState3.f2109y;
                if (i3 > 0) {
                    if (i3 == this.f2085p) {
                        for (int i4 = 0; i4 < this.f2085p; i4++) {
                            this.f2086q[i4].m1519b();
                            SavedState savedState4 = this.f2079F;
                            int iMo1413g = savedState4.f2110z[i4];
                            if (iMo1413g != Integer.MIN_VALUE) {
                                iMo1413g += savedState4.f2105E ? nl7Var.mo1413g() : nl7Var.mo1417k();
                            }
                            C0189s c0189s = this.f2086q[i4];
                            c0189s.f2188b = iMo1413g;
                            c0189s.f2189c = iMo1413g;
                        }
                    } else {
                        savedState3.f2110z = null;
                        savedState3.f2109y = 0;
                        savedState3.f2101A = 0;
                        savedState3.f2102B = null;
                        savedState3.f2103C = null;
                        savedState3.f2107e = savedState3.f2108i;
                    }
                }
                SavedState savedState5 = this.f2079F;
                this.f2078E = savedState5.f2106F;
                boolean z6 = savedState5.f2104D;
                mo1272c(null);
                SavedState savedState6 = this.f2079F;
                if (savedState6 != null && savedState6.f2104D != z6) {
                    savedState6.f2104D = z6;
                }
                this.f2092w = z6;
                m1468r0();
                m1389b1();
                SavedState savedState7 = this.f2079F;
                int i5 = savedState7.f2107e;
                if (i5 != -1) {
                    this.f2095z = i5;
                    haaVar.f19418c = savedState7.f2105E;
                } else {
                    haaVar.f19418c = this.f2093x;
                }
                if (savedState7.f2101A > 1) {
                    c0187q.f2185a = savedState7.f2102B;
                    c0187q.f2186b = savedState7.f2103C;
                }
            } else {
                m1389b1();
                haaVar.f19418c = this.f2093x;
            }
            if (et8Var.f13104g || (i2 = this.f2095z) == -1) {
                if (this.f2077D) {
                    int iM7762b = et8Var.m7762b();
                    iM1471w2 = m1471w() - 1;
                    while (true) {
                        if (iM1471w2 < 0) {
                            iM1441H2 = 0;
                            break;
                        }
                        iM1441H2 = AbstractC0181k.m1441H(m1469v(iM1471w2));
                        if (iM1441H2 < 0 && iM1441H2 < iM7762b) {
                            break;
                        } else {
                            iM1471w2--;
                        }
                    }
                } else {
                    int iM7762b2 = et8Var.m7762b();
                    iM1471w = m1471w();
                    i = 0;
                    while (true) {
                        if (i >= iM1471w) {
                            iM1441H2 = 0;
                            break;
                        }
                        iM1441H = AbstractC0181k.m1441H(m1469v(i));
                        if (iM1441H < 0 && iM1441H < iM7762b2) {
                            iM1441H2 = iM1441H;
                            break;
                        }
                        i++;
                    }
                }
                haaVar.f19416a = iM1441H2;
                haaVar.f19417b = RtlSpacingHelper.UNDEFINED;
            } else if (i2 < 0 || i2 >= et8Var.m7762b()) {
                this.f2095z = -1;
                this.f2074A = RtlSpacingHelper.UNDEFINED;
                if (this.f2077D) {
                    int iM7762b3 = et8Var.m7762b();
                    iM1471w2 = m1471w() - 1;
                    while (true) {
                        if (iM1471w2 < 0) {
                            iM1441H2 = 0;
                            break;
                        } else {
                            iM1441H2 = AbstractC0181k.m1441H(m1469v(iM1471w2));
                            if (iM1441H2 < 0) {
                            }
                            iM1471w2--;
                        }
                    }
                } else {
                    int iM7762b4 = et8Var.m7762b();
                    iM1471w = m1471w();
                    i = 0;
                    while (true) {
                        if (i >= iM1471w) {
                            iM1441H2 = 0;
                            break;
                        } else {
                            iM1441H = AbstractC0181k.m1441H(m1469v(i));
                            if (iM1441H < 0) {
                            }
                            i++;
                        }
                    }
                }
                haaVar.f19416a = iM1441H2;
                haaVar.f19417b = RtlSpacingHelper.UNDEFINED;
            } else {
                SavedState savedState8 = this.f2079F;
                if (savedState8 == null || savedState8.f2107e == -1 || savedState8.f2109y < 1) {
                    View viewMo1289r = mo1289r(this.f2095z);
                    if (viewMo1289r != null) {
                        haaVar.f19416a = this.f2093x ? m1373O0() : m1372N0();
                        if (this.f2074A != Integer.MIN_VALUE) {
                            if (haaVar.f19418c) {
                                haaVar.f19417b = (nl7Var.mo1413g() - this.f2074A) - nl7Var.mo1408b(viewMo1289r);
                            } else {
                                haaVar.f19417b = (nl7Var.mo1417k() + this.f2074A) - nl7Var.mo1411e(viewMo1289r);
                            }
                        } else if (nl7Var.mo1409c(viewMo1289r) > nl7Var.mo1418l()) {
                            haaVar.f19417b = haaVar.f19418c ? nl7Var.mo1413g() : nl7Var.mo1417k();
                        } else {
                            int iMo1411e = nl7Var.mo1411e(viewMo1289r) - nl7Var.mo1417k();
                            if (iMo1411e < 0) {
                                haaVar.f19417b = -iMo1411e;
                            } else {
                                int iMo1413g2 = nl7Var.mo1413g() - nl7Var.mo1408b(viewMo1289r);
                                if (iMo1413g2 < 0) {
                                    haaVar.f19417b = iMo1413g2;
                                } else {
                                    haaVar.f19417b = RtlSpacingHelper.UNDEFINED;
                                }
                            }
                        }
                    } else {
                        int i6 = this.f2095z;
                        haaVar.f19416a = i6;
                        int i7 = this.f2074A;
                        if (i7 == Integer.MIN_VALUE) {
                            if (m1471w() != 0) {
                                if ((i6 < m1372N0()) != this.f2093x) {
                                    z3 = false;
                                } else {
                                    z3 = true;
                                }
                            } else if (this.f2093x) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            haaVar.f19418c = z3;
                            nl7 nl7Var2 = staggeredGridLayoutManager.f2087r;
                            haaVar.f19417b = z3 ? nl7Var2.mo1413g() : nl7Var2.mo1417k();
                        } else {
                            boolean z7 = haaVar.f19418c;
                            nl7 nl7Var3 = staggeredGridLayoutManager.f2087r;
                            if (z7) {
                                haaVar.f19417b = nl7Var3.mo1413g() - i7;
                            } else {
                                haaVar.f19417b = nl7Var3.mo1417k() + i7;
                            }
                        }
                        haaVar.f19419d = true;
                    }
                } else {
                    haaVar.f19417b = RtlSpacingHelper.UNDEFINED;
                    haaVar.f19416a = this.f2095z;
                }
            }
            haaVar.f19420e = true;
        }
        if (this.f2079F == null && this.f2095z == -1 && (haaVar.f19418c != this.f2077D || m1381T0() != this.f2078E)) {
            c0187q.m1514a();
            haaVar.f19419d = true;
        }
        if (m1471w() > 0 && ((savedState = this.f2079F) == null || savedState.f2109y < 1)) {
            if (haaVar.f19419d) {
                for (int i8 = 0; i8 < this.f2085p; i8++) {
                    this.f2086q[i8].m1519b();
                    int i9 = haaVar.f19417b;
                    if (i9 != Integer.MIN_VALUE) {
                        C0189s c0189s2 = this.f2086q[i8];
                        c0189s2.f2188b = i9;
                        c0189s2.f2189c = i9;
                    }
                }
            } else if (z5 || haaVar.f19421f == null) {
                int i10 = 0;
                while (true) {
                    int i11 = this.f2085p;
                    c0189sArr = this.f2086q;
                    if (i10 >= i11) {
                        break;
                    }
                    C0189s c0189s3 = c0189sArr[i10];
                    boolean z8 = this.f2093x;
                    int i12 = haaVar.f19417b;
                    StaggeredGridLayoutManager staggeredGridLayoutManager2 = c0189s3.f2192f;
                    int iM1523f = z8 ? c0189s3.m1523f(RtlSpacingHelper.UNDEFINED) : c0189s3.m1525h(RtlSpacingHelper.UNDEFINED);
                    c0189s3.m1519b();
                    if (iM1523f != Integer.MIN_VALUE && ((!z8 || iM1523f >= staggeredGridLayoutManager2.f2087r.mo1413g()) && (z8 || iM1523f <= staggeredGridLayoutManager2.f2087r.mo1417k()))) {
                        if (i12 != Integer.MIN_VALUE) {
                            iM1523f += i12;
                        }
                        c0189s3.f2189c = iM1523f;
                        c0189s3.f2188b = iM1523f;
                    }
                    i10++;
                }
                int length = c0189sArr.length;
                int[] iArr = haaVar.f19421f;
                if (iArr == null || iArr.length < length) {
                    haaVar.f19421f = new int[staggeredGridLayoutManager.f2086q.length];
                }
                for (int i13 = 0; i13 < length; i13++) {
                    haaVar.f19421f[i13] = c0189sArr[i13].m1525h(RtlSpacingHelper.UNDEFINED);
                }
            } else {
                for (int i14 = 0; i14 < this.f2085p; i14++) {
                    C0189s c0189s4 = this.f2086q[i14];
                    c0189s4.m1519b();
                    int i15 = haaVar.f19421f[i14];
                    c0189s4.f2188b = i15;
                    c0189s4.f2189c = i15;
                }
            }
        }
        m1466q(c0182l);
        m26 m26Var = this.f2091v;
        m26Var.f27607a = false;
        nl7 nl7Var4 = this.f2088s;
        int iMo1418l = nl7Var4.mo1418l();
        this.f2090u = iMo1418l / this.f2085p;
        View.MeasureSpec.makeMeasureSpec(iMo1418l, nl7Var4.mo1415i());
        m1393f1(haaVar.f19416a, et8Var);
        if (haaVar.f19418c) {
            m1391d1(-1);
            m1367I0(c0182l, m26Var, et8Var);
            m1391d1(1);
            m26Var.f27609c = haaVar.f19416a + m26Var.f27610d;
            m1367I0(c0182l, m26Var, et8Var);
        } else {
            m1391d1(1);
            m1367I0(c0182l, m26Var, et8Var);
            m1391d1(-1);
            m26Var.f27609c = haaVar.f19416a + m26Var.f27610d;
            m1367I0(c0182l, m26Var, et8Var);
        }
        if (nl7Var4.mo1415i() != 1073741824) {
            int iM1471w3 = m1471w();
            float fMax = 0.0f;
            for (int i16 = 0; i16 < iM1471w3; i16++) {
                View viewM1469v = m1469v(i16);
                float fMo1409c = nl7Var4.mo1409c(viewM1469v);
                if (fMo1409c >= fMax) {
                    ((LayoutParams) viewM1469v.getLayoutParams()).getClass();
                    fMax = Math.max(fMax, fMo1409c);
                }
            }
            int i17 = this.f2090u;
            int iRound = Math.round(fMax * this.f2085p);
            if (nl7Var4.mo1415i() == Integer.MIN_VALUE) {
                iRound = Math.min(iRound, nl7Var4.mo1418l());
            }
            this.f2090u = iRound / this.f2085p;
            View.MeasureSpec.makeMeasureSpec(iRound, nl7Var4.mo1415i());
            if (this.f2090u != i17) {
                for (int i18 = 0; i18 < iM1471w3; i18++) {
                    View viewM1469v2 = m1469v(i18);
                    LayoutParams layoutParams = (LayoutParams) viewM1469v2.getLayoutParams();
                    layoutParams.getClass();
                    boolean zM1381T0 = m1381T0();
                    int i19 = this.f2089t;
                    if (zM1381T0 && i19 == 1) {
                        int i20 = -((this.f2085p - 1) - layoutParams.f2096e.f2191e);
                        viewM1469v2.offsetLeftAndRight((this.f2090u * i20) - (i20 * i17));
                    } else {
                        int i21 = layoutParams.f2096e.f2191e;
                        int i22 = this.f2090u * i21;
                        int i23 = i21 * i17;
                        if (i19 == 1) {
                            viewM1469v2.offsetLeftAndRight(i22 - i23);
                        } else {
                            viewM1469v2.offsetTopAndBottom(i22 - i23);
                        }
                    }
                }
            }
        }
        if (m1471w() > 0) {
            if (this.f2093x) {
                m1370L0(c0182l, et8Var, true);
                m1371M0(c0182l, et8Var, false);
            } else {
                m1371M0(c0182l, et8Var, true);
                m1370L0(c0182l, et8Var, false);
            }
        }
        if (z && !et8Var.f13104g && this.f2076C != 0 && m1471w() > 0 && m1380S0() != null) {
            RecyclerView recyclerView = this.f2142b;
            if (recyclerView != null) {
                recyclerView.removeCallbacks(this.f2084K);
            }
            z2 = m1365G0();
        }
        if (et8Var.f13104g) {
            haaVar.m10025a();
        }
        this.f2077D = haaVar.f19418c;
        this.f2078E = m1381T0();
        if (z2) {
            haaVar.m10025a();
            m1383V0(c0182l, et8Var, false);
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: W */
    public final void mo1209W(C0182l c0182l, et8 et8Var, C0681k7 c0681k7) {
        super.mo1209W(c0182l, et8Var, c0681k7);
        c0681k7.m11852j("androidx.recyclerview.widget.StaggeredGridLayoutManager");
    }

    /* JADX INFO: renamed from: W0 */
    public final boolean m1384W0(int i) {
        if (this.f2089t == 0) {
            return (i == -1) != this.f2093x;
        }
        return ((i == -1) == this.f2093x) == m1381T0();
    }

    /* JADX INFO: renamed from: X0 */
    public final void m1385X0(int i, et8 et8Var) {
        int iM1372N0;
        int i2;
        if (i > 0) {
            iM1372N0 = m1373O0();
            i2 = 1;
        } else {
            iM1372N0 = m1372N0();
            i2 = -1;
        }
        m26 m26Var = this.f2091v;
        m26Var.f27607a = true;
        m1393f1(iM1372N0, et8Var);
        m1391d1(i2);
        m26Var.f27609c = iM1372N0 + m26Var.f27610d;
        m26Var.f27608b = Math.abs(i);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: Y */
    public final void mo1210Y(C0182l c0182l, et8 et8Var, View view, C0681k7 c0681k7) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof LayoutParams)) {
            m1457X(view, c0681k7);
            return;
        }
        C0189s c0189s = ((LayoutParams) layoutParams).f2096e;
        if (this.f2089t == 0) {
            c0681k7.m11854l(C0644j7.m11151a(c0189s != null ? c0189s.f2191e : -1, 1, -1, -1, false, false));
        } else {
            c0681k7.m11854l(C0644j7.m11151a(-1, -1, c0189s != null ? c0189s.f2191e : -1, 1, false, false));
        }
    }

    /* JADX INFO: renamed from: Y0 */
    public final void m1386Y0(C0182l c0182l, m26 m26Var) {
        if (!m26Var.f27607a || m26Var.f27615i) {
            return;
        }
        int i = m26Var.f27608b;
        int i2 = m26Var.f27611e;
        if (i == 0) {
            if (i2 == -1) {
                m1387Z0(m26Var.f27613g, c0182l);
                return;
            } else {
                m1388a1(m26Var.f27612f, c0182l);
                return;
            }
        }
        int i3 = 1;
        if (i2 == -1) {
            int i4 = m26Var.f27612f;
            int iM1525h = this.f2086q[0].m1525h(i4);
            while (i3 < this.f2085p) {
                int iM1525h2 = this.f2086q[i3].m1525h(i4);
                if (iM1525h2 > iM1525h) {
                    iM1525h = iM1525h2;
                }
                i3++;
            }
            int i5 = i4 - iM1525h;
            int iMin = m26Var.f27613g;
            if (i5 >= 0) {
                iMin -= Math.min(i5, m26Var.f27608b);
            }
            m1387Z0(iMin, c0182l);
            return;
        }
        int i6 = m26Var.f27613g;
        int iM1523f = this.f2086q[0].m1523f(i6);
        while (i3 < this.f2085p) {
            int iM1523f2 = this.f2086q[i3].m1523f(i6);
            if (iM1523f2 < iM1523f) {
                iM1523f = iM1523f2;
            }
            i3++;
        }
        int i7 = iM1523f - m26Var.f27613g;
        int iMin2 = m26Var.f27612f;
        if (i7 >= 0) {
            iMin2 += Math.min(i7, m26Var.f27608b);
        }
        m1388a1(iMin2, c0182l);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: Z */
    public final void mo1211Z(int i, int i2) {
        m1379R0(i, i2, 1);
    }

    /* JADX INFO: renamed from: Z0 */
    public final void m1387Z0(int i, C0182l c0182l) {
        for (int iM1471w = m1471w() - 1; iM1471w >= 0; iM1471w--) {
            View viewM1469v = m1469v(iM1471w);
            nl7 nl7Var = this.f2087r;
            if (nl7Var.mo1411e(viewM1469v) < i || nl7Var.mo1420n(viewM1469v) < i) {
                return;
            }
            LayoutParams layoutParams = (LayoutParams) viewM1469v.getLayoutParams();
            layoutParams.getClass();
            if (layoutParams.f2096e.f2187a.size() == 1) {
                return;
            }
            C0189s c0189s = layoutParams.f2096e;
            ArrayList arrayList = c0189s.f2187a;
            int size = arrayList.size();
            View view = (View) arrayList.remove(size - 1);
            LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
            layoutParams2.f2096e = null;
            if (layoutParams2.f2069a.m1505j() || layoutParams2.f2069a.m1508m()) {
                c0189s.f2190d -= c0189s.f2192f.f2087r.mo1409c(view);
            }
            if (size == 1) {
                c0189s.f2188b = RtlSpacingHelper.UNDEFINED;
            }
            c0189s.f2189c = RtlSpacingHelper.UNDEFINED;
            m1464o0(viewM1469v, c0182l);
        }
    }

    /* JADX WARN: Code duplicated, block: B:6:0x000c  */
    @Override // p000.ct8
    /* JADX INFO: renamed from: a */
    public final PointF mo1271a(int i) {
        int i2 = -1;
        if (m1471w() != 0) {
            if ((i < m1372N0()) == this.f2093x) {
                i2 = 1;
            }
        } else if (this.f2093x) {
            i2 = 1;
        }
        PointF pointF = new PointF();
        if (i2 == 0) {
            return null;
        }
        if (this.f2089t == 0) {
            pointF.x = i2;
            pointF.y = 0.0f;
            return pointF;
        }
        pointF.x = 0.0f;
        pointF.y = i2;
        return pointF;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: a0 */
    public final void mo1212a0() {
        this.f2075B.m1514a();
        m1468r0();
    }

    /* JADX INFO: renamed from: a1 */
    public final void m1388a1(int i, C0182l c0182l) {
        while (m1471w() > 0) {
            View viewM1469v = m1469v(0);
            nl7 nl7Var = this.f2087r;
            if (nl7Var.mo1408b(viewM1469v) > i || nl7Var.mo1419m(viewM1469v) > i) {
                return;
            }
            LayoutParams layoutParams = (LayoutParams) viewM1469v.getLayoutParams();
            layoutParams.getClass();
            if (layoutParams.f2096e.f2187a.size() == 1) {
                return;
            }
            C0189s c0189s = layoutParams.f2096e;
            ArrayList arrayList = c0189s.f2187a;
            View view = (View) arrayList.remove(0);
            LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
            layoutParams2.f2096e = null;
            if (arrayList.size() == 0) {
                c0189s.f2189c = RtlSpacingHelper.UNDEFINED;
            }
            if (layoutParams2.f2069a.m1505j() || layoutParams2.f2069a.m1508m()) {
                c0189s.f2190d -= c0189s.f2192f.f2087r.mo1409c(view);
            }
            c0189s.f2188b = RtlSpacingHelper.UNDEFINED;
            m1464o0(viewM1469v, c0182l);
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: b0 */
    public final void mo1214b0(int i, int i2) {
        m1379R0(i, i2, 8);
    }

    /* JADX INFO: renamed from: b1 */
    public final void m1389b1() {
        if (this.f2089t == 1 || !m1381T0()) {
            this.f2093x = this.f2092w;
        } else {
            this.f2093x = !this.f2092w;
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: c */
    public final void mo1272c(String str) {
        if (this.f2079F == null) {
            super.mo1272c(str);
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: c0 */
    public final void mo1216c0(int i, int i2) {
        m1379R0(i, i2, 2);
    }

    /* JADX INFO: renamed from: c1 */
    public final int m1390c1(int i, et8 et8Var, C0182l c0182l) {
        if (m1471w() == 0 || i == 0) {
            return 0;
        }
        m1385X0(i, et8Var);
        m26 m26Var = this.f2091v;
        int iM1367I0 = m1367I0(c0182l, m26Var, et8Var);
        if (m26Var.f27608b >= iM1367I0) {
            i = i < 0 ? -iM1367I0 : iM1367I0;
        }
        this.f2087r.mo1421o(-i);
        this.f2077D = this.f2093x;
        m26Var.f27608b = 0;
        m1386Y0(c0182l, m26Var);
        return i;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: d0 */
    public final void mo1217d0(int i, int i2) {
        m1379R0(i, i2, 4);
    }

    /* JADX INFO: renamed from: d1 */
    public final void m1391d1(int i) {
        m26 m26Var = this.f2091v;
        m26Var.f27611e = i;
        m26Var.f27610d = this.f2093x != (i == -1) ? -1 : 1;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: e */
    public final boolean mo1275e() {
        return this.f2089t == 0;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: e0 */
    public final void mo1218e0(C0182l c0182l, et8 et8Var) {
        m1383V0(c0182l, et8Var, true);
    }

    /* JADX INFO: renamed from: e1 */
    public final void m1392e1(int i) {
        mo1272c(null);
        if (i != this.f2085p) {
            this.f2075B.m1514a();
            m1468r0();
            this.f2085p = i;
            this.f2094y = new BitSet(this.f2085p);
            this.f2086q = new C0189s[this.f2085p];
            for (int i2 = 0; i2 < this.f2085p; i2++) {
                this.f2086q[i2] = new C0189s(this, i2);
            }
            m1468r0();
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: f */
    public final boolean mo1277f() {
        return this.f2089t == 1;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: f0 */
    public final void mo1219f0(et8 et8Var) {
        this.f2095z = -1;
        this.f2074A = RtlSpacingHelper.UNDEFINED;
        this.f2079F = null;
        this.f2081H.m10025a();
    }

    /* JADX INFO: renamed from: f1 */
    public final void m1393f1(int i, et8 et8Var) {
        int iMo1418l;
        int iMo1418l2;
        int i2;
        m26 m26Var = this.f2091v;
        boolean z = false;
        m26Var.f27608b = 0;
        m26Var.f27609c = i;
        C0174d c0174d = this.f2145e;
        nl7 nl7Var = this.f2087r;
        if (c0174d == null || !c0174d.m7096d() || (i2 = et8Var.f13098a) == -1) {
            iMo1418l = 0;
            iMo1418l2 = 0;
        } else {
            if (this.f2093x == (i2 < i)) {
                iMo1418l = nl7Var.mo1418l();
                iMo1418l2 = 0;
            } else {
                iMo1418l2 = nl7Var.mo1418l();
                iMo1418l = 0;
            }
        }
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView == null || !recyclerView.f1999D) {
            m26Var.f27613g = nl7Var.mo1412f() + iMo1418l;
            m26Var.f27612f = -iMo1418l2;
        } else {
            m26Var.f27612f = nl7Var.mo1417k() - iMo1418l2;
            m26Var.f27613g = nl7Var.mo1413g() + iMo1418l;
        }
        m26Var.f27614h = false;
        m26Var.f27607a = true;
        if (nl7Var.mo1415i() == 0 && nl7Var.mo1412f() == 0) {
            z = true;
        }
        m26Var.f27615i = z;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: g */
    public final boolean mo1220g(RecyclerView.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: g0 */
    public final void mo1279g0(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            this.f2079F = savedState;
            if (this.f2095z != -1) {
                savedState.f2107e = -1;
                savedState.f2108i = -1;
                savedState.f2110z = null;
                savedState.f2109y = 0;
                savedState.f2101A = 0;
                savedState.f2102B = null;
                savedState.f2103C = null;
            }
            m1468r0();
        }
    }

    /* JADX INFO: renamed from: g1 */
    public final void m1394g1(C0189s c0189s, int i, int i2) {
        int i3 = c0189s.f2190d;
        int i4 = c0189s.f2191e;
        if (i != -1) {
            int i5 = c0189s.f2189c;
            if (i5 == Integer.MIN_VALUE) {
                c0189s.m1518a();
                i5 = c0189s.f2189c;
            }
            if (i5 - i3 >= i2) {
                this.f2094y.set(i4, false);
                return;
            }
            return;
        }
        int i6 = c0189s.f2188b;
        if (i6 == Integer.MIN_VALUE) {
            View view = (View) c0189s.f2187a.get(0);
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            c0189s.f2188b = c0189s.f2192f.f2087r.mo1411e(view);
            layoutParams.getClass();
            i6 = c0189s.f2188b;
        }
        if (i6 + i3 <= i2) {
            this.f2094y.set(i4, false);
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: h0 */
    public final Parcelable mo1281h0() {
        int iM1525h;
        int iMo1417k;
        int[] iArr;
        SavedState savedState = this.f2079F;
        if (savedState != null) {
            SavedState savedState2 = new SavedState();
            savedState2.f2109y = savedState.f2109y;
            savedState2.f2107e = savedState.f2107e;
            savedState2.f2108i = savedState.f2108i;
            savedState2.f2110z = savedState.f2110z;
            savedState2.f2101A = savedState.f2101A;
            savedState2.f2102B = savedState.f2102B;
            savedState2.f2104D = savedState.f2104D;
            savedState2.f2105E = savedState.f2105E;
            savedState2.f2106F = savedState.f2106F;
            savedState2.f2103C = savedState.f2103C;
            return savedState2;
        }
        SavedState savedState3 = new SavedState();
        savedState3.f2104D = this.f2092w;
        savedState3.f2105E = this.f2077D;
        savedState3.f2106F = this.f2078E;
        C0187q c0187q = this.f2075B;
        if (c0187q == null || (iArr = c0187q.f2185a) == null) {
            savedState3.f2101A = 0;
        } else {
            savedState3.f2102B = iArr;
            savedState3.f2101A = iArr.length;
            savedState3.f2103C = c0187q.f2186b;
        }
        if (m1471w() <= 0) {
            savedState3.f2107e = -1;
            savedState3.f2108i = -1;
            savedState3.f2109y = 0;
            return savedState3;
        }
        savedState3.f2107e = this.f2077D ? m1373O0() : m1372N0();
        View viewM1368J0 = this.f2093x ? m1368J0(true) : m1369K0(true);
        savedState3.f2108i = viewM1368J0 != null ? AbstractC0181k.m1441H(viewM1368J0) : -1;
        int i = this.f2085p;
        savedState3.f2109y = i;
        savedState3.f2110z = new int[i];
        for (int i2 = 0; i2 < this.f2085p; i2++) {
            boolean z = this.f2077D;
            C0189s[] c0189sArr = this.f2086q;
            nl7 nl7Var = this.f2087r;
            if (z) {
                iM1525h = c0189sArr[i2].m1523f(RtlSpacingHelper.UNDEFINED);
                if (iM1525h != Integer.MIN_VALUE) {
                    iMo1417k = nl7Var.mo1413g();
                    iM1525h -= iMo1417k;
                }
            } else {
                iM1525h = c0189sArr[i2].m1525h(RtlSpacingHelper.UNDEFINED);
                if (iM1525h != Integer.MIN_VALUE) {
                    iMo1417k = nl7Var.mo1417k();
                    iM1525h -= iMo1417k;
                }
            }
            savedState3.f2110z[i2] = iM1525h;
        }
        return savedState3;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: i */
    public final void mo1282i(int i, int i2, et8 et8Var, zo1 zo1Var) {
        m26 m26Var;
        int iM1523f;
        int iM1525h;
        if (this.f2089t != 0) {
            i = i2;
        }
        if (m1471w() == 0 || i == 0) {
            return;
        }
        m1385X0(i, et8Var);
        int[] iArr = this.f2083J;
        if (iArr == null || iArr.length < this.f2085p) {
            this.f2083J = new int[this.f2085p];
        }
        int i3 = 0;
        int i4 = 0;
        while (true) {
            int i5 = this.f2085p;
            m26Var = this.f2091v;
            if (i3 >= i5) {
                break;
            }
            if (m26Var.f27610d == -1) {
                iM1523f = m26Var.f27612f;
                iM1525h = this.f2086q[i3].m1525h(iM1523f);
            } else {
                iM1523f = this.f2086q[i3].m1523f(m26Var.f27613g);
                iM1525h = m26Var.f27613g;
            }
            int i6 = iM1523f - iM1525h;
            if (i6 >= 0) {
                this.f2083J[i4] = i6;
                i4++;
            }
            i3++;
        }
        Arrays.sort(this.f2083J, 0, i4);
        for (int i7 = 0; i7 < i4; i7++) {
            int i8 = m26Var.f27609c;
            if (i8 < 0 || i8 >= et8Var.m7762b()) {
                return;
            }
            zo1Var.m21325a(m26Var.f27609c, this.f2083J[i7]);
            m26Var.f27609c += m26Var.f27610d;
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: i0 */
    public final void mo1395i0(int i) {
        if (i == 0) {
            m1365G0();
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: k */
    public final int mo1286k(et8 et8Var) {
        if (m1471w() == 0) {
            return 0;
        }
        boolean z = !this.f2082I;
        return fy8.m8534U(et8Var, this.f2087r, m1369K0(z), m1368J0(z), this, this.f2082I);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: l */
    public final int mo1223l(et8 et8Var) {
        return m1366H0(et8Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: m */
    public final int mo1225m(et8 et8Var) {
        if (m1471w() == 0) {
            return 0;
        }
        boolean z = !this.f2082I;
        return fy8.m8536W(et8Var, this.f2087r, m1369K0(z), m1368J0(z), this, this.f2082I);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: n */
    public final int mo1288n(et8 et8Var) {
        if (m1471w() == 0) {
            return 0;
        }
        boolean z = !this.f2082I;
        return fy8.m8534U(et8Var, this.f2087r, m1369K0(z), m1368J0(z), this, this.f2082I);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: o */
    public final int mo1228o(et8 et8Var) {
        return m1366H0(et8Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: p */
    public final int mo1230p(et8 et8Var) {
        if (m1471w() == 0) {
            return 0;
        }
        boolean z = !this.f2082I;
        return fy8.m8536W(et8Var, this.f2087r, m1369K0(z), m1368J0(z), this, this.f2082I);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: s */
    public final RecyclerView.LayoutParams mo1234s() {
        return this.f2089t == 0 ? new LayoutParams(-2, -1) : new LayoutParams(-1, -2);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: s0 */
    public final int mo1235s0(int i, et8 et8Var, C0182l c0182l) {
        return m1390c1(i, et8Var, c0182l);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: t */
    public final RecyclerView.LayoutParams mo1237t(Context context, AttributeSet attributeSet) {
        return new LayoutParams(context, attributeSet);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: t0 */
    public final void mo1290t0(int i) {
        SavedState savedState = this.f2079F;
        if (savedState != null && savedState.f2107e != i) {
            savedState.f2110z = null;
            savedState.f2109y = 0;
            savedState.f2107e = -1;
            savedState.f2108i = -1;
        }
        this.f2095z = i;
        this.f2074A = RtlSpacingHelper.UNDEFINED;
        m1468r0();
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: u */
    public final RecyclerView.LayoutParams mo1239u(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams) : new LayoutParams(layoutParams);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: u0 */
    public final int mo1240u0(int i, et8 et8Var, C0182l c0182l) {
        return m1390c1(i, et8Var, c0182l);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: x0 */
    public final void mo1244x0(Rect rect, int i, int i2) {
        int iM1445h;
        int iM1445h2;
        int iM1453F = m1453F() + m1451E();
        int iM1450D = m1450D() + m1454G();
        if (this.f2089t == 1) {
            int iHeight = rect.height() + iM1450D;
            RecyclerView recyclerView = this.f2142b;
            WeakHashMap weakHashMap = obb.f31348a;
            iM1445h2 = AbstractC0181k.m1445h(i2, iHeight, recyclerView.getMinimumHeight());
            iM1445h = AbstractC0181k.m1445h(i, (this.f2090u * this.f2085p) + iM1453F, this.f2142b.getMinimumWidth());
        } else {
            int iWidth = rect.width() + iM1453F;
            RecyclerView recyclerView2 = this.f2142b;
            WeakHashMap weakHashMap2 = obb.f31348a;
            iM1445h = AbstractC0181k.m1445h(i, iWidth, recyclerView2.getMinimumWidth());
            iM1445h2 = AbstractC0181k.m1445h(i2, (this.f2090u * this.f2085p) + iM1450D, this.f2142b.getMinimumHeight());
        }
        this.f2142b.setMeasuredDimension(iM1445h, iM1445h2);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: y */
    public final int mo1246y(C0182l c0182l, et8 et8Var) {
        if (this.f2089t == 1) {
            return Math.min(this.f2085p, et8Var.m7762b());
        }
        return -1;
    }

    public StaggeredGridLayoutManager() {
        this.f2085p = -1;
        this.f2092w = false;
        this.f2093x = false;
        this.f2095z = -1;
        this.f2074A = RtlSpacingHelper.UNDEFINED;
        this.f2075B = new C0187q();
        this.f2076C = 2;
        this.f2080G = new Rect();
        this.f2081H = new haa(this);
        this.f2082I = true;
        this.f2084K = new wi0(this, 18);
        this.f2089t = 1;
        m1392e1(2);
        this.f2091v = new m26();
        this.f2087r = nl7.m14206a(this, this.f2089t);
        this.f2088s = nl7.m14206a(this, 1 - this.f2089t);
    }
}
