package androidx.recyclerview.widget;

import android.view.View;
import androidx.appcompat.widget.RtlSpacingHelper;
import p000.nl7;

/* JADX INFO: renamed from: androidx.recyclerview.widget.a */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public final class C0171a {

    /* JADX INFO: renamed from: a */
    public nl7 f2111a;

    /* JADX INFO: renamed from: b */
    public int f2112b;

    /* JADX INFO: renamed from: c */
    public int f2113c;

    /* JADX INFO: renamed from: d */
    public boolean f2114d;

    /* JADX INFO: renamed from: e */
    public boolean f2115e;

    public C0171a() {
        m1398c();
    }

    /* JADX INFO: renamed from: a */
    public final void m1396a() {
        boolean z = this.f2114d;
        nl7 nl7Var = this.f2111a;
        this.f2113c = z ? nl7Var.mo1413g() : nl7Var.mo1417k();
    }

    /* JADX INFO: renamed from: b */
    public final void m1397b(int i, View view) {
        nl7 nl7Var = this.f2111a;
        int iMo1418l = Integer.MIN_VALUE == nl7Var.f30239b ? 0 : nl7Var.mo1418l() - nl7Var.f30239b;
        if (iMo1418l >= 0) {
            boolean z = this.f2114d;
            nl7 nl7Var2 = this.f2111a;
            if (z) {
                int iMo1408b = nl7Var2.mo1408b(view);
                nl7 nl7Var3 = this.f2111a;
                this.f2113c = (Integer.MIN_VALUE != nl7Var3.f30239b ? nl7Var3.mo1418l() - nl7Var3.f30239b : 0) + iMo1408b;
            } else {
                this.f2113c = nl7Var2.mo1411e(view);
            }
            this.f2112b = i;
            return;
        }
        this.f2112b = i;
        boolean z2 = this.f2114d;
        nl7 nl7Var4 = this.f2111a;
        if (!z2) {
            int iMo1411e = nl7Var4.mo1411e(view);
            int iMo1417k = iMo1411e - this.f2111a.mo1417k();
            this.f2113c = iMo1411e;
            if (iMo1417k > 0) {
                int iMo1413g = (this.f2111a.mo1413g() - Math.min(0, (this.f2111a.mo1413g() - iMo1418l) - this.f2111a.mo1408b(view))) - (this.f2111a.mo1409c(view) + iMo1411e);
                if (iMo1413g < 0) {
                    this.f2113c -= Math.min(iMo1417k, -iMo1413g);
                    return;
                }
                return;
            }
            return;
        }
        int iMo1413g2 = (nl7Var4.mo1413g() - iMo1418l) - this.f2111a.mo1408b(view);
        this.f2113c = this.f2111a.mo1413g() - iMo1413g2;
        if (iMo1413g2 > 0) {
            int iMo1409c = this.f2113c - this.f2111a.mo1409c(view);
            int iMo1417k2 = this.f2111a.mo1417k();
            int iMin = iMo1409c - (Math.min(this.f2111a.mo1411e(view) - iMo1417k2, 0) + iMo1417k2);
            if (iMin < 0) {
                this.f2113c = Math.min(iMo1413g2, -iMin) + this.f2113c;
            }
        }
    }

    /* JADX INFO: renamed from: c */
    public final void m1398c() {
        this.f2112b = -1;
        this.f2113c = RtlSpacingHelper.UNDEFINED;
        this.f2114d = false;
        this.f2115e = false;
    }

    public final String toString() {
        return "AnchorInfo{mPosition=" + this.f2112b + ", mCoordinate=" + this.f2113c + ", mLayoutFromEnd=" + this.f2114d + ", mValid=" + this.f2115e + '}';
    }
}
