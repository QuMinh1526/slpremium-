package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import p000.C1521v3;
import p000.bt8;
import p000.dt8;

/* JADX INFO: renamed from: androidx.recyclerview.widget.d */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class C0174d extends dt8 {

    /* JADX INFO: renamed from: k */
    public PointF f2130k;

    /* JADX INFO: renamed from: l */
    public final DisplayMetrics f2131l;

    /* JADX INFO: renamed from: n */
    public float f2133n;

    /* JADX INFO: renamed from: i */
    public final LinearInterpolator f2128i = new LinearInterpolator();

    /* JADX INFO: renamed from: j */
    public final DecelerateInterpolator f2129j = new DecelerateInterpolator();

    /* JADX INFO: renamed from: m */
    public boolean f2132m = false;

    /* JADX INFO: renamed from: o */
    public int f2134o = 0;

    /* JADX INFO: renamed from: p */
    public int f2135p = 0;

    public C0174d(Context context) {
        this.f2131l = context.getResources().getDisplayMetrics();
    }

    /* JADX INFO: renamed from: k */
    public static int m1401k(int i, int i2, int i3, int i4, int i5) {
        if (i5 == -1) {
            return i3 - i;
        }
        if (i5 != 0) {
            if (i5 == 1) {
                return i4 - i2;
            }
            C1521v3.m18903j("snap preference should be one of the constants defined in SmoothScroller, starting with SNAP_");
            return 0;
        }
        int i6 = i3 - i;
        if (i6 > 0) {
            return i6;
        }
        int i7 = i4 - i2;
        if (i7 < 0) {
            return i7;
        }
        return 0;
    }

    /* JADX WARN: Code duplicated, block: B:10:0x0015  */
    @Override // p000.dt8
    /* JADX INFO: renamed from: g */
    public void mo1402g(View view, bt8 bt8Var) {
        int i;
        PointF pointF = this.f2130k;
        int i2 = 0;
        if (pointF != null) {
            float f = pointF.x;
            if (f == 0.0f) {
                i = 0;
            } else {
                i = f > 0.0f ? 1 : -1;
            }
        } else {
            i = 0;
        }
        int iMo1403l = mo1403l(view, i);
        PointF pointF2 = this.f2130k;
        if (pointF2 != null) {
            float f2 = pointF2.y;
            if (f2 != 0.0f) {
                i2 = f2 > 0.0f ? 1 : -1;
            }
        }
        int iMo1404m = mo1404m(view, i2);
        int iMo1406o = mo1406o((int) Math.sqrt((iMo1404m * iMo1404m) + (iMo1403l * iMo1403l)));
        if (iMo1406o > 0) {
            bt8Var.f4606a = -iMo1403l;
            bt8Var.f4607b = -iMo1404m;
            bt8Var.f4608c = iMo1406o;
            bt8Var.f4610e = this.f2129j;
            bt8Var.f4611f = true;
        }
    }

    /* JADX INFO: renamed from: l */
    public int mo1403l(View view, int i) {
        AbstractC0181k abstractC0181k = this.f11407c;
        if (abstractC0181k == null || !abstractC0181k.mo1275e()) {
            return 0;
        }
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        return m1401k((view.getLeft() - ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b.left) - ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin, view.getRight() + ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b.right + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, abstractC0181k.m1451E(), abstractC0181k.f2154n - abstractC0181k.m1453F(), i);
    }

    /* JADX INFO: renamed from: m */
    public int mo1404m(View view, int i) {
        AbstractC0181k abstractC0181k = this.f11407c;
        if (abstractC0181k == null || !abstractC0181k.mo1277f()) {
            return 0;
        }
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        return m1401k((view.getTop() - ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b.top) - ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, view.getBottom() + ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b.bottom + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, abstractC0181k.m1454G(), abstractC0181k.f2155o - abstractC0181k.m1450D(), i);
    }

    /* JADX INFO: renamed from: n */
    public float mo1405n(DisplayMetrics displayMetrics) {
        return 25.0f / displayMetrics.densityDpi;
    }

    /* JADX INFO: renamed from: o */
    public int mo1406o(int i) {
        return (int) Math.ceil(((double) mo1407p(i)) / 0.3356d);
    }

    /* JADX INFO: renamed from: p */
    public int mo1407p(int i) {
        float fAbs = Math.abs(i);
        if (!this.f2132m) {
            this.f2133n = mo1405n(this.f2131l);
            this.f2132m = true;
        }
        return (int) Math.ceil(fAbs * this.f2133n);
    }
}
