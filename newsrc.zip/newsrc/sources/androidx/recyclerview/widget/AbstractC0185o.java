package androidx.recyclerview.widget;

import android.util.Log;
import android.view.View;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.WeakHashMap;
import org.p003jf.dexlib2.Opcode;
import p000.C1521v3;
import p000.obb;
import p000.z23;

/* JADX INFO: renamed from: androidx.recyclerview.widget.o */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0185o {

    /* JADX INFO: renamed from: P */
    public static final List f2165P = Collections.EMPTY_LIST;

    /* JADX INFO: renamed from: F */
    public int f2171F;

    /* JADX INFO: renamed from: N */
    public RecyclerView f2179N;

    /* JADX INFO: renamed from: O */
    public AbstractC0177g f2180O;

    /* JADX INFO: renamed from: e */
    public final View f2181e;

    /* JADX INFO: renamed from: i */
    public WeakReference f2182i;

    /* JADX INFO: renamed from: y */
    public int f2183y = -1;

    /* JADX INFO: renamed from: z */
    public int f2184z = -1;

    /* JADX INFO: renamed from: A */
    public long f2166A = -1;

    /* JADX INFO: renamed from: B */
    public int f2167B = -1;

    /* JADX INFO: renamed from: C */
    public int f2168C = -1;

    /* JADX INFO: renamed from: D */
    public AbstractC0185o f2169D = null;

    /* JADX INFO: renamed from: E */
    public AbstractC0185o f2170E = null;

    /* JADX INFO: renamed from: G */
    public ArrayList f2172G = null;

    /* JADX INFO: renamed from: H */
    public List f2173H = null;

    /* JADX INFO: renamed from: I */
    public int f2174I = 0;

    /* JADX INFO: renamed from: J */
    public C0182l f2175J = null;

    /* JADX INFO: renamed from: K */
    public boolean f2176K = false;

    /* JADX INFO: renamed from: L */
    public int f2177L = 0;

    /* JADX INFO: renamed from: M */
    public int f2178M = -1;

    public AbstractC0185o(View view) {
        if (view != null) {
            this.f2181e = view;
        } else {
            C1521v3.m18903j("itemView may not be null");
            throw null;
        }
    }

    /* JADX INFO: renamed from: a */
    public final void m1496a(int i) {
        this.f2171F = i | this.f2171F;
    }

    /* JADX INFO: renamed from: b */
    public final int m1497b() {
        RecyclerView recyclerView = this.f2179N;
        if (recyclerView == null) {
            return -1;
        }
        return recyclerView.m1309J(this);
    }

    /* JADX INFO: renamed from: c */
    public final int m1498c() {
        RecyclerView recyclerView;
        AbstractC0177g abstractC0177g;
        int iM1309J;
        if (this.f2180O == null || (recyclerView = this.f2179N) == null || (abstractC0177g = recyclerView.f2009I) == null || (iM1309J = recyclerView.m1309J(this)) == -1 || this.f2180O != abstractC0177g) {
            return -1;
        }
        return iM1309J;
    }

    /* JADX INFO: renamed from: d */
    public final int m1499d() {
        int i = this.f2168C;
        return i == -1 ? this.f2183y : i;
    }

    /* JADX INFO: renamed from: e */
    public final List m1500e() {
        ArrayList arrayList;
        return ((this.f2171F & Opcode.CAN_INITIALIZE_REFERENCE) != 0 || (arrayList = this.f2172G) == null || arrayList.size() == 0) ? f2165P : this.f2173H;
    }

    /* JADX INFO: renamed from: f */
    public final boolean m1501f() {
        View view = this.f2181e;
        return (view.getParent() == null || view.getParent() == this.f2179N) ? false : true;
    }

    /* JADX INFO: renamed from: g */
    public final boolean m1502g() {
        return (this.f2171F & 1) != 0;
    }

    /* JADX INFO: renamed from: h */
    public final boolean m1503h() {
        return (this.f2171F & 4) != 0;
    }

    /* JADX INFO: renamed from: i */
    public final boolean m1504i() {
        if ((this.f2171F & 16) != 0) {
            return false;
        }
        WeakHashMap weakHashMap = obb.f31348a;
        return !this.f2181e.hasTransientState();
    }

    /* JADX INFO: renamed from: j */
    public final boolean m1505j() {
        return (this.f2171F & 8) != 0;
    }

    /* JADX INFO: renamed from: k */
    public final boolean m1506k() {
        return this.f2175J != null;
    }

    /* JADX INFO: renamed from: l */
    public final boolean m1507l() {
        return (this.f2171F & Opcode.STATIC_FIELD_ACCESSOR) != 0;
    }

    /* JADX INFO: renamed from: m */
    public final boolean m1508m() {
        return (this.f2171F & 2) != 0;
    }

    /* JADX INFO: renamed from: n */
    public final void m1509n(int i, boolean z) {
        if (this.f2184z == -1) {
            this.f2184z = this.f2183y;
        }
        if (this.f2168C == -1) {
            this.f2168C = this.f2183y;
        }
        if (z) {
            this.f2168C += i;
        }
        this.f2183y += i;
        View view = this.f2181e;
        if (view.getLayoutParams() != null) {
            ((RecyclerView.LayoutParams) view.getLayoutParams()).f2071c = true;
        }
    }

    /* JADX INFO: renamed from: o */
    public final void m1510o() {
        int[] iArr = RecyclerView.f1986X0;
        this.f2171F = 0;
        this.f2183y = -1;
        this.f2184z = -1;
        this.f2166A = -1L;
        this.f2168C = -1;
        this.f2174I = 0;
        this.f2169D = null;
        this.f2170E = null;
        ArrayList arrayList = this.f2172G;
        if (arrayList != null) {
            arrayList.clear();
        }
        this.f2171F &= -1025;
        this.f2177L = 0;
        this.f2178M = -1;
        RecyclerView.m1299l(this);
    }

    /* JADX INFO: renamed from: p */
    public final void m1511p(boolean z) {
        int i = this.f2174I;
        int i2 = z ? i - 1 : i + 1;
        this.f2174I = i2;
        if (i2 < 0) {
            this.f2174I = 0;
            int[] iArr = RecyclerView.f1986X0;
            Log.e("View", "isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for " + this);
        } else if (!z && i2 == 1) {
            this.f2171F |= 16;
        } else if (z && i2 == 0) {
            this.f2171F &= -17;
        }
        int[] iArr2 = RecyclerView.f1986X0;
    }

    /* JADX INFO: renamed from: q */
    public final boolean m1512q() {
        return (this.f2171F & Opcode.VOLATILE_FIELD_ACCESSOR) != 0;
    }

    /* JADX INFO: renamed from: r */
    public final boolean m1513r() {
        return (this.f2171F & 32) != 0;
    }

    public final String toString() {
        StringBuilder sbM20944z = z23.m20944z(getClass().isAnonymousClass() ? "ViewHolder" : getClass().getSimpleName(), "{");
        sbM20944z.append(Integer.toHexString(hashCode()));
        sbM20944z.append(" position=");
        sbM20944z.append(this.f2183y);
        sbM20944z.append(" id=");
        sbM20944z.append(this.f2166A);
        sbM20944z.append(", oldPos=");
        sbM20944z.append(this.f2184z);
        sbM20944z.append(", pLpos:");
        sbM20944z.append(this.f2168C);
        StringBuilder sb = new StringBuilder(sbM20944z.toString());
        if (m1506k()) {
            sb.append(" scrap ");
            sb.append(this.f2176K ? "[changeScrap]" : "[attachedScrap]");
        }
        if (m1503h()) {
            sb.append(" invalid");
        }
        if (!m1502g()) {
            sb.append(" unbound");
        }
        if ((this.f2171F & 2) != 0) {
            sb.append(" update");
        }
        if (m1505j()) {
            sb.append(" removed");
        }
        if (m1512q()) {
            sb.append(" ignored");
        }
        if (m1507l()) {
            sb.append(" tmpDetached");
        }
        if (!m1504i()) {
            sb.append(" not recyclable(" + this.f2174I + ")");
        }
        if ((this.f2171F & Opcode.JUMBO_OPCODE) != 0 || m1503h()) {
            sb.append(" undefined adapter position");
        }
        if (this.f2181e.getParent() == null) {
            sb.append(" no parent");
        }
        sb.append("}");
        return sb.toString();
    }
}
