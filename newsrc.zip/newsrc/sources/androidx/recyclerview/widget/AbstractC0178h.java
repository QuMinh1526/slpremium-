package androidx.recyclerview.widget;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;

/* JADX INFO: renamed from: androidx.recyclerview.widget.h */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0178h {
    /* JADX INFO: renamed from: f */
    public void mo1431f(Rect rect, View view, RecyclerView recyclerView) {
        ((RecyclerView.LayoutParams) view.getLayoutParams()).f2069a.getClass();
        rect.set(0, 0, 0, 0);
    }

    /* JADX INFO: renamed from: g */
    public void mo1432g(Canvas canvas, RecyclerView recyclerView) {
    }

    /* JADX INFO: renamed from: h */
    public void mo1433h(Canvas canvas, RecyclerView recyclerView) {
    }
}
