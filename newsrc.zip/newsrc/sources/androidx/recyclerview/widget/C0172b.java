package androidx.recyclerview.widget;

import android.view.View;
import java.util.List;

/* JADX INFO: renamed from: androidx.recyclerview.widget.b */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public final class C0172b {

    /* JADX INFO: renamed from: a */
    public boolean f2116a;

    /* JADX INFO: renamed from: b */
    public int f2117b;

    /* JADX INFO: renamed from: c */
    public int f2118c;

    /* JADX INFO: renamed from: d */
    public int f2119d;

    /* JADX INFO: renamed from: e */
    public int f2120e;

    /* JADX INFO: renamed from: f */
    public int f2121f;

    /* JADX INFO: renamed from: g */
    public int f2122g;

    /* JADX INFO: renamed from: h */
    public int f2123h;

    /* JADX INFO: renamed from: i */
    public int f2124i;

    /* JADX INFO: renamed from: j */
    public int f2125j;

    /* JADX INFO: renamed from: k */
    public List f2126k;

    /* JADX INFO: renamed from: l */
    public boolean f2127l;

    /* JADX INFO: renamed from: a */
    public final void m1399a(View view) {
        int iM1499d;
        int size = this.f2126k.size();
        View view2 = null;
        int i = Integer.MAX_VALUE;
        for (int i2 = 0; i2 < size; i2++) {
            View view3 = ((AbstractC0185o) this.f2126k.get(i2)).f2181e;
            RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view3.getLayoutParams();
            if (view3 != view && !layoutParams.f2069a.m1505j() && (iM1499d = (layoutParams.f2069a.m1499d() - this.f2119d) * this.f2120e) >= 0 && iM1499d < i) {
                view2 = view3;
                if (iM1499d == 0) {
                    break;
                } else {
                    i = iM1499d;
                }
            }
        }
        if (view2 == null) {
            this.f2119d = -1;
        } else {
            this.f2119d = ((RecyclerView.LayoutParams) view2.getLayoutParams()).f2069a.m1499d();
        }
    }

    /* JADX INFO: renamed from: b */
    public final View m1400b(C0182l c0182l) {
        List list = this.f2126k;
        if (list == null) {
            View viewM1479d = c0182l.m1479d(this.f2119d);
            this.f2119d += this.f2120e;
            return viewM1479d;
        }
        int size = list.size();
        for (int i = 0; i < size; i++) {
            View view = ((AbstractC0185o) this.f2126k.get(i)).f2181e;
            RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
            if (!layoutParams.f2069a.m1505j() && this.f2119d == layoutParams.f2069a.m1499d()) {
                m1399a(view);
                return view;
            }
        }
        return null;
    }
}
