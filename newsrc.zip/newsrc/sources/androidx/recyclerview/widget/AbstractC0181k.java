package androidx.recyclerview.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.widget.RtlSpacingHelper;
import java.util.ArrayList;
import java.util.WeakHashMap;
import org.p003jf.dexlib2.dexbacked.raw.ItemType;
import p000.C0609i7;
import p000.C0631iv;
import p000.C0644j7;
import p000.C0681k7;
import p000.C1521v3;
import p000.ccb;
import p000.cz9;
import p000.eo8;
import p000.et8;
import p000.obb;
import p000.qz6;
import p000.rg1;
import p000.rs8;
import p000.uy9;
import p000.vs8;
import p000.zo1;

/* JADX INFO: renamed from: androidx.recyclerview.widget.k */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0181k {

    /* JADX INFO: renamed from: a */
    public rg1 f2141a;

    /* JADX INFO: renamed from: b */
    public RecyclerView f2142b;

    /* JADX INFO: renamed from: c */
    public final qz6 f2143c;

    /* JADX INFO: renamed from: d */
    public final qz6 f2144d;

    /* JADX INFO: renamed from: e */
    public C0174d f2145e;

    /* JADX INFO: renamed from: f */
    public boolean f2146f;

    /* JADX INFO: renamed from: g */
    public boolean f2147g;

    /* JADX INFO: renamed from: h */
    public final boolean f2148h;

    /* JADX INFO: renamed from: i */
    public final boolean f2149i;

    /* JADX INFO: renamed from: j */
    public int f2150j;

    /* JADX INFO: renamed from: k */
    public boolean f2151k;

    /* JADX INFO: renamed from: l */
    public int f2152l;

    /* JADX INFO: renamed from: m */
    public int f2153m;

    /* JADX INFO: renamed from: n */
    public int f2154n;

    /* JADX INFO: renamed from: o */
    public int f2155o;

    public AbstractC0181k() {
        C0179i c0179i = new C0179i(this);
        C0180j c0180j = new C0180j(this);
        this.f2143c = new qz6(c0179i);
        this.f2144d = new qz6(c0180j);
        this.f2146f = false;
        this.f2147g = false;
        this.f2148h = true;
        this.f2149i = true;
    }

    /* JADX INFO: renamed from: A */
    public static int m1439A(View view) {
        Rect rect = ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b;
        return view.getMeasuredHeight() + rect.top + rect.bottom;
    }

    /* JADX INFO: renamed from: B */
    public static int m1440B(View view) {
        Rect rect = ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b;
        return view.getMeasuredWidth() + rect.left + rect.right;
    }

    /* JADX INFO: renamed from: H */
    public static int m1441H(View view) {
        return ((RecyclerView.LayoutParams) view.getLayoutParams()).f2069a.m1499d();
    }

    /* JADX INFO: renamed from: I */
    public static vs8 m1442I(Context context, AttributeSet attributeSet, int i, int i2) {
        vs8 vs8Var = new vs8();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, eo8.f12855a, i, i2);
        vs8Var.f44283a = typedArrayObtainStyledAttributes.getInt(0, 1);
        vs8Var.f44284b = typedArrayObtainStyledAttributes.getInt(10, 1);
        vs8Var.f44285c = typedArrayObtainStyledAttributes.getBoolean(9, false);
        vs8Var.f44286d = typedArrayObtainStyledAttributes.getBoolean(11, false);
        typedArrayObtainStyledAttributes.recycle();
        return vs8Var;
    }

    /* JADX INFO: renamed from: N */
    public static boolean m1443N(int i, int i2, int i3) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (i3 > 0 && i != i3) {
            return false;
        }
        if (mode == Integer.MIN_VALUE) {
            return size >= i;
        }
        if (mode != 0) {
            return mode == 1073741824 && size == i;
        }
        return true;
    }

    /* JADX INFO: renamed from: O */
    public static void m1444O(View view, int i, int i2, int i3, int i4) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        Rect rect = layoutParams.f2070b;
        view.layout(i + rect.left + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin, i2 + rect.top + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, (i3 - rect.right) - ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, (i4 - rect.bottom) - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin);
    }

    /* JADX INFO: renamed from: h */
    public static int m1445h(int i, int i2, int i3) {
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        if (mode != Integer.MIN_VALUE) {
            return mode != 1073741824 ? Math.max(i2, i3) : size;
        }
        return Math.min(size, Math.max(i2, i3));
    }

    /* JADX WARN: Code duplicated, block: B:10:0x001a  */
    /* JADX WARN: Code duplicated, block: B:14:0x0022  */
    /* JADX WARN: Code duplicated, block: B:5:0x0010  */
    /* JADX INFO: renamed from: x */
    public static int m1446x(boolean z, int i, int i2, int i3, int i4) {
        int iMax = Math.max(0, i - i3);
        if (z) {
            if (i4 >= 0) {
                i2 = 1073741824;
            } else if (i4 != -1 || (i2 != Integer.MIN_VALUE && (i2 == 0 || i2 != 1073741824))) {
                i2 = 0;
                i4 = 0;
            } else {
                i4 = iMax;
            }
        } else if (i4 >= 0) {
            i2 = 1073741824;
        } else if (i4 == -1) {
            i4 = iMax;
        } else if (i4 != -2) {
            i2 = 0;
            i4 = 0;
        } else if (i2 == Integer.MIN_VALUE || i2 == 1073741824) {
            i4 = iMax;
            i2 = Integer.MIN_VALUE;
        } else {
            i4 = iMax;
            i2 = 0;
        }
        return View.MeasureSpec.makeMeasureSpec(i4, i2);
    }

    /* JADX INFO: renamed from: A0 */
    public final boolean m1447A0(View view, int i, int i2, RecyclerView.LayoutParams layoutParams) {
        return (!view.isLayoutRequested() && this.f2148h && m1443N(view.getWidth(), i, ((ViewGroup.MarginLayoutParams) layoutParams).width) && m1443N(view.getHeight(), i2, ((ViewGroup.MarginLayoutParams) layoutParams).height)) ? false : true;
    }

    /* JADX INFO: renamed from: B0 */
    public boolean mo1247B0() {
        return false;
    }

    /* JADX INFO: renamed from: C */
    public final int m1448C() {
        RecyclerView recyclerView = this.f2142b;
        AbstractC0177g abstractC0177g = recyclerView != null ? recyclerView.f2009I : null;
        if (abstractC0177g != null) {
            return abstractC0177g.mo1422a();
        }
        return 0;
    }

    /* JADX INFO: renamed from: C0 */
    public final boolean m1449C0(View view, int i, int i2, RecyclerView.LayoutParams layoutParams) {
        return (this.f2148h && m1443N(view.getMeasuredWidth(), i, ((ViewGroup.MarginLayoutParams) layoutParams).width) && m1443N(view.getMeasuredHeight(), i2, ((ViewGroup.MarginLayoutParams) layoutParams).height)) ? false : true;
    }

    /* JADX INFO: renamed from: D */
    public final int m1450D() {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView != null) {
            return recyclerView.getPaddingBottom();
        }
        return 0;
    }

    /* JADX INFO: renamed from: D0 */
    public abstract void mo1248D0(RecyclerView recyclerView, int i);

    /* JADX INFO: renamed from: E */
    public final int m1451E() {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView != null) {
            return recyclerView.getPaddingLeft();
        }
        return 0;
    }

    /* JADX INFO: renamed from: E0 */
    public final void m1452E0(C0174d c0174d) {
        C0174d c0174d2 = this.f2145e;
        if (c0174d2 != null && c0174d != c0174d2 && c0174d2.m7096d()) {
            this.f2145e.m7101j();
        }
        this.f2145e = c0174d;
        c0174d.m7100i(this.f2142b, this);
    }

    /* JADX INFO: renamed from: F */
    public final int m1453F() {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView != null) {
            return recyclerView.getPaddingRight();
        }
        return 0;
    }

    /* JADX INFO: renamed from: F0 */
    public boolean mo1204F0() {
        return false;
    }

    /* JADX INFO: renamed from: G */
    public final int m1454G() {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView != null) {
            return recyclerView.getPaddingTop();
        }
        return 0;
    }

    /* JADX INFO: renamed from: J */
    public int mo1206J(C0182l c0182l, et8 et8Var) {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView == null || recyclerView.f2009I == null || !mo1277f()) {
            return 1;
        }
        return this.f2142b.f2009I.mo1422a();
    }

    /* JADX INFO: renamed from: K */
    public final void m1455K(View view, Rect rect) {
        Matrix matrix;
        Rect rect2 = ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b;
        rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
        if (this.f2142b != null && (matrix = view.getMatrix()) != null && !matrix.isIdentity()) {
            RectF rectF = this.f2142b.f2007H;
            rectF.set(rect);
            matrix.mapRect(rectF);
            rect.set((int) Math.floor(rectF.left), (int) Math.floor(rectF.top), (int) Math.ceil(rectF.right), (int) Math.ceil(rectF.bottom));
        }
        rect.offset(view.getLeft(), view.getTop());
    }

    /* JADX INFO: renamed from: L */
    public abstract boolean mo1253L();

    /* JADX INFO: renamed from: M */
    public boolean mo1255M() {
        return false;
    }

    /* JADX INFO: renamed from: P */
    public void mo1374P(int i) {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView != null) {
            int iM16513g = recyclerView.f1995B.m16513g();
            for (int i2 = 0; i2 < iM16513g; i2++) {
                recyclerView.f1995B.m16512f(i2).offsetLeftAndRight(i);
            }
        }
    }

    /* JADX INFO: renamed from: Q */
    public void mo1376Q(int i) {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView != null) {
            int iM16513g = recyclerView.f1995B.m16513g();
            for (int i2 = 0; i2 < iM16513g; i2++) {
                recyclerView.f1995B.m16512f(i2).offsetTopAndBottom(i);
            }
        }
    }

    /* JADX INFO: renamed from: T */
    public abstract void mo1263T(RecyclerView recyclerView);

    /* JADX INFO: renamed from: U */
    public abstract View mo1207U(View view, int i, C0182l c0182l, et8 et8Var);

    /* JADX INFO: renamed from: V */
    public void mo1265V(AccessibilityEvent accessibilityEvent) {
        RecyclerView recyclerView = this.f2142b;
        C0182l c0182l = recyclerView.f2065y;
        if (accessibilityEvent == null) {
            return;
        }
        boolean z = true;
        if (!recyclerView.canScrollVertically(1) && !this.f2142b.canScrollVertically(-1) && !this.f2142b.canScrollHorizontally(-1) && !this.f2142b.canScrollHorizontally(1)) {
            z = false;
        }
        accessibilityEvent.setScrollable(z);
        AbstractC0177g abstractC0177g = this.f2142b.f2009I;
        if (abstractC0177g != null) {
            accessibilityEvent.setItemCount(abstractC0177g.mo1422a());
        }
    }

    /* JADX INFO: renamed from: W */
    public void mo1209W(C0182l c0182l, et8 et8Var, C0681k7 c0681k7) {
        if (this.f2142b.canScrollVertically(-1) || this.f2142b.canScrollHorizontally(-1)) {
            c0681k7.m11844a(8192);
            c0681k7.m11856n(true);
            c0681k7.m11850h(67108864, true);
        }
        if (this.f2142b.canScrollVertically(1) || this.f2142b.canScrollHorizontally(1)) {
            c0681k7.m11844a(ItemType.MAP_LIST);
            c0681k7.m11856n(true);
            c0681k7.m11850h(67108864, true);
        }
        c0681k7.m11853k(C0609i7.m10579a(mo1206J(c0182l, et8Var), mo1246y(c0182l, et8Var), 0));
    }

    /* JADX INFO: renamed from: X */
    public final void m1457X(View view, C0681k7 c0681k7) {
        AbstractC0185o abstractC0185oM1292M = RecyclerView.m1292M(view);
        if (abstractC0185oM1292M == null || abstractC0185oM1292M.m1505j()) {
            return;
        }
        rg1 rg1Var = this.f2141a;
        if (((ArrayList) rg1Var.f36499e).contains(abstractC0185oM1292M.f2181e)) {
            return;
        }
        RecyclerView recyclerView = this.f2142b;
        mo1210Y(recyclerView.f2065y, recyclerView.f2000D0, view, c0681k7);
    }

    /* JADX INFO: renamed from: Y */
    public void mo1210Y(C0182l c0182l, et8 et8Var, View view, C0681k7 c0681k7) {
        c0681k7.m11854l(C0644j7.m11151a(mo1277f() ? m1441H(view) : 0, 1, mo1275e() ? m1441H(view) : 0, 1, false, false));
    }

    /* JADX INFO: renamed from: b */
    public final void m1458b(View view, int i, boolean z) {
        AbstractC0185o abstractC0185oM1292M = RecyclerView.m1292M(view);
        if (z || abstractC0185oM1292M.m1505j()) {
            uy9 uy9Var = (uy9) this.f2142b.f1997C.f35720i;
            ccb ccbVarM3156a = (ccb) uy9Var.get(abstractC0185oM1292M);
            if (ccbVarM3156a == null) {
                ccbVarM3156a = ccb.m3156a();
                uy9Var.put(abstractC0185oM1292M, ccbVarM3156a);
            }
            ccbVarM3156a.f5506a |= 1;
        } else {
            this.f2142b.f1997C.m16192u(abstractC0185oM1292M);
        }
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        if (abstractC0185oM1292M.m1513r() || abstractC0185oM1292M.m1506k()) {
            if (abstractC0185oM1292M.m1506k()) {
                abstractC0185oM1292M.f2175J.m1488m(abstractC0185oM1292M);
            } else {
                abstractC0185oM1292M.f2171F &= -33;
            }
            this.f2141a.m16509b(view, i, view.getLayoutParams(), false);
        } else {
            ViewParent parent = view.getParent();
            RecyclerView recyclerView = this.f2142b;
            rg1 rg1Var = this.f2141a;
            if (parent == recyclerView) {
                C0631iv c0631iv = (C0631iv) rg1Var.f36498d;
                int iIndexOfChild = ((rs8) rg1Var.f36497c).f37241e.indexOfChild(view);
                int iM10919c = (iIndexOfChild == -1 || c0631iv.m10922f(iIndexOfChild)) ? -1 : iIndexOfChild - c0631iv.m10919c(iIndexOfChild);
                if (i == -1) {
                    i = this.f2141a.m16513g();
                }
                if (iM10919c == -1) {
                    throw new IllegalStateException("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:" + this.f2142b.indexOfChild(view) + this.f2142b.m1301A());
                }
                if (iM10919c != i) {
                    AbstractC0181k abstractC0181k = this.f2142b.f2011J;
                    View viewM1469v = abstractC0181k.m1469v(iM10919c);
                    if (viewM1469v == null) {
                        throw new IllegalArgumentException("Cannot move a child from non-existing index:" + iM10919c + abstractC0181k.f2142b.toString());
                    }
                    abstractC0181k.m1469v(iM10919c);
                    abstractC0181k.f2141a.m16510c(iM10919c);
                    RecyclerView.LayoutParams layoutParams2 = (RecyclerView.LayoutParams) viewM1469v.getLayoutParams();
                    AbstractC0185o abstractC0185oM1292M2 = RecyclerView.m1292M(viewM1469v);
                    boolean zM1505j = abstractC0185oM1292M2.m1505j();
                    RecyclerView recyclerView2 = abstractC0181k.f2142b;
                    if (zM1505j) {
                        uy9 uy9Var2 = (uy9) recyclerView2.f1997C.f35720i;
                        ccb ccbVarM3156a2 = (ccb) uy9Var2.get(abstractC0185oM1292M2);
                        if (ccbVarM3156a2 == null) {
                            ccbVarM3156a2 = ccb.m3156a();
                            uy9Var2.put(abstractC0185oM1292M2, ccbVarM3156a2);
                        }
                        ccbVarM3156a2.f5506a = 1 | ccbVarM3156a2.f5506a;
                    } else {
                        recyclerView2.f1997C.m16192u(abstractC0185oM1292M2);
                    }
                    abstractC0181k.f2141a.m16509b(viewM1469v, i, layoutParams2, abstractC0185oM1292M2.m1505j());
                }
            } else {
                rg1Var.m16508a(view, i, false);
                layoutParams.f2071c = true;
                C0174d c0174d = this.f2145e;
                if (c0174d != null && c0174d.m7096d()) {
                    this.f2145e.m7098f(view);
                }
            }
        }
        if (layoutParams.f2072d) {
            abstractC0185oM1292M.f2181e.invalidate();
            layoutParams.f2072d = false;
        }
    }

    /* JADX INFO: renamed from: c */
    public void mo1272c(String str) {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView != null) {
            recyclerView.m1338k(str);
        }
    }

    /* JADX INFO: renamed from: d */
    public final void m1459d(View view, Rect rect) {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView == null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect.set(recyclerView.m1312N(view));
        }
    }

    /* JADX INFO: renamed from: e */
    public abstract boolean mo1275e();

    /* JADX INFO: renamed from: e0 */
    public abstract void mo1218e0(C0182l c0182l, et8 et8Var);

    /* JADX INFO: renamed from: f */
    public abstract boolean mo1277f();

    /* JADX INFO: renamed from: f0 */
    public abstract void mo1219f0(et8 et8Var);

    /* JADX INFO: renamed from: g */
    public boolean mo1220g(RecyclerView.LayoutParams layoutParams) {
        return layoutParams != null;
    }

    /* JADX INFO: renamed from: h0 */
    public Parcelable mo1281h0() {
        return null;
    }

    /* JADX INFO: renamed from: j0 */
    public boolean mo1222j0(int i, Bundle bundle) {
        RecyclerView recyclerView = this.f2142b;
        return mo1460k0(recyclerView.f2065y, recyclerView.f2000D0, i, bundle);
    }

    /* JADX INFO: renamed from: k */
    public abstract int mo1286k(et8 et8Var);

    /* JADX WARN: Code duplicated, block: B:21:0x0062 A[PHI: r8
      0x0062: PHI (r8v8 int) = (r8v5 int), (r8v18 int) binds: [B:27:0x007e, B:19:0x0054] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX INFO: renamed from: k0 */
    public boolean mo1460k0(C0182l c0182l, et8 et8Var, int i, Bundle bundle) {
        int iM1454G;
        int iM1451E;
        float f;
        if (this.f2142b != null) {
            int iHeight = this.f2155o;
            int iWidth = this.f2154n;
            Rect rect = new Rect();
            if (this.f2142b.getMatrix().isIdentity() && this.f2142b.getGlobalVisibleRect(rect)) {
                iHeight = rect.height();
                iWidth = rect.width();
            }
            if (i == 4096) {
                iM1454G = this.f2142b.canScrollVertically(1) ? (iHeight - m1454G()) - m1450D() : 0;
                if (this.f2142b.canScrollHorizontally(1)) {
                    iM1451E = (iWidth - m1451E()) - m1453F();
                } else {
                    iM1451E = 0;
                }
            } else if (i != 8192) {
                iM1454G = 0;
                iM1451E = 0;
            } else {
                iM1454G = this.f2142b.canScrollVertically(-1) ? -((iHeight - m1454G()) - m1450D()) : 0;
                if (this.f2142b.canScrollHorizontally(-1)) {
                    iM1451E = -((iWidth - m1451E()) - m1453F());
                } else {
                    iM1451E = 0;
                }
            }
            if (iM1454G != 0 || iM1451E != 0) {
                if (bundle != null) {
                    f = bundle.getFloat("androidx.core.view.accessibility.action.ARGUMENT_SCROLL_AMOUNT_FLOAT", 1.0f);
                    if (f < 0.0f) {
                        int[] iArr = RecyclerView.f1986X0;
                        return false;
                    }
                } else {
                    f = 1.0f;
                }
                if (Float.compare(f, Float.POSITIVE_INFINITY) != 0) {
                    if (Float.compare(1.0f, f) != 0 && Float.compare(0.0f, f) != 0) {
                        iM1451E = (int) (iM1451E * f);
                        iM1454G = (int) (iM1454G * f);
                    }
                    this.f2142b.m1349q0(iM1451E, iM1454G, true);
                    return true;
                }
                RecyclerView recyclerView = this.f2142b;
                AbstractC0177g abstractC0177g = recyclerView.f2009I;
                if (abstractC0177g != null) {
                    if (i == 4096) {
                        recyclerView.m1351r0(abstractC0177g.mo1422a() - 1);
                        return true;
                    }
                    if (i != 8192) {
                        return true;
                    }
                    recyclerView.m1351r0(0);
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: l */
    public abstract int mo1223l(et8 et8Var);

    /* JADX INFO: renamed from: l0 */
    public final void m1461l0() {
        for (int iM1471w = m1471w() - 1; iM1471w >= 0; iM1471w--) {
            this.f2141a.m16520o(iM1471w);
        }
    }

    /* JADX INFO: renamed from: m */
    public abstract int mo1225m(et8 et8Var);

    /* JADX INFO: renamed from: m0 */
    public final void m1462m0(C0182l c0182l) {
        for (int iM1471w = m1471w() - 1; iM1471w >= 0; iM1471w--) {
            if (!RecyclerView.m1292M(m1469v(iM1471w)).m1512q()) {
                m1465p0(iM1471w, c0182l);
            }
        }
    }

    /* JADX INFO: renamed from: n */
    public abstract int mo1288n(et8 et8Var);

    /* JADX INFO: renamed from: n0 */
    public final void m1463n0(C0182l c0182l) {
        ArrayList arrayList;
        int size = c0182l.f2156a.size();
        int i = size - 1;
        while (true) {
            arrayList = c0182l.f2156a;
            if (i < 0) {
                break;
            }
            View view = ((AbstractC0185o) arrayList.get(i)).f2181e;
            AbstractC0185o abstractC0185oM1292M = RecyclerView.m1292M(view);
            if (!abstractC0185oM1292M.m1512q()) {
                abstractC0185oM1292M.m1511p(false);
                if (abstractC0185oM1292M.m1507l()) {
                    this.f2142b.removeDetachedView(view, false);
                }
                cz9 cz9Var = this.f2142b.f2052l0;
                if (cz9Var != null) {
                    cz9Var.mo6691m(abstractC0185oM1292M);
                }
                abstractC0185oM1292M.m1511p(true);
                AbstractC0185o abstractC0185oM1292M2 = RecyclerView.m1292M(view);
                abstractC0185oM1292M2.f2175J = null;
                abstractC0185oM1292M2.f2176K = false;
                abstractC0185oM1292M2.f2171F &= -33;
                c0182l.m1485j(abstractC0185oM1292M2);
            }
            i--;
        }
        arrayList.clear();
        ArrayList arrayList2 = c0182l.f2157b;
        if (arrayList2 != null) {
            arrayList2.clear();
        }
        if (size > 0) {
            this.f2142b.invalidate();
        }
    }

    /* JADX INFO: renamed from: o */
    public abstract int mo1228o(et8 et8Var);

    /* JADX INFO: renamed from: o0 */
    public final void m1464o0(View view, C0182l c0182l) {
        rg1 rg1Var = this.f2141a;
        rs8 rs8Var = (rs8) rg1Var.f36497c;
        int i = rg1Var.f36496b;
        if (i == 1) {
            C1521v3.m18909p("Cannot call removeView(At) within removeView(At)");
            return;
        }
        if (i == 2) {
            C1521v3.m18909p("Cannot call removeView(At) within removeViewIfHidden");
            return;
        }
        try {
            rg1Var.f36496b = 1;
            rg1Var.f36500f = view;
            int iIndexOfChild = rs8Var.f37241e.indexOfChild(view);
            if (iIndexOfChild >= 0) {
                if (((C0631iv) rg1Var.f36498d).m10925i(iIndexOfChild)) {
                    rg1Var.m16523r(view);
                }
                rs8Var.m16722i(iIndexOfChild);
            }
            rg1Var.f36496b = 0;
            rg1Var.f36500f = null;
            c0182l.m1484i(view);
        } catch (Throwable th) {
            rg1Var.f36496b = 0;
            rg1Var.f36500f = null;
            throw th;
        }
    }

    /* JADX INFO: renamed from: p */
    public abstract int mo1230p(et8 et8Var);

    /* JADX INFO: renamed from: p0 */
    public final void m1465p0(int i, C0182l c0182l) {
        View viewM1469v = m1469v(i);
        if (m1469v(i) != null) {
            this.f2141a.m16520o(i);
        }
        c0182l.m1484i(viewM1469v);
    }

    /* JADX INFO: renamed from: q */
    public final void m1466q(C0182l c0182l) {
        for (int iM1471w = m1471w() - 1; iM1471w >= 0; iM1471w--) {
            View viewM1469v = m1469v(iM1471w);
            AbstractC0185o abstractC0185oM1292M = RecyclerView.m1292M(viewM1469v);
            if (!abstractC0185oM1292M.m1512q()) {
                if (!abstractC0185oM1292M.m1503h() || abstractC0185oM1292M.m1505j() || this.f2142b.f2009I.f2137b) {
                    m1469v(iM1471w);
                    this.f2141a.m16510c(iM1471w);
                    c0182l.m1486k(viewM1469v);
                    this.f2142b.f1997C.m16192u(abstractC0185oM1292M);
                } else {
                    if (m1469v(iM1471w) != null) {
                        this.f2141a.m16520o(iM1471w);
                    }
                    c0182l.m1485j(abstractC0185oM1292M);
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:28:0x00b0  */
    /* JADX WARN: Code duplicated, block: B:33:0x00b8  */
    /* JADX WARN: Code duplicated, block: B:35:0x00bc  */
    /* JADX INFO: renamed from: q0 */
    public boolean mo1467q0(RecyclerView recyclerView, View view, Rect rect, boolean z, boolean z2) {
        int iM1451E = m1451E();
        int iM1454G = m1454G();
        int iM1453F = this.f2154n - m1453F();
        int iM1450D = this.f2155o - m1450D();
        int left = (view.getLeft() + rect.left) - view.getScrollX();
        int top = (view.getTop() + rect.top) - view.getScrollY();
        int iWidth = rect.width() + left;
        int iHeight = rect.height() + top;
        int i = left - iM1451E;
        int iMin = Math.min(0, i);
        int i2 = top - iM1454G;
        int iMin2 = Math.min(0, i2);
        int i3 = iWidth - iM1453F;
        int iMax = Math.max(0, i3);
        int iMax2 = Math.max(0, iHeight - iM1450D);
        if (this.f2142b.getLayoutDirection() != 1) {
            if (iMin == 0) {
                iMin = Math.min(i, iMax);
            }
            iMax = iMin;
        } else if (iMax == 0) {
            iMax = Math.max(iMin, i3);
        }
        if (iMin2 == 0) {
            iMin2 = Math.min(i2, iMax2);
        }
        int[] iArr = {iMax, iMin2};
        int i4 = iArr[0];
        int i5 = iArr[1];
        if (z2) {
            View focusedChild = recyclerView.getFocusedChild();
            if (focusedChild != null) {
                int iM1451E2 = m1451E();
                int iM1454G2 = m1454G();
                int iM1453F2 = this.f2154n - m1453F();
                int iM1450D2 = this.f2155o - m1450D();
                Rect rect2 = this.f2142b.f2003F;
                mo1474z(focusedChild, rect2);
                if (rect2.left - i4 < iM1453F2 && rect2.right - i4 > iM1451E2 && rect2.top - i5 < iM1450D2 && rect2.bottom - i5 > iM1454G2) {
                    if (i4 == 0) {
                    }
                    if (z) {
                        recyclerView.scrollBy(i4, i5);
                        return true;
                    }
                    recyclerView.m1349q0(i4, i5, false);
                    return true;
                }
            }
        } else if (i4 == 0 || i5 != 0) {
            if (z) {
                recyclerView.scrollBy(i4, i5);
                return true;
            }
            recyclerView.m1349q0(i4, i5, false);
            return true;
        }
        return false;
    }

    /* JADX INFO: renamed from: r */
    public View mo1289r(int i) {
        int iM1471w = m1471w();
        for (int i2 = 0; i2 < iM1471w; i2++) {
            View viewM1469v = m1469v(i2);
            AbstractC0185o abstractC0185oM1292M = RecyclerView.m1292M(viewM1469v);
            if (abstractC0185oM1292M != null && abstractC0185oM1292M.m1499d() == i && !abstractC0185oM1292M.m1512q() && (this.f2142b.f2000D0.f13104g || !abstractC0185oM1292M.m1505j())) {
                return viewM1469v;
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: r0 */
    public final void m1468r0() {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView != null) {
            recyclerView.requestLayout();
        }
    }

    /* JADX INFO: renamed from: s */
    public abstract RecyclerView.LayoutParams mo1234s();

    /* JADX INFO: renamed from: s0 */
    public abstract int mo1235s0(int i, et8 et8Var, C0182l c0182l);

    /* JADX INFO: renamed from: t */
    public RecyclerView.LayoutParams mo1237t(Context context, AttributeSet attributeSet) {
        return new RecyclerView.LayoutParams(context, attributeSet);
    }

    /* JADX INFO: renamed from: t0 */
    public abstract void mo1290t0(int i);

    /* JADX INFO: renamed from: u */
    public RecyclerView.LayoutParams mo1239u(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof RecyclerView.LayoutParams) {
            return new RecyclerView.LayoutParams((RecyclerView.LayoutParams) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new RecyclerView.LayoutParams((ViewGroup.MarginLayoutParams) layoutParams) : new RecyclerView.LayoutParams(layoutParams);
    }

    /* JADX INFO: renamed from: u0 */
    public abstract int mo1240u0(int i, et8 et8Var, C0182l c0182l);

    /* JADX INFO: renamed from: v */
    public final View m1469v(int i) {
        rg1 rg1Var = this.f2141a;
        if (rg1Var != null) {
            return rg1Var.m16512f(i);
        }
        return null;
    }

    /* JADX INFO: renamed from: v0 */
    public final void m1470v0(RecyclerView recyclerView) {
        m1472w0(View.MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
    }

    /* JADX INFO: renamed from: w */
    public final int m1471w() {
        rg1 rg1Var = this.f2141a;
        if (rg1Var != null) {
            return rg1Var.m16513g();
        }
        return 0;
    }

    /* JADX INFO: renamed from: w0 */
    public final void m1472w0(int i, int i2) {
        this.f2154n = View.MeasureSpec.getSize(i);
        int mode = View.MeasureSpec.getMode(i);
        this.f2152l = mode;
        if (mode == 0 && !RecyclerView.f1988Z0) {
            this.f2154n = 0;
        }
        this.f2155o = View.MeasureSpec.getSize(i2);
        int mode2 = View.MeasureSpec.getMode(i2);
        this.f2153m = mode2;
        if (mode2 != 0 || RecyclerView.f1988Z0) {
            return;
        }
        this.f2155o = 0;
    }

    /* JADX INFO: renamed from: x0 */
    public void mo1244x0(Rect rect, int i, int i2) {
        int iM1453F = m1453F() + m1451E() + rect.width();
        int iM1450D = m1450D() + m1454G() + rect.height();
        RecyclerView recyclerView = this.f2142b;
        WeakHashMap weakHashMap = obb.f31348a;
        this.f2142b.setMeasuredDimension(m1445h(i, iM1453F, recyclerView.getMinimumWidth()), m1445h(i2, iM1450D, this.f2142b.getMinimumHeight()));
    }

    /* JADX INFO: renamed from: y */
    public int mo1246y(C0182l c0182l, et8 et8Var) {
        RecyclerView recyclerView = this.f2142b;
        if (recyclerView == null || recyclerView.f2009I == null || !mo1275e()) {
            return 1;
        }
        return this.f2142b.f2009I.mo1422a();
    }

    /* JADX INFO: renamed from: y0 */
    public final void m1473y0(int i, int i2) {
        int iM1471w = m1471w();
        if (iM1471w == 0) {
            this.f2142b.m1348q(i, i2);
            return;
        }
        int i3 = RtlSpacingHelper.UNDEFINED;
        int i4 = Integer.MAX_VALUE;
        int i5 = Integer.MIN_VALUE;
        int i6 = Integer.MAX_VALUE;
        for (int i7 = 0; i7 < iM1471w; i7++) {
            View viewM1469v = m1469v(i7);
            Rect rect = this.f2142b.f2003F;
            mo1474z(viewM1469v, rect);
            int i8 = rect.left;
            if (i8 < i6) {
                i6 = i8;
            }
            int i9 = rect.right;
            if (i9 > i3) {
                i3 = i9;
            }
            int i10 = rect.top;
            if (i10 < i4) {
                i4 = i10;
            }
            int i11 = rect.bottom;
            if (i11 > i5) {
                i5 = i11;
            }
        }
        this.f2142b.f2003F.set(i6, i4, i3, i5);
        mo1244x0(this.f2142b.f2003F, i, i2);
    }

    /* JADX INFO: renamed from: z */
    public void mo1474z(View view, Rect rect) {
        int[] iArr = RecyclerView.f1986X0;
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        Rect rect2 = layoutParams.f2070b;
        rect.set((view.getLeft() - rect2.left) - ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin, (view.getTop() - rect2.top) - ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, view.getRight() + rect2.right + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, view.getBottom() + rect2.bottom + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin);
    }

    /* JADX INFO: renamed from: z0 */
    public final void m1475z0(RecyclerView recyclerView) {
        if (recyclerView == null) {
            this.f2142b = null;
            this.f2141a = null;
            this.f2154n = 0;
            this.f2155o = 0;
        } else {
            this.f2142b = recyclerView;
            this.f2141a = recyclerView.f1995B;
            this.f2154n = recyclerView.getWidth();
            this.f2155o = recyclerView.getHeight();
        }
        this.f2152l = 1073741824;
        this.f2153m = 1073741824;
    }

    /* JADX INFO: renamed from: a0 */
    public void mo1212a0() {
    }

    /* JADX INFO: renamed from: R */
    public void mo1378R(AbstractC0177g abstractC0177g) {
    }

    /* JADX INFO: renamed from: S */
    public void mo1456S(RecyclerView recyclerView) {
    }

    /* JADX INFO: renamed from: g0 */
    public void mo1279g0(Parcelable parcelable) {
    }

    /* JADX INFO: renamed from: i0 */
    public void mo1395i0(int i) {
    }

    /* JADX INFO: renamed from: Z */
    public void mo1211Z(int i, int i2) {
    }

    /* JADX INFO: renamed from: b0 */
    public void mo1214b0(int i, int i2) {
    }

    /* JADX INFO: renamed from: c0 */
    public void mo1216c0(int i, int i2) {
    }

    /* JADX INFO: renamed from: d0 */
    public void mo1217d0(int i, int i2) {
    }

    /* JADX INFO: renamed from: j */
    public void mo1284j(int i, zo1 zo1Var) {
    }

    /* JADX INFO: renamed from: i */
    public void mo1282i(int i, int i2, et8 et8Var, zo1 zo1Var) {
    }
}
