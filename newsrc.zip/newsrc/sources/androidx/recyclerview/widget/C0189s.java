package androidx.recyclerview.widget;

import android.view.View;
import androidx.appcompat.widget.RtlSpacingHelper;
import java.util.ArrayList;
import p000.z82;

/* JADX INFO: renamed from: androidx.recyclerview.widget.s */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public final class C0189s {

    /* JADX INFO: renamed from: a */
    public final ArrayList f2187a = new ArrayList();

    /* JADX INFO: renamed from: b */
    public int f2188b = RtlSpacingHelper.UNDEFINED;

    /* JADX INFO: renamed from: c */
    public int f2189c = RtlSpacingHelper.UNDEFINED;

    /* JADX INFO: renamed from: d */
    public int f2190d = 0;

    /* JADX INFO: renamed from: e */
    public final int f2191e;

    /* JADX INFO: renamed from: f */
    public final /* synthetic */ StaggeredGridLayoutManager f2192f;

    public C0189s(StaggeredGridLayoutManager staggeredGridLayoutManager, int i) {
        this.f2192f = staggeredGridLayoutManager;
        this.f2191e = i;
    }

    /* JADX INFO: renamed from: a */
    public final void m1518a() {
        View view = (View) z82.m21083p(this.f2187a, 1);
        StaggeredGridLayoutManager.LayoutParams layoutParams = (StaggeredGridLayoutManager.LayoutParams) view.getLayoutParams();
        this.f2189c = this.f2192f.f2087r.mo1408b(view);
        layoutParams.getClass();
    }

    /* JADX INFO: renamed from: b */
    public final void m1519b() {
        this.f2187a.clear();
        this.f2188b = RtlSpacingHelper.UNDEFINED;
        this.f2189c = RtlSpacingHelper.UNDEFINED;
        this.f2190d = 0;
    }

    /* JADX INFO: renamed from: c */
    public final int m1520c() {
        boolean z = this.f2192f.f2092w;
        ArrayList arrayList = this.f2187a;
        return z ? m1522e(arrayList.size() - 1, -1) : m1522e(0, arrayList.size());
    }

    /* JADX INFO: renamed from: d */
    public final int m1521d() {
        boolean z = this.f2192f.f2092w;
        ArrayList arrayList = this.f2187a;
        return z ? m1522e(0, arrayList.size()) : m1522e(arrayList.size() - 1, -1);
    }

    /* JADX INFO: renamed from: e */
    public final int m1522e(int i, int i2) {
        StaggeredGridLayoutManager staggeredGridLayoutManager = this.f2192f;
        int iMo1417k = staggeredGridLayoutManager.f2087r.mo1417k();
        int iMo1413g = staggeredGridLayoutManager.f2087r.mo1413g();
        int i3 = i2 > i ? 1 : -1;
        while (i != i2) {
            View view = (View) this.f2187a.get(i);
            int iMo1411e = staggeredGridLayoutManager.f2087r.mo1411e(view);
            int iMo1408b = staggeredGridLayoutManager.f2087r.mo1408b(view);
            boolean z = iMo1411e <= iMo1413g;
            boolean z2 = iMo1408b >= iMo1417k;
            if (z && z2 && (iMo1411e < iMo1417k || iMo1408b > iMo1413g)) {
                return AbstractC0181k.m1441H(view);
            }
            i += i3;
        }
        return -1;
    }

    /* JADX INFO: renamed from: f */
    public final int m1523f(int i) {
        int i2 = this.f2189c;
        if (i2 != Integer.MIN_VALUE) {
            return i2;
        }
        if (this.f2187a.size() == 0) {
            return i;
        }
        m1518a();
        return this.f2189c;
    }

    /* JADX INFO: renamed from: g */
    public final View m1524g(int i, int i2) {
        StaggeredGridLayoutManager staggeredGridLayoutManager = this.f2192f;
        View view = null;
        ArrayList arrayList = this.f2187a;
        if (i2 != -1) {
            int size = arrayList.size() - 1;
            while (size >= 0) {
                View view2 = (View) arrayList.get(size);
                if ((staggeredGridLayoutManager.f2092w && AbstractC0181k.m1441H(view2) >= i) || ((!staggeredGridLayoutManager.f2092w && AbstractC0181k.m1441H(view2) <= i) || !view2.hasFocusable())) {
                    break;
                }
                size--;
                view = view2;
            }
            return view;
        }
        int size2 = arrayList.size();
        int i3 = 0;
        while (i3 < size2) {
            View view3 = (View) arrayList.get(i3);
            if ((staggeredGridLayoutManager.f2092w && AbstractC0181k.m1441H(view3) <= i) || ((!staggeredGridLayoutManager.f2092w && AbstractC0181k.m1441H(view3) >= i) || !view3.hasFocusable())) {
                break;
            }
            i3++;
            view = view3;
        }
        return view;
    }

    /* JADX INFO: renamed from: h */
    public final int m1525h(int i) {
        int i2 = this.f2188b;
        if (i2 != Integer.MIN_VALUE) {
            return i2;
        }
        ArrayList arrayList = this.f2187a;
        if (arrayList.size() == 0) {
            return i;
        }
        View view = (View) arrayList.get(0);
        StaggeredGridLayoutManager.LayoutParams layoutParams = (StaggeredGridLayoutManager.LayoutParams) view.getLayoutParams();
        this.f2188b = this.f2192f.f2087r.mo1411e(view);
        layoutParams.getClass();
        return this.f2188b;
    }
}
