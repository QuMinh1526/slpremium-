package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import p000.nl7;

/* JADX INFO: renamed from: androidx.recyclerview.widget.f */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public final class C0176f extends nl7 {
    @Override // p000.nl7
    /* JADX INFO: renamed from: b */
    public final int mo1408b(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        this.f30238a.getClass();
        return view.getBottom() + ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b.bottom + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: c */
    public final int mo1409c(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        this.f30238a.getClass();
        return AbstractC0181k.m1439A(view) + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: d */
    public final int mo1410d(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        this.f30238a.getClass();
        return AbstractC0181k.m1440B(view) + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: e */
    public final int mo1411e(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        this.f30238a.getClass();
        return (view.getTop() - ((RecyclerView.LayoutParams) view.getLayoutParams()).f2070b.top) - ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: f */
    public final int mo1412f() {
        return this.f30238a.f2155o;
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: g */
    public final int mo1413g() {
        AbstractC0181k abstractC0181k = this.f30238a;
        return abstractC0181k.f2155o - abstractC0181k.m1450D();
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: h */
    public final int mo1414h() {
        return this.f30238a.m1450D();
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: i */
    public final int mo1415i() {
        return this.f30238a.f2153m;
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: j */
    public final int mo1416j() {
        return this.f30238a.f2152l;
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: k */
    public final int mo1417k() {
        return this.f30238a.m1454G();
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: l */
    public final int mo1418l() {
        AbstractC0181k abstractC0181k = this.f30238a;
        return (abstractC0181k.f2155o - abstractC0181k.m1454G()) - abstractC0181k.m1450D();
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: m */
    public final int mo1419m(View view) {
        AbstractC0181k abstractC0181k = this.f30238a;
        Rect rect = this.f30240c;
        abstractC0181k.m1455K(view, rect);
        return rect.bottom;
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: n */
    public final int mo1420n(View view) {
        AbstractC0181k abstractC0181k = this.f30238a;
        Rect rect = this.f30240c;
        abstractC0181k.m1455K(view, rect);
        return rect.top;
    }

    @Override // p000.nl7
    /* JADX INFO: renamed from: o */
    public final void mo1421o(int i) {
        this.f30238a.mo1376Q(i);
    }
}
