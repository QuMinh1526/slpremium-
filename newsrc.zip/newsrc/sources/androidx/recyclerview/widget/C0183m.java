package androidx.recyclerview.widget;

import java.util.ArrayList;
import java.util.WeakHashMap;
import p000.C0498fm;
import p000.obb;
import p000.qs8;
import p000.ts8;

/* JADX INFO: renamed from: androidx.recyclerview.widget.m */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public final class C0183m extends ts8 {

    /* JADX INFO: renamed from: a */
    public final /* synthetic */ RecyclerView f2164a;

    public C0183m(RecyclerView recyclerView) {
        this.f2164a = recyclerView;
    }

    @Override // p000.ts8
    /* JADX INFO: renamed from: a */
    public final void mo1490a() {
        RecyclerView recyclerView = this.f2164a;
        recyclerView.m1338k(null);
        recyclerView.f2000D0.f13103f = true;
        recyclerView.m1325a0(true);
        if (recyclerView.f1993A.m8169h()) {
            return;
        }
        recyclerView.requestLayout();
    }

    @Override // p000.ts8
    /* JADX INFO: renamed from: b */
    public final void mo1491b(int i, Object obj, int i2) {
        RecyclerView recyclerView = this.f2164a;
        recyclerView.m1338k(null);
        C0498fm c0498fm = recyclerView.f1993A;
        ArrayList arrayList = (ArrayList) c0498fm.f14448c;
        if (i2 < 1) {
            return;
        }
        arrayList.add(c0498fm.m8170i(4, i, i2, obj));
        c0498fm.f14446a |= 4;
        if (arrayList.size() == 1) {
            m1495f();
        }
    }

    @Override // p000.ts8
    /* JADX INFO: renamed from: c */
    public final void mo1492c(int i, int i2) {
        RecyclerView recyclerView = this.f2164a;
        recyclerView.m1338k(null);
        C0498fm c0498fm = recyclerView.f1993A;
        ArrayList arrayList = (ArrayList) c0498fm.f14448c;
        if (i2 < 1) {
            return;
        }
        arrayList.add(c0498fm.m8170i(1, i, i2, null));
        c0498fm.f14446a |= 1;
        if (arrayList.size() == 1) {
            m1495f();
        }
    }

    @Override // p000.ts8
    /* JADX INFO: renamed from: d */
    public final void mo1493d(int i, int i2) {
        RecyclerView recyclerView = this.f2164a;
        recyclerView.m1338k(null);
        C0498fm c0498fm = recyclerView.f1993A;
        ArrayList arrayList = (ArrayList) c0498fm.f14448c;
        if (i == i2) {
            return;
        }
        arrayList.add(c0498fm.m8170i(8, i, i2, null));
        c0498fm.f14446a |= 8;
        if (arrayList.size() == 1) {
            m1495f();
        }
    }

    @Override // p000.ts8
    /* JADX INFO: renamed from: e */
    public final void mo1494e(int i, int i2) {
        RecyclerView recyclerView = this.f2164a;
        recyclerView.m1338k(null);
        C0498fm c0498fm = recyclerView.f1993A;
        ArrayList arrayList = (ArrayList) c0498fm.f14448c;
        if (i2 < 1) {
            return;
        }
        arrayList.add(c0498fm.m8170i(2, i, i2, null));
        c0498fm.f14446a |= 2;
        if (arrayList.size() == 1) {
            m1495f();
        }
    }

    /* JADX INFO: renamed from: f */
    public final void m1495f() {
        RecyclerView recyclerView = this.f2164a;
        if (!recyclerView.f2023P || !recyclerView.f2021O) {
            recyclerView.f2037W = true;
            recyclerView.requestLayout();
        } else {
            qs8 qs8Var = recyclerView.f2001E;
            WeakHashMap weakHashMap = obb.f31348a;
            recyclerView.postOnAnimation(qs8Var);
        }
    }
}
