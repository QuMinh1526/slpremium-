package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.annotation.RestrictTo;
import androidx.appcompat.widget.RtlSpacingHelper;
import java.util.ArrayList;
import java.util.List;
import org.p003jf.dexlib2.dexbacked.raw.ItemType;
import p000.C0446e7;
import p000.C0681k7;
import p000.C1521v3;
import p000.ab6;
import p000.ct8;
import p000.et8;
import p000.fy8;
import p000.nl7;
import p000.vs8;
import p000.z82;
import p000.zo1;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public class LinearLayoutManager extends AbstractC0181k implements ct8 {

    /* JADX INFO: renamed from: A */
    public final C0171a f1968A;

    /* JADX INFO: renamed from: B */
    public final ab6 f1969B;

    /* JADX INFO: renamed from: C */
    public final int f1970C;

    /* JADX INFO: renamed from: D */
    public final int[] f1971D;

    /* JADX INFO: renamed from: p */
    public int f1972p;

    /* JADX INFO: renamed from: q */
    public C0172b f1973q;

    /* JADX INFO: renamed from: r */
    public nl7 f1974r;

    /* JADX INFO: renamed from: s */
    public boolean f1975s;

    /* JADX INFO: renamed from: t */
    public boolean f1976t;

    /* JADX INFO: renamed from: u */
    public boolean f1977u;

    /* JADX INFO: renamed from: v */
    public boolean f1978v;

    /* JADX INFO: renamed from: w */
    public boolean f1979w;

    /* JADX INFO: renamed from: x */
    public int f1980x;

    /* JADX INFO: renamed from: y */
    public int f1981y;

    /* JADX INFO: renamed from: z */
    public SavedState f1982z;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    @SuppressLint({"BanParcelableUsage"})
    @RestrictTo({RestrictTo.Scope.LIBRARY})
    public static class SavedState implements Parcelable {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0173c();

        /* JADX INFO: renamed from: e */
        public int f1983e;

        /* JADX INFO: renamed from: i */
        public int f1984i;

        /* JADX INFO: renamed from: y */
        public boolean f1985y;

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f1983e);
            parcel.writeInt(this.f1984i);
            parcel.writeInt(this.f1985y ? 1 : 0);
        }
    }

    @SuppressLint({"UnknownNullness"})
    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        this.f1972p = 1;
        this.f1976t = false;
        this.f1977u = false;
        this.f1978v = false;
        this.f1979w = true;
        this.f1980x = -1;
        this.f1981y = RtlSpacingHelper.UNDEFINED;
        this.f1982z = null;
        this.f1968A = new C0171a();
        this.f1969B = new ab6();
        this.f1970C = 2;
        this.f1971D = new int[2];
        vs8 vs8VarM1442I = AbstractC0181k.m1442I(context, attributeSet, i, i2);
        m1280g1(vs8VarM1442I.f44283a);
        boolean z = vs8VarM1442I.f44285c;
        mo1272c(null);
        if (z != this.f1976t) {
            this.f1976t = z;
            m1468r0();
        }
        mo1221h1(vs8VarM1442I.f44286d);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: B0 */
    public final boolean mo1247B0() {
        if (this.f2153m != 1073741824 && this.f2152l != 1073741824) {
            int iM1471w = m1471w();
            for (int i = 0; i < iM1471w; i++) {
                ViewGroup.LayoutParams layoutParams = m1469v(i).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: D0 */
    public void mo1248D0(RecyclerView recyclerView, int i) {
        C0174d c0174d = new C0174d(recyclerView.getContext());
        c0174d.m7099h(i);
        m1452E0(c0174d);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: F0 */
    public boolean mo1204F0() {
        return this.f1982z == null && this.f1975s == this.f1978v;
    }

    /* JADX INFO: renamed from: G0 */
    public void mo1249G0(et8 et8Var, int[] iArr) {
        int i;
        int iMo1418l = et8Var.f13098a != -1 ? this.f1974r.mo1418l() : 0;
        if (this.f1973q.f2121f == -1) {
            i = 0;
        } else {
            i = iMo1418l;
            iMo1418l = 0;
        }
        iArr[0] = iMo1418l;
        iArr[1] = i;
    }

    /* JADX INFO: renamed from: H0 */
    public void mo1205H0(et8 et8Var, C0172b c0172b, zo1 zo1Var) {
        int i = c0172b.f2119d;
        if (i < 0 || i >= et8Var.m7762b()) {
            return;
        }
        zo1Var.m21325a(i, Math.max(0, c0172b.f2122g));
    }

    /* JADX INFO: renamed from: I0 */
    public final int m1250I0(et8 et8Var) {
        if (m1471w() == 0) {
            return 0;
        }
        m1256M0();
        return fy8.m8534U(et8Var, this.f1974r, m1259P0(!this.f1979w), m1258O0(!this.f1979w), this, this.f1979w);
    }

    /* JADX INFO: renamed from: J0 */
    public final int m1251J0(et8 et8Var) {
        if (m1471w() == 0) {
            return 0;
        }
        m1256M0();
        return fy8.m8535V(et8Var, this.f1974r, m1259P0(!this.f1979w), m1258O0(!this.f1979w), this, this.f1979w, this.f1977u);
    }

    /* JADX INFO: renamed from: K0 */
    public final int m1252K0(et8 et8Var) {
        if (m1471w() == 0) {
            return 0;
        }
        m1256M0();
        return fy8.m8536W(et8Var, this.f1974r, m1259P0(!this.f1979w), m1258O0(!this.f1979w), this, this.f1979w);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: L */
    public final boolean mo1253L() {
        return true;
    }

    /* JADX INFO: renamed from: L0 */
    public final int m1254L0(int i) {
        if (i == 1) {
            return (this.f1972p != 1 && mo1270Z0()) ? 1 : -1;
        }
        if (i == 2) {
            return (this.f1972p != 1 && mo1270Z0()) ? -1 : 1;
        }
        if (i == 17) {
            if (this.f1972p == 0) {
                return -1;
            }
            return RtlSpacingHelper.UNDEFINED;
        }
        if (i == 33) {
            if (this.f1972p == 1) {
                return -1;
            }
            return RtlSpacingHelper.UNDEFINED;
        }
        if (i == 66) {
            if (this.f1972p == 0) {
                return 1;
            }
            return RtlSpacingHelper.UNDEFINED;
        }
        if (i == 130 && this.f1972p == 1) {
            return 1;
        }
        return RtlSpacingHelper.UNDEFINED;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: M */
    public final boolean mo1255M() {
        return this.f1976t;
    }

    /* JADX INFO: renamed from: M0 */
    public final void m1256M0() {
        if (this.f1973q == null) {
            C0172b c0172b = new C0172b();
            c0172b.f2116a = true;
            c0172b.f2123h = 0;
            c0172b.f2124i = 0;
            c0172b.f2126k = null;
            this.f1973q = c0172b;
        }
    }

    /* JADX INFO: renamed from: N0 */
    public final int m1257N0(C0182l c0182l, C0172b c0172b, et8 et8Var, boolean z) {
        int i;
        int i2 = c0172b.f2118c;
        int i3 = c0172b.f2122g;
        if (i3 != Integer.MIN_VALUE) {
            if (i2 < 0) {
                c0172b.f2122g = i3 + i2;
            }
            m1273c1(c0182l, c0172b);
        }
        int i4 = c0172b.f2118c + c0172b.f2123h;
        while (true) {
            if ((!c0172b.f2127l && i4 <= 0) || (i = c0172b.f2119d) < 0 || i >= et8Var.m7762b()) {
                break;
            }
            ab6 ab6Var = this.f1969B;
            ab6Var.f569a = 0;
            ab6Var.f570b = false;
            ab6Var.f571c = false;
            ab6Var.f572d = false;
            mo1213a1(c0182l, et8Var, c0172b, ab6Var);
            if (!ab6Var.f570b) {
                int i5 = c0172b.f2117b;
                int i6 = ab6Var.f569a;
                c0172b.f2117b = (c0172b.f2121f * i6) + i5;
                if (!ab6Var.f571c || c0172b.f2126k != null || !et8Var.f13104g) {
                    c0172b.f2118c -= i6;
                    i4 -= i6;
                }
                int i7 = c0172b.f2122g;
                if (i7 != Integer.MIN_VALUE) {
                    int i8 = i7 + i6;
                    c0172b.f2122g = i8;
                    int i9 = c0172b.f2118c;
                    if (i9 < 0) {
                        c0172b.f2122g = i8 + i9;
                    }
                    m1273c1(c0182l, c0172b);
                }
                if (z && ab6Var.f572d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i2 - c0172b.f2118c;
    }

    /* JADX INFO: renamed from: O0 */
    public final View m1258O0(boolean z) {
        return this.f1977u ? m1264T0(0, m1471w(), z, true) : m1264T0(m1471w() - 1, -1, z, true);
    }

    /* JADX INFO: renamed from: P0 */
    public final View m1259P0(boolean z) {
        return this.f1977u ? m1264T0(m1471w() - 1, -1, z, true) : m1264T0(0, m1471w(), z, true);
    }

    /* JADX INFO: renamed from: Q0 */
    public final int m1260Q0() {
        View viewM1264T0 = m1264T0(0, m1471w(), false, true);
        if (viewM1264T0 == null) {
            return -1;
        }
        return AbstractC0181k.m1441H(viewM1264T0);
    }

    /* JADX INFO: renamed from: R0 */
    public final int m1261R0() {
        View viewM1264T0 = m1264T0(m1471w() - 1, -1, false, true);
        if (viewM1264T0 == null) {
            return -1;
        }
        return AbstractC0181k.m1441H(viewM1264T0);
    }

    /* JADX INFO: renamed from: S0 */
    public final View m1262S0(int i, int i2) {
        int i3;
        int i4;
        m1256M0();
        if (i2 <= i && i2 >= i) {
            return m1469v(i);
        }
        if (this.f1974r.mo1411e(m1469v(i)) < this.f1974r.mo1417k()) {
            i3 = 16644;
            i4 = 16388;
        } else {
            i3 = 4161;
            i4 = ItemType.TYPE_LIST;
        }
        return this.f1972p == 0 ? this.f2143c.m16180h(i, i2, i3, i4) : this.f2144d.m16180h(i, i2, i3, i4);
    }

    /* JADX INFO: renamed from: T0 */
    public final View m1264T0(int i, int i2, boolean z, boolean z2) {
        m1256M0();
        int i3 = z ? 24579 : 320;
        int i4 = z2 ? 320 : 0;
        return this.f1972p == 0 ? this.f2143c.m16180h(i, i2, i3, i4) : this.f2144d.m16180h(i, i2, i3, i4);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: U */
    public View mo1207U(View view, int i, C0182l c0182l, et8 et8Var) {
        int iM1254L0;
        View viewM1262S0;
        m1276e1();
        if (m1471w() != 0 && (iM1254L0 = m1254L0(i)) != Integer.MIN_VALUE) {
            m1256M0();
            m1283i1(iM1254L0, (int) (this.f1974r.mo1418l() * 0.33333334f), false, et8Var);
            C0172b c0172b = this.f1973q;
            c0172b.f2122g = RtlSpacingHelper.UNDEFINED;
            c0172b.f2116a = false;
            m1257N0(c0182l, c0172b, et8Var, true);
            boolean z = this.f1977u;
            if (iM1254L0 == -1) {
                viewM1262S0 = z ? m1262S0(m1471w() - 1, -1) : m1262S0(0, m1471w());
            } else {
                viewM1262S0 = z ? m1262S0(0, m1471w()) : m1262S0(m1471w() - 1, -1);
            }
            View viewM1269Y0 = iM1254L0 == -1 ? m1269Y0() : m1268X0();
            if (!viewM1269Y0.hasFocusable()) {
                return viewM1262S0;
            }
            if (viewM1262S0 != null) {
                return viewM1269Y0;
            }
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:33:0x0075  */
    /* JADX WARN: Code duplicated, block: B:35:0x0079  */
    /* JADX INFO: renamed from: U0 */
    public View mo1208U0(C0182l c0182l, et8 et8Var, boolean z, boolean z2) {
        int i;
        int iM1471w;
        int i2;
        m1256M0();
        int iM1471w2 = m1471w();
        if (z2) {
            iM1471w = m1471w() - 1;
            i = -1;
            i2 = -1;
        } else {
            i = iM1471w2;
            iM1471w = 0;
            i2 = 1;
        }
        int iM7762b = et8Var.m7762b();
        int iMo1417k = this.f1974r.mo1417k();
        int iMo1413g = this.f1974r.mo1413g();
        View view = null;
        View view2 = null;
        View view3 = null;
        while (iM1471w != i) {
            View viewM1469v = m1469v(iM1471w);
            int iM1441H = AbstractC0181k.m1441H(viewM1469v);
            int iMo1411e = this.f1974r.mo1411e(viewM1469v);
            int iMo1408b = this.f1974r.mo1408b(viewM1469v);
            if (iM1441H >= 0 && iM1441H < iM7762b) {
                if (!((RecyclerView.LayoutParams) viewM1469v.getLayoutParams()).f2069a.m1505j()) {
                    boolean z3 = iMo1408b <= iMo1417k && iMo1411e < iMo1417k;
                    boolean z4 = iMo1411e >= iMo1413g && iMo1408b > iMo1413g;
                    if (!z3 && !z4) {
                        return viewM1469v;
                    }
                    if (z) {
                        if (z4) {
                            view2 = viewM1469v;
                        } else if (view == null) {
                            view = viewM1469v;
                        }
                    } else if (z3) {
                        view2 = viewM1469v;
                    } else if (view == null) {
                        view = viewM1469v;
                    }
                } else if (view3 == null) {
                    view3 = viewM1469v;
                }
            }
            iM1471w += i2;
        }
        if (view != null) {
            return view;
        }
        return view2 != null ? view2 : view3;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: V */
    public final void mo1265V(AccessibilityEvent accessibilityEvent) {
        super.mo1265V(accessibilityEvent);
        if (m1471w() > 0) {
            accessibilityEvent.setFromIndex(m1260Q0());
            accessibilityEvent.setToIndex(m1261R0());
        }
    }

    /* JADX INFO: renamed from: V0 */
    public final int m1266V0(int i, C0182l c0182l, et8 et8Var, boolean z) {
        int iMo1413g;
        int iMo1413g2 = this.f1974r.mo1413g() - i;
        if (iMo1413g2 <= 0) {
            return 0;
        }
        int i2 = -m1278f1(-iMo1413g2, et8Var, c0182l);
        int i3 = i + i2;
        if (!z || (iMo1413g = this.f1974r.mo1413g() - i3) <= 0) {
            return i2;
        }
        this.f1974r.mo1421o(iMo1413g);
        return iMo1413g + i2;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: W */
    public void mo1209W(C0182l c0182l, et8 et8Var, C0681k7 c0681k7) {
        super.mo1209W(c0182l, et8Var, c0681k7);
        AbstractC0177g abstractC0177g = this.f2142b.f2009I;
        if (abstractC0177g == null || abstractC0177g.mo1422a() <= 0) {
            return;
        }
        c0681k7.m11845b(C0446e7.f12025o);
    }

    /* JADX INFO: renamed from: W0 */
    public final int m1267W0(int i, C0182l c0182l, et8 et8Var, boolean z) {
        int iMo1417k;
        int iMo1417k2 = i - this.f1974r.mo1417k();
        if (iMo1417k2 <= 0) {
            return 0;
        }
        int i2 = -m1278f1(iMo1417k2, et8Var, c0182l);
        int i3 = i + i2;
        if (!z || (iMo1417k = i3 - this.f1974r.mo1417k()) <= 0) {
            return i2;
        }
        this.f1974r.mo1421o(-iMo1417k);
        return i2 - iMo1417k;
    }

    /* JADX INFO: renamed from: X0 */
    public final View m1268X0() {
        return m1469v(this.f1977u ? 0 : m1471w() - 1);
    }

    /* JADX INFO: renamed from: Y0 */
    public final View m1269Y0() {
        return m1469v(this.f1977u ? m1471w() - 1 : 0);
    }

    /* JADX INFO: renamed from: Z0 */
    public boolean mo1270Z0() {
        return this.f2142b.getLayoutDirection() == 1;
    }

    @Override // p000.ct8
    /* JADX INFO: renamed from: a */
    public final PointF mo1271a(int i) {
        if (m1471w() == 0) {
            return null;
        }
        int i2 = (i < AbstractC0181k.m1441H(m1469v(0))) != this.f1977u ? -1 : 1;
        return this.f1972p == 0 ? new PointF(i2, 0.0f) : new PointF(0.0f, i2);
    }

    /* JADX INFO: renamed from: a1 */
    public void mo1213a1(C0182l c0182l, et8 et8Var, C0172b c0172b, ab6 ab6Var) {
        int i;
        int iMo1410d;
        int i2;
        int iMo1410d2;
        View viewM1400b = c0172b.m1400b(c0182l);
        if (viewM1400b == null) {
            ab6Var.f570b = true;
            return;
        }
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) viewM1400b.getLayoutParams();
        List list = c0172b.f2126k;
        boolean z = this.f1977u;
        int i3 = c0172b.f2121f;
        if (list == null) {
            if (z == (i3 == -1)) {
                m1458b(viewM1400b, -1, false);
            } else {
                m1458b(viewM1400b, 0, false);
            }
        } else {
            if (z == (i3 == -1)) {
                m1458b(viewM1400b, -1, true);
            } else {
                m1458b(viewM1400b, 0, true);
            }
        }
        RecyclerView.LayoutParams layoutParams2 = (RecyclerView.LayoutParams) viewM1400b.getLayoutParams();
        Rect rectM1312N = this.f2142b.m1312N(viewM1400b);
        int i4 = rectM1312N.left + rectM1312N.right;
        int i5 = rectM1312N.top + rectM1312N.bottom;
        int iM1446x = AbstractC0181k.m1446x(mo1275e(), this.f2154n, this.f2152l, m1453F() + m1451E() + ((ViewGroup.MarginLayoutParams) layoutParams2).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).rightMargin + i4, ((ViewGroup.MarginLayoutParams) layoutParams2).width);
        int iM1446x2 = AbstractC0181k.m1446x(mo1277f(), this.f2155o, this.f2153m, m1450D() + m1454G() + ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin + i5, ((ViewGroup.MarginLayoutParams) layoutParams2).height);
        if (m1447A0(viewM1400b, iM1446x, iM1446x2, layoutParams2)) {
            viewM1400b.measure(iM1446x, iM1446x2);
        }
        ab6Var.f569a = this.f1974r.mo1409c(viewM1400b);
        if (this.f1972p == 1) {
            if (mo1270Z0()) {
                iMo1410d2 = this.f2154n - m1453F();
                iMo1410d = iMo1410d2 - this.f1974r.mo1410d(viewM1400b);
            } else {
                int iM1451E = m1451E();
                iMo1410d2 = this.f1974r.mo1410d(viewM1400b) + iM1451E;
                iMo1410d = iM1451E;
            }
            int i6 = c0172b.f2121f;
            i2 = c0172b.f2117b;
            int i7 = ab6Var.f569a;
            if (i6 == -1) {
                int i8 = i2 - i7;
                i = i2;
                i2 = i8;
            } else {
                i = i7 + i2;
            }
        } else {
            int iM1454G = m1454G();
            int iMo1410d3 = this.f1974r.mo1410d(viewM1400b) + iM1454G;
            int i9 = c0172b.f2121f;
            int i10 = c0172b.f2117b;
            int i11 = ab6Var.f569a;
            if (i9 == -1) {
                int i12 = i10 - i11;
                iMo1410d2 = i10;
                i2 = iM1454G;
                i = iMo1410d3;
                iMo1410d = i12;
            } else {
                int i13 = i10 + i11;
                i = iMo1410d3;
                iMo1410d = i10;
                i2 = iM1454G;
                iMo1410d2 = i13;
            }
        }
        AbstractC0181k.m1444O(viewM1400b, iMo1410d, i2, iMo1410d2, i);
        if (layoutParams.f2069a.m1505j() || layoutParams.f2069a.m1508m()) {
            ab6Var.f571c = true;
        }
        ab6Var.f572d = viewM1400b.hasFocusable();
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: c */
    public final void mo1272c(String str) {
        if (this.f1982z == null) {
            super.mo1272c(str);
        }
    }

    /* JADX INFO: renamed from: c1 */
    public final void m1273c1(C0182l c0182l, C0172b c0172b) {
        if (!c0172b.f2116a || c0172b.f2127l) {
            return;
        }
        int i = c0172b.f2122g;
        int i2 = c0172b.f2124i;
        if (c0172b.f2121f == -1) {
            int iM1471w = m1471w();
            if (i < 0) {
                return;
            }
            int iMo1412f = (this.f1974r.mo1412f() - i) + i2;
            if (this.f1977u) {
                for (int i3 = 0; i3 < iM1471w; i3++) {
                    View viewM1469v = m1469v(i3);
                    if (this.f1974r.mo1411e(viewM1469v) < iMo1412f || this.f1974r.mo1420n(viewM1469v) < iMo1412f) {
                        m1274d1(c0182l, 0, i3);
                        return;
                    }
                }
                return;
            }
            int i4 = iM1471w - 1;
            for (int i5 = i4; i5 >= 0; i5--) {
                View viewM1469v2 = m1469v(i5);
                if (this.f1974r.mo1411e(viewM1469v2) < iMo1412f || this.f1974r.mo1420n(viewM1469v2) < iMo1412f) {
                    m1274d1(c0182l, i4, i5);
                    return;
                }
            }
            return;
        }
        if (i < 0) {
            return;
        }
        int i6 = i - i2;
        int iM1471w2 = m1471w();
        if (!this.f1977u) {
            for (int i7 = 0; i7 < iM1471w2; i7++) {
                View viewM1469v3 = m1469v(i7);
                if (this.f1974r.mo1408b(viewM1469v3) > i6 || this.f1974r.mo1419m(viewM1469v3) > i6) {
                    m1274d1(c0182l, 0, i7);
                    return;
                }
            }
            return;
        }
        int i8 = iM1471w2 - 1;
        for (int i9 = i8; i9 >= 0; i9--) {
            View viewM1469v4 = m1469v(i9);
            if (this.f1974r.mo1408b(viewM1469v4) > i6 || this.f1974r.mo1419m(viewM1469v4) > i6) {
                m1274d1(c0182l, i8, i9);
                return;
            }
        }
    }

    /* JADX INFO: renamed from: d1 */
    public final void m1274d1(C0182l c0182l, int i, int i2) {
        if (i == i2) {
            return;
        }
        if (i2 <= i) {
            while (i > i2) {
                m1465p0(i, c0182l);
                i--;
            }
        } else {
            for (int i3 = i2 - 1; i3 >= i; i3--) {
                m1465p0(i3, c0182l);
            }
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: e */
    public final boolean mo1275e() {
        return this.f1972p == 0;
    }

    /* JADX WARN: Code duplicated, block: B:102:0x01a3  */
    /* JADX WARN: Code duplicated, block: B:104:0x01a6  */
    /* JADX WARN: Code duplicated, block: B:111:0x01d1  */
    /* JADX WARN: Code duplicated, block: B:114:0x01d9  */
    /* JADX WARN: Code duplicated, block: B:118:0x01eb  */
    /* JADX WARN: Code duplicated, block: B:120:0x01f5  */
    /* JADX WARN: Code duplicated, block: B:121:0x01f7  */
    /* JADX WARN: Code duplicated, block: B:123:0x0202  */
    /* JADX WARN: Code duplicated, block: B:126:0x020e  */
    /* JADX WARN: Code duplicated, block: B:130:0x022e A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:132:0x0232  */
    /* JADX WARN: Code duplicated, block: B:134:0x0235 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:136:0x0239  */
    /* JADX WARN: Code duplicated, block: B:138:0x023c A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:139:0x023e  */
    /* JADX WARN: Code duplicated, block: B:141:0x0242  */
    /* JADX WARN: Code duplicated, block: B:143:0x0246  */
    /* JADX WARN: Code duplicated, block: B:145:0x024d  */
    /* JADX WARN: Code duplicated, block: B:146:0x0253  */
    /* JADX WARN: Code duplicated, block: B:95:0x018c  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v12 */
    /* JADX WARN: Type inference failed for: r4v13, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r4v14 */
    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: e0 */
    public void mo1218e0(C0182l c0182l, et8 et8Var) {
        View focusedChild;
        int iM7762b;
        RecyclerView recyclerView;
        View focusedChild2;
        boolean z;
        boolean z2;
        View viewMo1208U0;
        boolean z3;
        nl7 nl7Var;
        int iMo1411e;
        int iMo1408b;
        int iMo1417k;
        int iMo1413g;
        boolean z4;
        boolean z5;
        nl7 nl7Var2;
        int iMo1418l;
        RecyclerView.LayoutParams layoutParams;
        int i;
        int iMo1411e2;
        int i2;
        int i3;
        ?? r4;
        List list;
        int i4;
        int i5;
        int iM1266V0;
        int i6;
        View viewMo1289r;
        int iMo1411e3;
        int iMo1413g2;
        int i7;
        int i8 = -1;
        if (!(this.f1982z == null && this.f1980x == -1) && et8Var.m7762b() == 0) {
            m1462m0(c0182l);
            return;
        }
        SavedState savedState = this.f1982z;
        if (savedState != null && (i7 = savedState.f1983e) >= 0) {
            this.f1980x = i7;
        }
        m1256M0();
        boolean z6 = false;
        this.f1973q.f2116a = false;
        m1276e1();
        RecyclerView recyclerView2 = this.f2142b;
        if (recyclerView2 == null || (focusedChild = recyclerView2.getFocusedChild()) == null || ((ArrayList) this.f2141a.f36499e).contains(focusedChild)) {
            focusedChild = null;
        }
        C0171a c0171a = this.f1968A;
        if (!c0171a.f2115e || this.f1980x != -1 || this.f1982z != null) {
            c0171a.m1398c();
            c0171a.f2114d = this.f1977u ^ this.f1978v;
            if (et8Var.f13104g || (i = this.f1980x) == -1) {
                if (m1471w() != 0) {
                    recyclerView = this.f2142b;
                    if (recyclerView != null || (focusedChild2 = recyclerView.getFocusedChild()) == null || ((ArrayList) this.f2141a.f36499e).contains(focusedChild2)) {
                        focusedChild2 = null;
                    }
                    if (focusedChild2 != null) {
                        layoutParams = (RecyclerView.LayoutParams) focusedChild2.getLayoutParams();
                        if (!layoutParams.f2069a.m1505j() || layoutParams.f2069a.m1499d() < 0 || layoutParams.f2069a.m1499d() >= et8Var.m7762b()) {
                            z = this.f1975s;
                            z2 = this.f1978v;
                            if (z == z2 || (viewMo1208U0 = mo1208U0(c0182l, et8Var, c0171a.f2114d, z2)) == null) {
                                c0171a.m1396a();
                                if (this.f1978v) {
                                    iM7762b = et8Var.m7762b() - 1;
                                } else {
                                    iM7762b = 0;
                                }
                                c0171a.f2112b = iM7762b;
                            } else {
                                int iM1441H = AbstractC0181k.m1441H(viewMo1208U0);
                                z3 = c0171a.f2114d;
                                nl7Var = c0171a.f2111a;
                                if (z3) {
                                    int iMo1408b2 = nl7Var.mo1408b(viewMo1208U0);
                                    nl7Var2 = c0171a.f2111a;
                                    if (Integer.MIN_VALUE == nl7Var2.f30239b) {
                                        iMo1418l = 0;
                                    } else {
                                        iMo1418l = nl7Var2.mo1418l() - nl7Var2.f30239b;
                                    }
                                    c0171a.f2113c = iMo1418l + iMo1408b2;
                                } else {
                                    c0171a.f2113c = nl7Var.mo1411e(viewMo1208U0);
                                }
                                c0171a.f2112b = iM1441H;
                                if (!et8Var.f13104g && mo1204F0()) {
                                    iMo1411e = this.f1974r.mo1411e(viewMo1208U0);
                                    iMo1408b = this.f1974r.mo1408b(viewMo1208U0);
                                    iMo1417k = this.f1974r.mo1417k();
                                    iMo1413g = this.f1974r.mo1413g();
                                    if (iMo1408b <= iMo1417k || iMo1411e >= iMo1417k) {
                                        z4 = false;
                                    } else {
                                        z4 = true;
                                    }
                                    if (iMo1411e >= iMo1413g || iMo1408b <= iMo1413g) {
                                        z5 = false;
                                    } else {
                                        z5 = true;
                                    }
                                    if (z4 || z5) {
                                        if (c0171a.f2114d) {
                                            iMo1417k = iMo1413g;
                                        }
                                        c0171a.f2113c = iMo1417k;
                                    }
                                }
                            }
                        } else {
                            c0171a.m1397b(AbstractC0181k.m1441H(focusedChild2), focusedChild2);
                        }
                    } else {
                        z = this.f1975s;
                        z2 = this.f1978v;
                        if (z == z2) {
                            c0171a.m1396a();
                            if (this.f1978v) {
                                iM7762b = et8Var.m7762b() - 1;
                            } else {
                                iM7762b = 0;
                            }
                            c0171a.f2112b = iM7762b;
                        } else {
                            int iM1441H2 = AbstractC0181k.m1441H(viewMo1208U0);
                            z3 = c0171a.f2114d;
                            nl7Var = c0171a.f2111a;
                            if (z3) {
                                int iMo1408b3 = nl7Var.mo1408b(viewMo1208U0);
                                nl7Var2 = c0171a.f2111a;
                                if (Integer.MIN_VALUE == nl7Var2.f30239b) {
                                    iMo1418l = 0;
                                } else {
                                    iMo1418l = nl7Var2.mo1418l() - nl7Var2.f30239b;
                                }
                                c0171a.f2113c = iMo1418l + iMo1408b3;
                            } else {
                                c0171a.f2113c = nl7Var.mo1411e(viewMo1208U0);
                            }
                            c0171a.f2112b = iM1441H2;
                            if (!et8Var.f13104g) {
                                iMo1411e = this.f1974r.mo1411e(viewMo1208U0);
                                iMo1408b = this.f1974r.mo1408b(viewMo1208U0);
                                iMo1417k = this.f1974r.mo1417k();
                                iMo1413g = this.f1974r.mo1413g();
                                if (iMo1408b <= iMo1417k) {
                                    z4 = false;
                                } else {
                                    z4 = false;
                                }
                                if (iMo1411e >= iMo1413g) {
                                    z5 = false;
                                } else {
                                    z5 = false;
                                }
                                if (z4) {
                                    if (c0171a.f2114d) {
                                        iMo1417k = iMo1413g;
                                    }
                                    c0171a.f2113c = iMo1417k;
                                } else {
                                    if (c0171a.f2114d) {
                                        iMo1417k = iMo1413g;
                                    }
                                    c0171a.f2113c = iMo1417k;
                                }
                            }
                        }
                    }
                } else {
                    c0171a.m1396a();
                    if (this.f1978v) {
                        iM7762b = et8Var.m7762b() - 1;
                    } else {
                        iM7762b = 0;
                    }
                    c0171a.f2112b = iM7762b;
                }
            } else if (i < 0 || i >= et8Var.m7762b()) {
                this.f1980x = -1;
                this.f1981y = RtlSpacingHelper.UNDEFINED;
                if (m1471w() != 0) {
                    recyclerView = this.f2142b;
                    if (recyclerView != null) {
                        focusedChild2 = null;
                    } else {
                        focusedChild2 = null;
                    }
                    if (focusedChild2 != null) {
                        layoutParams = (RecyclerView.LayoutParams) focusedChild2.getLayoutParams();
                        if (layoutParams.f2069a.m1505j()) {
                            z = this.f1975s;
                            z2 = this.f1978v;
                            if (z == z2) {
                                c0171a.m1396a();
                                if (this.f1978v) {
                                    iM7762b = et8Var.m7762b() - 1;
                                } else {
                                    iM7762b = 0;
                                }
                                c0171a.f2112b = iM7762b;
                            } else {
                                int iM1441H3 = AbstractC0181k.m1441H(viewMo1208U0);
                                z3 = c0171a.f2114d;
                                nl7Var = c0171a.f2111a;
                                if (z3) {
                                    int iMo1408b4 = nl7Var.mo1408b(viewMo1208U0);
                                    nl7Var2 = c0171a.f2111a;
                                    if (Integer.MIN_VALUE == nl7Var2.f30239b) {
                                        iMo1418l = 0;
                                    } else {
                                        iMo1418l = nl7Var2.mo1418l() - nl7Var2.f30239b;
                                    }
                                    c0171a.f2113c = iMo1418l + iMo1408b4;
                                } else {
                                    c0171a.f2113c = nl7Var.mo1411e(viewMo1208U0);
                                }
                                c0171a.f2112b = iM1441H3;
                                if (!et8Var.f13104g) {
                                    iMo1411e = this.f1974r.mo1411e(viewMo1208U0);
                                    iMo1408b = this.f1974r.mo1408b(viewMo1208U0);
                                    iMo1417k = this.f1974r.mo1417k();
                                    iMo1413g = this.f1974r.mo1413g();
                                    if (iMo1408b <= iMo1417k) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (iMo1411e >= iMo1413g) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (z4) {
                                        if (c0171a.f2114d) {
                                            iMo1417k = iMo1413g;
                                        }
                                        c0171a.f2113c = iMo1417k;
                                    } else {
                                        if (c0171a.f2114d) {
                                            iMo1417k = iMo1413g;
                                        }
                                        c0171a.f2113c = iMo1417k;
                                    }
                                }
                            }
                        } else {
                            z = this.f1975s;
                            z2 = this.f1978v;
                            if (z == z2) {
                                c0171a.m1396a();
                                if (this.f1978v) {
                                    iM7762b = et8Var.m7762b() - 1;
                                } else {
                                    iM7762b = 0;
                                }
                                c0171a.f2112b = iM7762b;
                            } else {
                                int iM1441H4 = AbstractC0181k.m1441H(viewMo1208U0);
                                z3 = c0171a.f2114d;
                                nl7Var = c0171a.f2111a;
                                if (z3) {
                                    int iMo1408b5 = nl7Var.mo1408b(viewMo1208U0);
                                    nl7Var2 = c0171a.f2111a;
                                    if (Integer.MIN_VALUE == nl7Var2.f30239b) {
                                        iMo1418l = 0;
                                    } else {
                                        iMo1418l = nl7Var2.mo1418l() - nl7Var2.f30239b;
                                    }
                                    c0171a.f2113c = iMo1418l + iMo1408b5;
                                } else {
                                    c0171a.f2113c = nl7Var.mo1411e(viewMo1208U0);
                                }
                                c0171a.f2112b = iM1441H4;
                                if (!et8Var.f13104g) {
                                    iMo1411e = this.f1974r.mo1411e(viewMo1208U0);
                                    iMo1408b = this.f1974r.mo1408b(viewMo1208U0);
                                    iMo1417k = this.f1974r.mo1417k();
                                    iMo1413g = this.f1974r.mo1413g();
                                    if (iMo1408b <= iMo1417k) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (iMo1411e >= iMo1413g) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (z4) {
                                        if (c0171a.f2114d) {
                                            iMo1417k = iMo1413g;
                                        }
                                        c0171a.f2113c = iMo1417k;
                                    } else {
                                        if (c0171a.f2114d) {
                                            iMo1417k = iMo1413g;
                                        }
                                        c0171a.f2113c = iMo1417k;
                                    }
                                }
                            }
                        }
                    } else {
                        z = this.f1975s;
                        z2 = this.f1978v;
                        if (z == z2) {
                            c0171a.m1396a();
                            if (this.f1978v) {
                                iM7762b = et8Var.m7762b() - 1;
                            } else {
                                iM7762b = 0;
                            }
                            c0171a.f2112b = iM7762b;
                        } else {
                            int iM1441H5 = AbstractC0181k.m1441H(viewMo1208U0);
                            z3 = c0171a.f2114d;
                            nl7Var = c0171a.f2111a;
                            if (z3) {
                                int iMo1408b6 = nl7Var.mo1408b(viewMo1208U0);
                                nl7Var2 = c0171a.f2111a;
                                if (Integer.MIN_VALUE == nl7Var2.f30239b) {
                                    iMo1418l = 0;
                                } else {
                                    iMo1418l = nl7Var2.mo1418l() - nl7Var2.f30239b;
                                }
                                c0171a.f2113c = iMo1418l + iMo1408b6;
                            } else {
                                c0171a.f2113c = nl7Var.mo1411e(viewMo1208U0);
                            }
                            c0171a.f2112b = iM1441H5;
                            if (!et8Var.f13104g) {
                                iMo1411e = this.f1974r.mo1411e(viewMo1208U0);
                                iMo1408b = this.f1974r.mo1408b(viewMo1208U0);
                                iMo1417k = this.f1974r.mo1417k();
                                iMo1413g = this.f1974r.mo1413g();
                                if (iMo1408b <= iMo1417k) {
                                    z4 = false;
                                } else {
                                    z4 = false;
                                }
                                if (iMo1411e >= iMo1413g) {
                                    z5 = false;
                                } else {
                                    z5 = false;
                                }
                                if (z4) {
                                    if (c0171a.f2114d) {
                                        iMo1417k = iMo1413g;
                                    }
                                    c0171a.f2113c = iMo1417k;
                                } else {
                                    if (c0171a.f2114d) {
                                        iMo1417k = iMo1413g;
                                    }
                                    c0171a.f2113c = iMo1417k;
                                }
                            }
                        }
                    }
                } else {
                    c0171a.m1396a();
                    if (this.f1978v) {
                        iM7762b = et8Var.m7762b() - 1;
                    } else {
                        iM7762b = 0;
                    }
                    c0171a.f2112b = iM7762b;
                }
            } else {
                int i9 = this.f1980x;
                c0171a.f2112b = i9;
                SavedState savedState2 = this.f1982z;
                if (savedState2 != null && savedState2.f1983e >= 0) {
                    boolean z7 = savedState2.f1985y;
                    c0171a.f2114d = z7;
                    nl7 nl7Var3 = this.f1974r;
                    if (z7) {
                        c0171a.f2113c = nl7Var3.mo1413g() - this.f1982z.f1984i;
                    } else {
                        c0171a.f2113c = nl7Var3.mo1417k() + this.f1982z.f1984i;
                    }
                } else if (this.f1981y == Integer.MIN_VALUE) {
                    View viewMo1289r2 = mo1289r(i9);
                    if (viewMo1289r2 == null) {
                        if (m1471w() > 0) {
                            c0171a.f2114d = (this.f1980x < AbstractC0181k.m1441H(m1469v(0))) == this.f1977u;
                        }
                        c0171a.m1396a();
                    } else if (this.f1974r.mo1409c(viewMo1289r2) > this.f1974r.mo1418l()) {
                        c0171a.m1396a();
                    } else {
                        int iMo1411e4 = this.f1974r.mo1411e(viewMo1289r2) - this.f1974r.mo1417k();
                        nl7 nl7Var4 = this.f1974r;
                        if (iMo1411e4 < 0) {
                            c0171a.f2113c = nl7Var4.mo1417k();
                            c0171a.f2114d = false;
                        } else if (nl7Var4.mo1413g() - this.f1974r.mo1408b(viewMo1289r2) < 0) {
                            c0171a.f2113c = this.f1974r.mo1413g();
                            c0171a.f2114d = true;
                        } else {
                            boolean z8 = c0171a.f2114d;
                            nl7 nl7Var5 = this.f1974r;
                            if (z8) {
                                int iMo1408b7 = nl7Var5.mo1408b(viewMo1289r2);
                                nl7 nl7Var6 = this.f1974r;
                                iMo1411e2 = (Integer.MIN_VALUE == nl7Var6.f30239b ? 0 : nl7Var6.mo1418l() - nl7Var6.f30239b) + iMo1408b7;
                            } else {
                                iMo1411e2 = nl7Var5.mo1411e(viewMo1289r2);
                            }
                            c0171a.f2113c = iMo1411e2;
                        }
                    }
                } else {
                    boolean z9 = this.f1977u;
                    c0171a.f2114d = z9;
                    nl7 nl7Var7 = this.f1974r;
                    if (z9) {
                        c0171a.f2113c = nl7Var7.mo1413g() - this.f1981y;
                    } else {
                        c0171a.f2113c = nl7Var7.mo1417k() + this.f1981y;
                    }
                }
            }
            c0171a.f2115e = true;
        } else if (focusedChild != null && (this.f1974r.mo1411e(focusedChild) >= this.f1974r.mo1413g() || this.f1974r.mo1408b(focusedChild) <= this.f1974r.mo1417k())) {
            c0171a.m1397b(AbstractC0181k.m1441H(focusedChild), focusedChild);
        }
        C0172b c0172b = this.f1973q;
        c0172b.f2121f = c0172b.f2125j >= 0 ? 1 : -1;
        int[] iArr = this.f1971D;
        iArr[0] = 0;
        iArr[1] = 0;
        mo1249G0(et8Var, iArr);
        int iMo1417k2 = this.f1974r.mo1417k() + Math.max(0, iArr[0]);
        int iMo1414h = this.f1974r.mo1414h() + Math.max(0, iArr[1]);
        if (et8Var.f13104g && (i6 = this.f1980x) != -1 && this.f1981y != Integer.MIN_VALUE && (viewMo1289r = mo1289r(i6)) != null) {
            boolean z10 = this.f1977u;
            nl7 nl7Var8 = this.f1974r;
            if (z10) {
                iMo1413g2 = nl7Var8.mo1413g() - this.f1974r.mo1408b(viewMo1289r);
                iMo1411e3 = this.f1981y;
            } else {
                iMo1411e3 = nl7Var8.mo1411e(viewMo1289r) - this.f1974r.mo1417k();
                iMo1413g2 = this.f1981y;
            }
            int i10 = iMo1413g2 - iMo1411e3;
            if (i10 > 0) {
                iMo1417k2 += i10;
            } else {
                iMo1414h -= i10;
            }
        }
        boolean z11 = c0171a.f2114d;
        boolean z12 = this.f1977u;
        if (!z11 ? !z12 : z12) {
            i8 = 1;
        }
        mo1215b1(c0182l, et8Var, c0171a, i8);
        m1466q(c0182l);
        this.f1973q.f2127l = this.f1974r.mo1415i() == 0 && this.f1974r.mo1412f() == 0;
        this.f1973q.getClass();
        this.f1973q.f2124i = 0;
        boolean z13 = c0171a.f2114d;
        int i11 = c0171a.f2112b;
        if (z13) {
            m1287k1(i11, c0171a.f2113c);
            C0172b c0172b2 = this.f1973q;
            c0172b2.f2123h = iMo1417k2;
            m1257N0(c0182l, c0172b2, et8Var, false);
            C0172b c0172b3 = this.f1973q;
            i3 = c0172b3.f2117b;
            int i12 = c0172b3.f2119d;
            int i13 = c0172b3.f2118c;
            if (i13 > 0) {
                iMo1414h += i13;
            }
            m1285j1(c0171a.f2112b, c0171a.f2113c);
            C0172b c0172b4 = this.f1973q;
            c0172b4.f2123h = iMo1414h;
            c0172b4.f2119d += c0172b4.f2120e;
            m1257N0(c0182l, c0172b4, et8Var, false);
            C0172b c0172b5 = this.f1973q;
            i2 = c0172b5.f2117b;
            int i14 = c0172b5.f2118c;
            if (i14 > 0) {
                m1287k1(i12, i3);
                C0172b c0172b6 = this.f1973q;
                c0172b6.f2123h = i14;
                m1257N0(c0182l, c0172b6, et8Var, false);
                i3 = this.f1973q.f2117b;
            }
        } else {
            m1285j1(i11, c0171a.f2113c);
            C0172b c0172b7 = this.f1973q;
            c0172b7.f2123h = iMo1414h;
            m1257N0(c0182l, c0172b7, et8Var, false);
            C0172b c0172b8 = this.f1973q;
            i2 = c0172b8.f2117b;
            int i15 = c0172b8.f2119d;
            int i16 = c0172b8.f2118c;
            if (i16 > 0) {
                iMo1417k2 += i16;
            }
            m1287k1(c0171a.f2112b, c0171a.f2113c);
            C0172b c0172b9 = this.f1973q;
            c0172b9.f2123h = iMo1417k2;
            c0172b9.f2119d += c0172b9.f2120e;
            m1257N0(c0182l, c0172b9, et8Var, false);
            C0172b c0172b10 = this.f1973q;
            int i17 = c0172b10.f2117b;
            int i18 = c0172b10.f2118c;
            if (i18 > 0) {
                m1285j1(i15, i2);
                C0172b c0172b11 = this.f1973q;
                c0172b11.f2123h = i18;
                m1257N0(c0182l, c0172b11, et8Var, false);
                i2 = this.f1973q.f2117b;
            }
            i3 = i17;
        }
        if (m1471w() > 0) {
            if (this.f1977u ^ this.f1978v) {
                int iM1266V1 = m1266V0(i2, c0182l, et8Var, true);
                i4 = i3 + iM1266V1;
                i5 = i2 + iM1266V1;
                iM1266V0 = m1267W0(i4, c0182l, et8Var, false);
            } else {
                int iM1267W0 = m1267W0(i3, c0182l, et8Var, true);
                i4 = i3 + iM1267W0;
                i5 = i2 + iM1267W0;
                iM1266V0 = m1266V0(i5, c0182l, et8Var, false);
            }
            i3 = i4 + iM1266V0;
            i2 = i5 + iM1266V0;
        }
        if (et8Var.f13108k && m1471w() != 0 && !et8Var.f13104g && mo1204F0()) {
            List list2 = c0182l.f2159d;
            int size = list2.size();
            int iM1441H6 = AbstractC0181k.m1441H(m1469v(0));
            int i19 = 0;
            int iMo1409c = 0;
            int iMo1409c2 = 0;
            while (i19 < size) {
                AbstractC0185o abstractC0185o = (AbstractC0185o) list2.get(i19);
                boolean zM1505j = abstractC0185o.m1505j();
                View view = abstractC0185o.f2181e;
                if (!zM1505j) {
                    boolean z14 = abstractC0185o.m1499d() < iM1441H6 ? true : z6;
                    boolean z15 = this.f1977u;
                    nl7 nl7Var9 = this.f1974r;
                    if (z14 != z15) {
                        iMo1409c += nl7Var9.mo1409c(view);
                    } else {
                        iMo1409c2 += nl7Var9.mo1409c(view);
                    }
                }
                i19++;
                z6 = false;
            }
            this.f1973q.f2126k = list2;
            if (iMo1409c > 0) {
                m1287k1(AbstractC0181k.m1441H(m1269Y0()), i3);
                C0172b c0172b12 = this.f1973q;
                c0172b12.f2123h = iMo1409c;
                r4 = 0;
                c0172b12.f2118c = 0;
                c0172b12.m1399a(null);
                m1257N0(c0182l, this.f1973q, et8Var, false);
            } else {
                r4 = 0;
            }
            if (iMo1409c2 > 0) {
                m1285j1(AbstractC0181k.m1441H(m1268X0()), i2);
                C0172b c0172b13 = this.f1973q;
                c0172b13.f2123h = iMo1409c2;
                c0172b13.f2118c = r4;
                list = null;
                c0172b13.m1399a(null);
                m1257N0(c0182l, this.f1973q, et8Var, r4);
            } else {
                list = null;
            }
            this.f1973q.f2126k = list;
        }
        if (et8Var.f13104g) {
            c0171a.m1398c();
        } else {
            nl7 nl7Var10 = this.f1974r;
            nl7Var10.f30239b = nl7Var10.mo1418l();
        }
        this.f1975s = this.f1978v;
    }

    /* JADX INFO: renamed from: e1 */
    public final void m1276e1() {
        if (this.f1972p == 1 || !mo1270Z0()) {
            this.f1977u = this.f1976t;
        } else {
            this.f1977u = !this.f1976t;
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: f */
    public boolean mo1277f() {
        return this.f1972p == 1;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: f0 */
    public void mo1219f0(et8 et8Var) {
        this.f1982z = null;
        this.f1980x = -1;
        this.f1981y = RtlSpacingHelper.UNDEFINED;
        this.f1968A.m1398c();
    }

    /* JADX INFO: renamed from: f1 */
    public final int m1278f1(int i, et8 et8Var, C0182l c0182l) {
        if (m1471w() != 0 && i != 0) {
            m1256M0();
            this.f1973q.f2116a = true;
            int i2 = i > 0 ? 1 : -1;
            int iAbs = Math.abs(i);
            m1283i1(i2, iAbs, true, et8Var);
            C0172b c0172b = this.f1973q;
            int iM1257N0 = m1257N0(c0182l, c0172b, et8Var, false) + c0172b.f2122g;
            if (iM1257N0 >= 0) {
                if (iAbs > iM1257N0) {
                    i = i2 * iM1257N0;
                }
                this.f1974r.mo1421o(-i);
                this.f1973q.f2125j = i;
                return i;
            }
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: g0 */
    public final void mo1279g0(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            this.f1982z = savedState;
            if (this.f1980x != -1) {
                savedState.f1983e = -1;
            }
            m1468r0();
        }
    }

    /* JADX INFO: renamed from: g1 */
    public final void m1280g1(int i) {
        if (i != 0 && i != 1) {
            C1521v3.m18903j(z82.m21085r(i, "invalid orientation:"));
            return;
        }
        mo1272c(null);
        if (i != this.f1972p || this.f1974r == null) {
            nl7 nl7VarM14206a = nl7.m14206a(this, i);
            this.f1974r = nl7VarM14206a;
            this.f1968A.f2111a = nl7VarM14206a;
            this.f1972p = i;
            m1468r0();
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: h0 */
    public final Parcelable mo1281h0() {
        SavedState savedState = this.f1982z;
        if (savedState != null) {
            SavedState savedState2 = new SavedState();
            savedState2.f1983e = savedState.f1983e;
            savedState2.f1984i = savedState.f1984i;
            savedState2.f1985y = savedState.f1985y;
            return savedState2;
        }
        SavedState savedState3 = new SavedState();
        if (m1471w() <= 0) {
            savedState3.f1983e = -1;
            return savedState3;
        }
        m1256M0();
        boolean z = this.f1975s ^ this.f1977u;
        savedState3.f1985y = z;
        if (z) {
            View viewM1268X0 = m1268X0();
            savedState3.f1984i = this.f1974r.mo1413g() - this.f1974r.mo1408b(viewM1268X0);
            savedState3.f1983e = AbstractC0181k.m1441H(viewM1268X0);
            return savedState3;
        }
        View viewM1269Y0 = m1269Y0();
        savedState3.f1983e = AbstractC0181k.m1441H(viewM1269Y0);
        savedState3.f1984i = this.f1974r.mo1411e(viewM1269Y0) - this.f1974r.mo1417k();
        return savedState3;
    }

    /* JADX INFO: renamed from: h1 */
    public void mo1221h1(boolean z) {
        mo1272c(null);
        if (this.f1978v == z) {
            return;
        }
        this.f1978v = z;
        m1468r0();
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: i */
    public final void mo1282i(int i, int i2, et8 et8Var, zo1 zo1Var) {
        if (this.f1972p != 0) {
            i = i2;
        }
        if (m1471w() == 0 || i == 0) {
            return;
        }
        m1256M0();
        m1283i1(i > 0 ? 1 : -1, Math.abs(i), true, et8Var);
        mo1205H0(et8Var, this.f1973q, zo1Var);
    }

    /* JADX INFO: renamed from: i1 */
    public final void m1283i1(int i, int i2, boolean z, et8 et8Var) {
        int iMo1417k;
        this.f1973q.f2127l = this.f1974r.mo1415i() == 0 && this.f1974r.mo1412f() == 0;
        this.f1973q.f2121f = i;
        int[] iArr = this.f1971D;
        iArr[0] = 0;
        iArr[1] = 0;
        mo1249G0(et8Var, iArr);
        int iMax = Math.max(0, iArr[0]);
        int iMax2 = Math.max(0, iArr[1]);
        boolean z2 = i == 1;
        C0172b c0172b = this.f1973q;
        int i3 = z2 ? iMax2 : iMax;
        c0172b.f2123h = i3;
        if (!z2) {
            iMax = iMax2;
        }
        c0172b.f2124i = iMax;
        if (z2) {
            c0172b.f2123h = this.f1974r.mo1414h() + i3;
            View viewM1268X0 = m1268X0();
            C0172b c0172b2 = this.f1973q;
            c0172b2.f2120e = this.f1977u ? -1 : 1;
            int iM1441H = AbstractC0181k.m1441H(viewM1268X0);
            C0172b c0172b3 = this.f1973q;
            c0172b2.f2119d = iM1441H + c0172b3.f2120e;
            c0172b3.f2117b = this.f1974r.mo1408b(viewM1268X0);
            iMo1417k = this.f1974r.mo1408b(viewM1268X0) - this.f1974r.mo1413g();
        } else {
            View viewM1269Y0 = m1269Y0();
            C0172b c0172b4 = this.f1973q;
            c0172b4.f2123h = this.f1974r.mo1417k() + c0172b4.f2123h;
            C0172b c0172b5 = this.f1973q;
            c0172b5.f2120e = this.f1977u ? 1 : -1;
            int iM1441H2 = AbstractC0181k.m1441H(viewM1269Y0);
            C0172b c0172b6 = this.f1973q;
            c0172b5.f2119d = iM1441H2 + c0172b6.f2120e;
            c0172b6.f2117b = this.f1974r.mo1411e(viewM1269Y0);
            iMo1417k = (-this.f1974r.mo1411e(viewM1269Y0)) + this.f1974r.mo1417k();
        }
        C0172b c0172b7 = this.f1973q;
        c0172b7.f2118c = i2;
        if (z) {
            c0172b7.f2118c = i2 - iMo1417k;
        }
        c0172b7.f2122g = iMo1417k;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: j */
    public final void mo1284j(int i, zo1 zo1Var) {
        boolean z;
        int i2;
        SavedState savedState = this.f1982z;
        if (savedState == null || (i2 = savedState.f1983e) < 0) {
            m1276e1();
            z = this.f1977u;
            i2 = this.f1980x;
            if (i2 == -1) {
                i2 = z ? i - 1 : 0;
            }
        } else {
            z = savedState.f1985y;
        }
        int i3 = z ? -1 : 1;
        for (int i4 = 0; i4 < this.f1970C && i2 >= 0 && i2 < i; i4++) {
            zo1Var.m21325a(i2, 0);
            i2 += i3;
        }
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0048  */
    /* JADX WARN: Code duplicated, block: B:21:0x0050  */
    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: j0 */
    public boolean mo1222j0(int i, Bundle bundle) {
        int iMin;
        SavedState savedState;
        if (super.mo1222j0(i, bundle)) {
            return true;
        }
        if (i == 16908343 && bundle != null) {
            if (this.f1972p == 1) {
                int i2 = bundle.getInt("android.view.accessibility.action.ARGUMENT_ROW_INT", -1);
                if (i2 >= 0) {
                    RecyclerView recyclerView = this.f2142b;
                    iMin = Math.min(i2, mo1206J(recyclerView.f2065y, recyclerView.f2000D0) - 1);
                    if (iMin >= 0) {
                        this.f1980x = iMin;
                        this.f1981y = 0;
                        savedState = this.f1982z;
                        if (savedState != null) {
                            savedState.f1983e = -1;
                        }
                        m1468r0();
                        return true;
                    }
                }
            } else {
                int i3 = bundle.getInt("android.view.accessibility.action.ARGUMENT_COLUMN_INT", -1);
                if (i3 >= 0) {
                    RecyclerView recyclerView2 = this.f2142b;
                    iMin = Math.min(i3, mo1246y(recyclerView2.f2065y, recyclerView2.f2000D0) - 1);
                    if (iMin >= 0) {
                        this.f1980x = iMin;
                        this.f1981y = 0;
                        savedState = this.f1982z;
                        if (savedState != null) {
                            savedState.f1983e = -1;
                        }
                        m1468r0();
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: j1 */
    public final void m1285j1(int i, int i2) {
        this.f1973q.f2118c = this.f1974r.mo1413g() - i2;
        C0172b c0172b = this.f1973q;
        c0172b.f2120e = this.f1977u ? -1 : 1;
        c0172b.f2119d = i;
        c0172b.f2121f = 1;
        c0172b.f2117b = i2;
        c0172b.f2122g = RtlSpacingHelper.UNDEFINED;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: k */
    public final int mo1286k(et8 et8Var) {
        return m1250I0(et8Var);
    }

    /* JADX INFO: renamed from: k1 */
    public final void m1287k1(int i, int i2) {
        this.f1973q.f2118c = i2 - this.f1974r.mo1417k();
        C0172b c0172b = this.f1973q;
        c0172b.f2119d = i;
        c0172b.f2120e = this.f1977u ? 1 : -1;
        c0172b.f2121f = -1;
        c0172b.f2117b = i2;
        c0172b.f2122g = RtlSpacingHelper.UNDEFINED;
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: l */
    public int mo1223l(et8 et8Var) {
        return m1251J0(et8Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: m */
    public int mo1225m(et8 et8Var) {
        return m1252K0(et8Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: n */
    public int mo1288n(et8 et8Var) {
        return m1250I0(et8Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: o */
    public int mo1228o(et8 et8Var) {
        return m1251J0(et8Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: p */
    public int mo1230p(et8 et8Var) {
        return m1252K0(et8Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: r */
    public final View mo1289r(int i) {
        int iM1471w = m1471w();
        if (iM1471w == 0) {
            return null;
        }
        int iM1441H = i - AbstractC0181k.m1441H(m1469v(0));
        if (iM1441H >= 0 && iM1441H < iM1471w) {
            View viewM1469v = m1469v(iM1441H);
            if (AbstractC0181k.m1441H(viewM1469v) == i) {
                return viewM1469v;
            }
        }
        return super.mo1289r(i);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: s */
    public RecyclerView.LayoutParams mo1234s() {
        return new RecyclerView.LayoutParams(-2, -2);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: s0 */
    public int mo1235s0(int i, et8 et8Var, C0182l c0182l) {
        if (this.f1972p == 1) {
            return 0;
        }
        return m1278f1(i, et8Var, c0182l);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: t0 */
    public final void mo1290t0(int i) {
        this.f1980x = i;
        this.f1981y = RtlSpacingHelper.UNDEFINED;
        SavedState savedState = this.f1982z;
        if (savedState != null) {
            savedState.f1983e = -1;
        }
        m1468r0();
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: u0 */
    public int mo1240u0(int i, et8 et8Var, C0182l c0182l) {
        if (this.f1972p == 0) {
            return 0;
        }
        return m1278f1(i, et8Var, c0182l);
    }

    @Override // androidx.recyclerview.widget.AbstractC0181k
    /* JADX INFO: renamed from: T */
    public final void mo1263T(RecyclerView recyclerView) {
    }

    public LinearLayoutManager(Context context, int i, boolean z) {
        this.f1972p = 1;
        this.f1976t = false;
        this.f1977u = false;
        this.f1978v = false;
        this.f1979w = true;
        this.f1980x = -1;
        this.f1981y = RtlSpacingHelper.UNDEFINED;
        this.f1982z = null;
        this.f1968A = new C0171a();
        this.f1969B = new ab6();
        this.f1970C = 2;
        this.f1971D = new int[2];
        m1280g1(i);
        mo1272c(null);
        if (z == this.f1976t) {
            return;
        }
        this.f1976t = z;
        m1468r0();
    }

    public LinearLayoutManager(Context context) {
        this(context, 1, false);
    }

    /* JADX INFO: renamed from: b1 */
    public void mo1215b1(C0182l c0182l, et8 et8Var, C0171a c0171a, int i) {
    }
}
