package androidx.recyclerview.widget;

import android.os.Trace;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import p000.C0631iv;
import p000.C1270p6;
import p000.C1307q6;
import p000.C1521v3;
import p000.at8;
import p000.cz9;
import p000.et8;
import p000.ht8;
import p000.jn8;
import p000.nxa;
import p000.obb;
import p000.pva;
import p000.rg1;
import p000.ro6;
import p000.rs8;
import p000.vf3;
import p000.z23;
import p000.z78;
import p000.z82;
import p000.zo1;
import p000.zs8;

/* JADX INFO: renamed from: androidx.recyclerview.widget.l */
/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public final class C0182l {

    /* JADX INFO: renamed from: a */
    public final ArrayList f2156a;

    /* JADX INFO: renamed from: b */
    public ArrayList f2157b;

    /* JADX INFO: renamed from: c */
    public final ArrayList f2158c;

    /* JADX INFO: renamed from: d */
    public final List f2159d;

    /* JADX INFO: renamed from: e */
    public final int f2160e;

    /* JADX INFO: renamed from: f */
    public int f2161f;

    /* JADX INFO: renamed from: g */
    public at8 f2162g;

    /* JADX INFO: renamed from: h */
    public final /* synthetic */ RecyclerView f2163h;

    public C0182l(RecyclerView recyclerView) {
        this.f2163h = recyclerView;
        ArrayList arrayList = new ArrayList();
        this.f2156a = arrayList;
        this.f2157b = null;
        this.f2158c = new ArrayList();
        this.f2159d = Collections.unmodifiableList(arrayList);
        this.f2160e = 2;
        this.f2161f = 2;
    }

    /* JADX INFO: renamed from: a */
    public final void m1476a(AbstractC0185o abstractC0185o, boolean z) {
        RecyclerView.m1299l(abstractC0185o);
        View view = abstractC0185o.f2181e;
        RecyclerView recyclerView = this.f2163h;
        ht8 ht8Var = recyclerView.f2012J0;
        if (ht8Var != null) {
            ht8 ht8Var2 = (ht8) ht8Var.f20299B;
            obb.m14621n(view, ht8Var2 != null ? (C1307q6) ((WeakHashMap) ht8Var2.f20299B).remove(view) : null);
        }
        if (z) {
            ArrayList arrayList = recyclerView.f2013K;
            if (arrayList.size() > 0) {
                z82.m21066E(arrayList.get(0));
                throw null;
            }
            AbstractC0177g abstractC0177g = recyclerView.f2009I;
            if (abstractC0177g != null) {
                abstractC0177g.mo1429h(abstractC0185o);
            }
            if (recyclerView.f2000D0 != null) {
                recyclerView.f1997C.m16193v(abstractC0185o);
            }
        }
        abstractC0185o.f2180O = null;
        abstractC0185o.f2179N = null;
        at8 at8VarM1478c = m1478c();
        at8VarM1478c.getClass();
        int i = abstractC0185o.f2167B;
        ArrayList arrayList2 = at8VarM1478c.m1844b(i).f50808a;
        if (((zs8) at8VarM1478c.f2837a.get(i)).f50809b <= arrayList2.size()) {
            z78.m21044d(view);
        } else {
            abstractC0185o.m1510o();
            arrayList2.add(abstractC0185o);
        }
    }

    /* JADX INFO: renamed from: b */
    public final int m1477b(int i) {
        RecyclerView recyclerView = this.f2163h;
        et8 et8Var = recyclerView.f2000D0;
        if (i >= 0 && i < et8Var.m7762b()) {
            return !et8Var.f13104g ? i : recyclerView.f1993A.m8168g(i, 0);
        }
        StringBuilder sbM20941w = z23.m20941w(i, "invalid position ", ". State item count is ");
        sbM20941w.append(et8Var.m7762b());
        sbM20941w.append(recyclerView.m1301A());
        throw new IndexOutOfBoundsException(sbM20941w.toString());
    }

    /* JADX INFO: renamed from: c */
    public final at8 m1478c() {
        if (this.f2162g == null) {
            this.f2162g = new at8();
            m1480e();
        }
        return this.f2162g;
    }

    /* JADX INFO: renamed from: d */
    public final View m1479d(int i) {
        return m1487l(i, Long.MAX_VALUE).f2181e;
    }

    /* JADX INFO: renamed from: e */
    public final void m1480e() {
        RecyclerView recyclerView;
        AbstractC0177g abstractC0177g;
        at8 at8Var = this.f2162g;
        if (at8Var == null || (abstractC0177g = (recyclerView = this.f2163h).f2009I) == null || !recyclerView.f2021O) {
            return;
        }
        at8Var.f2839c.add(abstractC0177g);
    }

    /* JADX INFO: renamed from: f */
    public final void m1481f(AbstractC0177g abstractC0177g, boolean z) {
        at8 at8Var = this.f2162g;
        if (at8Var != null) {
            SparseArray sparseArray = at8Var.f2837a;
            Set set = at8Var.f2839c;
            set.remove(abstractC0177g);
            if (set.size() != 0 || z) {
                return;
            }
            for (int i = 0; i < sparseArray.size(); i++) {
                ArrayList arrayList = ((zs8) sparseArray.get(sparseArray.keyAt(i))).f50808a;
                for (int i2 = 0; i2 < arrayList.size(); i2++) {
                    z78.m21044d(((AbstractC0185o) arrayList.get(i2)).f2181e);
                }
            }
        }
    }

    /* JADX INFO: renamed from: g */
    public final void m1482g() {
        ArrayList arrayList = this.f2158c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            m1483h(size);
        }
        arrayList.clear();
        if (RecyclerView.f1989a1) {
            zo1 zo1Var = this.f2163h.f1998C0;
            int[] iArr = (int[]) zo1Var.f50613d;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            zo1Var.f50612c = 0;
        }
    }

    /* JADX INFO: renamed from: h */
    public final void m1483h(int i) {
        int[] iArr = RecyclerView.f1986X0;
        ArrayList arrayList = this.f2158c;
        m1476a((AbstractC0185o) arrayList.get(i), true);
        arrayList.remove(i);
    }

    /* JADX INFO: renamed from: i */
    public final void m1484i(View view) {
        AbstractC0185o abstractC0185oM1292M = RecyclerView.m1292M(view);
        boolean zM1507l = abstractC0185oM1292M.m1507l();
        RecyclerView recyclerView = this.f2163h;
        if (zM1507l) {
            recyclerView.removeDetachedView(view, false);
        }
        if (abstractC0185oM1292M.m1506k()) {
            abstractC0185oM1292M.f2175J.m1488m(abstractC0185oM1292M);
        } else if (abstractC0185oM1292M.m1513r()) {
            abstractC0185oM1292M.f2171F &= -33;
        }
        m1485j(abstractC0185oM1292M);
        if (recyclerView.f2052l0 == null || abstractC0185oM1292M.m1504i()) {
            return;
        }
        recyclerView.f2052l0.mo6691m(abstractC0185oM1292M);
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0032  */
    /* JADX WARN: Code duplicated, block: B:41:0x007c  */
    /* JADX WARN: Code duplicated, block: B:43:0x008a  */
    /* JADX WARN: Code duplicated, block: B:45:0x0091  */
    /* JADX WARN: Code duplicated, block: B:48:0x009c A[LOOP:2: B:44:0x008f->B:48:0x009c, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:75:0x009f A[EDGE_INSN: B:75:0x009f->B:49:0x009f BREAK  A[LOOP:1: B:40:0x007a->B:47:0x0099], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:76:0x009f A[EDGE_INSN: B:76:0x009f->B:49:0x009f BREAK  A[LOOP:1: B:40:0x007a->B:47:0x0099, LOOP_LABEL: LOOP:1: B:40:0x007a->B:47:0x0099], SYNTHETIC] */
    /* JADX INFO: renamed from: j */
    public final void m1485j(AbstractC0185o abstractC0185o) {
        boolean z;
        boolean z2;
        int i;
        int i2;
        int i3;
        int i4;
        RecyclerView recyclerView = this.f2163h;
        zo1 zo1Var = recyclerView.f1998C0;
        boolean zM1506k = abstractC0185o.m1506k();
        View view = abstractC0185o.f2181e;
        boolean z3 = false;
        boolean z4 = true;
        if (zM1506k || view.getParent() != null) {
            StringBuilder sb = new StringBuilder("Scrapped or attached views may not be recycled. isScrap:");
            sb.append(abstractC0185o.m1506k());
            sb.append(" isAttached:");
            sb.append(view.getParent() != null);
            sb.append(recyclerView.m1301A());
            throw new IllegalArgumentException(sb.toString());
        }
        if (abstractC0185o.m1507l()) {
            StringBuilder sb2 = new StringBuilder("Tmp detached view should be removed from RecyclerView before it can be recycled: ");
            sb2.append(abstractC0185o);
            C1521v3.m18904k(sb2, recyclerView.m1301A());
            return;
        }
        if (abstractC0185o.m1512q()) {
            C1521v3.m18903j("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.".concat(recyclerView.m1301A()));
            return;
        }
        if ((abstractC0185o.f2171F & 16) == 0) {
            WeakHashMap weakHashMap = obb.f31348a;
            if (view.hasTransientState()) {
                z = true;
            } else {
                z = false;
            }
        } else {
            z = false;
        }
        int[] iArr = RecyclerView.f1986X0;
        if (abstractC0185o.m1504i()) {
            if (this.f2161f <= 0 || (abstractC0185o.f2171F & 526) != 0) {
                z2 = false;
            } else {
                ArrayList arrayList = this.f2158c;
                int size = arrayList.size();
                if (size >= this.f2161f && size > 0) {
                    m1483h(0);
                    size--;
                }
                if (RecyclerView.f1989a1 && size > 0) {
                    int i5 = abstractC0185o.f2183y;
                    if (((int[]) zo1Var.f50613d) != null) {
                        int i6 = zo1Var.f50612c * 2;
                        int i7 = 0;
                        while (true) {
                            if (i7 >= i6) {
                                i = size - 1;
                                loop1: while (i >= 0) {
                                    i2 = ((AbstractC0185o) arrayList.get(i)).f2183y;
                                    if (((int[]) zo1Var.f50613d) != null) {
                                        break;
                                    }
                                    i3 = zo1Var.f50612c * 2;
                                    i4 = 0;
                                    while (true) {
                                        if (i4 < i3) {
                                            break loop1;
                                        } else if (((int[]) zo1Var.f50613d)[i4] == i2) {
                                            break;
                                        } else {
                                            i4 += 2;
                                        }
                                    }
                                    i--;
                                }
                                size = i + 1;
                            } else if (((int[]) zo1Var.f50613d)[i7] != i5) {
                                i7 += 2;
                            }
                        }
                    } else {
                        i = size - 1;
                        loop1: while (i >= 0) {
                            i2 = ((AbstractC0185o) arrayList.get(i)).f2183y;
                            if (((int[]) zo1Var.f50613d) != null) {
                                break;
                                break;
                            }
                            i3 = zo1Var.f50612c * 2;
                            i4 = 0;
                            while (true) {
                                if (i4 < i3) {
                                    break loop1;
                                    break loop1;
                                } else if (((int[]) zo1Var.f50613d)[i4] == i2) {
                                    break;
                                } else {
                                    i4 += 2;
                                }
                            }
                            i--;
                        }
                        size = i + 1;
                    }
                }
                arrayList.add(size, abstractC0185o);
                z2 = true;
            }
            if (z2) {
                z4 = false;
            } else {
                m1476a(abstractC0185o, true);
            }
            z3 = z2;
        } else {
            z4 = false;
        }
        recyclerView.f1997C.m16193v(abstractC0185o);
        if (z3 || z4 || !z) {
            return;
        }
        z78.m21044d(view);
        abstractC0185o.f2180O = null;
        abstractC0185o.f2179N = null;
    }

    /* JADX INFO: renamed from: k */
    public final void m1486k(View view) {
        cz9 cz9Var;
        AbstractC0185o abstractC0185oM1292M = RecyclerView.m1292M(view);
        int i = abstractC0185oM1292M.f2171F & 12;
        RecyclerView recyclerView = this.f2163h;
        if (i == 0 && abstractC0185oM1292M.m1508m() && (cz9Var = recyclerView.f2052l0) != null && !cz9Var.mo6688j(abstractC0185oM1292M, abstractC0185oM1292M.m1500e())) {
            if (this.f2157b == null) {
                this.f2157b = new ArrayList();
            }
            abstractC0185oM1292M.f2175J = this;
            abstractC0185oM1292M.f2176K = true;
            this.f2157b.add(abstractC0185oM1292M);
            return;
        }
        if (abstractC0185oM1292M.m1503h() && !abstractC0185oM1292M.m1505j() && !recyclerView.f2009I.f2137b) {
            C1521v3.m18903j("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.".concat(recyclerView.m1301A()));
            return;
        }
        abstractC0185oM1292M.f2175J = this;
        abstractC0185oM1292M.f2176K = false;
        this.f2156a.add(abstractC0185oM1292M);
    }

    /* JADX WARN: Code duplicated, block: B:101:0x0195  */
    /* JADX WARN: Code duplicated, block: B:102:0x019a  */
    /* JADX WARN: Code duplicated, block: B:110:0x01b6  */
    /* JADX WARN: Code duplicated, block: B:117:0x01ce  */
    /* JADX WARN: Code duplicated, block: B:119:0x01d8  */
    /* JADX WARN: Code duplicated, block: B:120:0x01e3  */
    /* JADX WARN: Code duplicated, block: B:122:0x01e9  */
    /* JADX WARN: Code duplicated, block: B:124:0x01f4  */
    /* JADX WARN: Code duplicated, block: B:127:0x0212  */
    /* JADX WARN: Code duplicated, block: B:130:0x021d  */
    /* JADX WARN: Code duplicated, block: B:132:0x0225  */
    /* JADX WARN: Code duplicated, block: B:134:0x022f  */
    /* JADX WARN: Code duplicated, block: B:136:0x023d  */
    /* JADX WARN: Code duplicated, block: B:138:0x0249  */
    /* JADX WARN: Code duplicated, block: B:154:0x02a4  */
    /* JADX WARN: Code duplicated, block: B:165:0x02c9  */
    /* JADX WARN: Code duplicated, block: B:167:0x02d1  */
    /* JADX WARN: Code duplicated, block: B:169:0x02e1  */
    /* JADX WARN: Code duplicated, block: B:171:0x02e9  */
    /* JADX WARN: Code duplicated, block: B:173:0x02f1  */
    /* JADX WARN: Code duplicated, block: B:176:0x0304 A[LOOP:4: B:172:0x02ef->B:176:0x0304, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:177:0x0307 A[EDGE_INSN: B:177:0x0307->B:178:0x0308 BREAK  A[LOOP:4: B:172:0x02ef->B:176:0x0304]] */
    /* JADX WARN: Code duplicated, block: B:179:0x030a  */
    /* JADX WARN: Code duplicated, block: B:182:0x0312  */
    /* JADX WARN: Code duplicated, block: B:184:0x031a  */
    /* JADX WARN: Code duplicated, block: B:190:0x032e  */
    /* JADX WARN: Code duplicated, block: B:192:0x0332 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:197:0x0340 A[Catch: all -> 0x0399, TryCatch #0 {all -> 0x0399, blocks: (B:195:0x033a, B:197:0x0340, B:198:0x0351, B:200:0x035d, B:211:0x0391, B:212:0x0398), top: B:332:0x033a }] */
    /* JADX WARN: Code duplicated, block: B:200:0x035d A[Catch: all -> 0x0399, TRY_LEAVE, TryCatch #0 {all -> 0x0399, blocks: (B:195:0x033a, B:197:0x0340, B:198:0x0351, B:200:0x035d, B:211:0x0391, B:212:0x0398), top: B:332:0x033a }] */
    /* JADX WARN: Code duplicated, block: B:209:0x0387  */
    /* JADX WARN: Code duplicated, block: B:211:0x0391 A[Catch: all -> 0x0399, TRY_ENTER, TryCatch #0 {all -> 0x0399, blocks: (B:195:0x033a, B:197:0x0340, B:198:0x0351, B:200:0x035d, B:211:0x0391, B:212:0x0398), top: B:332:0x033a }] */
    /* JADX WARN: Code duplicated, block: B:218:0x03c1  */
    /* JADX WARN: Code duplicated, block: B:225:0x03d3  */
    /* JADX WARN: Code duplicated, block: B:226:0x03d6  */
    /* JADX WARN: Code duplicated, block: B:228:0x03d9  */
    /* JADX WARN: Code duplicated, block: B:230:0x03e1  */
    /* JADX WARN: Code duplicated, block: B:236:0x0404  */
    /* JADX WARN: Code duplicated, block: B:238:0x040a  */
    /* JADX WARN: Code duplicated, block: B:240:0x0410  */
    /* JADX WARN: Code duplicated, block: B:241:0x0413  */
    /* JADX WARN: Code duplicated, block: B:243:0x0416  */
    /* JADX WARN: Code duplicated, block: B:249:0x043a  */
    /* JADX WARN: Code duplicated, block: B:251:0x0446  */
    /* JADX WARN: Code duplicated, block: B:255:0x0451  */
    /* JADX WARN: Code duplicated, block: B:257:0x0457  */
    /* JADX WARN: Code duplicated, block: B:258:0x0465  */
    /* JADX WARN: Code duplicated, block: B:261:0x046f  */
    /* JADX WARN: Code duplicated, block: B:262:0x0472  */
    /* JADX WARN: Code duplicated, block: B:264:0x0475  */
    /* JADX WARN: Code duplicated, block: B:266:0x047b  */
    /* JADX WARN: Code duplicated, block: B:269:0x048f  */
    /* JADX WARN: Code duplicated, block: B:272:0x04ad  */
    /* JADX WARN: Code duplicated, block: B:274:0x04b1  */
    /* JADX WARN: Code duplicated, block: B:277:0x04c2  */
    /* JADX WARN: Code duplicated, block: B:280:0x04cd  */
    /* JADX WARN: Code duplicated, block: B:284:0x04e4  */
    /* JADX WARN: Code duplicated, block: B:287:0x04f1  */
    /* JADX WARN: Code duplicated, block: B:290:0x04f9  */
    /* JADX WARN: Code duplicated, block: B:292:0x04fc  */
    /* JADX WARN: Code duplicated, block: B:294:0x0503  */
    /* JADX WARN: Code duplicated, block: B:298:0x050b  */
    /* JADX WARN: Code duplicated, block: B:300:0x0511  */
    /* JADX WARN: Code duplicated, block: B:302:0x0517  */
    /* JADX WARN: Code duplicated, block: B:303:0x0519  */
    /* JADX WARN: Code duplicated, block: B:305:0x051d  */
    /* JADX WARN: Code duplicated, block: B:306:0x0522  */
    /* JADX WARN: Code duplicated, block: B:308:0x052a A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:311:0x0537  */
    /* JADX WARN: Code duplicated, block: B:314:0x053c  */
    /* JADX WARN: Code duplicated, block: B:318:0x0545  */
    /* JADX WARN: Code duplicated, block: B:319:0x054f  */
    /* JADX WARN: Code duplicated, block: B:321:0x0555  */
    /* JADX WARN: Code duplicated, block: B:322:0x055f  */
    /* JADX WARN: Code duplicated, block: B:325:0x0565 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:327:0x0568  */
    /* JADX WARN: Code duplicated, block: B:339:0x00bd A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:344:0x029a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:349:0x02c2 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:353:0x0307 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:354:0x02fd A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:355:0x00ec A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:35:0x007c A[EDGE_INSN: B:35:0x007c->B:36:0x007d BREAK  A[LOOP:0: B:14:0x0024->B:20:0x003e]] */
    /* JADX WARN: Code duplicated, block: B:360:0x018c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:42:0x0089  */
    /* JADX WARN: Code duplicated, block: B:44:0x0090  */
    /* JADX WARN: Code duplicated, block: B:58:0x00ca  */
    /* JADX WARN: Code duplicated, block: B:68:0x00f1  */
    /* JADX WARN: Code duplicated, block: B:70:0x0107  */
    /* JADX WARN: Code duplicated, block: B:72:0x010d  */
    /* JADX WARN: Code duplicated, block: B:77:0x012d  */
    /* JADX WARN: Code duplicated, block: B:80:0x0136 A[EDGE_INSN: B:80:0x0136->B:98:0x018d BREAK  A[LOOP:1: B:43:0x008e->B:55:0x00ba]] */
    /* JADX WARN: Code duplicated, block: B:81:0x0145  */
    /* JADX WARN: Code duplicated, block: B:83:0x0157  */
    /* JADX WARN: Code duplicated, block: B:85:0x015d  */
    /* JADX WARN: Code duplicated, block: B:87:0x0163  */
    /* JADX WARN: Code duplicated, block: B:89:0x016a  */
    /* JADX WARN: Code duplicated, block: B:99:0x018f  */
    /* JADX INFO: renamed from: l */
    public final AbstractC0185o m1487l(int i, long j) {
        AbstractC0185o abstractC0185oMo1428g;
        boolean z;
        ArrayList arrayList;
        ArrayList arrayList2;
        boolean z2;
        long j2;
        long j3;
        View view;
        int iM8168g;
        int i2;
        long jM1313O;
        boolean z3;
        AbstractC0177g abstractC0177g;
        boolean z4;
        long jM1313O2;
        long j4;
        AccessibilityManager accessibilityManager;
        boolean z5;
        boolean z6;
        boolean z7;
        ht8 ht8Var;
        ht8 ht8Var2;
        View.AccessibilityDelegate accessibilityDelegateM14611d;
        C1307q6 c1307q6;
        ArrayList arrayList3;
        ViewGroup.LayoutParams layoutParams;
        long j5;
        boolean z8;
        ViewGroup.LayoutParams layoutParams2;
        RecyclerView.LayoutParams layoutParams3;
        int i3;
        boolean z9;
        int iM8168g2;
        int iMo1424c;
        AbstractC0177g abstractC0177g2;
        long jM1313O3;
        long jM1313O4;
        long j6;
        RecyclerView recyclerViewM1291G;
        long j7;
        boolean z10;
        zs8 zs8Var;
        AbstractC0185o abstractC0185o;
        ArrayList arrayList4;
        int size;
        long jMo1423b;
        int size2;
        int i4;
        int size3;
        AbstractC0185o abstractC0185o2;
        long j8;
        int size4;
        int i5;
        ArrayList arrayList5;
        int size5;
        int i6;
        View view2;
        int size6;
        int i7;
        AbstractC0185o abstractC0185o3;
        AbstractC0185o abstractC0185oM1292M;
        rg1 rg1Var;
        C0631iv c0631iv;
        int iIndexOfChild;
        C0631iv c0631iv2;
        int iIndexOfChild2;
        int iM10919c;
        AbstractC0185o abstractC0185oM1292M2;
        int i8;
        boolean z11;
        AbstractC0185o abstractC0185o4;
        int size7;
        int iM8168g3;
        RecyclerView recyclerView = this.f2163h;
        et8 et8Var = recyclerView.f2000D0;
        if (i < 0 || i >= et8Var.m7762b()) {
            StringBuilder sbM20940v = z23.m20940v(i, i, "Invalid item position ", "(", "). Item count:");
            sbM20940v.append(et8Var.m7762b());
            sbM20940v.append(recyclerView.m1301A());
            throw new IndexOutOfBoundsException(sbM20940v.toString());
        }
        if (et8Var.f13104g) {
            ArrayList arrayList6 = this.f2157b;
            if (arrayList6 != null && (size7 = arrayList6.size()) != 0) {
                int i9 = 0;
                while (true) {
                    if (i9 >= size7) {
                        if (recyclerView.f2009I.f2137b && (iM8168g3 = recyclerView.f1993A.m8168g(i, 0)) > 0 && iM8168g3 < recyclerView.f2009I.mo1422a()) {
                            long jMo1423b2 = recyclerView.f2009I.mo1423b(iM8168g3);
                            int i10 = 0;
                            while (true) {
                                if (i10 >= size7) {
                                    abstractC0185oMo1428g = null;
                                    break;
                                }
                                AbstractC0185o abstractC0185o5 = (AbstractC0185o) this.f2157b.get(i10);
                                if (!abstractC0185o5.m1513r() && abstractC0185o5.f2166A == jMo1423b2) {
                                    abstractC0185o5.m1496a(32);
                                    abstractC0185oMo1428g = abstractC0185o5;
                                    break;
                                }
                                i10++;
                            }
                        } else {
                            abstractC0185oMo1428g = null;
                            break;
                        }
                    } else {
                        abstractC0185oMo1428g = (AbstractC0185o) this.f2157b.get(i9);
                        if (!abstractC0185oMo1428g.m1513r() && abstractC0185oMo1428g.m1499d() == i) {
                            abstractC0185oMo1428g.m1496a(32);
                            break;
                        }
                        i9++;
                    }
                }
            } else {
                abstractC0185oMo1428g = null;
                break;
            }
            if (abstractC0185oMo1428g != null) {
                z = true;
            }
            arrayList = this.f2156a;
            arrayList2 = this.f2158c;
            if (abstractC0185oMo1428g == null) {
                size4 = arrayList.size();
                i5 = 0;
                while (true) {
                    if (i5 < size4) {
                        arrayList5 = (ArrayList) recyclerView.f1995B.f36499e;
                        size5 = arrayList5.size();
                        i6 = 0;
                        while (true) {
                            if (i6 < size5) {
                                z2 = true;
                                view2 = null;
                                break;
                            }
                            view2 = (View) arrayList5.get(i6);
                            abstractC0185oM1292M2 = RecyclerView.m1292M(view2);
                            z2 = true;
                            if (abstractC0185oM1292M2.m1499d() != i && !abstractC0185oM1292M2.m1503h() && !abstractC0185oM1292M2.m1505j()) {
                                break;
                            }
                            i6++;
                        }
                        if (view2 != null) {
                            size6 = arrayList2.size();
                            i7 = 0;
                            while (true) {
                                if (i7 < size6) {
                                    abstractC0185oMo1428g = null;
                                    break;
                                }
                                abstractC0185o3 = (AbstractC0185o) arrayList2.get(i7);
                                if (abstractC0185o3.m1503h() && abstractC0185o3.m1499d() == i && !abstractC0185o3.m1501f()) {
                                    arrayList2.remove(i7);
                                    int[] iArr = RecyclerView.f1986X0;
                                    abstractC0185oMo1428g = abstractC0185o3;
                                    break;
                                }
                                i7++;
                            }
                        } else {
                            abstractC0185oM1292M = RecyclerView.m1292M(view2);
                            rg1Var = recyclerView.f1995B;
                            c0631iv = (C0631iv) rg1Var.f36498d;
                            iIndexOfChild = ((rs8) rg1Var.f36497c).f37241e.indexOfChild(view2);
                            if (iIndexOfChild >= 0) {
                                ro6.m16614y(view2, "view is not a child, cannot hide ");
                                return null;
                            }
                            if (c0631iv.m10922f(iIndexOfChild)) {
                                vf3.m19098p(view2, "trying to unhide a view that was not hidden");
                                return null;
                            }
                            c0631iv.m10918b(iIndexOfChild);
                            rg1Var.m16523r(view2);
                            rg1 rg1Var2 = recyclerView.f1995B;
                            c0631iv2 = (C0631iv) rg1Var2.f36498d;
                            iIndexOfChild2 = ((rs8) rg1Var2.f36497c).f37241e.indexOfChild(view2);
                            if (iIndexOfChild2 == -1 && !c0631iv2.m10922f(iIndexOfChild2)) {
                                iM10919c = iIndexOfChild2 - c0631iv2.m10919c(iIndexOfChild2);
                            } else {
                                iM10919c = -1;
                            }
                            if (iM10919c != -1) {
                                StringBuilder sb = new StringBuilder("layout index should not be -1 after unhiding a view:");
                                sb.append(abstractC0185oM1292M);
                                nxa.m14380e(sb, recyclerView.m1301A());
                                return null;
                            }
                            recyclerView.f1995B.m16510c(iM10919c);
                            m1486k(view2);
                            abstractC0185oM1292M.m1496a(8224);
                            abstractC0185oMo1428g = abstractC0185oM1292M;
                            break;
                        }
                    } else {
                        abstractC0185o4 = (AbstractC0185o) arrayList.get(i5);
                        if (abstractC0185o4.m1513r() && abstractC0185o4.m1499d() == i && !abstractC0185o4.m1503h() && (et8Var.f13104g || !abstractC0185o4.m1505j())) {
                            abstractC0185o4.m1496a(32);
                            abstractC0185oMo1428g = abstractC0185o4;
                            z2 = true;
                            break;
                        }
                        i5++;
                    }
                }
                if (abstractC0185oMo1428g != null) {
                    if (!abstractC0185oMo1428g.m1505j()) {
                        int[] iArr2 = RecyclerView.f1986X0;
                        z11 = et8Var.f13104g;
                    } else {
                        i8 = abstractC0185oMo1428g.f2183y;
                        if (i8 >= 0 || i8 >= recyclerView.f2009I.mo1422a()) {
                            throw new IndexOutOfBoundsException("Inconsistency detected. Invalid view holder adapter position" + abstractC0185oMo1428g + recyclerView.m1301A());
                        }
                        if (et8Var.f13104g || recyclerView.f2009I.mo1424c(abstractC0185oMo1428g.f2183y) == abstractC0185oMo1428g.f2167B) {
                            AbstractC0177g abstractC0177g3 = recyclerView.f2009I;
                            if (!abstractC0177g3.f2137b || abstractC0185oMo1428g.f2166A == abstractC0177g3.mo1423b(abstractC0185oMo1428g.f2183y)) {
                                z11 = z2;
                            } else {
                                z11 = false;
                            }
                        } else {
                            z11 = false;
                        }
                    }
                    if (z11) {
                        z = z2;
                    } else {
                        abstractC0185oMo1428g.m1496a(4);
                        if (abstractC0185oMo1428g.m1506k()) {
                            recyclerView.removeDetachedView(abstractC0185oMo1428g.f2181e, false);
                            abstractC0185oMo1428g.f2175J.m1488m(abstractC0185oMo1428g);
                        } else if (abstractC0185oMo1428g.m1513r()) {
                            abstractC0185oMo1428g.f2171F &= -33;
                        }
                        m1485j(abstractC0185oMo1428g);
                        abstractC0185oMo1428g = null;
                    }
                }
            } else {
                z2 = true;
            }
            if (abstractC0185oMo1428g == null) {
                iM8168g2 = recyclerView.f1993A.m8168g(i, 0);
                if (iM8168g2 >= 0) {
                    j2 = 3;
                    if (iM8168g2 < recyclerView.f2009I.mo1422a()) {
                        iMo1424c = recyclerView.f2009I.mo1424c(iM8168g2);
                        abstractC0177g2 = recyclerView.f2009I;
                        j3 = 4;
                        if (abstractC0177g2.f2137b) {
                            jMo1423b = abstractC0177g2.mo1423b(iM8168g2);
                            size2 = arrayList.size() - 1;
                            while (true) {
                                if (size2 >= 0) {
                                    i4 = iM8168g2;
                                    size3 = arrayList2.size() - 1;
                                    while (true) {
                                        if (size3 >= 0) {
                                            abstractC0185o2 = (AbstractC0185o) arrayList2.get(size3);
                                            if (abstractC0185o2.f2166A == jMo1423b || abstractC0185o2.m1501f()) {
                                                size3--;
                                            } else {
                                                if (iMo1424c == abstractC0185o2.f2167B) {
                                                    arrayList2.remove(size3);
                                                    abstractC0185oMo1428g = abstractC0185o2;
                                                    break;
                                                }
                                                m1483h(size3);
                                            }
                                        }
                                        abstractC0185oMo1428g = null;
                                        break;
                                    }
                                }
                                AbstractC0185o abstractC0185o6 = (AbstractC0185o) arrayList.get(size2);
                                i4 = iM8168g2;
                                j8 = abstractC0185o6.f2166A;
                                View view3 = abstractC0185o6.f2181e;
                                if (j8 != jMo1423b && !abstractC0185o6.m1513r()) {
                                    if (iMo1424c == abstractC0185o6.f2167B) {
                                        abstractC0185o6.m1496a(32);
                                        if (abstractC0185o6.m1505j() && !et8Var.f13104g) {
                                            abstractC0185o6.f2171F = (abstractC0185o6.f2171F & (-15)) | 2;
                                        }
                                        abstractC0185oMo1428g = abstractC0185o6;
                                        break;
                                    }
                                    arrayList.remove(size2);
                                    recyclerView.removeDetachedView(view3, false);
                                    AbstractC0185o abstractC0185oM1292M3 = RecyclerView.m1292M(view3);
                                    abstractC0185oM1292M3.f2175J = null;
                                    abstractC0185oM1292M3.f2176K = false;
                                    abstractC0185oM1292M3.f2171F &= -33;
                                    m1485j(abstractC0185oM1292M3);
                                }
                                size2--;
                                iM8168g2 = i4;
                            }
                            if (abstractC0185oMo1428g != null) {
                                abstractC0185oMo1428g.f2183y = i4;
                                z = z2;
                            }
                        }
                        if (abstractC0185oMo1428g == null) {
                            int[] iArr3 = RecyclerView.f1986X0;
                            zs8Var = (zs8) m1478c().f2837a.get(iMo1424c);
                            if (zs8Var != null) {
                                abstractC0185o = null;
                                break;
                            }
                            arrayList4 = zs8Var.f50808a;
                            if (arrayList4.isEmpty()) {
                                size = arrayList4.size() - 1;
                                while (true) {
                                    if (size >= 0) {
                                        abstractC0185o = null;
                                        break;
                                    }
                                    if (!((AbstractC0185o) arrayList4.get(size)).m1501f()) {
                                        abstractC0185o = (AbstractC0185o) arrayList4.remove(size);
                                        break;
                                    }
                                    size--;
                                }
                            } else {
                                abstractC0185o = null;
                                break;
                            }
                            if (abstractC0185o != null) {
                                abstractC0185o.m1510o();
                                int[] iArr4 = RecyclerView.f1986X0;
                            }
                            abstractC0185oMo1428g = abstractC0185o;
                        }
                        if (abstractC0185oMo1428g == null) {
                            jM1313O3 = recyclerView.m1313O();
                            if (j != Long.MAX_VALUE) {
                                j7 = this.f2162g.m1844b(iMo1424c).f50810c;
                                if (j7 != 0 || j7 + jM1313O3 < j) {
                                    z10 = z2;
                                } else {
                                    z10 = false;
                                }
                                if (!z10) {
                                    return null;
                                }
                            }
                            AbstractC0177g abstractC0177g4 = recyclerView.f2009I;
                            abstractC0177g4.getClass();
                            try {
                                if (pva.m15556a()) {
                                    Trace.beginSection(String.format("RV onCreateViewHolder type=0x%X", Integer.valueOf(iMo1424c)));
                                }
                                abstractC0185oMo1428g = abstractC0177g4.mo1428g(recyclerView, iMo1424c);
                                if (abstractC0185oMo1428g.f2181e.getParent() == null) {
                                    throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
                                }
                                abstractC0185oMo1428g.f2167B = iMo1424c;
                                Trace.endSection();
                                if (RecyclerView.f1989a1 && (recyclerViewM1291G = RecyclerView.m1291G(abstractC0185oMo1428g.f2181e)) != null) {
                                    abstractC0185oMo1428g.f2182i = new WeakReference(recyclerViewM1291G);
                                }
                                jM1313O4 = recyclerView.m1313O() - jM1313O3;
                                zs8 zs8VarM1844b = this.f2162g.m1844b(iMo1424c);
                                j6 = zs8VarM1844b.f50810c;
                                if (j6 != 0) {
                                    jM1313O4 = (jM1313O4 / 4) + ((j6 / 4) * 3);
                                }
                                zs8VarM1844b.f50810c = jM1313O4;
                            } catch (Throwable th) {
                                Trace.endSection();
                                throw th;
                            }
                        }
                    }
                }
                StringBuilder sbM20940v2 = z23.m20940v(i, iM8168g2, "Inconsistency detected. Invalid item position ", "(offset:", ").state:");
                sbM20940v2.append(et8Var.m7762b());
                sbM20940v2.append(recyclerView.m1301A());
                throw new IndexOutOfBoundsException(sbM20940v2.toString());
            }
            j2 = 3;
            j3 = 4;
            view = abstractC0185oMo1428g.f2181e;
            if (z && !et8Var.f13104g) {
                i3 = abstractC0185oMo1428g.f2171F;
                if ((i3 & 8192) != 0) {
                    z9 = z2;
                } else {
                    z9 = false;
                }
                if (z9) {
                    abstractC0185oMo1428g.f2171F = i3 & (-8193);
                    if (et8Var.f13107j) {
                        cz9.m6679i(abstractC0185oMo1428g);
                        cz9 cz9Var = recyclerView.f2052l0;
                        abstractC0185oMo1428g.m1500e();
                        cz9Var.getClass();
                        jn8 jn8Var = new jn8();
                        jn8Var.m11479k(abstractC0185oMo1428g);
                        recyclerView.m1326b0(abstractC0185oMo1428g, jn8Var);
                    }
                }
            }
            if (et8Var.f13104g || !abstractC0185oMo1428g.m1502g()) {
                if (abstractC0185oMo1428g.m1502g()) {
                    if ((abstractC0185oMo1428g.f2171F & 2) != 0) {
                        z8 = z2;
                    } else {
                        z8 = false;
                    }
                    if (!z8 || abstractC0185oMo1428g.m1503h()) {
                    }
                    layoutParams2 = view.getLayoutParams();
                    if (layoutParams2 == null) {
                        layoutParams3 = (RecyclerView.LayoutParams) recyclerView.generateDefaultLayoutParams();
                        view.setLayoutParams(layoutParams3);
                    } else if (recyclerView.checkLayoutParams(layoutParams2)) {
                        layoutParams3 = (RecyclerView.LayoutParams) layoutParams2;
                    } else {
                        layoutParams3 = (RecyclerView.LayoutParams) recyclerView.generateLayoutParams(layoutParams2);
                        view.setLayoutParams(layoutParams3);
                    }
                    layoutParams3.f2069a = abstractC0185oMo1428g;
                    if (z || !z7) {
                        z6 = false;
                    }
                    layoutParams3.f2072d = z6;
                    return abstractC0185oMo1428g;
                }
                int[] iArr5 = RecyclerView.f1986X0;
                iM8168g = recyclerView.f1993A.m8168g(i, 0);
                abstractC0185oMo1428g.f2180O = null;
                abstractC0185oMo1428g.f2179N = recyclerView;
                i2 = abstractC0185oMo1428g.f2167B;
                jM1313O = recyclerView.m1313O();
                if (j != Long.MAX_VALUE) {
                    j5 = this.f2162g.m1844b(i2).f50811d;
                    if (j5 != 0 || j5 + jM1313O < j) {
                        if (abstractC0185oMo1428g.m1507l()) {
                            recyclerView.attachViewToParent(view, recyclerView.getChildCount(), view.getLayoutParams());
                            z3 = z2;
                        } else {
                            z3 = false;
                        }
                        abstractC0177g = recyclerView.f2009I;
                        abstractC0177g.getClass();
                        if (abstractC0185oMo1428g.f2180O == null) {
                            z4 = z2;
                        } else {
                            z4 = false;
                        }
                        if (z4) {
                            abstractC0185oMo1428g.f2183y = iM8168g;
                            if (abstractC0177g.f2137b) {
                                abstractC0185oMo1428g.f2166A = abstractC0177g.mo1423b(iM8168g);
                            }
                            abstractC0185oMo1428g.f2171F = (abstractC0185oMo1428g.f2171F & (-520)) | 1;
                            if (pva.m15556a()) {
                                Trace.beginSection(String.format("RV onBindViewHolder type=0x%X", Integer.valueOf(abstractC0185oMo1428g.f2167B)));
                            }
                        }
                        abstractC0185oMo1428g.f2180O = abstractC0177g;
                        abstractC0177g.mo1427f(abstractC0185oMo1428g, iM8168g, abstractC0185oMo1428g.m1500e());
                        if (z4) {
                            arrayList3 = abstractC0185oMo1428g.f2172G;
                            if (arrayList3 != null) {
                                arrayList3.clear();
                            }
                            abstractC0185oMo1428g.f2171F &= -1025;
                            layoutParams = view.getLayoutParams();
                            if (layoutParams instanceof RecyclerView.LayoutParams) {
                                ((RecyclerView.LayoutParams) layoutParams).f2071c = z2;
                            }
                            Trace.endSection();
                        }
                        if (z3) {
                            recyclerView.detachViewFromParent(view);
                        }
                        jM1313O2 = recyclerView.m1313O() - jM1313O;
                        zs8 zs8VarM1844b2 = this.f2162g.m1844b(abstractC0185oMo1428g.f2167B);
                        j4 = zs8VarM1844b2.f50811d;
                        if (j4 != 0) {
                            jM1313O2 = (jM1313O2 / j3) + ((j4 / j3) * j2);
                        }
                        zs8VarM1844b2.f50811d = jM1313O2;
                        accessibilityManager = recyclerView.f2039a0;
                        if (accessibilityManager == null && accessibilityManager.isEnabled()) {
                            z5 = true;
                        } else {
                            z5 = false;
                        }
                        if (z5) {
                            z6 = true;
                            if (view.getImportantForAccessibility() == 0) {
                                view.setImportantForAccessibility(1);
                            }
                            ht8Var = recyclerView.f2012J0;
                            if (ht8Var != null) {
                                ht8Var2 = (ht8) ht8Var.f20299B;
                                if (ht8Var2 != null) {
                                    accessibilityDelegateM14611d = obb.m14611d(view);
                                    if (accessibilityDelegateM14611d == null) {
                                        c1307q6 = null;
                                    } else if (accessibilityDelegateM14611d instanceof C1270p6) {
                                        c1307q6 = ((C1270p6) accessibilityDelegateM14611d).f32788a;
                                    } else {
                                        c1307q6 = new C1307q6(accessibilityDelegateM14611d);
                                    }
                                    if (c1307q6 != null && c1307q6 != ht8Var2) {
                                        ((WeakHashMap) ht8Var2.f20299B).put(view, c1307q6);
                                    }
                                }
                                obb.m14621n(view, ht8Var2);
                            }
                        } else {
                            z6 = true;
                        }
                        if (et8Var.f13104g) {
                            abstractC0185oMo1428g.f2168C = i;
                        }
                        z7 = z6;
                    } else {
                        z7 = false;
                        z6 = z2;
                    }
                } else {
                    if (abstractC0185oMo1428g.m1507l()) {
                        recyclerView.attachViewToParent(view, recyclerView.getChildCount(), view.getLayoutParams());
                        z3 = z2;
                    } else {
                        z3 = false;
                    }
                    abstractC0177g = recyclerView.f2009I;
                    abstractC0177g.getClass();
                    if (abstractC0185oMo1428g.f2180O == null) {
                        z4 = z2;
                    } else {
                        z4 = false;
                    }
                    if (z4) {
                        abstractC0185oMo1428g.f2183y = iM8168g;
                        if (abstractC0177g.f2137b) {
                            abstractC0185oMo1428g.f2166A = abstractC0177g.mo1423b(iM8168g);
                        }
                        abstractC0185oMo1428g.f2171F = (abstractC0185oMo1428g.f2171F & (-520)) | 1;
                        if (pva.m15556a()) {
                            Trace.beginSection(String.format("RV onBindViewHolder type=0x%X", Integer.valueOf(abstractC0185oMo1428g.f2167B)));
                        }
                    }
                    abstractC0185oMo1428g.f2180O = abstractC0177g;
                    abstractC0177g.mo1427f(abstractC0185oMo1428g, iM8168g, abstractC0185oMo1428g.m1500e());
                    if (z4) {
                        arrayList3 = abstractC0185oMo1428g.f2172G;
                        if (arrayList3 != null) {
                            arrayList3.clear();
                        }
                        abstractC0185oMo1428g.f2171F &= -1025;
                        layoutParams = view.getLayoutParams();
                        if (layoutParams instanceof RecyclerView.LayoutParams) {
                            ((RecyclerView.LayoutParams) layoutParams).f2071c = z2;
                        }
                        Trace.endSection();
                    }
                    if (z3) {
                        recyclerView.detachViewFromParent(view);
                    }
                    jM1313O2 = recyclerView.m1313O() - jM1313O;
                    zs8 zs8VarM1844b3 = this.f2162g.m1844b(abstractC0185oMo1428g.f2167B);
                    j4 = zs8VarM1844b3.f50811d;
                    if (j4 != 0) {
                        jM1313O2 = (jM1313O2 / j3) + ((j4 / j3) * j2);
                    }
                    zs8VarM1844b3.f50811d = jM1313O2;
                    accessibilityManager = recyclerView.f2039a0;
                    if (accessibilityManager == null) {
                        z5 = false;
                    } else {
                        z5 = false;
                    }
                    if (z5) {
                        z6 = true;
                        if (view.getImportantForAccessibility() == 0) {
                            view.setImportantForAccessibility(1);
                        }
                        ht8Var = recyclerView.f2012J0;
                        if (ht8Var != null) {
                            ht8Var2 = (ht8) ht8Var.f20299B;
                            if (ht8Var2 != null) {
                                accessibilityDelegateM14611d = obb.m14611d(view);
                                if (accessibilityDelegateM14611d == null) {
                                    c1307q6 = null;
                                } else if (accessibilityDelegateM14611d instanceof C1270p6) {
                                    c1307q6 = ((C1270p6) accessibilityDelegateM14611d).f32788a;
                                } else {
                                    c1307q6 = new C1307q6(accessibilityDelegateM14611d);
                                }
                                if (c1307q6 != null) {
                                    ((WeakHashMap) ht8Var2.f20299B).put(view, c1307q6);
                                }
                            }
                            obb.m14621n(view, ht8Var2);
                        }
                    } else {
                        z6 = true;
                    }
                    if (et8Var.f13104g) {
                        abstractC0185oMo1428g.f2168C = i;
                    }
                    z7 = z6;
                }
                layoutParams2 = view.getLayoutParams();
                if (layoutParams2 == null) {
                    layoutParams3 = (RecyclerView.LayoutParams) recyclerView.generateDefaultLayoutParams();
                    view.setLayoutParams(layoutParams3);
                } else if (recyclerView.checkLayoutParams(layoutParams2)) {
                    layoutParams3 = (RecyclerView.LayoutParams) recyclerView.generateLayoutParams(layoutParams2);
                    view.setLayoutParams(layoutParams3);
                } else {
                    layoutParams3 = (RecyclerView.LayoutParams) layoutParams2;
                }
                layoutParams3.f2069a = abstractC0185oMo1428g;
                if (z) {
                    z6 = false;
                } else {
                    z6 = false;
                }
                layoutParams3.f2072d = z6;
                return abstractC0185oMo1428g;
            }
            abstractC0185oMo1428g.f2168C = i;
            z6 = z2;
            z7 = false;
            layoutParams2 = view.getLayoutParams();
            if (layoutParams2 == null) {
                layoutParams3 = (RecyclerView.LayoutParams) recyclerView.generateDefaultLayoutParams();
                view.setLayoutParams(layoutParams3);
            } else if (recyclerView.checkLayoutParams(layoutParams2)) {
                layoutParams3 = (RecyclerView.LayoutParams) recyclerView.generateLayoutParams(layoutParams2);
                view.setLayoutParams(layoutParams3);
            } else {
                layoutParams3 = (RecyclerView.LayoutParams) layoutParams2;
            }
            layoutParams3.f2069a = abstractC0185oMo1428g;
            if (z) {
                z6 = false;
            } else {
                z6 = false;
            }
            layoutParams3.f2072d = z6;
            return abstractC0185oMo1428g;
        }
        abstractC0185oMo1428g = null;
        z = false;
        arrayList = this.f2156a;
        arrayList2 = this.f2158c;
        if (abstractC0185oMo1428g == null) {
            size4 = arrayList.size();
            i5 = 0;
            while (true) {
                if (i5 < size4) {
                    arrayList5 = (ArrayList) recyclerView.f1995B.f36499e;
                    size5 = arrayList5.size();
                    i6 = 0;
                    while (true) {
                        if (i6 < size5) {
                            z2 = true;
                            view2 = null;
                            break;
                        }
                        view2 = (View) arrayList5.get(i6);
                        abstractC0185oM1292M2 = RecyclerView.m1292M(view2);
                        z2 = true;
                        if (abstractC0185oM1292M2.m1499d() != i) {
                        }
                        i6++;
                    }
                    if (view2 != null) {
                        size6 = arrayList2.size();
                        i7 = 0;
                        while (true) {
                            if (i7 < size6) {
                                abstractC0185oMo1428g = null;
                                break;
                            }
                            abstractC0185o3 = (AbstractC0185o) arrayList2.get(i7);
                            if (abstractC0185o3.m1503h()) {
                            }
                            i7++;
                        }
                    } else {
                        abstractC0185oM1292M = RecyclerView.m1292M(view2);
                        rg1Var = recyclerView.f1995B;
                        c0631iv = (C0631iv) rg1Var.f36498d;
                        iIndexOfChild = ((rs8) rg1Var.f36497c).f37241e.indexOfChild(view2);
                        if (iIndexOfChild >= 0) {
                            ro6.m16614y(view2, "view is not a child, cannot hide ");
                            return null;
                        }
                        if (c0631iv.m10922f(iIndexOfChild)) {
                            vf3.m19098p(view2, "trying to unhide a view that was not hidden");
                            return null;
                        }
                        c0631iv.m10918b(iIndexOfChild);
                        rg1Var.m16523r(view2);
                        rg1 rg1Var3 = recyclerView.f1995B;
                        c0631iv2 = (C0631iv) rg1Var3.f36498d;
                        iIndexOfChild2 = ((rs8) rg1Var3.f36497c).f37241e.indexOfChild(view2);
                        if (iIndexOfChild2 == -1) {
                            iM10919c = -1;
                        } else {
                            iM10919c = iIndexOfChild2 - c0631iv2.m10919c(iIndexOfChild2);
                        }
                        if (iM10919c != -1) {
                            StringBuilder sb2 = new StringBuilder("layout index should not be -1 after unhiding a view:");
                            sb2.append(abstractC0185oM1292M);
                            nxa.m14380e(sb2, recyclerView.m1301A());
                            return null;
                        }
                        recyclerView.f1995B.m16510c(iM10919c);
                        m1486k(view2);
                        abstractC0185oM1292M.m1496a(8224);
                        abstractC0185oMo1428g = abstractC0185oM1292M;
                        break;
                    }
                } else {
                    abstractC0185o4 = (AbstractC0185o) arrayList.get(i5);
                    if (abstractC0185o4.m1513r()) {
                    }
                    i5++;
                }
            }
            if (abstractC0185oMo1428g != null) {
                if (!abstractC0185oMo1428g.m1505j()) {
                    i8 = abstractC0185oMo1428g.f2183y;
                    if (i8 >= 0) {
                    }
                    throw new IndexOutOfBoundsException("Inconsistency detected. Invalid view holder adapter position" + abstractC0185oMo1428g + recyclerView.m1301A());
                }
                int[] iArr6 = RecyclerView.f1986X0;
                z11 = et8Var.f13104g;
                if (z11) {
                    abstractC0185oMo1428g.m1496a(4);
                    if (abstractC0185oMo1428g.m1506k()) {
                        recyclerView.removeDetachedView(abstractC0185oMo1428g.f2181e, false);
                        abstractC0185oMo1428g.f2175J.m1488m(abstractC0185oMo1428g);
                    } else if (abstractC0185oMo1428g.m1513r()) {
                        abstractC0185oMo1428g.f2171F &= -33;
                    }
                    m1485j(abstractC0185oMo1428g);
                    abstractC0185oMo1428g = null;
                } else {
                    z = z2;
                }
            }
        } else {
            z2 = true;
        }
        if (abstractC0185oMo1428g == null) {
            iM8168g2 = recyclerView.f1993A.m8168g(i, 0);
            if (iM8168g2 >= 0) {
                j2 = 3;
                if (iM8168g2 < recyclerView.f2009I.mo1422a()) {
                    iMo1424c = recyclerView.f2009I.mo1424c(iM8168g2);
                    abstractC0177g2 = recyclerView.f2009I;
                    j3 = 4;
                    if (abstractC0177g2.f2137b) {
                        jMo1423b = abstractC0177g2.mo1423b(iM8168g2);
                        size2 = arrayList.size() - 1;
                        while (true) {
                            if (size2 >= 0) {
                                i4 = iM8168g2;
                                size3 = arrayList2.size() - 1;
                                while (true) {
                                    if (size3 >= 0) {
                                        abstractC0185o2 = (AbstractC0185o) arrayList2.get(size3);
                                        if (abstractC0185o2.f2166A == jMo1423b) {
                                        }
                                        size3--;
                                    }
                                    abstractC0185oMo1428g = null;
                                    break;
                                }
                            }
                            AbstractC0185o abstractC0185o7 = (AbstractC0185o) arrayList.get(size2);
                            i4 = iM8168g2;
                            j8 = abstractC0185o7.f2166A;
                            View view4 = abstractC0185o7.f2181e;
                            if (j8 != jMo1423b) {
                            }
                            size2--;
                            iM8168g2 = i4;
                        }
                        if (abstractC0185oMo1428g != null) {
                            abstractC0185oMo1428g.f2183y = i4;
                            z = z2;
                        }
                    }
                    if (abstractC0185oMo1428g == null) {
                        int[] iArr7 = RecyclerView.f1986X0;
                        zs8Var = (zs8) m1478c().f2837a.get(iMo1424c);
                        if (zs8Var != null) {
                            abstractC0185o = null;
                            break;
                        }
                        arrayList4 = zs8Var.f50808a;
                        if (arrayList4.isEmpty()) {
                            abstractC0185o = null;
                            break;
                        }
                        size = arrayList4.size() - 1;
                        while (true) {
                            if (size >= 0) {
                                abstractC0185o = null;
                                break;
                            }
                            if (!((AbstractC0185o) arrayList4.get(size)).m1501f()) {
                                abstractC0185o = (AbstractC0185o) arrayList4.remove(size);
                                break;
                            }
                            size--;
                        }
                        if (abstractC0185o != null) {
                            abstractC0185o.m1510o();
                            int[] iArr8 = RecyclerView.f1986X0;
                        }
                        abstractC0185oMo1428g = abstractC0185o;
                    }
                    if (abstractC0185oMo1428g == null) {
                        jM1313O3 = recyclerView.m1313O();
                        if (j != Long.MAX_VALUE) {
                            j7 = this.f2162g.m1844b(iMo1424c).f50810c;
                            if (j7 != 0) {
                                z10 = z2;
                            } else {
                                z10 = z2;
                            }
                            if (!z10) {
                                return null;
                            }
                        }
                        AbstractC0177g abstractC0177g5 = recyclerView.f2009I;
                        abstractC0177g5.getClass();
                        if (pva.m15556a()) {
                            Trace.beginSection(String.format("RV onCreateViewHolder type=0x%X", Integer.valueOf(iMo1424c)));
                        }
                        abstractC0185oMo1428g = abstractC0177g5.mo1428g(recyclerView, iMo1424c);
                        if (abstractC0185oMo1428g.f2181e.getParent() == null) {
                            throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
                        }
                        abstractC0185oMo1428g.f2167B = iMo1424c;
                        Trace.endSection();
                        if (RecyclerView.f1989a1) {
                            abstractC0185oMo1428g.f2182i = new WeakReference(recyclerViewM1291G);
                        }
                        jM1313O4 = recyclerView.m1313O() - jM1313O3;
                        zs8 zs8VarM1844b4 = this.f2162g.m1844b(iMo1424c);
                        j6 = zs8VarM1844b4.f50810c;
                        if (j6 != 0) {
                            jM1313O4 = (jM1313O4 / 4) + ((j6 / 4) * 3);
                        }
                        zs8VarM1844b4.f50810c = jM1313O4;
                    }
                }
            }
            StringBuilder sbM20940v3 = z23.m20940v(i, iM8168g2, "Inconsistency detected. Invalid item position ", "(offset:", ").state:");
            sbM20940v3.append(et8Var.m7762b());
            sbM20940v3.append(recyclerView.m1301A());
            throw new IndexOutOfBoundsException(sbM20940v3.toString());
        }
        j2 = 3;
        j3 = 4;
        view = abstractC0185oMo1428g.f2181e;
        if (z) {
            i3 = abstractC0185oMo1428g.f2171F;
            if ((i3 & 8192) != 0) {
                z9 = z2;
            } else {
                z9 = false;
            }
            if (z9) {
                abstractC0185oMo1428g.f2171F = i3 & (-8193);
                if (et8Var.f13107j) {
                    cz9.m6679i(abstractC0185oMo1428g);
                    cz9 cz9Var2 = recyclerView.f2052l0;
                    abstractC0185oMo1428g.m1500e();
                    cz9Var2.getClass();
                    jn8 jn8Var2 = new jn8();
                    jn8Var2.m11479k(abstractC0185oMo1428g);
                    recyclerView.m1326b0(abstractC0185oMo1428g, jn8Var2);
                }
            }
        }
        if (et8Var.f13104g) {
            if (abstractC0185oMo1428g.m1502g()) {
                if ((abstractC0185oMo1428g.f2171F & 2) != 0) {
                    z8 = z2;
                } else {
                    z8 = false;
                }
                if (!z8) {
                }
            }
            int[] iArr9 = RecyclerView.f1986X0;
            iM8168g = recyclerView.f1993A.m8168g(i, 0);
            abstractC0185oMo1428g.f2180O = null;
            abstractC0185oMo1428g.f2179N = recyclerView;
            i2 = abstractC0185oMo1428g.f2167B;
            jM1313O = recyclerView.m1313O();
            if (j != Long.MAX_VALUE) {
                j5 = this.f2162g.m1844b(i2).f50811d;
                if (j5 != 0) {
                    if (abstractC0185oMo1428g.m1507l()) {
                        recyclerView.attachViewToParent(view, recyclerView.getChildCount(), view.getLayoutParams());
                        z3 = z2;
                    } else {
                        z3 = false;
                    }
                    abstractC0177g = recyclerView.f2009I;
                    abstractC0177g.getClass();
                    if (abstractC0185oMo1428g.f2180O == null) {
                        z4 = z2;
                    } else {
                        z4 = false;
                    }
                    if (z4) {
                        abstractC0185oMo1428g.f2183y = iM8168g;
                        if (abstractC0177g.f2137b) {
                            abstractC0185oMo1428g.f2166A = abstractC0177g.mo1423b(iM8168g);
                        }
                        abstractC0185oMo1428g.f2171F = (abstractC0185oMo1428g.f2171F & (-520)) | 1;
                        if (pva.m15556a()) {
                            Trace.beginSection(String.format("RV onBindViewHolder type=0x%X", Integer.valueOf(abstractC0185oMo1428g.f2167B)));
                        }
                    }
                    abstractC0185oMo1428g.f2180O = abstractC0177g;
                    abstractC0177g.mo1427f(abstractC0185oMo1428g, iM8168g, abstractC0185oMo1428g.m1500e());
                    if (z4) {
                        arrayList3 = abstractC0185oMo1428g.f2172G;
                        if (arrayList3 != null) {
                            arrayList3.clear();
                        }
                        abstractC0185oMo1428g.f2171F &= -1025;
                        layoutParams = view.getLayoutParams();
                        if (layoutParams instanceof RecyclerView.LayoutParams) {
                            ((RecyclerView.LayoutParams) layoutParams).f2071c = z2;
                        }
                        Trace.endSection();
                    }
                    if (z3) {
                        recyclerView.detachViewFromParent(view);
                    }
                    jM1313O2 = recyclerView.m1313O() - jM1313O;
                    zs8 zs8VarM1844b5 = this.f2162g.m1844b(abstractC0185oMo1428g.f2167B);
                    j4 = zs8VarM1844b5.f50811d;
                    if (j4 != 0) {
                        jM1313O2 = (jM1313O2 / j3) + ((j4 / j3) * j2);
                    }
                    zs8VarM1844b5.f50811d = jM1313O2;
                    accessibilityManager = recyclerView.f2039a0;
                    if (accessibilityManager == null) {
                        z5 = false;
                    } else {
                        z5 = false;
                    }
                    if (z5) {
                        z6 = true;
                        if (view.getImportantForAccessibility() == 0) {
                            view.setImportantForAccessibility(1);
                        }
                        ht8Var = recyclerView.f2012J0;
                        if (ht8Var != null) {
                            ht8Var2 = (ht8) ht8Var.f20299B;
                            if (ht8Var2 != null) {
                                accessibilityDelegateM14611d = obb.m14611d(view);
                                if (accessibilityDelegateM14611d == null) {
                                    c1307q6 = null;
                                } else if (accessibilityDelegateM14611d instanceof C1270p6) {
                                    c1307q6 = ((C1270p6) accessibilityDelegateM14611d).f32788a;
                                } else {
                                    c1307q6 = new C1307q6(accessibilityDelegateM14611d);
                                }
                                if (c1307q6 != null) {
                                    ((WeakHashMap) ht8Var2.f20299B).put(view, c1307q6);
                                }
                            }
                            obb.m14621n(view, ht8Var2);
                        }
                    } else {
                        z6 = true;
                    }
                    if (et8Var.f13104g) {
                        abstractC0185oMo1428g.f2168C = i;
                    }
                    z7 = z6;
                } else {
                    if (abstractC0185oMo1428g.m1507l()) {
                        recyclerView.attachViewToParent(view, recyclerView.getChildCount(), view.getLayoutParams());
                        z3 = z2;
                    } else {
                        z3 = false;
                    }
                    abstractC0177g = recyclerView.f2009I;
                    abstractC0177g.getClass();
                    if (abstractC0185oMo1428g.f2180O == null) {
                        z4 = z2;
                    } else {
                        z4 = false;
                    }
                    if (z4) {
                        abstractC0185oMo1428g.f2183y = iM8168g;
                        if (abstractC0177g.f2137b) {
                            abstractC0185oMo1428g.f2166A = abstractC0177g.mo1423b(iM8168g);
                        }
                        abstractC0185oMo1428g.f2171F = (abstractC0185oMo1428g.f2171F & (-520)) | 1;
                        if (pva.m15556a()) {
                            Trace.beginSection(String.format("RV onBindViewHolder type=0x%X", Integer.valueOf(abstractC0185oMo1428g.f2167B)));
                        }
                    }
                    abstractC0185oMo1428g.f2180O = abstractC0177g;
                    abstractC0177g.mo1427f(abstractC0185oMo1428g, iM8168g, abstractC0185oMo1428g.m1500e());
                    if (z4) {
                        arrayList3 = abstractC0185oMo1428g.f2172G;
                        if (arrayList3 != null) {
                            arrayList3.clear();
                        }
                        abstractC0185oMo1428g.f2171F &= -1025;
                        layoutParams = view.getLayoutParams();
                        if (layoutParams instanceof RecyclerView.LayoutParams) {
                            ((RecyclerView.LayoutParams) layoutParams).f2071c = z2;
                        }
                        Trace.endSection();
                    }
                    if (z3) {
                        recyclerView.detachViewFromParent(view);
                    }
                    jM1313O2 = recyclerView.m1313O() - jM1313O;
                    zs8 zs8VarM1844b6 = this.f2162g.m1844b(abstractC0185oMo1428g.f2167B);
                    j4 = zs8VarM1844b6.f50811d;
                    if (j4 != 0) {
                        jM1313O2 = (jM1313O2 / j3) + ((j4 / j3) * j2);
                    }
                    zs8VarM1844b6.f50811d = jM1313O2;
                    accessibilityManager = recyclerView.f2039a0;
                    if (accessibilityManager == null) {
                        z5 = false;
                    } else {
                        z5 = false;
                    }
                    if (z5) {
                        z6 = true;
                        if (view.getImportantForAccessibility() == 0) {
                            view.setImportantForAccessibility(1);
                        }
                        ht8Var = recyclerView.f2012J0;
                        if (ht8Var != null) {
                            ht8Var2 = (ht8) ht8Var.f20299B;
                            if (ht8Var2 != null) {
                                accessibilityDelegateM14611d = obb.m14611d(view);
                                if (accessibilityDelegateM14611d == null) {
                                    c1307q6 = null;
                                } else if (accessibilityDelegateM14611d instanceof C1270p6) {
                                    c1307q6 = ((C1270p6) accessibilityDelegateM14611d).f32788a;
                                } else {
                                    c1307q6 = new C1307q6(accessibilityDelegateM14611d);
                                }
                                if (c1307q6 != null) {
                                    ((WeakHashMap) ht8Var2.f20299B).put(view, c1307q6);
                                }
                            }
                            obb.m14621n(view, ht8Var2);
                        }
                    } else {
                        z6 = true;
                    }
                    if (et8Var.f13104g) {
                        abstractC0185oMo1428g.f2168C = i;
                    }
                    z7 = z6;
                }
            } else {
                if (abstractC0185oMo1428g.m1507l()) {
                    recyclerView.attachViewToParent(view, recyclerView.getChildCount(), view.getLayoutParams());
                    z3 = z2;
                } else {
                    z3 = false;
                }
                abstractC0177g = recyclerView.f2009I;
                abstractC0177g.getClass();
                if (abstractC0185oMo1428g.f2180O == null) {
                    z4 = z2;
                } else {
                    z4 = false;
                }
                if (z4) {
                    abstractC0185oMo1428g.f2183y = iM8168g;
                    if (abstractC0177g.f2137b) {
                        abstractC0185oMo1428g.f2166A = abstractC0177g.mo1423b(iM8168g);
                    }
                    abstractC0185oMo1428g.f2171F = (abstractC0185oMo1428g.f2171F & (-520)) | 1;
                    if (pva.m15556a()) {
                        Trace.beginSection(String.format("RV onBindViewHolder type=0x%X", Integer.valueOf(abstractC0185oMo1428g.f2167B)));
                    }
                }
                abstractC0185oMo1428g.f2180O = abstractC0177g;
                abstractC0177g.mo1427f(abstractC0185oMo1428g, iM8168g, abstractC0185oMo1428g.m1500e());
                if (z4) {
                    arrayList3 = abstractC0185oMo1428g.f2172G;
                    if (arrayList3 != null) {
                        arrayList3.clear();
                    }
                    abstractC0185oMo1428g.f2171F &= -1025;
                    layoutParams = view.getLayoutParams();
                    if (layoutParams instanceof RecyclerView.LayoutParams) {
                        ((RecyclerView.LayoutParams) layoutParams).f2071c = z2;
                    }
                    Trace.endSection();
                }
                if (z3) {
                    recyclerView.detachViewFromParent(view);
                }
                jM1313O2 = recyclerView.m1313O() - jM1313O;
                zs8 zs8VarM1844b7 = this.f2162g.m1844b(abstractC0185oMo1428g.f2167B);
                j4 = zs8VarM1844b7.f50811d;
                if (j4 != 0) {
                    jM1313O2 = (jM1313O2 / j3) + ((j4 / j3) * j2);
                }
                zs8VarM1844b7.f50811d = jM1313O2;
                accessibilityManager = recyclerView.f2039a0;
                if (accessibilityManager == null) {
                    z5 = false;
                } else {
                    z5 = false;
                }
                if (z5) {
                    z6 = true;
                    if (view.getImportantForAccessibility() == 0) {
                        view.setImportantForAccessibility(1);
                    }
                    ht8Var = recyclerView.f2012J0;
                    if (ht8Var != null) {
                        ht8Var2 = (ht8) ht8Var.f20299B;
                        if (ht8Var2 != null) {
                            accessibilityDelegateM14611d = obb.m14611d(view);
                            if (accessibilityDelegateM14611d == null) {
                                c1307q6 = null;
                            } else if (accessibilityDelegateM14611d instanceof C1270p6) {
                                c1307q6 = ((C1270p6) accessibilityDelegateM14611d).f32788a;
                            } else {
                                c1307q6 = new C1307q6(accessibilityDelegateM14611d);
                            }
                            if (c1307q6 != null) {
                                ((WeakHashMap) ht8Var2.f20299B).put(view, c1307q6);
                            }
                        }
                        obb.m14621n(view, ht8Var2);
                    }
                } else {
                    z6 = true;
                }
                if (et8Var.f13104g) {
                    abstractC0185oMo1428g.f2168C = i;
                }
                z7 = z6;
            }
        } else {
            if (abstractC0185oMo1428g.m1502g()) {
                if ((abstractC0185oMo1428g.f2171F & 2) != 0) {
                    z8 = z2;
                } else {
                    z8 = false;
                }
                if (!z8) {
                }
            }
            int[] iArr10 = RecyclerView.f1986X0;
            iM8168g = recyclerView.f1993A.m8168g(i, 0);
            abstractC0185oMo1428g.f2180O = null;
            abstractC0185oMo1428g.f2179N = recyclerView;
            i2 = abstractC0185oMo1428g.f2167B;
            jM1313O = recyclerView.m1313O();
            if (j != Long.MAX_VALUE) {
                j5 = this.f2162g.m1844b(i2).f50811d;
                if (j5 != 0) {
                    if (abstractC0185oMo1428g.m1507l()) {
                        recyclerView.attachViewToParent(view, recyclerView.getChildCount(), view.getLayoutParams());
                        z3 = z2;
                    } else {
                        z3 = false;
                    }
                    abstractC0177g = recyclerView.f2009I;
                    abstractC0177g.getClass();
                    if (abstractC0185oMo1428g.f2180O == null) {
                        z4 = z2;
                    } else {
                        z4 = false;
                    }
                    if (z4) {
                        abstractC0185oMo1428g.f2183y = iM8168g;
                        if (abstractC0177g.f2137b) {
                            abstractC0185oMo1428g.f2166A = abstractC0177g.mo1423b(iM8168g);
                        }
                        abstractC0185oMo1428g.f2171F = (abstractC0185oMo1428g.f2171F & (-520)) | 1;
                        if (pva.m15556a()) {
                            Trace.beginSection(String.format("RV onBindViewHolder type=0x%X", Integer.valueOf(abstractC0185oMo1428g.f2167B)));
                        }
                    }
                    abstractC0185oMo1428g.f2180O = abstractC0177g;
                    abstractC0177g.mo1427f(abstractC0185oMo1428g, iM8168g, abstractC0185oMo1428g.m1500e());
                    if (z4) {
                        arrayList3 = abstractC0185oMo1428g.f2172G;
                        if (arrayList3 != null) {
                            arrayList3.clear();
                        }
                        abstractC0185oMo1428g.f2171F &= -1025;
                        layoutParams = view.getLayoutParams();
                        if (layoutParams instanceof RecyclerView.LayoutParams) {
                            ((RecyclerView.LayoutParams) layoutParams).f2071c = z2;
                        }
                        Trace.endSection();
                    }
                    if (z3) {
                        recyclerView.detachViewFromParent(view);
                    }
                    jM1313O2 = recyclerView.m1313O() - jM1313O;
                    zs8 zs8VarM1844b8 = this.f2162g.m1844b(abstractC0185oMo1428g.f2167B);
                    j4 = zs8VarM1844b8.f50811d;
                    if (j4 != 0) {
                        jM1313O2 = (jM1313O2 / j3) + ((j4 / j3) * j2);
                    }
                    zs8VarM1844b8.f50811d = jM1313O2;
                    accessibilityManager = recyclerView.f2039a0;
                    if (accessibilityManager == null) {
                        z5 = false;
                    } else {
                        z5 = false;
                    }
                    if (z5) {
                        z6 = true;
                        if (view.getImportantForAccessibility() == 0) {
                            view.setImportantForAccessibility(1);
                        }
                        ht8Var = recyclerView.f2012J0;
                        if (ht8Var != null) {
                            ht8Var2 = (ht8) ht8Var.f20299B;
                            if (ht8Var2 != null) {
                                accessibilityDelegateM14611d = obb.m14611d(view);
                                if (accessibilityDelegateM14611d == null) {
                                    c1307q6 = null;
                                } else if (accessibilityDelegateM14611d instanceof C1270p6) {
                                    c1307q6 = ((C1270p6) accessibilityDelegateM14611d).f32788a;
                                } else {
                                    c1307q6 = new C1307q6(accessibilityDelegateM14611d);
                                }
                                if (c1307q6 != null) {
                                    ((WeakHashMap) ht8Var2.f20299B).put(view, c1307q6);
                                }
                            }
                            obb.m14621n(view, ht8Var2);
                        }
                    } else {
                        z6 = true;
                    }
                    if (et8Var.f13104g) {
                        abstractC0185oMo1428g.f2168C = i;
                    }
                    z7 = z6;
                } else {
                    if (abstractC0185oMo1428g.m1507l()) {
                        recyclerView.attachViewToParent(view, recyclerView.getChildCount(), view.getLayoutParams());
                        z3 = z2;
                    } else {
                        z3 = false;
                    }
                    abstractC0177g = recyclerView.f2009I;
                    abstractC0177g.getClass();
                    if (abstractC0185oMo1428g.f2180O == null) {
                        z4 = z2;
                    } else {
                        z4 = false;
                    }
                    if (z4) {
                        abstractC0185oMo1428g.f2183y = iM8168g;
                        if (abstractC0177g.f2137b) {
                            abstractC0185oMo1428g.f2166A = abstractC0177g.mo1423b(iM8168g);
                        }
                        abstractC0185oMo1428g.f2171F = (abstractC0185oMo1428g.f2171F & (-520)) | 1;
                        if (pva.m15556a()) {
                            Trace.beginSection(String.format("RV onBindViewHolder type=0x%X", Integer.valueOf(abstractC0185oMo1428g.f2167B)));
                        }
                    }
                    abstractC0185oMo1428g.f2180O = abstractC0177g;
                    abstractC0177g.mo1427f(abstractC0185oMo1428g, iM8168g, abstractC0185oMo1428g.m1500e());
                    if (z4) {
                        arrayList3 = abstractC0185oMo1428g.f2172G;
                        if (arrayList3 != null) {
                            arrayList3.clear();
                        }
                        abstractC0185oMo1428g.f2171F &= -1025;
                        layoutParams = view.getLayoutParams();
                        if (layoutParams instanceof RecyclerView.LayoutParams) {
                            ((RecyclerView.LayoutParams) layoutParams).f2071c = z2;
                        }
                        Trace.endSection();
                    }
                    if (z3) {
                        recyclerView.detachViewFromParent(view);
                    }
                    jM1313O2 = recyclerView.m1313O() - jM1313O;
                    zs8 zs8VarM1844b9 = this.f2162g.m1844b(abstractC0185oMo1428g.f2167B);
                    j4 = zs8VarM1844b9.f50811d;
                    if (j4 != 0) {
                        jM1313O2 = (jM1313O2 / j3) + ((j4 / j3) * j2);
                    }
                    zs8VarM1844b9.f50811d = jM1313O2;
                    accessibilityManager = recyclerView.f2039a0;
                    if (accessibilityManager == null) {
                        z5 = false;
                    } else {
                        z5 = false;
                    }
                    if (z5) {
                        z6 = true;
                        if (view.getImportantForAccessibility() == 0) {
                            view.setImportantForAccessibility(1);
                        }
                        ht8Var = recyclerView.f2012J0;
                        if (ht8Var != null) {
                            ht8Var2 = (ht8) ht8Var.f20299B;
                            if (ht8Var2 != null) {
                                accessibilityDelegateM14611d = obb.m14611d(view);
                                if (accessibilityDelegateM14611d == null) {
                                    c1307q6 = null;
                                } else if (accessibilityDelegateM14611d instanceof C1270p6) {
                                    c1307q6 = ((C1270p6) accessibilityDelegateM14611d).f32788a;
                                } else {
                                    c1307q6 = new C1307q6(accessibilityDelegateM14611d);
                                }
                                if (c1307q6 != null) {
                                    ((WeakHashMap) ht8Var2.f20299B).put(view, c1307q6);
                                }
                            }
                            obb.m14621n(view, ht8Var2);
                        }
                    } else {
                        z6 = true;
                    }
                    if (et8Var.f13104g) {
                        abstractC0185oMo1428g.f2168C = i;
                    }
                    z7 = z6;
                }
            } else {
                if (abstractC0185oMo1428g.m1507l()) {
                    recyclerView.attachViewToParent(view, recyclerView.getChildCount(), view.getLayoutParams());
                    z3 = z2;
                } else {
                    z3 = false;
                }
                abstractC0177g = recyclerView.f2009I;
                abstractC0177g.getClass();
                if (abstractC0185oMo1428g.f2180O == null) {
                    z4 = z2;
                } else {
                    z4 = false;
                }
                if (z4) {
                    abstractC0185oMo1428g.f2183y = iM8168g;
                    if (abstractC0177g.f2137b) {
                        abstractC0185oMo1428g.f2166A = abstractC0177g.mo1423b(iM8168g);
                    }
                    abstractC0185oMo1428g.f2171F = (abstractC0185oMo1428g.f2171F & (-520)) | 1;
                    if (pva.m15556a()) {
                        Trace.beginSection(String.format("RV onBindViewHolder type=0x%X", Integer.valueOf(abstractC0185oMo1428g.f2167B)));
                    }
                }
                abstractC0185oMo1428g.f2180O = abstractC0177g;
                abstractC0177g.mo1427f(abstractC0185oMo1428g, iM8168g, abstractC0185oMo1428g.m1500e());
                if (z4) {
                    arrayList3 = abstractC0185oMo1428g.f2172G;
                    if (arrayList3 != null) {
                        arrayList3.clear();
                    }
                    abstractC0185oMo1428g.f2171F &= -1025;
                    layoutParams = view.getLayoutParams();
                    if (layoutParams instanceof RecyclerView.LayoutParams) {
                        ((RecyclerView.LayoutParams) layoutParams).f2071c = z2;
                    }
                    Trace.endSection();
                }
                if (z3) {
                    recyclerView.detachViewFromParent(view);
                }
                jM1313O2 = recyclerView.m1313O() - jM1313O;
                zs8 zs8VarM1844b10 = this.f2162g.m1844b(abstractC0185oMo1428g.f2167B);
                j4 = zs8VarM1844b10.f50811d;
                if (j4 != 0) {
                    jM1313O2 = (jM1313O2 / j3) + ((j4 / j3) * j2);
                }
                zs8VarM1844b10.f50811d = jM1313O2;
                accessibilityManager = recyclerView.f2039a0;
                if (accessibilityManager == null) {
                    z5 = false;
                } else {
                    z5 = false;
                }
                if (z5) {
                    z6 = true;
                    if (view.getImportantForAccessibility() == 0) {
                        view.setImportantForAccessibility(1);
                    }
                    ht8Var = recyclerView.f2012J0;
                    if (ht8Var != null) {
                        ht8Var2 = (ht8) ht8Var.f20299B;
                        if (ht8Var2 != null) {
                            accessibilityDelegateM14611d = obb.m14611d(view);
                            if (accessibilityDelegateM14611d == null) {
                                c1307q6 = null;
                            } else if (accessibilityDelegateM14611d instanceof C1270p6) {
                                c1307q6 = ((C1270p6) accessibilityDelegateM14611d).f32788a;
                            } else {
                                c1307q6 = new C1307q6(accessibilityDelegateM14611d);
                            }
                            if (c1307q6 != null) {
                                ((WeakHashMap) ht8Var2.f20299B).put(view, c1307q6);
                            }
                        }
                        obb.m14621n(view, ht8Var2);
                    }
                } else {
                    z6 = true;
                }
                if (et8Var.f13104g) {
                    abstractC0185oMo1428g.f2168C = i;
                }
                z7 = z6;
            }
        }
        layoutParams2 = view.getLayoutParams();
        if (layoutParams2 == null) {
            layoutParams3 = (RecyclerView.LayoutParams) recyclerView.generateDefaultLayoutParams();
            view.setLayoutParams(layoutParams3);
        } else if (recyclerView.checkLayoutParams(layoutParams2)) {
            layoutParams3 = (RecyclerView.LayoutParams) recyclerView.generateLayoutParams(layoutParams2);
            view.setLayoutParams(layoutParams3);
        } else {
            layoutParams3 = (RecyclerView.LayoutParams) layoutParams2;
        }
        layoutParams3.f2069a = abstractC0185oMo1428g;
        if (z) {
            z6 = false;
        } else {
            z6 = false;
        }
        layoutParams3.f2072d = z6;
        return abstractC0185oMo1428g;
    }

    /* JADX INFO: renamed from: m */
    public final void m1488m(AbstractC0185o abstractC0185o) {
        if (abstractC0185o.f2176K) {
            this.f2157b.remove(abstractC0185o);
        } else {
            this.f2156a.remove(abstractC0185o);
        }
        abstractC0185o.f2175J = null;
        abstractC0185o.f2176K = false;
        abstractC0185o.f2171F &= -33;
    }

    /* JADX INFO: renamed from: n */
    public final void m1489n() {
        AbstractC0181k abstractC0181k = this.f2163h.f2011J;
        this.f2161f = this.f2160e + (abstractC0181k != null ? abstractC0181k.f2150j : 0);
        ArrayList arrayList = this.f2158c;
        for (int size = arrayList.size() - 1; size >= 0 && arrayList.size() > this.f2161f; size--) {
            m1483h(size);
        }
    }
}
