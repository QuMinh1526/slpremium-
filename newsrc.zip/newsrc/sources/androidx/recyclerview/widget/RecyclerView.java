package androidx.recyclerview.widget;

import android.R;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.appcompat.widget.RtlSpacingHelper;
import androidx.customview.view.AbsSavedState;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.WeakHashMap;
import org.p003jf.dexlib2.Opcode;
import org.p003jf.dexlib2.dexbacked.raw.ItemType;
import p000.AbstractC0598hx;
import p000.C0461em;
import p000.C0498fm;
import p000.C0631iv;
import p000.C0767l;
import p000.C1477tx;
import p000.C1521v3;
import p000.at8;
import p000.ccb;
import p000.cl5;
import p000.cz9;
import p000.e5c;
import p000.eo8;
import p000.et8;
import p000.eu3;
import p000.fbb;
import p000.ft8;
import p000.fu2;
import p000.gt8;
import p000.hj4;
import p000.ht8;
import p000.ibb;
import p000.jn8;
import p000.l40;
import p000.ll4;
import p000.nl2;
import p000.nxa;
import p000.o28;
import p000.obb;
import p000.ph6;
import p000.qs8;
import p000.qz6;
import p000.rg1;
import p000.ro6;
import p000.rs8;
import p000.s47;
import p000.sbb;
import p000.ubb;
import p000.uy9;
import p000.ws8;
import p000.xs8;
import p000.ys8;
import p000.z78;
import p000.z82;
import p000.zo1;
import p000.zza;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes.dex */
public class RecyclerView extends ViewGroup implements s47 {

    /* JADX INFO: renamed from: X0 */
    public static final int[] f1986X0 = {R.attr.nestedScrollingEnabled};

    /* JADX INFO: renamed from: Y0 */
    public static final float f1987Y0 = (float) (Math.log(0.78d) / Math.log(0.9d));

    /* JADX INFO: renamed from: Z0 */
    public static final boolean f1988Z0 = true;

    /* JADX INFO: renamed from: a1 */
    public static final boolean f1989a1 = true;

    /* JADX INFO: renamed from: b1 */
    public static final Class[] f1990b1;

    /* JADX INFO: renamed from: c1 */
    public static final cl5 f1991c1;

    /* JADX INFO: renamed from: d1 */
    public static final ft8 f1992d1;

    /* JADX INFO: renamed from: A */
    public final C0498fm f1993A;

    /* JADX INFO: renamed from: A0 */
    public final gt8 f1994A0;

    /* JADX INFO: renamed from: B */
    public final rg1 f1995B;

    /* JADX INFO: renamed from: B0 */
    public ll4 f1996B0;

    /* JADX INFO: renamed from: C */
    public final qz6 f1997C;

    /* JADX INFO: renamed from: C0 */
    public final zo1 f1998C0;

    /* JADX INFO: renamed from: D */
    public boolean f1999D;

    /* JADX INFO: renamed from: D0 */
    public final et8 f2000D0;

    /* JADX INFO: renamed from: E */
    public final qs8 f2001E;

    /* JADX INFO: renamed from: E0 */
    public ArrayList f2002E0;

    /* JADX INFO: renamed from: F */
    public final Rect f2003F;

    /* JADX INFO: renamed from: F0 */
    public boolean f2004F0;

    /* JADX INFO: renamed from: G */
    public final Rect f2005G;

    /* JADX INFO: renamed from: G0 */
    public boolean f2006G0;

    /* JADX INFO: renamed from: H */
    public final RectF f2007H;

    /* JADX INFO: renamed from: H0 */
    public final rs8 f2008H0;

    /* JADX INFO: renamed from: I */
    public AbstractC0177g f2009I;

    /* JADX INFO: renamed from: I0 */
    public boolean f2010I0;

    /* JADX INFO: renamed from: J */
    public AbstractC0181k f2011J;

    /* JADX INFO: renamed from: J0 */
    public ht8 f2012J0;

    /* JADX INFO: renamed from: K */
    public final ArrayList f2013K;

    /* JADX INFO: renamed from: K0 */
    public final int[] f2014K0;

    /* JADX INFO: renamed from: L */
    public final ArrayList f2015L;

    /* JADX INFO: renamed from: L0 */
    public C1477tx f2016L0;

    /* JADX INFO: renamed from: M */
    public final ArrayList f2017M;

    /* JADX INFO: renamed from: M0 */
    public final int[] f2018M0;

    /* JADX INFO: renamed from: N */
    public xs8 f2019N;

    /* JADX INFO: renamed from: N0 */
    public final int[] f2020N0;

    /* JADX INFO: renamed from: O */
    public boolean f2021O;

    /* JADX INFO: renamed from: O0 */
    public final int[] f2022O0;

    /* JADX INFO: renamed from: P */
    public boolean f2023P;

    /* JADX INFO: renamed from: P0 */
    public final ArrayList f2024P0;

    /* JADX INFO: renamed from: Q */
    public boolean f2025Q;

    /* JADX INFO: renamed from: Q0 */
    public final qs8 f2026Q0;

    /* JADX INFO: renamed from: R */
    public int f2027R;

    /* JADX INFO: renamed from: R0 */
    public boolean f2028R0;

    /* JADX INFO: renamed from: S */
    public boolean f2029S;

    /* JADX INFO: renamed from: S0 */
    public int f2030S0;

    /* JADX INFO: renamed from: T */
    public boolean f2031T;

    /* JADX INFO: renamed from: T0 */
    public int f2032T0;

    /* JADX INFO: renamed from: U */
    public boolean f2033U;

    /* JADX INFO: renamed from: U0 */
    public final boolean f2034U0;

    /* JADX INFO: renamed from: V */
    public int f2035V;

    /* JADX INFO: renamed from: V0 */
    public final rs8 f2036V0;

    /* JADX INFO: renamed from: W */
    public boolean f2037W;

    /* JADX INFO: renamed from: W0 */
    public final fu2 f2038W0;

    /* JADX INFO: renamed from: a0 */
    public final AccessibilityManager f2039a0;

    /* JADX INFO: renamed from: b0 */
    public ArrayList f2040b0;

    /* JADX INFO: renamed from: c0 */
    public boolean f2041c0;

    /* JADX INFO: renamed from: d0 */
    public boolean f2042d0;

    /* JADX INFO: renamed from: e */
    public final float f2043e;

    /* JADX INFO: renamed from: e0 */
    public int f2044e0;

    /* JADX INFO: renamed from: f0 */
    public int f2045f0;

    /* JADX INFO: renamed from: g0 */
    public o28 f2046g0;

    /* JADX INFO: renamed from: h0 */
    public EdgeEffect f2047h0;

    /* JADX INFO: renamed from: i */
    public final C0183m f2048i;

    /* JADX INFO: renamed from: i0 */
    public EdgeEffect f2049i0;

    /* JADX INFO: renamed from: j0 */
    public EdgeEffect f2050j0;

    /* JADX INFO: renamed from: k0 */
    public EdgeEffect f2051k0;

    /* JADX INFO: renamed from: l0 */
    public cz9 f2052l0;

    /* JADX INFO: renamed from: m0 */
    public int f2053m0;

    /* JADX INFO: renamed from: n0 */
    public int f2054n0;

    /* JADX INFO: renamed from: o0 */
    public VelocityTracker f2055o0;

    /* JADX INFO: renamed from: p0 */
    public int f2056p0;

    /* JADX INFO: renamed from: q0 */
    public int f2057q0;

    /* JADX INFO: renamed from: r0 */
    public int f2058r0;

    /* JADX INFO: renamed from: s0 */
    public int f2059s0;

    /* JADX INFO: renamed from: t0 */
    public int f2060t0;

    /* JADX INFO: renamed from: u0 */
    public C0767l f2061u0;

    /* JADX INFO: renamed from: v0 */
    public final int f2062v0;

    /* JADX INFO: renamed from: w0 */
    public final int f2063w0;

    /* JADX INFO: renamed from: x0 */
    public final float f2064x0;

    /* JADX INFO: renamed from: y */
    public final C0182l f2065y;

    /* JADX INFO: renamed from: y0 */
    public final float f2066y0;

    /* JADX INFO: renamed from: z */
    public SavedState f2067z;

    /* JADX INFO: renamed from: z0 */
    public final boolean f2068z0;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    @RestrictTo({RestrictTo.Scope.LIBRARY})
    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0184n();

        /* JADX INFO: renamed from: e */
        public Parcelable f2073e;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f2073e = parcel.readParcelable(classLoader == null ? AbstractC0181k.class.getClassLoader() : classLoader);
        }

        @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeParcelable(this.f2073e, 0);
        }
    }

    static {
        Class cls = Integer.TYPE;
        f1990b1 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        f1991c1 = new cl5(2);
        f1992d1 = new ft8();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public RecyclerView(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) throws Throwable {
        float fM18240a;
        char c;
        int i2;
        Throwable th;
        ClassLoader classLoader;
        Constructor constructor;
        Object[] objArr;
        super(context, attributeSet, i);
        this.f2048i = new C0183m(this);
        this.f2065y = new C0182l(this);
        this.f1997C = new qz6(25);
        this.f2001E = new qs8(this, 0);
        this.f2003F = new Rect();
        this.f2005G = new Rect();
        this.f2007H = new RectF();
        this.f2013K = new ArrayList();
        this.f2015L = new ArrayList();
        this.f2017M = new ArrayList();
        this.f2027R = 0;
        this.f2041c0 = false;
        this.f2042d0 = false;
        this.f2044e0 = 0;
        this.f2045f0 = 0;
        this.f2046g0 = f1992d1;
        this.f2052l0 = new nl2();
        this.f2053m0 = 0;
        this.f2054n0 = -1;
        this.f2064x0 = Float.MIN_VALUE;
        this.f2066y0 = Float.MIN_VALUE;
        int i3 = 1;
        this.f2068z0 = true;
        this.f1994A0 = new gt8(this);
        this.f1998C0 = f1989a1 ? new zo1() : null;
        et8 et8Var = new et8();
        et8Var.f13098a = -1;
        et8Var.f13099b = 0;
        et8Var.f13100c = 0;
        et8Var.f13101d = 1;
        et8Var.f13102e = 0;
        et8Var.f13103f = false;
        et8Var.f13104g = false;
        et8Var.f13105h = false;
        et8Var.f13106i = false;
        et8Var.f13107j = false;
        et8Var.f13108k = false;
        this.f2000D0 = et8Var;
        this.f2004F0 = false;
        this.f2006G0 = false;
        rs8 rs8Var = new rs8(this);
        this.f2008H0 = rs8Var;
        this.f2010I0 = false;
        this.f2014K0 = new int[2];
        this.f2018M0 = new int[2];
        this.f2020N0 = new int[2];
        this.f2022O0 = new int[2];
        this.f2024P0 = new ArrayList();
        this.f2026Q0 = new qs8(this, i3);
        this.f2030S0 = 0;
        this.f2032T0 = 0;
        this.f2036V0 = new rs8(this);
        this.f2038W0 = new fu2(getContext(), new rs8(this));
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f2060t0 = viewConfiguration.getScaledTouchSlop();
        int i4 = Build.VERSION.SDK_INT;
        if (i4 >= 26) {
            Method method = ubb.f41756a;
            fM18240a = l40.m12766c(viewConfiguration);
        } else {
            fM18240a = ubb.m18240a(viewConfiguration, context);
        }
        this.f2064x0 = fM18240a;
        this.f2066y0 = i4 >= 26 ? l40.m12767d(viewConfiguration) : ubb.m18240a(viewConfiguration, context);
        this.f2062v0 = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f2063w0 = viewConfiguration.getScaledMaximumFlingVelocity();
        this.f2043e = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        setWillNotDraw(getOverScrollMode() == 2);
        this.f2052l0.f10191a = rs8Var;
        this.f1993A = new C0498fm(new rs8(this));
        this.f1995B = new rg1(new rs8(this));
        WeakHashMap weakHashMap = obb.f31348a;
        if ((i4 >= 26 ? ibb.m10628a(this) : 0) == 0 && i4 >= 26) {
            ibb.m10629b(this, 8);
        }
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        this.f2039a0 = (AccessibilityManager) getContext().getSystemService("accessibility");
        ht8 ht8Var = new ht8(this);
        this.f2012J0 = ht8Var;
        obb.m14621n(this, ht8Var);
        int[] iArr = eo8.f12855a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i, 0);
        obb.m14620m(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, i);
        String string = typedArrayObtainStyledAttributes.getString(8);
        if (typedArrayObtainStyledAttributes.getInt(2, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.f1999D = typedArrayObtainStyledAttributes.getBoolean(1, true);
        if (typedArrayObtainStyledAttributes.getBoolean(3, false)) {
            StateListDrawable stateListDrawable = (StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(6);
            Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(7);
            StateListDrawable stateListDrawable2 = (StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(4);
            Drawable drawable2 = typedArrayObtainStyledAttributes.getDrawable(5);
            if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
                C1521v3.m18903j("Trying to set fast scroller without both required drawables.".concat(m1301A()));
                throw null;
            }
            Resources resources = getContext().getResources();
            c = 3;
            i2 = 4;
            th = null;
            new eu3(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(ginlemon.flowerfree.R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(ginlemon.flowerfree.R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(ginlemon.flowerfree.R.dimen.fastscroll_margin));
        } else {
            c = 3;
            i2 = 4;
            th = null;
        }
        typedArrayObtainStyledAttributes.recycle();
        this.f2034U0 = context.getPackageManager().hasSystemFeature("android.hardware.rotaryencoder.lowres");
        if (string != null) {
            String strTrim = string.trim();
            if (!strTrim.isEmpty()) {
                if (strTrim.charAt(0) == '.') {
                    strTrim = context.getPackageName() + strTrim;
                } else if (!strTrim.contains(".")) {
                    strTrim = RecyclerView.class.getPackage().getName() + '.' + strTrim;
                }
                String str = strTrim;
                try {
                    try {
                        if (isInEditMode()) {
                            classLoader = getClass().getClassLoader();
                        } else {
                            try {
                                classLoader = context.getClassLoader();
                            } catch (ClassNotFoundException e) {
                                e = e;
                                th = null;
                                ro6.m16599j(attributeSet.getPositionDescription(), ": Unable to find LayoutManager ", str, e);
                                throw th;
                            } catch (IllegalAccessException e2) {
                                e = e2;
                                th = null;
                                ro6.m16599j(attributeSet.getPositionDescription(), ": Cannot access non-public constructor ", str, e);
                                throw th;
                            } catch (InstantiationException e3) {
                                e = e3;
                                th = null;
                                ro6.m16599j(attributeSet.getPositionDescription(), ": Could not instantiate the LayoutManager: ", str, e);
                                throw th;
                            } catch (InvocationTargetException e4) {
                                e = e4;
                                th = null;
                                ro6.m16599j(attributeSet.getPositionDescription(), ": Could not instantiate the LayoutManager: ", str, e);
                                throw th;
                            }
                        }
                        Class<? extends U> clsAsSubclass = Class.forName(str, false, classLoader).asSubclass(AbstractC0181k.class);
                        try {
                            constructor = clsAsSubclass.getConstructor(f1990b1);
                            objArr = new Object[i2];
                            objArr[0] = context;
                            objArr[i3] = attributeSet;
                            objArr[2] = Integer.valueOf(i);
                            objArr[c] = 0;
                        } catch (NoSuchMethodException e5) {
                            try {
                                constructor = clsAsSubclass.getConstructor(th);
                                objArr = null;
                            } catch (NoSuchMethodException e6) {
                                e6.initCause(e5);
                                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + str, e6);
                            }
                        }
                        constructor.setAccessible(true);
                        m1342m0((AbstractC0181k) constructor.newInstance(objArr));
                    } catch (ClassCastException e7) {
                        ro6.m16599j(attributeSet.getPositionDescription(), ": Class is not a LayoutManager ", str, e7);
                        throw null;
                    }
                } catch (ClassNotFoundException e8) {
                    e = e8;
                } catch (IllegalAccessException e9) {
                    e = e9;
                } catch (InstantiationException e10) {
                    e = e10;
                } catch (InvocationTargetException e11) {
                    e = e11;
                }
            }
        }
        int[] iArr2 = f1986X0;
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i, 0);
        obb.m14620m(this, context, iArr2, attributeSet, typedArrayObtainStyledAttributes2, i);
        boolean z = typedArrayObtainStyledAttributes2.getBoolean(0, true);
        typedArrayObtainStyledAttributes2.recycle();
        setNestedScrollingEnabled(z);
        setTag(ginlemon.flowerfree.R.id.is_pooling_container_tag, Boolean.TRUE);
    }

    /* JADX INFO: renamed from: G */
    public static RecyclerView m1291G(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            RecyclerView recyclerViewM1291G = m1291G(viewGroup.getChildAt(i));
            if (recyclerViewM1291G != null) {
                return recyclerViewM1291G;
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: M */
    public static AbstractC0185o m1292M(View view) {
        if (view == null) {
            return null;
        }
        return ((LayoutParams) view.getLayoutParams()).f2069a;
    }

    /* JADX INFO: renamed from: l */
    public static void m1299l(AbstractC0185o abstractC0185o) {
        WeakReference weakReference = abstractC0185o.f2182i;
        if (weakReference != null) {
            View view = (View) weakReference.get();
            while (view != null) {
                if (view == abstractC0185o.f2181e) {
                    return;
                }
                Object parent = view.getParent();
                view = parent instanceof View ? (View) parent : null;
            }
            abstractC0185o.f2182i = null;
        }
    }

    /* JADX INFO: renamed from: o */
    public static int m1300o(int i, EdgeEffect edgeEffect, EdgeEffect edgeEffect2, int i2) {
        if (i > 0 && edgeEffect != null && AbstractC0598hx.m10443z(edgeEffect) != 0.0f) {
            int iRound = Math.round(AbstractC0598hx.m10410M(edgeEffect, ((-i) * 4.0f) / i2, 0.5f) * ((-i2) / 4.0f));
            if (iRound != i) {
                edgeEffect.finish();
            }
            return i - iRound;
        }
        if (i >= 0 || edgeEffect2 == null || AbstractC0598hx.m10443z(edgeEffect2) == 0.0f) {
            return i;
        }
        float f = i2;
        int iRound2 = Math.round(AbstractC0598hx.m10410M(edgeEffect2, (i * 4.0f) / f, 0.5f) * (f / 4.0f));
        if (iRound2 != i) {
            edgeEffect2.finish();
        }
        return i - iRound2;
    }

    /* JADX INFO: renamed from: A */
    public final String m1301A() {
        return " " + super.toString() + ", adapter:" + this.f2009I + ", layout:" + this.f2011J + ", context:" + getContext();
    }

    /* JADX INFO: renamed from: B */
    public final void m1302B(et8 et8Var) {
        if (this.f2053m0 != 2) {
            et8Var.getClass();
            return;
        }
        OverScroller overScroller = this.f1994A0.f18514y;
        overScroller.getFinalX();
        overScroller.getCurrX();
        et8Var.getClass();
        overScroller.getFinalY();
        overScroller.getCurrY();
    }

    /* JADX INFO: renamed from: C */
    public final View m1303C(float f, float f2) {
        rg1 rg1Var = this.f1995B;
        for (int iM16513g = rg1Var.m16513g() - 1; iM16513g >= 0; iM16513g--) {
            View viewM16512f = rg1Var.m16512f(iM16513g);
            float translationX = viewM16512f.getTranslationX();
            float translationY = viewM16512f.getTranslationY();
            if (f >= viewM16512f.getLeft() + translationX && f <= viewM16512f.getRight() + translationX && f2 >= viewM16512f.getTop() + translationY && f2 <= viewM16512f.getBottom() + translationY) {
                return viewM16512f;
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: D */
    public final View m1304D(View view) {
        ViewParent parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = parent;
            parent = view.getParent();
        }
        if (parent == this) {
            return view;
        }
        return null;
    }

    /* JADX INFO: renamed from: E */
    public final boolean m1305E(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        ArrayList arrayList = this.f2017M;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            xs8 xs8Var = (xs8) arrayList.get(i);
            if (xs8Var.mo7767c(this, motionEvent) && action != 3) {
                this.f2019N = xs8Var;
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: F */
    public final void m1306F(int[] iArr) {
        rg1 rg1Var = this.f1995B;
        int iM16513g = rg1Var.m16513g();
        if (iM16513g == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i = Integer.MAX_VALUE;
        int i2 = RtlSpacingHelper.UNDEFINED;
        for (int i3 = 0; i3 < iM16513g; i3++) {
            AbstractC0185o abstractC0185oM1292M = m1292M(rg1Var.m16512f(i3));
            if (!abstractC0185oM1292M.m1512q()) {
                int iM1499d = abstractC0185oM1292M.m1499d();
                if (iM1499d < i) {
                    i = iM1499d;
                }
                if (iM1499d > i2) {
                    i2 = iM1499d;
                }
            }
        }
        iArr[0] = i;
        iArr[1] = i2;
    }

    /* JADX INFO: renamed from: H */
    public final AbstractC0185o m1307H(int i) {
        AbstractC0185o abstractC0185o = null;
        if (this.f2041c0) {
            return null;
        }
        rg1 rg1Var = this.f1995B;
        int iM16516k = rg1Var.m16516k();
        for (int i2 = 0; i2 < iM16516k; i2++) {
            AbstractC0185o abstractC0185oM1292M = m1292M(rg1Var.m16515j(i2));
            if (abstractC0185oM1292M != null && !abstractC0185oM1292M.m1505j() && m1309J(abstractC0185oM1292M) == i) {
                if (!((ArrayList) rg1Var.f36499e).contains(abstractC0185oM1292M.f2181e)) {
                    return abstractC0185oM1292M;
                }
                abstractC0185o = abstractC0185oM1292M;
            }
        }
        return abstractC0185o;
    }

    /* JADX WARN: Code duplicated, block: B:39:0x0078  */
    /* JADX WARN: Code duplicated, block: B:57:0x00ba  */
    /* JADX INFO: renamed from: I */
    public final boolean m1308I(int i, int i2, int i3, int i4) {
        int iMax;
        int i5;
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k == null) {
            Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return false;
        }
        if (!this.f2031T) {
            boolean zMo1275e = abstractC0181k.mo1275e();
            boolean zMo1277f = this.f2011J.mo1277f();
            if (!zMo1275e || Math.abs(i) < i3) {
                i = 0;
            }
            if (!zMo1277f || Math.abs(i2) < i3) {
                i2 = 0;
            }
            if (i != 0 || i2 != 0) {
                if (i == 0) {
                    iMax = 0;
                } else {
                    EdgeEffect edgeEffect = this.f2047h0;
                    if (edgeEffect == null || AbstractC0598hx.m10443z(edgeEffect) == 0.0f) {
                        EdgeEffect edgeEffect2 = this.f2050j0;
                        if (edgeEffect2 == null || AbstractC0598hx.m10443z(edgeEffect2) == 0.0f) {
                            iMax = 0;
                        } else if (m1347p0(this.f2050j0, i, getWidth())) {
                            this.f2050j0.onAbsorb(i);
                            i = 0;
                        }
                    } else {
                        int i6 = -i;
                        if (m1347p0(this.f2047h0, i6, getWidth())) {
                            this.f2047h0.onAbsorb(i6);
                            i = 0;
                        }
                    }
                    iMax = i;
                    i = 0;
                }
                if (i2 == 0) {
                    i5 = i2;
                    i2 = 0;
                } else {
                    EdgeEffect edgeEffect3 = this.f2049i0;
                    if (edgeEffect3 == null || AbstractC0598hx.m10443z(edgeEffect3) == 0.0f) {
                        EdgeEffect edgeEffect4 = this.f2051k0;
                        if (edgeEffect4 == null || AbstractC0598hx.m10443z(edgeEffect4) == 0.0f) {
                            i5 = i2;
                            i2 = 0;
                        } else if (m1347p0(this.f2051k0, i2, getHeight())) {
                            this.f2051k0.onAbsorb(i2);
                            i2 = 0;
                        }
                    } else {
                        int i7 = -i2;
                        if (m1347p0(this.f2049i0, i7, getHeight())) {
                            this.f2049i0.onAbsorb(i7);
                            i2 = 0;
                        }
                    }
                    i5 = 0;
                }
                gt8 gt8Var = this.f1994A0;
                if (iMax != 0 || i2 != 0) {
                    int i8 = -i4;
                    iMax = Math.max(i8, Math.min(iMax, i4));
                    i2 = Math.max(i8, Math.min(i2, i4));
                    m1355t0(1);
                    gt8Var.m9691a(iMax, i2);
                }
                if (i != 0 || i5 != 0) {
                    float f = i;
                    float f2 = i5;
                    if (!dispatchNestedPreFling(f, f2)) {
                        boolean z = zMo1275e || zMo1277f;
                        dispatchNestedFling(f, f2, z);
                        C0767l c0767l = this.f2061u0;
                        if (c0767l == null || !c0767l.m12534L(i, i5)) {
                            if (z) {
                                m1355t0(1);
                                int i9 = -i4;
                                gt8Var.m9691a(Math.max(i9, Math.min(i, i4)), Math.max(i9, Math.min(i5, i4)));
                                return true;
                            }
                        }
                        return true;
                    }
                } else if (iMax != 0 || i2 != 0) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: J */
    public final int m1309J(AbstractC0185o abstractC0185o) {
        if ((abstractC0185o.f2171F & 524) == 0 && abstractC0185o.m1502g()) {
            int i = abstractC0185o.f2183y;
            ArrayList arrayList = (ArrayList) this.f1993A.f14448c;
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0461em c0461em = (C0461em) arrayList.get(i2);
                int i3 = c0461em.f12745a;
                if (i3 != 1) {
                    if (i3 == 2) {
                        int i4 = c0461em.f12746b;
                        if (i4 <= i) {
                            int i5 = c0461em.f12748d;
                            if (i4 + i5 <= i) {
                                i -= i5;
                            }
                        } else {
                            continue;
                        }
                    } else if (i3 == 8) {
                        int i6 = c0461em.f12746b;
                        if (i6 == i) {
                            i = c0461em.f12748d;
                        } else {
                            if (i6 < i) {
                                i--;
                            }
                            if (c0461em.f12748d <= i) {
                                i++;
                            }
                        }
                    }
                } else if (c0461em.f12746b <= i) {
                    i += c0461em.f12748d;
                }
            }
            return i;
        }
        return -1;
    }

    /* JADX INFO: renamed from: K */
    public final long m1310K(AbstractC0185o abstractC0185o) {
        return this.f2009I.f2137b ? abstractC0185o.f2166A : abstractC0185o.f2183y;
    }

    /* JADX INFO: renamed from: L */
    public final AbstractC0185o m1311L(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return m1292M(view);
        }
        nxa.m14379d("View ", view, " is not a direct child of ", this);
        return null;
    }

    /* JADX INFO: renamed from: N */
    public final Rect m1312N(View view) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        boolean z = layoutParams.f2071c;
        Rect rect = layoutParams.f2070b;
        if (!z || (this.f2000D0.f13104g && (layoutParams.f2069a.m1508m() || layoutParams.f2069a.m1503h()))) {
            return rect;
        }
        rect.set(0, 0, 0, 0);
        ArrayList arrayList = this.f2015L;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            Rect rect2 = this.f2003F;
            rect2.set(0, 0, 0, 0);
            ((AbstractC0178h) arrayList.get(i)).mo1431f(rect2, view, this);
            rect.left += rect2.left;
            rect.top += rect2.top;
            rect.right += rect2.right;
            rect.bottom += rect2.bottom;
        }
        layoutParams.f2071c = false;
        return rect;
    }

    /* JADX INFO: renamed from: O */
    public final long m1313O() {
        if (f1989a1) {
            return System.nanoTime();
        }
        return 0L;
    }

    /* JADX INFO: renamed from: P */
    public final C1477tx m1314P() {
        if (this.f2016L0 == null) {
            this.f2016L0 = new C1477tx(this);
        }
        return this.f2016L0;
    }

    /* JADX INFO: renamed from: Q */
    public final boolean m1315Q() {
        return !this.f2025Q || this.f2041c0 || this.f1993A.m8169h();
    }

    /* JADX INFO: renamed from: R */
    public final boolean m1316R() {
        return this.f2044e0 > 0;
    }

    /* JADX INFO: renamed from: S */
    public final void m1317S(int i) {
        if (this.f2011J == null) {
            return;
        }
        m1345o0(2);
        this.f2011J.mo1290t0(i);
        awakenScrollBars();
    }

    /* JADX INFO: renamed from: T */
    public final void m1318T() {
        rg1 rg1Var = this.f1995B;
        int iM16516k = rg1Var.m16516k();
        for (int i = 0; i < iM16516k; i++) {
            ((LayoutParams) rg1Var.m16515j(i).getLayoutParams()).f2071c = true;
        }
        ArrayList arrayList = this.f2065y.f2158c;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            LayoutParams layoutParams = (LayoutParams) ((AbstractC0185o) arrayList.get(i2)).f2181e.getLayoutParams();
            if (layoutParams != null) {
                layoutParams.f2071c = true;
            }
        }
    }

    /* JADX INFO: renamed from: U */
    public final void m1319U(int i, int i2, boolean z) {
        int i3 = i + i2;
        rg1 rg1Var = this.f1995B;
        int iM16516k = rg1Var.m16516k();
        for (int i4 = 0; i4 < iM16516k; i4++) {
            AbstractC0185o abstractC0185oM1292M = m1292M(rg1Var.m16515j(i4));
            if (abstractC0185oM1292M != null && !abstractC0185oM1292M.m1512q()) {
                int i5 = abstractC0185oM1292M.f2183y;
                et8 et8Var = this.f2000D0;
                if (i5 >= i3) {
                    abstractC0185oM1292M.m1509n(-i2, z);
                    et8Var.f13103f = true;
                } else if (i5 >= i) {
                    abstractC0185oM1292M.m1496a(8);
                    abstractC0185oM1292M.m1509n(-i2, z);
                    abstractC0185oM1292M.f2183y = i - 1;
                    et8Var.f13103f = true;
                }
            }
        }
        C0182l c0182l = this.f2065y;
        ArrayList arrayList = c0182l.f2158c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            AbstractC0185o abstractC0185o = (AbstractC0185o) arrayList.get(size);
            if (abstractC0185o != null) {
                int i6 = abstractC0185o.f2183y;
                if (i6 >= i3) {
                    abstractC0185o.m1509n(-i2, z);
                } else if (i6 >= i) {
                    abstractC0185o.m1496a(8);
                    c0182l.m1483h(size);
                }
            }
        }
        requestLayout();
    }

    /* JADX INFO: renamed from: V */
    public final void m1320V() {
        this.f2044e0++;
    }

    /* JADX INFO: renamed from: W */
    public final void m1321W(boolean z) {
        int i;
        AccessibilityManager accessibilityManager;
        int i2 = this.f2044e0 - 1;
        this.f2044e0 = i2;
        if (i2 < 1) {
            this.f2044e0 = 0;
            if (z) {
                int i3 = this.f2035V;
                this.f2035V = 0;
                if (i3 != 0 && (accessibilityManager = this.f2039a0) != null && accessibilityManager.isEnabled()) {
                    AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain();
                    accessibilityEventObtain.setEventType(2048);
                    e5c.m7286D(accessibilityEventObtain, i3);
                    sendAccessibilityEventUnchecked(accessibilityEventObtain);
                }
                ArrayList arrayList = this.f2024P0;
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    AbstractC0185o abstractC0185o = (AbstractC0185o) arrayList.get(size);
                    if (abstractC0185o.f2181e.getParent() == this && !abstractC0185o.m1512q() && (i = abstractC0185o.f2178M) != -1) {
                        abstractC0185o.f2181e.setImportantForAccessibility(i);
                        abstractC0185o.f2178M = -1;
                    }
                }
                arrayList.clear();
            }
        }
    }

    /* JADX INFO: renamed from: X */
    public final void m1322X(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f2054n0) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f2054n0 = motionEvent.getPointerId(i);
            int x = (int) (motionEvent.getX(i) + 0.5f);
            this.f2058r0 = x;
            this.f2056p0 = x;
            int y = (int) (motionEvent.getY(i) + 0.5f);
            this.f2059s0 = y;
            this.f2057q0 = y;
        }
    }

    /* JADX INFO: renamed from: Y */
    public final void m1323Y() {
        if (this.f2010I0 || !this.f2021O) {
            return;
        }
        WeakHashMap weakHashMap = obb.f31348a;
        postOnAnimation(this.f2026Q0);
        this.f2010I0 = true;
    }

    /* JADX INFO: renamed from: Z */
    public final void m1324Z() {
        boolean z;
        boolean z2 = this.f2041c0;
        C0498fm c0498fm = this.f1993A;
        boolean z3 = false;
        if (z2) {
            c0498fm.m8173l((ArrayList) c0498fm.f14448c);
            c0498fm.m8173l((ArrayList) c0498fm.f14449d);
            c0498fm.f14446a = 0;
            if (this.f2042d0) {
                this.f2011J.mo1212a0();
            }
        }
        if (this.f2052l0 != null && this.f2011J.mo1204F0()) {
            c0498fm.m8172k();
        } else {
            c0498fm.m8165d();
        }
        boolean z4 = this.f2004F0 || this.f2006G0;
        boolean z5 = this.f2025Q && this.f2052l0 != null && ((z = this.f2041c0) || z4 || this.f2011J.f2146f) && (!z || this.f2009I.f2137b);
        et8 et8Var = this.f2000D0;
        et8Var.f13107j = z5;
        if (z5 && z4 && !this.f2041c0 && this.f2052l0 != null && this.f2011J.mo1204F0()) {
            z3 = true;
        }
        et8Var.f13108k = z3;
    }

    /* JADX INFO: renamed from: a0 */
    public final void m1325a0(boolean z) {
        this.f2042d0 = z | this.f2042d0;
        this.f2041c0 = true;
        rg1 rg1Var = this.f1995B;
        int iM16516k = rg1Var.m16516k();
        for (int i = 0; i < iM16516k; i++) {
            AbstractC0185o abstractC0185oM1292M = m1292M(rg1Var.m16515j(i));
            if (abstractC0185oM1292M != null && !abstractC0185oM1292M.m1512q()) {
                abstractC0185oM1292M.m1496a(6);
            }
        }
        m1318T();
        C0182l c0182l = this.f2065y;
        ArrayList arrayList = c0182l.f2158c;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            AbstractC0185o abstractC0185o = (AbstractC0185o) arrayList.get(i2);
            if (abstractC0185o != null) {
                abstractC0185o.m1496a(6);
                abstractC0185o.m1496a(Opcode.CAN_INITIALIZE_REFERENCE);
            }
        }
        AbstractC0177g abstractC0177g = c0182l.f2163h.f2009I;
        if (abstractC0177g == null || !abstractC0177g.f2137b) {
            c0182l.m1482g();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i, int i2) {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null) {
            abstractC0181k.getClass();
        }
        super.addFocusables(arrayList, i, i2);
    }

    /* JADX INFO: renamed from: b0 */
    public final void m1326b0(AbstractC0185o abstractC0185o, jn8 jn8Var) {
        abstractC0185o.f2171F &= -8193;
        boolean z = this.f2000D0.f13105h;
        qz6 qz6Var = this.f1997C;
        if (z && abstractC0185o.m1508m() && !abstractC0185o.m1505j() && !abstractC0185o.m1512q()) {
            ((ph6) qz6Var.f35721y).m15327j(m1310K(abstractC0185o), abstractC0185o);
        }
        uy9 uy9Var = (uy9) qz6Var.f35720i;
        ccb ccbVarM3156a = (ccb) uy9Var.get(abstractC0185o);
        if (ccbVarM3156a == null) {
            ccbVarM3156a = ccb.m3156a();
            uy9Var.put(abstractC0185o, ccbVarM3156a);
        }
        ccbVarM3156a.f5507b = jn8Var;
        ccbVarM3156a.f5506a |= 4;
    }

    /* JADX INFO: renamed from: c0 */
    public final void m1327c0() {
        boolean zIsFinished;
        EdgeEffect edgeEffect = this.f2047h0;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            zIsFinished = this.f2047h0.isFinished();
        } else {
            zIsFinished = false;
        }
        EdgeEffect edgeEffect2 = this.f2049i0;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            zIsFinished |= this.f2049i0.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f2050j0;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            zIsFinished |= this.f2050j0.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f2051k0;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            zIsFinished |= this.f2051k0.isFinished();
        }
        if (zIsFinished) {
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && this.f2011J.mo1220g((LayoutParams) layoutParams);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null && abstractC0181k.mo1275e()) {
            return this.f2011J.mo1286k(this.f2000D0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null && abstractC0181k.mo1275e()) {
            return this.f2011J.mo1223l(this.f2000D0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null && abstractC0181k.mo1275e()) {
            return this.f2011J.mo1225m(this.f2000D0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollExtent() {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null && abstractC0181k.mo1277f()) {
            return this.f2011J.mo1288n(this.f2000D0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollOffset() {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null && abstractC0181k.mo1277f()) {
            return this.f2011J.mo1228o(this.f2000D0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null && abstractC0181k.mo1277f()) {
            return this.f2011J.mo1230p(this.f2000D0);
        }
        return 0;
    }

    /* JADX INFO: renamed from: d0 */
    public final int m1328d0(int i, float f) {
        float height = f / getHeight();
        float width = i / getWidth();
        EdgeEffect edgeEffect = this.f2047h0;
        float f2 = 0.0f;
        if (edgeEffect == null || AbstractC0598hx.m10443z(edgeEffect) == 0.0f) {
            EdgeEffect edgeEffect2 = this.f2050j0;
            if (edgeEffect2 != null && AbstractC0598hx.m10443z(edgeEffect2) != 0.0f) {
                boolean zCanScrollHorizontally = canScrollHorizontally(1);
                EdgeEffect edgeEffect3 = this.f2050j0;
                if (zCanScrollHorizontally) {
                    edgeEffect3.onRelease();
                } else {
                    float fM10410M = AbstractC0598hx.m10410M(edgeEffect3, width, height);
                    if (AbstractC0598hx.m10443z(this.f2050j0) == 0.0f) {
                        this.f2050j0.onRelease();
                    }
                    f2 = fM10410M;
                }
                invalidate();
            }
        } else {
            boolean zCanScrollHorizontally2 = canScrollHorizontally(-1);
            EdgeEffect edgeEffect4 = this.f2047h0;
            if (zCanScrollHorizontally2) {
                edgeEffect4.onRelease();
            } else {
                float f3 = -AbstractC0598hx.m10410M(edgeEffect4, -width, 1.0f - height);
                if (AbstractC0598hx.m10443z(this.f2047h0) == 0.0f) {
                    this.f2047h0.onRelease();
                }
                f2 = f3;
            }
            invalidate();
        }
        return Math.round(f2 * getWidth());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (super.dispatchKeyEvent(keyEvent)) {
            return true;
        }
        AbstractC0181k abstractC0181k = this.f2011J;
        int iMo1422a = 0;
        if (abstractC0181k != null) {
            if (abstractC0181k.mo1277f()) {
                int keyCode = keyEvent.getKeyCode();
                if (keyCode == 92 || keyCode == 93) {
                    int measuredHeight = getMeasuredHeight();
                    if (keyCode == 93) {
                        m1349q0(0, measuredHeight, false);
                        return true;
                    }
                    m1349q0(0, -measuredHeight, false);
                    return true;
                }
                if (keyCode == 122 || keyCode == 123) {
                    boolean zMo1255M = abstractC0181k.mo1255M();
                    if (keyCode == 122) {
                        if (zMo1255M) {
                            iMo1422a = this.f2009I.mo1422a();
                        }
                    } else if (!zMo1255M) {
                        iMo1422a = this.f2009I.mo1422a();
                    }
                    m1351r0(iMo1422a);
                    return true;
                }
            } else if (abstractC0181k.mo1275e()) {
                int keyCode2 = keyEvent.getKeyCode();
                if (keyCode2 == 92 || keyCode2 == 93) {
                    int measuredWidth = getMeasuredWidth();
                    if (keyCode2 == 93) {
                        m1349q0(measuredWidth, 0, false);
                        return true;
                    }
                    m1349q0(-measuredWidth, 0, false);
                    return true;
                }
                if (keyCode2 == 122 || keyCode2 == 123) {
                    boolean zMo1255M2 = abstractC0181k.mo1255M();
                    if (keyCode2 == 122) {
                        if (zMo1255M2) {
                            iMo1422a = this.f2009I.mo1422a();
                        }
                    } else if (!zMo1255M2) {
                        iMo1422a = this.f2009I.mo1422a();
                    }
                    m1351r0(iMo1422a);
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        return m1314P().m17957a(f, f2, z);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f2) {
        return m1314P().m17958b(f, f2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return m1314P().m17959c(i, i2, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return m1314P().m17960d(i, i2, i3, i4, iArr, 0, null);
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        boolean z;
        super.draw(canvas);
        ArrayList arrayList = this.f2015L;
        int size = arrayList.size();
        boolean z2 = false;
        for (int i = 0; i < size; i++) {
            ((AbstractC0178h) arrayList.get(i)).mo1433h(canvas, this);
        }
        EdgeEffect edgeEffect = this.f2047h0;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z = false;
        } else {
            int iSave = canvas.save();
            int paddingBottom = this.f1999D ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, 0.0f);
            EdgeEffect edgeEffect2 = this.f2047h0;
            z = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect3 = this.f2049i0;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int iSave2 = canvas.save();
            if (this.f1999D) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.f2049i0;
            z |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(iSave2);
        }
        EdgeEffect edgeEffect5 = this.f2050j0;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int iSave3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.f1999D ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(paddingTop, -width);
            EdgeEffect edgeEffect6 = this.f2050j0;
            z |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(iSave3);
        }
        EdgeEffect edgeEffect7 = this.f2051k0;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int iSave4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.f1999D) {
                canvas.translate(getPaddingRight() + (-getWidth()), getPaddingBottom() + (-getHeight()));
            } else {
                canvas.translate(-getWidth(), -getHeight());
            }
            EdgeEffect edgeEffect8 = this.f2051k0;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z2 = true;
            }
            z |= z2;
            canvas.restoreToCount(iSave4);
        }
        if ((z || this.f2052l0 == null || arrayList.size() <= 0 || !this.f2052l0.mo6693o()) ? z : true) {
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j) {
        return super.drawChild(canvas, view, j);
    }

    /* JADX INFO: renamed from: e0 */
    public final int m1329e0(int i, float f) {
        float width = f / getWidth();
        float height = i / getHeight();
        EdgeEffect edgeEffect = this.f2049i0;
        float f2 = 0.0f;
        if (edgeEffect == null || AbstractC0598hx.m10443z(edgeEffect) == 0.0f) {
            EdgeEffect edgeEffect2 = this.f2051k0;
            if (edgeEffect2 != null && AbstractC0598hx.m10443z(edgeEffect2) != 0.0f) {
                boolean zCanScrollVertically = canScrollVertically(1);
                EdgeEffect edgeEffect3 = this.f2051k0;
                if (zCanScrollVertically) {
                    edgeEffect3.onRelease();
                } else {
                    float fM10410M = AbstractC0598hx.m10410M(edgeEffect3, height, 1.0f - width);
                    if (AbstractC0598hx.m10443z(this.f2051k0) == 0.0f) {
                        this.f2051k0.onRelease();
                    }
                    f2 = fM10410M;
                }
                invalidate();
            }
        } else {
            boolean zCanScrollVertically2 = canScrollVertically(-1);
            EdgeEffect edgeEffect4 = this.f2049i0;
            if (zCanScrollVertically2) {
                edgeEffect4.onRelease();
            } else {
                float f3 = -AbstractC0598hx.m10410M(edgeEffect4, -height, width);
                if (AbstractC0598hx.m10443z(this.f2049i0) == 0.0f) {
                    this.f2049i0.onRelease();
                }
                f2 = f3;
            }
            invalidate();
        }
        return Math.round(f2 * getHeight());
    }

    /* JADX INFO: renamed from: f0 */
    public final void m1330f0(AbstractC0178h abstractC0178h) {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null) {
            abstractC0181k.mo1272c("Cannot remove item decoration during a scroll  or layout");
        }
        ArrayList arrayList = this.f2015L;
        arrayList.remove(abstractC0178h);
        if (arrayList.isEmpty()) {
            setWillNotDraw(getOverScrollMode() == 2);
        }
        m1318T();
        requestLayout();
    }

    /* JADX WARN: Code duplicated, block: B:118:0x0167  */
    /* JADX WARN: Code duplicated, block: B:137:0x019e A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:138:0x019f  */
    /* JADX WARN: Code duplicated, block: B:24:0x004c  */
    @Override // android.view.ViewGroup, android.view.ViewParent
    public final View focusSearch(View view, int i) {
        View viewMo1207U;
        int i2;
        byte b;
        boolean z;
        this.f2011J.getClass();
        boolean z2 = true;
        boolean z3 = (this.f2009I == null || this.f2011J == null || m1316R() || this.f2031T) ? false : true;
        FocusFinder focusFinder = FocusFinder.getInstance();
        et8 et8Var = this.f2000D0;
        C0182l c0182l = this.f2065y;
        if (z3 && (i == 2 || i == 1)) {
            if (this.f2011J.mo1277f()) {
                if (focusFinder.findNextFocus(this, view, i == 2 ? 130 : 33) == null) {
                    z = true;
                } else {
                    z = false;
                }
            } else {
                z = false;
            }
            if (!z && this.f2011J.mo1275e()) {
                z = focusFinder.findNextFocus(this, view, (this.f2011J.f2142b.getLayoutDirection() == 1) ^ (i == 2) ? 66 : 17) == null;
            }
            if (z) {
                m1346p();
                if (m1304D(view) != null) {
                    m1353s0();
                    this.f2011J.mo1207U(view, i, c0182l, et8Var);
                    m1357u0(false);
                }
                return null;
            }
            viewMo1207U = focusFinder.findNextFocus(this, view, i);
            if (viewMo1207U == null) {
            }
            if (viewMo1207U != null) {
                z2 = false;
            } else {
                z2 = false;
            }
            if (z2) {
                return viewMo1207U;
            }
            return super.focusSearch(view, i);
        }
        View viewFindNextFocus = focusFinder.findNextFocus(this, view, i);
        if (viewFindNextFocus == null && z3) {
            m1346p();
            if (m1304D(view) != null) {
                m1353s0();
                viewMo1207U = this.f2011J.mo1207U(view, i, c0182l, et8Var);
                m1357u0(false);
            }
            return null;
        }
        viewMo1207U = viewFindNextFocus;
        if (viewMo1207U == null && !viewMo1207U.hasFocusable()) {
            if (getFocusedChild() == null) {
                return super.focusSearch(view, i);
            }
            m1331g0(viewMo1207U, null);
            return view;
        }
        if (viewMo1207U != null || viewMo1207U == this || viewMo1207U == view) {
            z2 = false;
        } else if (m1304D(viewMo1207U) == null) {
            z2 = false;
        } else if (view != null && m1304D(view) != null) {
            int width = view.getWidth();
            int height = view.getHeight();
            Rect rect = this.f2003F;
            rect.set(0, 0, width, height);
            int width2 = viewMo1207U.getWidth();
            int height2 = viewMo1207U.getHeight();
            Rect rect2 = this.f2005G;
            rect2.set(0, 0, width2, height2);
            offsetDescendantRectToMyCoords(view, rect);
            offsetDescendantRectToMyCoords(viewMo1207U, rect2);
            int i3 = this.f2011J.f2142b.getLayoutDirection() == 1 ? -1 : 1;
            int i4 = rect.left;
            int i5 = rect2.left;
            if ((i4 < i5 || rect.right <= i5) && rect.right < rect2.right) {
                i2 = 1;
            } else {
                int i6 = rect.right;
                int i7 = rect2.right;
                i2 = ((i6 > i7 || i4 >= i7) && i4 > i5) ? -1 : 0;
            }
            int i8 = rect.top;
            int i9 = rect2.top;
            if ((i8 < i9 || rect.bottom <= i9) && rect.bottom < rect2.bottom) {
                b = 1;
            } else {
                int i10 = rect.bottom;
                int i11 = rect2.bottom;
                b = ((i10 > i11 || i8 >= i11) && i8 > i9) ? (byte) -1 : (byte) 0;
            }
            if (i != 1) {
                if (i != 2) {
                    if (i != 17) {
                        if (i != 33) {
                            if (i != 66) {
                                if (i != 130) {
                                    throw new IllegalArgumentException("Invalid direction: " + i + m1301A());
                                }
                                if (b <= 0) {
                                    z2 = false;
                                }
                            } else if (i2 <= 0) {
                                z2 = false;
                            }
                        } else if (b >= 0) {
                            z2 = false;
                        }
                    } else if (i2 >= 0) {
                        z2 = false;
                    }
                } else if (b <= 0 && (b != 0 || i2 * i3 <= 0)) {
                    z2 = false;
                }
            } else if (b >= 0 && (b != 0 || i2 * i3 >= 0)) {
                z2 = false;
            }
        }
        if (z2) {
            return viewMo1207U;
        }
        return super.focusSearch(view, i);
    }

    /* JADX INFO: renamed from: g0 */
    public final void m1331g0(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        int width = view3.getWidth();
        int height = view3.getHeight();
        Rect rect = this.f2003F;
        rect.set(0, 0, width, height);
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof LayoutParams) {
            LayoutParams layoutParams2 = (LayoutParams) layoutParams;
            if (!layoutParams2.f2071c) {
                Rect rect2 = layoutParams2.f2070b;
                rect.left -= rect2.left;
                rect.right += rect2.right;
                rect.top -= rect2.top;
                rect.bottom += rect2.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, rect);
            offsetRectIntoDescendantCoords(view, rect);
        }
        this.f2011J.mo1467q0(this, view, this.f2003F, !this.f2025Q, view2 == null);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null) {
            return abstractC0181k.mo1234s();
        }
        C1521v3.m18909p("RecyclerView has no LayoutManager".concat(m1301A()));
        return null;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null) {
            return abstractC0181k.mo1237t(getContext(), attributeSet);
        }
        C1521v3.m18909p("RecyclerView has no LayoutManager".concat(m1301A()));
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    @Override // android.view.View
    public final int getBaseline() {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k == null) {
            return super.getBaseline();
        }
        abstractC0181k.getClass();
        return -1;
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i, int i2) {
        return super.getChildDrawingOrder(i, i2);
    }

    @Override // android.view.ViewGroup
    public final boolean getClipToPadding() {
        return this.f1999D;
    }

    /* JADX INFO: renamed from: h */
    public final void m1332h(AbstractC0185o abstractC0185o) {
        View view = abstractC0185o.f2181e;
        boolean z = view.getParent() == this;
        this.f2065y.m1488m(m1311L(view));
        boolean zM1507l = abstractC0185o.m1507l();
        rg1 rg1Var = this.f1995B;
        if (zM1507l) {
            rg1Var.m16509b(view, -1, view.getLayoutParams(), true);
            return;
        }
        if (!z) {
            rg1Var.m16508a(view, -1, true);
            return;
        }
        int iIndexOfChild = ((rs8) rg1Var.f36497c).f37241e.indexOfChild(view);
        if (iIndexOfChild < 0) {
            ro6.m16614y(view, "view is not a child, cannot hide ");
        } else {
            ((C0631iv) rg1Var.f36498d).m10927k(iIndexOfChild);
            rg1Var.m16517l(view);
        }
    }

    /* JADX WARN: Code duplicated, block: B:30:0x00d2  */
    /* JADX WARN: Code duplicated, block: B:32:0x00ea  */
    /* JADX WARN: Code duplicated, block: B:34:0x00ee  */
    /* JADX WARN: Code duplicated, block: B:35:0x0105 A[DONT_INVERT, PHI: r10
      0x0105: PHI (r10v9 boolean) = (r10v7 boolean), (r10v10 boolean) binds: [B:33:0x00ec, B:31:0x00e7] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:36:0x0107  */
    /* JADX WARN: Code duplicated, block: B:40:0x010f  */
    /* JADX WARN: Code duplicated, block: B:43:0x0118  */
    /* JADX INFO: renamed from: h0 */
    public final boolean m1333h0(int i, int i2, MotionEvent motionEvent, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        boolean z;
        float f;
        boolean z2;
        m1346p();
        AbstractC0177g abstractC0177g = this.f2009I;
        int[] iArr = this.f2022O0;
        if (abstractC0177g != null) {
            iArr[0] = 0;
            iArr[1] = 0;
            m1335i0(iArr, i, i2);
            int i8 = iArr[0];
            int i9 = iArr[1];
            i6 = i - i8;
            i7 = i2 - i9;
            i4 = i8;
            i5 = i9;
        } else {
            i4 = 0;
            i5 = 0;
            i6 = 0;
            i7 = 0;
        }
        if (!this.f2015L.isEmpty()) {
            invalidate();
        }
        iArr[0] = 0;
        iArr[1] = 0;
        m1314P().m17960d(i4, i5, i6, i7, this.f2018M0, i3, iArr);
        int i10 = iArr[0];
        int i11 = i6 - i10;
        int i12 = iArr[1];
        int i13 = i7 - i12;
        boolean z3 = (i10 == 0 && i12 == 0) ? false : true;
        int i14 = this.f2058r0;
        int[] iArr2 = this.f2018M0;
        int i15 = iArr2[0];
        this.f2058r0 = i14 - i15;
        int i16 = this.f2059s0;
        int i17 = iArr2[1];
        this.f2059s0 = i16 - i17;
        int[] iArr3 = this.f2020N0;
        iArr3[0] = iArr3[0] + i15;
        iArr3[1] = iArr3[1] + i17;
        if (getOverScrollMode() != 2) {
            if (motionEvent == null || hj4.m10175V(motionEvent, ItemType.STRING_DATA_ITEM)) {
                z = true;
            } else {
                float x = motionEvent.getX();
                float f2 = i11;
                float y = motionEvent.getY();
                float f3 = i13;
                if (f2 < 0.0f) {
                    m1361x();
                    f = 0.0f;
                    z = true;
                    AbstractC0598hx.m10410M(this.f2047h0, (-f2) / getWidth(), 1.0f - (y / getHeight()));
                } else {
                    f = 0.0f;
                    z = true;
                    if (f2 > 0.0f) {
                        m1362y();
                        AbstractC0598hx.m10410M(this.f2050j0, f2 / getWidth(), y / getHeight());
                    } else {
                        z2 = false;
                    }
                    if (f3 < f) {
                        m1363z();
                        AbstractC0598hx.m10410M(this.f2049i0, (-f3) / getHeight(), x / getWidth());
                    } else if (f3 > f) {
                        m1360w();
                        AbstractC0598hx.m10410M(this.f2051k0, f3 / getHeight(), 1.0f - (x / getWidth()));
                    } else {
                        if (z2 || f2 != f || f3 != f) {
                            postInvalidateOnAnimation();
                        }
                        if (Build.VERSION.SDK_INT >= 31 && hj4.m10175V(motionEvent, 4194304)) {
                            m1327c0();
                        }
                    }
                    z2 = z;
                    if (z2) {
                        postInvalidateOnAnimation();
                    } else {
                        postInvalidateOnAnimation();
                    }
                    if (Build.VERSION.SDK_INT >= 31) {
                        m1327c0();
                    }
                }
                z2 = z;
                if (f3 < f) {
                    m1363z();
                    AbstractC0598hx.m10410M(this.f2049i0, (-f3) / getHeight(), x / getWidth());
                } else if (f3 > f) {
                    m1360w();
                    AbstractC0598hx.m10410M(this.f2051k0, f3 / getHeight(), 1.0f - (x / getWidth()));
                } else {
                    if (z2) {
                        postInvalidateOnAnimation();
                    } else {
                        postInvalidateOnAnimation();
                    }
                    if (Build.VERSION.SDK_INT >= 31) {
                        m1327c0();
                    }
                }
                z2 = z;
                if (z2) {
                    postInvalidateOnAnimation();
                } else {
                    postInvalidateOnAnimation();
                }
                if (Build.VERSION.SDK_INT >= 31) {
                    m1327c0();
                }
            }
            m1343n(i, i2);
        } else {
            z = true;
        }
        if (i4 != 0 || i5 != 0) {
            m1358v(i4, i5);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        if (!z3 && i4 == 0 && i5 == 0) {
            return false;
        }
        return z;
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return m1314P().m17962f(0);
    }

    /* JADX INFO: renamed from: i */
    public final void m1334i(AbstractC0178h abstractC0178h) {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null) {
            abstractC0181k.mo1272c("Cannot add item decoration during a scroll  or layout");
        }
        ArrayList arrayList = this.f2015L;
        if (arrayList.isEmpty()) {
            setWillNotDraw(false);
        }
        arrayList.add(abstractC0178h);
        m1318T();
        requestLayout();
    }

    /* JADX INFO: renamed from: i0 */
    public final void m1335i0(int[] iArr, int i, int i2) {
        AbstractC0185o abstractC0185o;
        m1353s0();
        m1320V();
        Trace.beginSection("RV Scroll");
        et8 et8Var = this.f2000D0;
        m1302B(et8Var);
        C0182l c0182l = this.f2065y;
        int iMo1235s0 = i != 0 ? this.f2011J.mo1235s0(i, et8Var, c0182l) : 0;
        int iMo1240u0 = i2 != 0 ? this.f2011J.mo1240u0(i2, et8Var, c0182l) : 0;
        Trace.endSection();
        rg1 rg1Var = this.f1995B;
        int iM16513g = rg1Var.m16513g();
        for (int i3 = 0; i3 < iM16513g; i3++) {
            View viewM16512f = rg1Var.m16512f(i3);
            AbstractC0185o abstractC0185oM1311L = m1311L(viewM16512f);
            if (abstractC0185oM1311L != null && (abstractC0185o = abstractC0185oM1311L.f2170E) != null) {
                View view = abstractC0185o.f2181e;
                int left = viewM16512f.getLeft();
                int top = viewM16512f.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
        m1321W(true);
        m1357u0(false);
        if (iArr != null) {
            iArr[0] = iMo1235s0;
            iArr[1] = iMo1240u0;
        }
    }

    @Override // android.view.View
    public final boolean isAttachedToWindow() {
        return this.f2021O;
    }

    @Override // android.view.ViewGroup
    public final boolean isLayoutSuppressed() {
        return this.f2031T;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return m1314P().f41017a;
    }

    /* JADX INFO: renamed from: j */
    public final void m1336j(ys8 ys8Var) {
        if (this.f2002E0 == null) {
            this.f2002E0 = new ArrayList();
        }
        this.f2002E0.add(ys8Var);
    }

    /* JADX INFO: renamed from: j0 */
    public final void m1337j0(int i) {
        if (this.f2031T) {
            return;
        }
        m1359v0();
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k == null) {
            Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            abstractC0181k.mo1290t0(i);
            awakenScrollBars();
        }
    }

    /* JADX INFO: renamed from: k */
    public final void m1338k(String str) {
        if (!m1316R()) {
            if (this.f2045f0 > 0) {
                Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(m1301A()));
            }
        } else if (str == null) {
            C1521v3.m18909p("Cannot call this method while RecyclerView is computing a layout or scrolling".concat(m1301A()));
        } else {
            C1521v3.m18909p(str);
        }
    }

    /* JADX INFO: renamed from: k0 */
    public void mo1339k0(AbstractC0177g abstractC0177g) {
        suppressLayout(false);
        AbstractC0177g abstractC0177g2 = this.f2009I;
        C0183m c0183m = this.f2048i;
        if (abstractC0177g2 != null) {
            abstractC0177g2.f2136a.unregisterObserver(c0183m);
            this.f2009I.getClass();
        }
        cz9 cz9Var = this.f2052l0;
        if (cz9Var != null) {
            cz9Var.mo6692n();
        }
        AbstractC0181k abstractC0181k = this.f2011J;
        C0182l c0182l = this.f2065y;
        if (abstractC0181k != null) {
            abstractC0181k.m1462m0(c0182l);
            this.f2011J.m1463n0(c0182l);
        }
        c0182l.f2156a.clear();
        c0182l.m1482g();
        C0498fm c0498fm = this.f1993A;
        c0498fm.m8173l((ArrayList) c0498fm.f14448c);
        c0498fm.m8173l((ArrayList) c0498fm.f14449d);
        c0498fm.f14446a = 0;
        AbstractC0177g abstractC0177g3 = this.f2009I;
        this.f2009I = abstractC0177g;
        if (abstractC0177g != null) {
            abstractC0177g.f2136a.registerObserver(c0183m);
        }
        AbstractC0181k abstractC0181k2 = this.f2011J;
        if (abstractC0181k2 != null) {
            abstractC0181k2.mo1378R(this.f2009I);
        }
        AbstractC0177g abstractC0177g4 = this.f2009I;
        c0182l.f2156a.clear();
        c0182l.m1482g();
        c0182l.m1481f(abstractC0177g3, true);
        at8 at8VarM1478c = c0182l.m1478c();
        if (abstractC0177g3 != null) {
            at8VarM1478c.f2838b--;
        }
        if (at8VarM1478c.f2838b == 0) {
            at8VarM1478c.m1843a();
        }
        if (abstractC0177g4 != null) {
            at8VarM1478c.f2838b++;
        }
        c0182l.m1480e();
        this.f2000D0.f13103f = true;
        m1325a0(false);
        requestLayout();
    }

    /* JADX INFO: renamed from: l0 */
    public final void m1340l0(cz9 cz9Var) {
        cz9 cz9Var2 = this.f2052l0;
        if (cz9Var2 != null) {
            cz9Var2.mo6692n();
            this.f2052l0.f10191a = null;
        }
        this.f2052l0 = cz9Var;
        if (cz9Var != null) {
            cz9Var.f10191a = this.f2008H0;
        }
    }

    /* JADX INFO: renamed from: m */
    public final void m1341m() {
        rg1 rg1Var = this.f1995B;
        int iM16516k = rg1Var.m16516k();
        for (int i = 0; i < iM16516k; i++) {
            AbstractC0185o abstractC0185oM1292M = m1292M(rg1Var.m16515j(i));
            if (!abstractC0185oM1292M.m1512q()) {
                abstractC0185oM1292M.f2184z = -1;
                abstractC0185oM1292M.f2168C = -1;
            }
        }
        C0182l c0182l = this.f2065y;
        ArrayList arrayList = c0182l.f2156a;
        ArrayList arrayList2 = c0182l.f2158c;
        int size = arrayList2.size();
        for (int i2 = 0; i2 < size; i2++) {
            AbstractC0185o abstractC0185o = (AbstractC0185o) arrayList2.get(i2);
            abstractC0185o.f2184z = -1;
            abstractC0185o.f2168C = -1;
        }
        int size2 = arrayList.size();
        for (int i3 = 0; i3 < size2; i3++) {
            AbstractC0185o abstractC0185o2 = (AbstractC0185o) arrayList.get(i3);
            abstractC0185o2.f2184z = -1;
            abstractC0185o2.f2168C = -1;
        }
        ArrayList arrayList3 = c0182l.f2157b;
        if (arrayList3 != null) {
            int size3 = arrayList3.size();
            for (int i4 = 0; i4 < size3; i4++) {
                AbstractC0185o abstractC0185o3 = (AbstractC0185o) c0182l.f2157b.get(i4);
                abstractC0185o3.f2184z = -1;
                abstractC0185o3.f2168C = -1;
            }
        }
    }

    /* JADX INFO: renamed from: m0 */
    public final void m1342m0(AbstractC0181k abstractC0181k) {
        RecyclerView recyclerView;
        if (abstractC0181k == this.f2011J) {
            return;
        }
        m1359v0();
        AbstractC0181k abstractC0181k2 = this.f2011J;
        C0182l c0182l = this.f2065y;
        if (abstractC0181k2 != null) {
            cz9 cz9Var = this.f2052l0;
            if (cz9Var != null) {
                cz9Var.mo6692n();
            }
            this.f2011J.m1462m0(c0182l);
            this.f2011J.m1463n0(c0182l);
            c0182l.f2156a.clear();
            c0182l.m1482g();
            if (this.f2021O) {
                AbstractC0181k abstractC0181k3 = this.f2011J;
                abstractC0181k3.f2147g = false;
                abstractC0181k3.mo1263T(this);
            }
            this.f2011J.m1475z0(null);
            this.f2011J = null;
        } else {
            c0182l.f2156a.clear();
            c0182l.m1482g();
        }
        rg1 rg1Var = this.f1995B;
        ((C0631iv) rg1Var.f36498d).m10926j();
        ArrayList arrayList = (ArrayList) rg1Var.f36499e;
        int size = arrayList.size() - 1;
        while (true) {
            recyclerView = ((rs8) rg1Var.f36497c).f37241e;
            if (size < 0) {
                break;
            }
            AbstractC0185o abstractC0185oM1292M = m1292M((View) arrayList.get(size));
            if (abstractC0185oM1292M != null) {
                int i = abstractC0185oM1292M.f2177L;
                if (recyclerView.m1316R()) {
                    abstractC0185oM1292M.f2178M = i;
                    recyclerView.f2024P0.add(abstractC0185oM1292M);
                } else {
                    abstractC0185oM1292M.f2181e.setImportantForAccessibility(i);
                }
                abstractC0185oM1292M.f2177L = 0;
            }
            arrayList.remove(size);
            size--;
        }
        int childCount = recyclerView.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = recyclerView.getChildAt(i2);
            recyclerView.m1350r(childAt);
            childAt.clearAnimation();
        }
        recyclerView.removeAllViews();
        this.f2011J = abstractC0181k;
        if (abstractC0181k != null) {
            if (abstractC0181k.f2142b != null) {
                StringBuilder sb = new StringBuilder("LayoutManager ");
                sb.append(abstractC0181k);
                String strM1301A = abstractC0181k.f2142b.m1301A();
                sb.append(" is already attached to a RecyclerView:");
                sb.append(strM1301A);
                throw new IllegalArgumentException(sb.toString());
            }
            abstractC0181k.m1475z0(this);
            if (this.f2021O) {
                AbstractC0181k abstractC0181k4 = this.f2011J;
                abstractC0181k4.f2147g = true;
                abstractC0181k4.mo1456S(this);
            }
        }
        c0182l.m1489n();
        requestLayout();
    }

    /* JADX INFO: renamed from: n */
    public final void m1343n(int i, int i2) {
        boolean zIsFinished;
        EdgeEffect edgeEffect = this.f2047h0;
        if (edgeEffect == null || edgeEffect.isFinished() || i <= 0) {
            zIsFinished = false;
        } else {
            this.f2047h0.onRelease();
            zIsFinished = this.f2047h0.isFinished();
        }
        EdgeEffect edgeEffect2 = this.f2050j0;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i < 0) {
            this.f2050j0.onRelease();
            zIsFinished |= this.f2050j0.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f2049i0;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i2 > 0) {
            this.f2049i0.onRelease();
            zIsFinished |= this.f2049i0.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f2051k0;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i2 < 0) {
            this.f2051k0.onRelease();
            zIsFinished |= this.f2051k0.isFinished();
        }
        if (zIsFinished) {
            postInvalidateOnAnimation();
        }
    }

    /* JADX INFO: renamed from: n0 */
    public final void m1344n0(at8 at8Var) {
        C0182l c0182l = this.f2065y;
        RecyclerView recyclerView = c0182l.f2163h;
        c0182l.m1481f(recyclerView.f2009I, false);
        at8 at8Var2 = c0182l.f2162g;
        if (at8Var2 != null) {
            at8Var2.f2838b--;
        }
        c0182l.f2162g = at8Var;
        if (at8Var != null && recyclerView.f2009I != null) {
            at8Var.f2838b++;
        }
        c0182l.m1480e();
    }

    /* JADX INFO: renamed from: o0 */
    public final void m1345o0(int i) {
        C0174d c0174d;
        if (i == this.f2053m0) {
            return;
        }
        this.f2053m0 = i;
        if (i != 2) {
            gt8 gt8Var = this.f1994A0;
            gt8Var.f18511C.removeCallbacks(gt8Var);
            gt8Var.f18514y.abortAnimation();
            AbstractC0181k abstractC0181k = this.f2011J;
            if (abstractC0181k != null && (c0174d = abstractC0181k.f2145e) != null) {
                c0174d.m7101j();
            }
        }
        AbstractC0181k abstractC0181k2 = this.f2011J;
        if (abstractC0181k2 != null) {
            abstractC0181k2.mo1395i0(i);
        }
        ArrayList arrayList = this.f2002E0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((ys8) this.f2002E0.get(size)).mo10010a(this, i);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0058  */
    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        float refreshRate;
        super.onAttachedToWindow();
        this.f2044e0 = 0;
        this.f2021O = true;
        this.f2025Q = this.f2025Q && !isLayoutRequested();
        this.f2065y.m1480e();
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null) {
            abstractC0181k.f2147g = true;
            abstractC0181k.mo1456S(this);
        }
        this.f2010I0 = false;
        if (f1989a1) {
            ThreadLocal threadLocal = ll4.f26855A;
            ll4 ll4Var = (ll4) threadLocal.get();
            this.f1996B0 = ll4Var;
            if (ll4Var == null) {
                this.f1996B0 = new ll4();
                WeakHashMap weakHashMap = obb.f31348a;
                Display display = getDisplay();
                if (isInEditMode() || display == null) {
                    refreshRate = 60.0f;
                } else {
                    refreshRate = display.getRefreshRate();
                    if (refreshRate < 30.0f) {
                        refreshRate = 60.0f;
                    }
                }
                ll4 ll4Var2 = this.f1996B0;
                ll4Var2.f26859y = (long) (1.0E9f / refreshRate);
                threadLocal.set(ll4Var2);
            }
            ll4 ll4Var3 = this.f1996B0;
            ll4Var3.getClass();
            ll4Var3.f26857e.add(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        ll4 ll4Var;
        super.onDetachedFromWindow();
        cz9 cz9Var = this.f2052l0;
        if (cz9Var != null) {
            cz9Var.mo6692n();
        }
        m1359v0();
        int i = 0;
        this.f2021O = false;
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null) {
            abstractC0181k.f2147g = false;
            abstractC0181k.mo1263T(this);
        }
        this.f2024P0.clear();
        removeCallbacks(this.f2026Q0);
        this.f1997C.getClass();
        while (ccb.f5505d.mo2162a() != null) {
        }
        C0182l c0182l = this.f2065y;
        ArrayList arrayList = c0182l.f2158c;
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            z78.m21044d(((AbstractC0185o) arrayList.get(i2)).f2181e);
        }
        c0182l.m1481f(c0182l.f2163h.f2009I, false);
        while (i < getChildCount()) {
            int i3 = i + 1;
            View childAt = getChildAt(i);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            ArrayList arrayList2 = z78.m21047h(childAt).f427a;
            for (int iM21662E = zza.m21662E(arrayList2); -1 < iM21662E; iM21662E--) {
                ((sbb) arrayList2.get(iM21662E)).f38096a.m814d();
            }
            i = i3;
        }
        if (!f1989a1 || (ll4Var = this.f1996B0) == null) {
            return;
        }
        ll4Var.f26857e.remove(this);
        this.f1996B0 = null;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ArrayList arrayList = this.f2015L;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((AbstractC0178h) arrayList.get(i)).mo1432g(canvas, this);
        }
    }

    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        int i;
        boolean z;
        float axisValue;
        if (this.f2011J != null && !this.f2031T && motionEvent.getAction() == 8) {
            float f = 0.0f;
            if ((motionEvent.getSource() & 2) != 0) {
                float f2 = this.f2011J.mo1277f() ? -motionEvent.getAxisValue(9) : 0.0f;
                z = false;
                axisValue = this.f2011J.mo1275e() ? motionEvent.getAxisValue(10) : 0.0f;
                f = f2;
                i = 0;
            } else if ((motionEvent.getSource() & 4194304) != 0) {
                i = 26;
                axisValue = motionEvent.getAxisValue(26);
                if (this.f2011J.mo1277f()) {
                    float f3 = -axisValue;
                    axisValue = 0.0f;
                    f = f3;
                } else if (!this.f2011J.mo1275e()) {
                    axisValue = 0.0f;
                }
                z = this.f2034U0;
            } else {
                i = 0;
                z = false;
                axisValue = 0.0f;
            }
            int i2 = (int) (f * this.f2066y0);
            int i3 = (int) (axisValue * this.f2064x0);
            if (z) {
                OverScroller overScroller = this.f1994A0.f18514y;
                m1349q0((overScroller.getFinalX() - overScroller.getCurrX()) + i3, (overScroller.getFinalY() - overScroller.getCurrY()) + i2, true);
            } else {
                AbstractC0181k abstractC0181k = this.f2011J;
                if (abstractC0181k == null) {
                    Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
                } else if (!this.f2031T) {
                    int[] iArr = this.f2022O0;
                    iArr[0] = 0;
                    iArr[1] = 0;
                    boolean zMo1275e = abstractC0181k.mo1275e();
                    boolean zMo1277f = this.f2011J.mo1277f();
                    int i4 = zMo1277f ? (zMo1275e ? 1 : 0) | 2 : zMo1275e ? 1 : 0;
                    float y = motionEvent.getY();
                    float x = motionEvent.getX();
                    int iM1328d0 = i3 - m1328d0(i3, y);
                    int iM1329e0 = i2 - m1329e0(i2, x);
                    m1314P().m17965i(i4, 1);
                    if (m1314P().m17959c(zMo1275e ? iM1328d0 : 0, zMo1277f ? iM1329e0 : 0, 1, this.f2022O0, this.f2018M0)) {
                        iM1328d0 -= iArr[0];
                        iM1329e0 -= iArr[1];
                    }
                    m1333h0(zMo1275e ? iM1328d0 : 0, zMo1277f ? iM1329e0 : 0, motionEvent, 1);
                    ll4 ll4Var = this.f1996B0;
                    if (ll4Var != null && (iM1328d0 != 0 || iM1329e0 != 0)) {
                        ll4Var.m13083a(this, iM1328d0, iM1329e0);
                    }
                    m1314P().m17966j(1);
                }
            }
            if (i != 0 && !z) {
                this.f2038W0.m8298a(motionEvent, i);
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z;
        boolean z2;
        if (!this.f2031T) {
            this.f2019N = null;
            if (m1305E(motionEvent)) {
                VelocityTracker velocityTracker = this.f2055o0;
                if (velocityTracker != null) {
                    velocityTracker.clear();
                }
                m1314P().m17966j(0);
                m1327c0();
                m1345o0(0);
                return true;
            }
            AbstractC0181k abstractC0181k = this.f2011J;
            if (abstractC0181k != null) {
                boolean zMo1275e = abstractC0181k.mo1275e();
                boolean zMo1277f = this.f2011J.mo1277f();
                if (this.f2055o0 == null) {
                    this.f2055o0 = VelocityTracker.obtain();
                }
                this.f2055o0.addMovement(motionEvent);
                int actionMasked = motionEvent.getActionMasked();
                int actionIndex = motionEvent.getActionIndex();
                if (actionMasked == 0) {
                    if (this.f2033U) {
                        this.f2033U = false;
                    }
                    this.f2054n0 = motionEvent.getPointerId(0);
                    int x = (int) (motionEvent.getX() + 0.5f);
                    this.f2058r0 = x;
                    this.f2056p0 = x;
                    int y = (int) (motionEvent.getY() + 0.5f);
                    this.f2059s0 = y;
                    this.f2057q0 = y;
                    EdgeEffect edgeEffect = this.f2047h0;
                    if (edgeEffect == null || AbstractC0598hx.m10443z(edgeEffect) == 0.0f || canScrollHorizontally(-1)) {
                        z = false;
                    } else {
                        AbstractC0598hx.m10410M(this.f2047h0, 0.0f, 1.0f - (motionEvent.getY() / getHeight()));
                        z = true;
                    }
                    EdgeEffect edgeEffect2 = this.f2050j0;
                    if (edgeEffect2 != null && AbstractC0598hx.m10443z(edgeEffect2) != 0.0f && !canScrollHorizontally(1)) {
                        AbstractC0598hx.m10410M(this.f2050j0, 0.0f, motionEvent.getY() / getHeight());
                        z = true;
                    }
                    EdgeEffect edgeEffect3 = this.f2049i0;
                    if (edgeEffect3 != null && AbstractC0598hx.m10443z(edgeEffect3) != 0.0f && !canScrollVertically(-1)) {
                        AbstractC0598hx.m10410M(this.f2049i0, 0.0f, motionEvent.getX() / getWidth());
                        z = true;
                    }
                    EdgeEffect edgeEffect4 = this.f2051k0;
                    if (edgeEffect4 != null && AbstractC0598hx.m10443z(edgeEffect4) != 0.0f && !canScrollVertically(1)) {
                        AbstractC0598hx.m10410M(this.f2051k0, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
                        z = true;
                    }
                    if (z || this.f2053m0 == 2) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                        m1345o0(1);
                        m1314P().m17966j(1);
                    }
                    int[] iArr = this.f2020N0;
                    iArr[1] = 0;
                    iArr[0] = 0;
                    m1355t0(0);
                } else if (actionMasked == 1) {
                    this.f2055o0.clear();
                    m1314P().m17966j(0);
                } else if (actionMasked == 2) {
                    int iFindPointerIndex = motionEvent.findPointerIndex(this.f2054n0);
                    if (iFindPointerIndex < 0) {
                        Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f2054n0 + " not found. Did any MotionEvents get skipped?");
                        return false;
                    }
                    int x2 = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
                    int y2 = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
                    if (this.f2053m0 != 1) {
                        int i = x2 - this.f2056p0;
                        int i2 = y2 - this.f2057q0;
                        if (!zMo1275e || Math.abs(i) <= this.f2060t0) {
                            z2 = false;
                        } else {
                            this.f2058r0 = x2;
                            z2 = true;
                        }
                        if (zMo1277f && Math.abs(i2) > this.f2060t0) {
                            this.f2059s0 = y2;
                            z2 = true;
                        }
                        if (z2) {
                            m1345o0(1);
                        }
                    }
                } else if (actionMasked == 3) {
                    VelocityTracker velocityTracker2 = this.f2055o0;
                    if (velocityTracker2 != null) {
                        velocityTracker2.clear();
                    }
                    m1314P().m17966j(0);
                    m1327c0();
                    m1345o0(0);
                } else if (actionMasked == 5) {
                    this.f2054n0 = motionEvent.getPointerId(actionIndex);
                    int x3 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                    this.f2058r0 = x3;
                    this.f2056p0 = x3;
                    int y3 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                    this.f2059s0 = y3;
                    this.f2057q0 = y3;
                } else if (actionMasked == 6) {
                    m1322X(motionEvent);
                }
                if (this.f2053m0 == 1) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        Trace.beginSection("RV OnLayout");
        m1352s();
        Trace.endSection();
        this.f2025Q = true;
    }

    @Override // android.view.View
    public void onMeasure(int i, int i2) {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k == null) {
            m1348q(i, i2);
            return;
        }
        boolean zMo1253L = abstractC0181k.mo1253L();
        boolean z = false;
        et8 et8Var = this.f2000D0;
        if (zMo1253L) {
            int mode = View.MeasureSpec.getMode(i);
            int mode2 = View.MeasureSpec.getMode(i2);
            this.f2011J.f2142b.m1348q(i, i2);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z = true;
            }
            this.f2028R0 = z;
            if (z || this.f2009I == null) {
                return;
            }
            if (et8Var.f13101d == 1) {
                m1354t();
            }
            this.f2011J.m1472w0(i, i2);
            et8Var.f13106i = true;
            m1356u();
            this.f2011J.m1473y0(i, i2);
            if (this.f2011J.mo1247B0()) {
                this.f2011J.m1472w0(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                et8Var.f13106i = true;
                m1356u();
                this.f2011J.m1473y0(i, i2);
            }
            this.f2030S0 = getMeasuredWidth();
            this.f2032T0 = getMeasuredHeight();
            return;
        }
        if (this.f2023P) {
            this.f2011J.f2142b.m1348q(i, i2);
            return;
        }
        if (this.f2037W) {
            m1353s0();
            m1320V();
            m1324Z();
            m1321W(true);
            if (et8Var.f13108k) {
                et8Var.f13104g = true;
            } else {
                this.f1993A.m8165d();
                et8Var.f13104g = false;
            }
            this.f2037W = false;
            m1357u0(false);
        } else if (et8Var.f13108k) {
            setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
        AbstractC0177g abstractC0177g = this.f2009I;
        if (abstractC0177g != null) {
            et8Var.f13102e = abstractC0177g.mo1422a();
        } else {
            et8Var.f13102e = 0;
        }
        m1353s0();
        this.f2011J.f2142b.m1348q(i, i2);
        m1357u0(false);
        et8Var.f13104g = false;
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (m1316R()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i, rect);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        this.f2067z = savedState;
        super.onRestoreInstanceState(savedState.getSuperState());
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        SavedState savedState2 = this.f2067z;
        if (savedState2 != null) {
            savedState.f2073e = savedState2.f2073e;
            return savedState;
        }
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null) {
            savedState.f2073e = abstractC0181k.mo1281h0();
            return savedState;
        }
        savedState.f2073e = null;
        return savedState;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i == i3 && i2 == i4) {
            return;
        }
        this.f2051k0 = null;
        this.f2049i0 = null;
        this.f2050j0 = null;
        this.f2047h0 = null;
    }

    /* JADX WARN: Code duplicated, block: B:63:0x0117 A[PHI: r8
      0x0117: PHI (r8v7 int) = (r8v2 int), (r8v11 int) binds: [B:56:0x0102, B:61:0x0113] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean zM1305E;
        int i;
        char c;
        int i2;
        int i3;
        boolean z;
        if (!this.f2031T && !this.f2033U) {
            xs8 xs8Var = this.f2019N;
            if (xs8Var == null) {
                zM1305E = motionEvent.getAction() == 0 ? false : m1305E(motionEvent);
            } else {
                xs8Var.mo7766a(this, motionEvent);
                int action = motionEvent.getAction();
                if (action == 3 || action == 1) {
                    this.f2019N = null;
                }
                zM1305E = true;
            }
            if (zM1305E) {
                VelocityTracker velocityTracker = this.f2055o0;
                if (velocityTracker != null) {
                    velocityTracker.clear();
                }
                m1314P().m17966j(0);
                m1327c0();
                m1345o0(0);
                return true;
            }
            AbstractC0181k abstractC0181k = this.f2011J;
            if (abstractC0181k != null) {
                boolean zMo1275e = abstractC0181k.mo1275e();
                boolean zMo1277f = this.f2011J.mo1277f();
                if (this.f2055o0 == null) {
                    this.f2055o0 = VelocityTracker.obtain();
                }
                int actionMasked = motionEvent.getActionMasked();
                int actionIndex = motionEvent.getActionIndex();
                int[] iArr = this.f2020N0;
                if (actionMasked == 0) {
                    iArr[1] = 0;
                    iArr[0] = 0;
                }
                MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                motionEventObtain.offsetLocation(iArr[0], iArr[1]);
                if (actionMasked != 0) {
                    if (actionMasked == 1) {
                        this.f2055o0.addMovement(motionEventObtain);
                        VelocityTracker velocityTracker2 = this.f2055o0;
                        int i4 = this.f2063w0;
                        velocityTracker2.computeCurrentVelocity(1000, i4);
                        float f = zMo1275e ? -this.f2055o0.getXVelocity(this.f2054n0) : 0.0f;
                        float f2 = zMo1277f ? -this.f2055o0.getYVelocity(this.f2054n0) : 0.0f;
                        if (!(f == 0.0f && f2 == 0.0f) && m1308I((int) f, (int) f2, this.f2062v0, i4)) {
                            i = 0;
                        } else {
                            i = 0;
                            m1345o0(0);
                        }
                        VelocityTracker velocityTracker3 = this.f2055o0;
                        if (velocityTracker3 != null) {
                            velocityTracker3.clear();
                        }
                        m1314P().m17966j(i);
                        m1327c0();
                    } else if (actionMasked == 2) {
                        int iFindPointerIndex = motionEvent.findPointerIndex(this.f2054n0);
                        if (iFindPointerIndex < 0) {
                            Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f2054n0 + " not found. Did any MotionEvents get skipped?");
                            return false;
                        }
                        int x = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
                        int y = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
                        int iMax = this.f2058r0 - x;
                        int iMax2 = this.f2059s0 - y;
                        if (this.f2053m0 != 1) {
                            if (zMo1275e) {
                                int i5 = this.f2060t0;
                                iMax = iMax > 0 ? Math.max(0, iMax - i5) : Math.min(0, iMax + i5);
                                if (iMax != 0) {
                                    z = true;
                                } else {
                                    z = false;
                                }
                            } else {
                                z = false;
                            }
                            if (zMo1277f) {
                                int i6 = this.f2060t0;
                                iMax2 = iMax2 > 0 ? Math.max(0, iMax2 - i6) : Math.min(0, iMax2 + i6);
                                if (iMax2 != 0) {
                                    z = true;
                                }
                            }
                            if (z) {
                                m1345o0(1);
                            }
                        }
                        if (this.f2053m0 == 1) {
                            int[] iArr2 = this.f2022O0;
                            iArr2[0] = 0;
                            iArr2[1] = 0;
                            int iM1328d0 = iMax - m1328d0(iMax, motionEvent.getY());
                            int iM1329e0 = iMax2 - m1329e0(iMax2, motionEvent.getX());
                            boolean zM17959c = m1314P().m17959c(zMo1275e ? iM1328d0 : 0, zMo1277f ? iM1329e0 : 0, 0, this.f2022O0, this.f2018M0);
                            int[] iArr3 = this.f2018M0;
                            if (zM17959c) {
                                iM1328d0 -= iArr2[0];
                                iM1329e0 -= iArr2[1];
                                iArr[0] = iArr[0] + iArr3[0];
                                iArr[1] = iArr[1] + iArr3[1];
                                c = 1;
                                getParent().requestDisallowInterceptTouchEvent(true);
                            } else {
                                c = 1;
                            }
                            this.f2058r0 = x - iArr3[0];
                            this.f2059s0 = y - iArr3[c];
                            int i7 = zMo1275e ? iM1328d0 : 0;
                            if (zMo1277f) {
                                i2 = iM1329e0;
                                i3 = 0;
                            } else {
                                i2 = 0;
                                i3 = 0;
                            }
                            if (m1333h0(i7, i2, motionEvent, i3)) {
                                getParent().requestDisallowInterceptTouchEvent(true);
                            }
                            ll4 ll4Var = this.f1996B0;
                            if (ll4Var != null && (iM1328d0 != 0 || iM1329e0 != 0)) {
                                ll4Var.m13083a(this, iM1328d0, iM1329e0);
                            }
                        }
                    } else if (actionMasked == 3) {
                        VelocityTracker velocityTracker4 = this.f2055o0;
                        if (velocityTracker4 != null) {
                            velocityTracker4.clear();
                        }
                        m1314P().m17966j(0);
                        m1327c0();
                        m1345o0(0);
                    } else if (actionMasked == 5) {
                        this.f2054n0 = motionEvent.getPointerId(actionIndex);
                        int x2 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                        this.f2058r0 = x2;
                        this.f2056p0 = x2;
                        int y2 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                        this.f2059s0 = y2;
                        this.f2057q0 = y2;
                    } else if (actionMasked == 6) {
                        m1322X(motionEvent);
                    }
                    motionEventObtain.recycle();
                    return true;
                }
                this.f2054n0 = motionEvent.getPointerId(0);
                int x3 = (int) (motionEvent.getX() + 0.5f);
                this.f2058r0 = x3;
                this.f2056p0 = x3;
                int y3 = (int) (motionEvent.getY() + 0.5f);
                this.f2059s0 = y3;
                this.f2057q0 = y3;
                m1355t0(0);
                this.f2055o0.addMovement(motionEventObtain);
                motionEventObtain.recycle();
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: p */
    public final void m1346p() {
        if (!this.f2025Q || this.f2041c0) {
            Trace.beginSection("RV FullInvalidate");
            m1352s();
            Trace.endSection();
            return;
        }
        C0498fm c0498fm = this.f1993A;
        if (c0498fm.m8169h()) {
            int i = c0498fm.f14446a;
            if ((i & 4) == 0 || (i & 11) != 0) {
                if (c0498fm.m8169h()) {
                    Trace.beginSection("RV FullInvalidate");
                    m1352s();
                    Trace.endSection();
                    return;
                }
                return;
            }
            Trace.beginSection("RV PartialInvalidate");
            m1353s0();
            m1320V();
            c0498fm.m8172k();
            if (!this.f2029S) {
                rg1 rg1Var = this.f1995B;
                int iM16513g = rg1Var.m16513g();
                for (int i2 = 0; i2 < iM16513g; i2++) {
                    AbstractC0185o abstractC0185oM1292M = m1292M(rg1Var.m16512f(i2));
                    if (abstractC0185oM1292M != null && !abstractC0185oM1292M.m1512q() && abstractC0185oM1292M.m1508m()) {
                        m1352s();
                    }
                }
                c0498fm.m8164c();
            }
            m1357u0(true);
            m1321W(true);
            Trace.endSection();
        }
    }

    /* JADX INFO: renamed from: p0 */
    public final boolean m1347p0(EdgeEffect edgeEffect, int i, int i2) {
        if (i > 0) {
            return true;
        }
        float fM10443z = AbstractC0598hx.m10443z(edgeEffect) * i2;
        float fAbs = Math.abs(-i) * 0.35f;
        float f = this.f2043e * 0.015f;
        double dLog = Math.log(fAbs / f);
        double d = f1987Y0;
        return ((float) (Math.exp((d / (d - 1.0d)) * dLog) * ((double) f))) < fM10443z;
    }

    /* JADX INFO: renamed from: q */
    public final void m1348q(int i, int i2) {
        int paddingRight = getPaddingRight() + getPaddingLeft();
        WeakHashMap weakHashMap = obb.f31348a;
        setMeasuredDimension(AbstractC0181k.m1445h(i, paddingRight, getMinimumWidth()), AbstractC0181k.m1445h(i2, getPaddingBottom() + getPaddingTop(), getMinimumHeight()));
    }

    /* JADX INFO: renamed from: q0 */
    public final void m1349q0(int i, int i2, boolean z) {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f2031T) {
            return;
        }
        if (!abstractC0181k.mo1275e()) {
            i = 0;
        }
        if (!this.f2011J.mo1277f()) {
            i2 = 0;
        }
        if (i == 0 && i2 == 0) {
            return;
        }
        if (z) {
            int i3 = i != 0 ? 1 : 0;
            if (i2 != 0) {
                i3 |= 2;
            }
            m1314P().m17965i(i3, 1);
        }
        this.f1994A0.m9693c(i, i2, RtlSpacingHelper.UNDEFINED, null);
    }

    /* JADX INFO: renamed from: r */
    public final void m1350r(View view) {
        m1292M(view);
        ArrayList arrayList = this.f2040b0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((ws8) this.f2040b0.get(size)).mo6876b(view);
            }
        }
    }

    /* JADX INFO: renamed from: r0 */
    public final void m1351r0(int i) {
        if (this.f2031T) {
            return;
        }
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            abstractC0181k.mo1248D0(this, i);
        }
    }

    @Override // android.view.ViewGroup
    public final void removeDetachedView(View view, boolean z) {
        AbstractC0185o abstractC0185oM1292M = m1292M(view);
        if (abstractC0185oM1292M != null) {
            if (abstractC0185oM1292M.m1507l()) {
                abstractC0185oM1292M.f2171F &= -257;
            } else if (!abstractC0185oM1292M.m1512q()) {
                StringBuilder sb = new StringBuilder("Called removeDetachedView with a view which is not flagged as tmp detached.");
                sb.append(abstractC0185oM1292M);
                C1521v3.m18904k(sb, m1301A());
                return;
            }
        }
        view.clearAnimation();
        m1350r(view);
        super.removeDetachedView(view, z);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        C0174d c0174d = this.f2011J.f2145e;
        if ((c0174d == null || !c0174d.m7096d()) && !m1316R() && view2 != null) {
            m1331g0(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        return this.f2011J.mo1467q0(this, view, rect, z, false);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z) {
        ArrayList arrayList = this.f2017M;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((xs8) arrayList.get(i)).mo7768e(z);
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.f2027R != 0 || this.f2031T) {
            this.f2029S = true;
        } else {
            super.requestLayout();
        }
    }

    /* JADX WARN: Code duplicated, block: B:162:0x0359  */
    /* JADX WARN: Code duplicated, block: B:181:0x0399  */
    /* JADX WARN: Code duplicated, block: B:183:0x039c  */
    /* JADX WARN: Code duplicated, block: B:189:0x03b1  */
    /* JADX WARN: Code duplicated, block: B:191:0x03b7  */
    /* JADX WARN: Code duplicated, block: B:194:0x03bc  */
    /* JADX WARN: Code duplicated, block: B:197:0x03c4  */
    /* JADX WARN: Code duplicated, block: B:200:0x03cb  */
    /* JADX WARN: Code duplicated, block: B:203:0x03d4 A[LOOP:4: B:196:0x03c2->B:203:0x03d4, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:206:0x03e1  */
    /* JADX WARN: Code duplicated, block: B:209:0x03e8  */
    /* JADX WARN: Code duplicated, block: B:212:0x03f1 A[LOOP:5: B:205:0x03df->B:212:0x03f1, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:213:0x03f4  */
    /* JADX WARN: Code duplicated, block: B:215:0x03f7  */
    /* JADX WARN: Code duplicated, block: B:246:0x03d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:247:0x03d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:248:0x03f5 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:249:0x03af A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:250:0x03f4 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:251:0x03f4 A[SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: s */
    public final void m1352s() {
        boolean z;
        long j;
        AbstractC0185o abstractC0185o;
        View view;
        int i;
        int iM7762b;
        int i2;
        int iMin;
        AbstractC0185o abstractC0185oM1307H;
        View view2;
        AbstractC0185o abstractC0185oM1307H2;
        int i3;
        View viewFindViewById;
        boolean z2;
        int i4;
        boolean z3;
        if (this.f2009I == null) {
            Log.w("RecyclerView", "No adapter attached; skipping layout");
            return;
        }
        if (this.f2011J == null) {
            Log.e("RecyclerView", "No layout manager attached; skipping layout");
            return;
        }
        et8 et8Var = this.f2000D0;
        boolean z4 = false;
        et8Var.f13106i = false;
        boolean z5 = true;
        Object[] objArr = this.f2028R0 && !(this.f2030S0 == getWidth() && this.f2032T0 == getHeight());
        this.f2030S0 = 0;
        this.f2032T0 = 0;
        this.f2028R0 = false;
        if (et8Var.f13101d == 1) {
            m1354t();
            this.f2011J.m1470v0(this);
            m1356u();
        } else {
            C0498fm c0498fm = this.f1993A;
            if ((((ArrayList) c0498fm.f14449d).isEmpty() || ((ArrayList) c0498fm.f14448c).isEmpty()) && !objArr == true && this.f2011J.f2154n == getWidth() && this.f2011J.f2155o == getHeight()) {
                this.f2011J.m1470v0(this);
            } else {
                this.f2011J.m1470v0(this);
                m1356u();
            }
        }
        et8Var.m7761a(4);
        m1353s0();
        m1320V();
        et8Var.f13101d = 1;
        boolean z6 = et8Var.f13107j;
        rg1 rg1Var = this.f1995B;
        C0182l c0182l = this.f2065y;
        qz6 qz6Var = this.f1997C;
        if (z6) {
            int iM16513g = rg1Var.m16513g() - 1;
            while (iM16513g >= 0) {
                AbstractC0185o abstractC0185oM1292M = m1292M(rg1Var.m16512f(iM16513g));
                if (abstractC0185oM1292M.m1512q()) {
                    z3 = z5;
                } else {
                    long jM1310K = m1310K(abstractC0185oM1292M);
                    this.f2052l0.getClass();
                    jn8 jn8Var = new jn8();
                    jn8Var.m11479k(abstractC0185oM1292M);
                    ph6 ph6Var = (ph6) qz6Var.f35721y;
                    z3 = z5;
                    uy9 uy9Var = (uy9) qz6Var.f35720i;
                    AbstractC0185o abstractC0185o2 = (AbstractC0185o) ph6Var.m15322e(jM1310K);
                    if (abstractC0185o2 == null || abstractC0185o2.m1512q()) {
                        qz6Var.m16178d(abstractC0185oM1292M, jn8Var);
                    } else {
                        ccb ccbVar = (ccb) uy9Var.get(abstractC0185o2);
                        boolean z7 = (ccbVar == null || (ccbVar.f5506a & 1) == 0) ? z4 : z3;
                        ccb ccbVar2 = (ccb) uy9Var.get(abstractC0185oM1292M);
                        boolean z8 = (ccbVar2 == null || (ccbVar2.f5506a & 1) == 0) ? z4 : z3;
                        if (z7 && abstractC0185o2 == abstractC0185oM1292M) {
                            qz6Var.m16178d(abstractC0185oM1292M, jn8Var);
                        } else {
                            jn8 jn8VarM16189r = qz6Var.m16189r(abstractC0185o2, 4);
                            qz6Var.m16178d(abstractC0185oM1292M, jn8Var);
                            jn8 jn8VarM16189r2 = qz6Var.m16189r(abstractC0185oM1292M, 8);
                            if (jn8VarM16189r == null) {
                                int iM16513g2 = rg1Var.m16513g();
                                for (int i5 = 0; i5 < iM16513g2; i5++) {
                                    AbstractC0185o abstractC0185oM1292M2 = m1292M(rg1Var.m16512f(i5));
                                    if (abstractC0185oM1292M2 != abstractC0185oM1292M && m1310K(abstractC0185oM1292M2) == jM1310K) {
                                        AbstractC0177g abstractC0177g = this.f2009I;
                                        if (abstractC0177g == null || !abstractC0177g.f2137b) {
                                            StringBuilder sb = new StringBuilder("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:");
                                            sb.append(abstractC0185oM1292M2);
                                            sb.append(" \n View Holder 2:");
                                            sb.append(abstractC0185oM1292M);
                                            nxa.m14380e(sb, m1301A());
                                            return;
                                        }
                                        StringBuilder sb2 = new StringBuilder("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:");
                                        sb2.append(abstractC0185oM1292M2);
                                        sb2.append(" \n View Holder 2:");
                                        sb2.append(abstractC0185oM1292M);
                                        nxa.m14380e(sb2, m1301A());
                                        return;
                                    }
                                }
                                Log.e("RecyclerView", "Problem while matching changed view holders with the newones. The pre-layout information for the change holder " + abstractC0185o2 + " cannot be found but it is necessary for " + abstractC0185oM1292M + m1301A());
                            } else {
                                abstractC0185o2.m1511p(false);
                                if (z7) {
                                    m1332h(abstractC0185o2);
                                }
                                if (abstractC0185o2 != abstractC0185oM1292M) {
                                    if (z8) {
                                        m1332h(abstractC0185oM1292M);
                                    }
                                    abstractC0185o2.f2169D = abstractC0185oM1292M;
                                    m1332h(abstractC0185o2);
                                    c0182l.m1488m(abstractC0185o2);
                                    abstractC0185oM1292M.m1511p(false);
                                    abstractC0185oM1292M.f2170E = abstractC0185o2;
                                }
                                if (this.f2052l0.mo6683d(abstractC0185o2, abstractC0185oM1292M, jn8VarM16189r, jn8VarM16189r2)) {
                                    m1323Y();
                                }
                            }
                        }
                    }
                }
                iM16513g--;
                z5 = z3;
                z4 = false;
            }
            z = z5;
            uy9 uy9Var2 = (uy9) qz6Var.f35720i;
            for (int i6 = uy9Var2.f42820y - 1; i6 >= 0; i6--) {
                AbstractC0185o abstractC0185o3 = (AbstractC0185o) uy9Var2.m18748f(i6);
                ccb ccbVar3 = (ccb) uy9Var2.m18749g(i6);
                int i7 = ccbVar3.f5506a;
                int i8 = i7 & 3;
                rs8 rs8Var = this.f2036V0;
                if (i8 == 3) {
                    RecyclerView recyclerView = rs8Var.f37241e;
                    recyclerView.f2011J.m1464o0(abstractC0185o3.f2181e, recyclerView.f2065y);
                } else if ((i7 & 1) != 0) {
                    jn8 jn8Var2 = ccbVar3.f5507b;
                    if (jn8Var2 == null) {
                        RecyclerView recyclerView2 = rs8Var.f37241e;
                        recyclerView2.f2011J.m1464o0(abstractC0185o3.f2181e, recyclerView2.f2065y);
                    } else {
                        jn8 jn8Var3 = ccbVar3.f5508c;
                        RecyclerView recyclerView3 = rs8Var.f37241e;
                        recyclerView3.f2065y.m1488m(abstractC0185o3);
                        recyclerView3.m1332h(abstractC0185o3);
                        abstractC0185o3.m1511p(false);
                        if (recyclerView3.f2052l0.mo6684e(abstractC0185o3, jn8Var2, jn8Var3)) {
                            recyclerView3.m1323Y();
                        }
                    }
                } else if ((i7 & 14) == 14) {
                    jn8 jn8Var4 = ccbVar3.f5507b;
                    jn8 jn8Var5 = ccbVar3.f5508c;
                    RecyclerView recyclerView4 = rs8Var.f37241e;
                    abstractC0185o3.m1511p(false);
                    if (recyclerView4.f2052l0.mo6681b(abstractC0185o3, jn8Var4, jn8Var5)) {
                        recyclerView4.m1323Y();
                    }
                } else if ((i7 & 12) == 12) {
                    jn8 jn8Var6 = ccbVar3.f5507b;
                    jn8 jn8Var7 = ccbVar3.f5508c;
                    rs8Var.getClass();
                    abstractC0185o3.m1511p(false);
                    RecyclerView recyclerView5 = rs8Var.f37241e;
                    boolean z9 = recyclerView5.f2041c0;
                    cz9 cz9Var = recyclerView5.f2052l0;
                    if (z9) {
                        if (cz9Var.mo6683d(abstractC0185o3, abstractC0185o3, jn8Var6, jn8Var7)) {
                            recyclerView5.m1323Y();
                        }
                    } else if (cz9Var.mo6686g(abstractC0185o3, jn8Var6, jn8Var7)) {
                        recyclerView5.m1323Y();
                    }
                } else if ((i7 & 4) != 0) {
                    jn8 jn8Var8 = ccbVar3.f5507b;
                    RecyclerView recyclerView6 = rs8Var.f37241e;
                    recyclerView6.f2065y.m1488m(abstractC0185o3);
                    recyclerView6.m1332h(abstractC0185o3);
                    abstractC0185o3.m1511p(false);
                    if (recyclerView6.f2052l0.mo6684e(abstractC0185o3, jn8Var8, null)) {
                        recyclerView6.m1323Y();
                    }
                } else {
                    if ((i7 & 8) != 0) {
                        jn8 jn8Var9 = ccbVar3.f5507b;
                        jn8 jn8Var10 = ccbVar3.f5508c;
                        RecyclerView recyclerView7 = rs8Var.f37241e;
                        i4 = 0;
                        abstractC0185o3.m1511p(false);
                        if (recyclerView7.f2052l0.mo6681b(abstractC0185o3, jn8Var9, jn8Var10)) {
                            recyclerView7.m1323Y();
                        }
                    }
                    ccbVar3.f5506a = i4;
                    ccbVar3.f5507b = null;
                    ccbVar3.f5508c = null;
                    ccb.f5505d.mo2164c(ccbVar3);
                }
                i4 = 0;
                ccbVar3.f5506a = i4;
                ccbVar3.f5507b = null;
                ccbVar3.f5508c = null;
                ccb.f5505d.mo2164c(ccbVar3);
            }
        } else {
            z = true;
        }
        this.f2011J.m1463n0(c0182l);
        et8Var.f13099b = et8Var.f13102e;
        this.f2041c0 = false;
        this.f2042d0 = false;
        et8Var.f13107j = false;
        et8Var.f13108k = false;
        this.f2011J.f2146f = false;
        ArrayList arrayList = c0182l.f2157b;
        if (arrayList != null) {
            arrayList.clear();
        }
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k.f2151k) {
            abstractC0181k.f2150j = 0;
            abstractC0181k.f2151k = false;
            c0182l.m1489n();
        }
        this.f2011J.mo1219f0(et8Var);
        boolean z10 = z;
        m1321W(z10);
        m1357u0(false);
        ((uy9) qz6Var.f35720i).clear();
        ((ph6) qz6Var.f35721y).m15319b();
        int[] iArr = this.f2014K0;
        int i9 = iArr[0];
        int i10 = iArr[z10 ? 1 : 0];
        m1306F(iArr);
        if (iArr[0] != i9 || iArr[z10 ? 1 : 0] != i10) {
            m1358v(0, 0);
        }
        if (this.f2068z0 && this.f2009I != null && hasFocus() && getDescendantFocusability() != 393216 && (getDescendantFocusability() != 131072 || !isFocused())) {
            if (isFocused()) {
                j = et8Var.f13110m;
                if (j == -1) {
                    abstractC0185o = null;
                } else {
                    abstractC0185o = null;
                }
                if (abstractC0185o != null) {
                    view2 = abstractC0185o.f2181e;
                    if (!((ArrayList) rg1Var.f36499e).contains(view2)) {
                        if (rg1Var.m16513g() <= 0) {
                            view = null;
                        } else {
                            i = et8Var.f13109l;
                            if (i == -1) {
                                i = 0;
                            }
                            iM7762b = et8Var.m7762b();
                            i2 = i;
                            while (true) {
                                if (i2 < iM7762b) {
                                    abstractC0185oM1307H2 = m1307H(i2);
                                    if (abstractC0185oM1307H2 != null) {
                                        view = abstractC0185oM1307H2.f2181e;
                                        if (!view.hasFocusable()) {
                                            i2++;
                                        }
                                    }
                                }
                                iMin = Math.min(iM7762b, i) - 1;
                                while (true) {
                                    if (iMin >= 0) {
                                        abstractC0185oM1307H = m1307H(iMin);
                                        if (abstractC0185oM1307H != null) {
                                            view2 = abstractC0185oM1307H.f2181e;
                                            if (view2.hasFocusable()) {
                                                view = view2;
                                            } else {
                                                iMin--;
                                            }
                                        }
                                    }
                                    view = null;
                                }
                            }
                        }
                    } else if (rg1Var.m16513g() <= 0) {
                        view = null;
                    } else {
                        i = et8Var.f13109l;
                        if (i == -1) {
                            i = 0;
                        }
                        iM7762b = et8Var.m7762b();
                        i2 = i;
                        while (true) {
                            if (i2 < iM7762b) {
                                abstractC0185oM1307H2 = m1307H(i2);
                                if (abstractC0185oM1307H2 != null) {
                                    view = abstractC0185oM1307H2.f2181e;
                                    if (!view.hasFocusable()) {
                                        i2++;
                                    }
                                }
                            }
                            iMin = Math.min(iM7762b, i) - 1;
                            while (true) {
                                if (iMin >= 0) {
                                    abstractC0185oM1307H = m1307H(iMin);
                                    if (abstractC0185oM1307H != null) {
                                        view2 = abstractC0185oM1307H.f2181e;
                                        if (view2.hasFocusable()) {
                                            view = view2;
                                        } else {
                                            iMin--;
                                        }
                                    }
                                }
                                view = null;
                            }
                        }
                    }
                } else if (rg1Var.m16513g() <= 0) {
                    view = null;
                } else {
                    i = et8Var.f13109l;
                    if (i == -1) {
                        i = 0;
                    }
                    iM7762b = et8Var.m7762b();
                    i2 = i;
                    while (true) {
                        if (i2 < iM7762b) {
                            abstractC0185oM1307H2 = m1307H(i2);
                            if (abstractC0185oM1307H2 != null) {
                                view = abstractC0185oM1307H2.f2181e;
                                if (!view.hasFocusable()) {
                                    i2++;
                                }
                            }
                        }
                        iMin = Math.min(iM7762b, i) - 1;
                        while (true) {
                            if (iMin >= 0) {
                                abstractC0185oM1307H = m1307H(iMin);
                                if (abstractC0185oM1307H != null) {
                                    view2 = abstractC0185oM1307H.f2181e;
                                    if (view2.hasFocusable()) {
                                        view = view2;
                                    } else {
                                        iMin--;
                                    }
                                }
                            }
                            view = null;
                        }
                    }
                }
                if (view != null) {
                    i3 = et8Var.f13111n;
                    if (i3 != -1) {
                        view = viewFindViewById;
                    }
                    view.requestFocus();
                }
            } else if (((ArrayList) rg1Var.f36499e).contains(getFocusedChild())) {
                j = et8Var.f13110m;
                if (j == -1 && (z2 = this.f2009I.f2137b) && z2) {
                    int iM16516k = rg1Var.m16516k();
                    abstractC0185o = null;
                    for (int i11 = 0; i11 < iM16516k; i11++) {
                        AbstractC0185o abstractC0185oM1292M3 = m1292M(rg1Var.m16515j(i11));
                        if (abstractC0185oM1292M3 != null && !abstractC0185oM1292M3.m1505j() && abstractC0185oM1292M3.f2166A == j) {
                            if (!((ArrayList) rg1Var.f36499e).contains(abstractC0185oM1292M3.f2181e)) {
                                abstractC0185o = abstractC0185oM1292M3;
                                break;
                            }
                            abstractC0185o = abstractC0185oM1292M3;
                        }
                    }
                } else {
                    abstractC0185o = null;
                }
                if (abstractC0185o != null) {
                    view2 = abstractC0185o.f2181e;
                    if (!((ArrayList) rg1Var.f36499e).contains(view2) && view2.hasFocusable()) {
                        view = view2;
                    } else if (rg1Var.m16513g() <= 0) {
                        view = null;
                    } else {
                        i = et8Var.f13109l;
                        if (i == -1) {
                            i = 0;
                        }
                        iM7762b = et8Var.m7762b();
                        i2 = i;
                        while (true) {
                            if (i2 < iM7762b) {
                                abstractC0185oM1307H2 = m1307H(i2);
                                if (abstractC0185oM1307H2 != null) {
                                    view = abstractC0185oM1307H2.f2181e;
                                    if (!view.hasFocusable()) {
                                        i2++;
                                    }
                                }
                            }
                            iMin = Math.min(iM7762b, i) - 1;
                            while (true) {
                                if (iMin >= 0) {
                                    abstractC0185oM1307H = m1307H(iMin);
                                    if (abstractC0185oM1307H != null) {
                                        view2 = abstractC0185oM1307H.f2181e;
                                        if (view2.hasFocusable()) {
                                            view = view2;
                                        } else {
                                            iMin--;
                                        }
                                    }
                                }
                                view = null;
                            }
                        }
                    }
                } else if (rg1Var.m16513g() <= 0) {
                    view = null;
                } else {
                    i = et8Var.f13109l;
                    if (i == -1) {
                        i = 0;
                    }
                    iM7762b = et8Var.m7762b();
                    i2 = i;
                    while (true) {
                        if (i2 < iM7762b) {
                            abstractC0185oM1307H2 = m1307H(i2);
                            if (abstractC0185oM1307H2 != null) {
                                view = abstractC0185oM1307H2.f2181e;
                                if (!view.hasFocusable()) {
                                    i2++;
                                }
                            }
                        }
                        iMin = Math.min(iM7762b, i) - 1;
                        while (true) {
                            if (iMin >= 0) {
                                abstractC0185oM1307H = m1307H(iMin);
                                if (abstractC0185oM1307H != null) {
                                    view2 = abstractC0185oM1307H.f2181e;
                                    if (view2.hasFocusable()) {
                                        view = view2;
                                    } else {
                                        iMin--;
                                    }
                                }
                            }
                            view = null;
                        }
                    }
                }
                if (view != null) {
                    i3 = et8Var.f13111n;
                    if (i3 != -1 && (viewFindViewById = view.findViewById(i3)) != null && viewFindViewById.isFocusable()) {
                        view = viewFindViewById;
                    }
                    view.requestFocus();
                }
            }
        }
        et8Var.f13110m = -1L;
        et8Var.f13109l = -1;
        et8Var.f13111n = -1;
    }

    /* JADX INFO: renamed from: s0 */
    public final void m1353s0() {
        int i = this.f2027R + 1;
        this.f2027R = i;
        if (i != 1 || this.f2031T) {
            return;
        }
        this.f2029S = false;
    }

    @Override // android.view.View
    public final void scrollBy(int i, int i2) {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f2031T) {
            return;
        }
        boolean zMo1275e = abstractC0181k.mo1275e();
        boolean zMo1277f = this.f2011J.mo1277f();
        if (zMo1275e || zMo1277f) {
            if (!zMo1275e) {
                i = 0;
            }
            if (!zMo1277f) {
                i2 = 0;
            }
            m1333h0(i, i2, null, 0);
        }
    }

    @Override // android.view.View
    public final void scrollTo(int i, int i2) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (!m1316R()) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        } else {
            int iM7309u = accessibilityEvent != null ? e5c.m7309u(accessibilityEvent) : 0;
            this.f2035V |= iM7309u != 0 ? iM7309u : 0;
        }
    }

    @Override // android.view.ViewGroup
    public final void setClipToPadding(boolean z) {
        if (z != this.f1999D) {
            this.f2051k0 = null;
            this.f2049i0 = null;
            this.f2050j0 = null;
            this.f2047h0 = null;
        }
        this.f1999D = z;
        super.setClipToPadding(z);
        if (this.f2025Q) {
            requestLayout();
        }
    }

    @Override // android.view.ViewGroup
    public final void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition == null) {
            super.setLayoutTransition(null);
        } else {
            C1521v3.m18903j("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
        }
    }

    @Override // android.view.View
    public final void setNestedScrollingEnabled(boolean z) {
        C1477tx c1477txM1314P = m1314P();
        if (c1477txM1314P.f41017a) {
            ViewGroup viewGroup = (ViewGroup) c1477txM1314P.f41020d;
            WeakHashMap weakHashMap = obb.f31348a;
            fbb.m8068o(viewGroup);
        }
        c1477txM1314P.f41017a = z;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        return m1314P().m17965i(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        m1314P().m17966j(0);
    }

    @Override // android.view.ViewGroup
    public final void suppressLayout(boolean z) {
        if (z != this.f2031T) {
            m1338k("Do not suppressLayout in layout or scroll");
            if (z) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                onTouchEvent(MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0));
                this.f2031T = true;
                this.f2033U = true;
                m1359v0();
                return;
            }
            this.f2031T = false;
            if (this.f2029S && this.f2011J != null && this.f2009I != null) {
                requestLayout();
            }
            this.f2029S = false;
        }
    }

    /* JADX INFO: renamed from: t */
    public final void m1354t() {
        ccb ccbVar;
        View viewM1304D;
        et8 et8Var = this.f2000D0;
        et8Var.m7761a(1);
        m1302B(et8Var);
        et8Var.f13106i = false;
        m1353s0();
        qz6 qz6Var = this.f1997C;
        uy9 uy9Var = (uy9) qz6Var.f35720i;
        uy9 uy9Var2 = (uy9) qz6Var.f35720i;
        uy9Var.clear();
        ph6 ph6Var = (ph6) qz6Var.f35721y;
        ph6Var.m15319b();
        m1320V();
        m1324Z();
        AbstractC0185o abstractC0185oM1311L = null;
        View focusedChild = (this.f2068z0 && hasFocus() && this.f2009I != null) ? getFocusedChild() : null;
        if (focusedChild != null && (viewM1304D = m1304D(focusedChild)) != null) {
            abstractC0185oM1311L = m1311L(viewM1304D);
        }
        if (abstractC0185oM1311L == null) {
            et8Var.f13110m = -1L;
            et8Var.f13109l = -1;
            et8Var.f13111n = -1;
        } else {
            et8Var.f13110m = this.f2009I.f2137b ? abstractC0185oM1311L.f2166A : -1L;
            et8Var.f13109l = this.f2041c0 ? -1 : abstractC0185oM1311L.m1505j() ? abstractC0185oM1311L.f2184z : abstractC0185oM1311L.m1497b();
            View focusedChild2 = abstractC0185oM1311L.f2181e;
            int id = focusedChild2.getId();
            while (!focusedChild2.isFocused() && (focusedChild2 instanceof ViewGroup) && focusedChild2.hasFocus()) {
                focusedChild2 = ((ViewGroup) focusedChild2).getFocusedChild();
                if (focusedChild2.getId() != -1) {
                    id = focusedChild2.getId();
                }
            }
            et8Var.f13111n = id;
        }
        et8Var.f13105h = et8Var.f13107j && this.f2006G0;
        this.f2006G0 = false;
        this.f2004F0 = false;
        et8Var.f13104g = et8Var.f13108k;
        et8Var.f13102e = this.f2009I.mo1422a();
        m1306F(this.f2014K0);
        boolean z = et8Var.f13107j;
        rg1 rg1Var = this.f1995B;
        if (z) {
            int iM16513g = rg1Var.m16513g();
            for (int i = 0; i < iM16513g; i++) {
                AbstractC0185o abstractC0185oM1292M = m1292M(rg1Var.m16512f(i));
                if (!abstractC0185oM1292M.m1512q() && (!abstractC0185oM1292M.m1503h() || this.f2009I.f2137b)) {
                    cz9 cz9Var = this.f2052l0;
                    cz9.m6679i(abstractC0185oM1292M);
                    abstractC0185oM1292M.m1500e();
                    cz9Var.getClass();
                    jn8 jn8Var = new jn8();
                    jn8Var.m11479k(abstractC0185oM1292M);
                    ccb ccbVarM3156a = (ccb) uy9Var2.get(abstractC0185oM1292M);
                    if (ccbVarM3156a == null) {
                        ccbVarM3156a = ccb.m3156a();
                        uy9Var2.put(abstractC0185oM1292M, ccbVarM3156a);
                    }
                    ccbVarM3156a.f5507b = jn8Var;
                    ccbVarM3156a.f5506a |= 4;
                    if (et8Var.f13105h && abstractC0185oM1292M.m1508m() && !abstractC0185oM1292M.m1505j() && !abstractC0185oM1292M.m1512q() && !abstractC0185oM1292M.m1503h()) {
                        ph6Var.m15327j(m1310K(abstractC0185oM1292M), abstractC0185oM1292M);
                    }
                }
            }
        }
        if (et8Var.f13108k) {
            int iM16516k = rg1Var.m16516k();
            for (int i2 = 0; i2 < iM16516k; i2++) {
                AbstractC0185o abstractC0185oM1292M2 = m1292M(rg1Var.m16515j(i2));
                if (!abstractC0185oM1292M2.m1512q() && abstractC0185oM1292M2.f2184z == -1) {
                    abstractC0185oM1292M2.f2184z = abstractC0185oM1292M2.f2183y;
                }
            }
            boolean z2 = et8Var.f13103f;
            et8Var.f13103f = false;
            this.f2011J.mo1218e0(this.f2065y, et8Var);
            et8Var.f13103f = z2;
            for (int i3 = 0; i3 < rg1Var.m16513g(); i3++) {
                AbstractC0185o abstractC0185oM1292M3 = m1292M(rg1Var.m16512f(i3));
                if (!abstractC0185oM1292M3.m1512q() && ((ccbVar = (ccb) uy9Var2.get(abstractC0185oM1292M3)) == null || (ccbVar.f5506a & 4) == 0)) {
                    cz9.m6679i(abstractC0185oM1292M3);
                    boolean z3 = (abstractC0185oM1292M3.f2171F & 8192) != 0;
                    cz9 cz9Var2 = this.f2052l0;
                    abstractC0185oM1292M3.m1500e();
                    cz9Var2.getClass();
                    jn8 jn8Var2 = new jn8();
                    jn8Var2.m11479k(abstractC0185oM1292M3);
                    if (z3) {
                        m1326b0(abstractC0185oM1292M3, jn8Var2);
                    } else {
                        ccb ccbVarM3156a2 = (ccb) uy9Var2.get(abstractC0185oM1292M3);
                        if (ccbVarM3156a2 == null) {
                            ccbVarM3156a2 = ccb.m3156a();
                            uy9Var2.put(abstractC0185oM1292M3, ccbVarM3156a2);
                        }
                        ccbVarM3156a2.f5506a |= 2;
                        ccbVarM3156a2.f5507b = jn8Var2;
                    }
                }
            }
            m1341m();
        } else {
            m1341m();
        }
        m1321W(true);
        m1357u0(false);
        et8Var.f13101d = 2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: t0 */
    public final void m1355t0(int i) {
        boolean zMo1275e = this.f2011J.mo1275e();
        int i2 = zMo1275e;
        if (this.f2011J.mo1277f()) {
            i2 = (zMo1275e ? 1 : 0) | 2;
        }
        m1314P().m17965i(i2, i);
    }

    /* JADX INFO: renamed from: u */
    public final void m1356u() {
        m1353s0();
        m1320V();
        et8 et8Var = this.f2000D0;
        et8Var.m7761a(6);
        this.f1993A.m8165d();
        et8Var.f13102e = this.f2009I.mo1422a();
        et8Var.f13100c = 0;
        if (this.f2067z != null) {
            AbstractC0177g abstractC0177g = this.f2009I;
            int iM21067F = z82.m21067F(abstractC0177g.f2138c);
            if (iM21067F == 1 ? abstractC0177g.mo1422a() > 0 : iM21067F != 2) {
                Parcelable parcelable = this.f2067z.f2073e;
                if (parcelable != null) {
                    this.f2011J.mo1279g0(parcelable);
                }
                this.f2067z = null;
            }
        }
        et8Var.f13104g = false;
        this.f2011J.mo1218e0(this.f2065y, et8Var);
        et8Var.f13103f = false;
        et8Var.f13107j = et8Var.f13107j && this.f2052l0 != null;
        et8Var.f13101d = 4;
        m1321W(true);
        m1357u0(false);
    }

    /* JADX INFO: renamed from: u0 */
    public final void m1357u0(boolean z) {
        if (this.f2027R < 1) {
            this.f2027R = 1;
        }
        if (!z && !this.f2031T) {
            this.f2029S = false;
        }
        if (this.f2027R == 1) {
            if (z && this.f2029S && !this.f2031T && this.f2011J != null && this.f2009I != null) {
                m1352s();
            }
            if (!this.f2031T) {
                this.f2029S = false;
            }
        }
        this.f2027R--;
    }

    /* JADX INFO: renamed from: v */
    public final void m1358v(int i, int i2) {
        this.f2045f0++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i, scrollY - i2);
        ArrayList arrayList = this.f2002E0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((ys8) this.f2002E0.get(size)).mo6245b(this, i, i2);
            }
        }
        this.f2045f0--;
    }

    /* JADX INFO: renamed from: v0 */
    public final void m1359v0() {
        C0174d c0174d;
        m1345o0(0);
        gt8 gt8Var = this.f1994A0;
        gt8Var.f18511C.removeCallbacks(gt8Var);
        gt8Var.f18514y.abortAnimation();
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k == null || (c0174d = abstractC0181k.f2145e) == null) {
            return;
        }
        c0174d.m7101j();
    }

    /* JADX INFO: renamed from: w */
    public final void m1360w() {
        if (this.f2051k0 != null) {
            return;
        }
        EdgeEffect edgeEffectMo8178e = this.f2046g0.mo8178e(this);
        this.f2051k0 = edgeEffectMo8178e;
        if (this.f1999D) {
            edgeEffectMo8178e.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffectMo8178e.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    /* JADX INFO: renamed from: x */
    public final void m1361x() {
        if (this.f2047h0 != null) {
            return;
        }
        EdgeEffect edgeEffectMo8178e = this.f2046g0.mo8178e(this);
        this.f2047h0 = edgeEffectMo8178e;
        if (this.f1999D) {
            edgeEffectMo8178e.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffectMo8178e.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    /* JADX INFO: renamed from: y */
    public final void m1362y() {
        if (this.f2050j0 != null) {
            return;
        }
        EdgeEffect edgeEffectMo8178e = this.f2046g0.mo8178e(this);
        this.f2050j0 = edgeEffectMo8178e;
        if (this.f1999D) {
            edgeEffectMo8178e.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffectMo8178e.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    /* JADX INFO: renamed from: z */
    public final void m1363z() {
        if (this.f2049i0 != null) {
            return;
        }
        EdgeEffect edgeEffectMo8178e = this.f2046g0.mo8178e(this);
        this.f2049i0 = edgeEffectMo8178e;
        if (this.f1999D) {
            edgeEffectMo8178e.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffectMo8178e.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: a */
        public AbstractC0185o f2069a;

        /* JADX INFO: renamed from: b */
        public final Rect f2070b;

        /* JADX INFO: renamed from: c */
        public boolean f2071c;

        /* JADX INFO: renamed from: d */
        public boolean f2072d;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2070b = new Rect();
            this.f2071c = true;
            this.f2072d = false;
        }

        public LayoutParams(int i, int i2) {
            super(i, i2);
            this.f2070b = new Rect();
            this.f2071c = true;
            this.f2072d = false;
        }

        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f2070b = new Rect();
            this.f2071c = true;
            this.f2072d = false;
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f2070b = new Rect();
            this.f2071c = true;
            this.f2072d = false;
        }

        public LayoutParams(LayoutParams layoutParams) {
            super((ViewGroup.LayoutParams) layoutParams);
            this.f2070b = new Rect();
            this.f2071c = true;
            this.f2072d = false;
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        AbstractC0181k abstractC0181k = this.f2011J;
        if (abstractC0181k != null) {
            return abstractC0181k.mo1239u(layoutParams);
        }
        C1521v3.m18909p("RecyclerView has no LayoutManager".concat(m1301A()));
        return null;
    }

    public RecyclerView(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, ginlemon.flowerfree.R.attr.recyclerViewStyle);
    }

    public RecyclerView(Context context) {
        this(context, null);
    }
}
