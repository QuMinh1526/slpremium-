package androidx.viewpager2.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.AbstractC0177g;
import androidx.recyclerview.widget.AbstractC0181k;
import java.util.ArrayList;
import org.p003jf.dexlib2.dexbacked.raw.ItemType;
import p000.C0609i7;
import p000.C0767l;
import p000.C1521v3;
import p000.ag5;
import p000.bdb;
import p000.cc1;
import p000.cdb;
import p000.ddb;
import p000.edb;
import p000.hdb;
import p000.idb;
import p000.nd9;
import p000.obb;
import p000.od9;
import p000.oj2;
import p000.qn8;
import p000.vf3;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public final class ViewPager2 extends ViewGroup {

    /* JADX INFO: renamed from: A */
    public boolean f2414A;

    /* JADX INFO: renamed from: B */
    public final bdb f2415B;

    /* JADX INFO: renamed from: C */
    public edb f2416C;

    /* JADX INFO: renamed from: D */
    public int f2417D;

    /* JADX INFO: renamed from: E */
    public Parcelable f2418E;

    /* JADX INFO: renamed from: F */
    public idb f2419F;

    /* JADX INFO: renamed from: G */
    public hdb f2420G;

    /* JADX INFO: renamed from: H */
    public od9 f2421H;

    /* JADX INFO: renamed from: I */
    public cdb f2422I;

    /* JADX INFO: renamed from: J */
    public oj2 f2423J;

    /* JADX INFO: renamed from: K */
    public ag5 f2424K;

    /* JADX INFO: renamed from: L */
    public boolean f2425L;

    /* JADX INFO: renamed from: M */
    public final boolean f2426M;

    /* JADX INFO: renamed from: N */
    public int f2427N;

    /* JADX INFO: renamed from: O */
    public C0767l f2428O;

    /* JADX INFO: renamed from: e */
    public final Rect f2429e;

    /* JADX INFO: renamed from: i */
    public final Rect f2430i;

    /* JADX INFO: renamed from: y */
    public final cdb f2431y;

    /* JADX INFO: renamed from: z */
    public int f2432z;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0194a();

        /* JADX INFO: renamed from: e */
        public int f2433e;

        /* JADX INFO: renamed from: i */
        public int f2434i;

        /* JADX INFO: renamed from: y */
        public Parcelable f2435y;

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f2433e);
            parcel.writeInt(this.f2434i);
            parcel.writeParcelable(this.f2435y, i);
        }
    }

    public ViewPager2(Context context) {
        super(context);
        this.f2429e = new Rect();
        this.f2430i = new Rect();
        this.f2431y = new cdb();
        this.f2414A = false;
        this.f2415B = new bdb(this, 0);
        this.f2417D = -1;
        this.f2425L = false;
        this.f2426M = true;
        this.f2427N = -1;
        m1635b(context, null);
    }

    /* JADX INFO: renamed from: a */
    public final int m1634a() {
        int width;
        int paddingRight;
        idb idbVar = this.f2419F;
        if (this.f2416C.f1972p == 1) {
            width = idbVar.getHeight() - idbVar.getPaddingTop();
            paddingRight = idbVar.getPaddingBottom();
        } else {
            width = idbVar.getWidth() - idbVar.getPaddingLeft();
            paddingRight = idbVar.getPaddingRight();
        }
        return width - paddingRight;
    }

    /* JADX INFO: renamed from: b */
    public final void m1635b(Context context, AttributeSet attributeSet) {
        this.f2428O = new C0767l(this);
        idb idbVar = new idb(this, context);
        this.f2419F = idbVar;
        idbVar.setId(View.generateViewId());
        this.f2419F.setDescendantFocusability(131072);
        edb edbVar = new edb(this, context);
        this.f2416C = edbVar;
        this.f2419F.m1342m0(edbVar);
        idb idbVar2 = this.f2419F;
        idbVar2.f2060t0 = ViewConfiguration.get(idbVar2.getContext()).getScaledPagingTouchSlop();
        int[] iArr = qn8.f35211a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr);
        obb.m14620m(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, 0);
        int i = 0;
        try {
            this.f2416C.m1280g1(typedArrayObtainStyledAttributes.getInt(0, 0));
            this.f2428O.m12543U();
            typedArrayObtainStyledAttributes.recycle();
            this.f2419F.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
            idb idbVar3 = this.f2419F;
            ddb ddbVar = new ddb();
            if (idbVar3.f2040b0 == null) {
                idbVar3.f2040b0 = new ArrayList();
            }
            idbVar3.f2040b0.add(ddbVar);
            od9 od9Var = new od9(this);
            this.f2421H = od9Var;
            this.f2423J = new oj2(od9Var, 14);
            hdb hdbVar = new hdb(this);
            this.f2420G = hdbVar;
            hdbVar.m12549p(this.f2419F);
            this.f2419F.m1336j(this.f2421H);
            cdb cdbVar = new cdb();
            this.f2422I = cdbVar;
            this.f2421H.f31427a = cdbVar;
            cdb cdbVar2 = new cdb(this, i);
            int i2 = 1;
            cdb cdbVar3 = new cdb(this, i2);
            ((ArrayList) cdbVar.f5586b).add(cdbVar2);
            ((ArrayList) this.f2422I.f5586b).add(cdbVar3);
            C0767l c0767l = this.f2428O;
            idb idbVar4 = this.f2419F;
            c0767l.getClass();
            idbVar4.setImportantForAccessibility(2);
            c0767l.f25639z = new bdb(c0767l, i2);
            ViewPager2 viewPager2 = (ViewPager2) c0767l.f25635A;
            if (viewPager2.getImportantForAccessibility() == 0) {
                viewPager2.setImportantForAccessibility(1);
            }
            ((ArrayList) this.f2422I.f5586b).add(this.f2431y);
            ag5 ag5Var = new ag5(this.f2416C);
            this.f2424K = ag5Var;
            ((ArrayList) this.f2422I.f5586b).add(ag5Var);
            idb idbVar5 = this.f2419F;
            attachViewToParent(idbVar5, 0, idbVar5.getLayoutParams());
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    /* JADX INFO: renamed from: c */
    public final void m1636c() {
        AbstractC0177g abstractC0177g;
        int i = this.f2417D;
        if (i == -1 || (abstractC0177g = this.f2419F.f2009I) == null) {
            return;
        }
        if (this.f2418E != null) {
            this.f2418E = null;
        }
        int iMax = Math.max(0, Math.min(i, abstractC0177g.mo1422a() - 1));
        this.f2432z = iMax;
        this.f2417D = -1;
        this.f2419F.m1337j0(iMax);
        this.f2428O.m12543U();
    }

    @Override // android.view.View
    public final boolean canScrollHorizontally(int i) {
        return this.f2419F.canScrollHorizontally(i);
    }

    @Override // android.view.View
    public final boolean canScrollVertically(int i) {
        return this.f2419F.canScrollVertically(i);
    }

    /* JADX INFO: renamed from: d */
    public final void m1637d(int i, boolean z) {
        Object obj = this.f2423J.f31721i;
        m1638e(i, z);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        Parcelable parcelable = (Parcelable) sparseArray.get(getId());
        if (parcelable instanceof SavedState) {
            int i = ((SavedState) parcelable).f2433e;
            sparseArray.put(this.f2419F.getId(), (Parcelable) sparseArray.get(i));
            sparseArray.remove(i);
        }
        super.dispatchRestoreInstanceState(sparseArray);
        m1636c();
    }

    /* JADX INFO: renamed from: e */
    public final void m1638e(int i, boolean z) {
        cdb cdbVar;
        AbstractC0177g abstractC0177g = this.f2419F.f2009I;
        if (abstractC0177g == null) {
            if (this.f2417D != -1) {
                this.f2417D = Math.max(i, 0);
                return;
            }
            return;
        }
        if (abstractC0177g.mo1422a() <= 0) {
            return;
        }
        int iMin = Math.min(Math.max(i, 0), abstractC0177g.mo1422a() - 1);
        int i2 = this.f2432z;
        if (iMin == i2 && this.f2421H.f31432f == 0) {
            return;
        }
        if (iMin == i2 && z) {
            return;
        }
        double d = i2;
        this.f2432z = iMin;
        this.f2428O.m12543U();
        od9 od9Var = this.f2421H;
        if (od9Var.f31432f != 0) {
            od9Var.m14662e();
            nd9 nd9Var = od9Var.f31433g;
            d = ((double) nd9Var.f29856a) + ((double) nd9Var.f29857b);
        }
        od9 od9Var2 = this.f2421H;
        od9Var2.getClass();
        od9Var2.f31431e = z ? 2 : 3;
        boolean z2 = od9Var2.f31435i != iMin;
        od9Var2.f31435i = iMin;
        od9Var2.m14660c(2);
        if (z2 && (cdbVar = od9Var2.f31427a) != null) {
            cdbVar.mo366c(iMin);
        }
        if (!z) {
            this.f2419F.m1337j0(iMin);
            return;
        }
        double d2 = iMin;
        double dAbs = Math.abs(d2 - d);
        idb idbVar = this.f2419F;
        if (dAbs <= 3.0d) {
            idbVar.m1351r0(iMin);
            return;
        }
        idbVar.m1337j0(d2 > d ? iMin - 3 : iMin + 3);
        idb idbVar2 = this.f2419F;
        idbVar2.post(new cc1(iMin, idbVar2));
    }

    /* JADX INFO: renamed from: f */
    public final void m1639f() {
        hdb hdbVar = this.f2420G;
        if (hdbVar == null) {
            C1521v3.m18909p("Design assumption violated.");
            return;
        }
        View viewMo10052w = hdbVar.mo10052w(this.f2416C);
        if (viewMo10052w == null) {
            return;
        }
        this.f2416C.getClass();
        int iM1441H = AbstractC0181k.m1441H(viewMo10052w);
        if (iM1441H != this.f2432z && this.f2421H.f31432f == 0) {
            this.f2422I.mo366c(iM1441H);
        }
        this.f2414A = false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final CharSequence getAccessibilityClassName() {
        this.f2428O.getClass();
        this.f2428O.getClass();
        return "androidx.viewpager.widget.ViewPager";
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        int iMo1422a;
        int iMo1422a2;
        int iMo1422a3;
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        ViewPager2 viewPager2 = (ViewPager2) this.f2428O.f25635A;
        AbstractC0177g abstractC0177g = viewPager2.f2419F.f2009I;
        if (abstractC0177g != null) {
            if (viewPager2.f2416C.f1972p == 1) {
                iMo1422a = abstractC0177g.mo1422a();
                iMo1422a2 = 1;
            } else {
                iMo1422a2 = abstractC0177g.mo1422a();
                iMo1422a = 1;
            }
        } else {
            iMo1422a = 0;
            iMo1422a2 = 0;
        }
        accessibilityNodeInfo.setCollectionInfo((AccessibilityNodeInfo.CollectionInfo) C0609i7.m10579a(iMo1422a, iMo1422a2, 0).f20967a);
        AbstractC0177g abstractC0177g2 = viewPager2.f2419F.f2009I;
        if (abstractC0177g2 == null || (iMo1422a3 = abstractC0177g2.mo1422a()) == 0 || !viewPager2.f2426M) {
            return;
        }
        if (viewPager2.f2432z > 0) {
            accessibilityNodeInfo.addAction(8192);
        }
        if (viewPager2.f2432z < iMo1422a3 - 1) {
            accessibilityNodeInfo.addAction(ItemType.MAP_LIST);
        }
        accessibilityNodeInfo.setScrollable(true);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int measuredWidth = this.f2419F.getMeasuredWidth();
        int measuredHeight = this.f2419F.getMeasuredHeight();
        int paddingLeft = getPaddingLeft();
        Rect rect = this.f2429e;
        rect.left = paddingLeft;
        rect.right = (i3 - i) - getPaddingRight();
        rect.top = getPaddingTop();
        rect.bottom = (i4 - i2) - getPaddingBottom();
        Rect rect2 = this.f2430i;
        Gravity.apply(8388659, measuredWidth, measuredHeight, rect, rect2);
        this.f2419F.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
        if (this.f2414A) {
            m1639f();
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        measureChild(this.f2419F, i, i2);
        int measuredWidth = this.f2419F.getMeasuredWidth();
        int measuredHeight = this.f2419F.getMeasuredHeight();
        int measuredState = this.f2419F.getMeasuredState();
        int paddingRight = getPaddingRight() + getPaddingLeft() + measuredWidth;
        int paddingBottom = getPaddingBottom() + getPaddingTop() + measuredHeight;
        setMeasuredDimension(View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i, measuredState), View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i2, measuredState << 16));
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f2417D = savedState.f2434i;
        this.f2418E = savedState.f2435y;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f2433e = this.f2419F.getId();
        int i = this.f2417D;
        if (i == -1) {
            i = this.f2432z;
        }
        savedState.f2434i = i;
        Parcelable parcelable = this.f2418E;
        if (parcelable != null) {
            savedState.f2435y = parcelable;
            return savedState;
        }
        AbstractC0177g abstractC0177g = this.f2419F.f2009I;
        return savedState;
    }

    @Override // android.view.ViewGroup
    public final void onViewAdded(View view) {
        throw new IllegalStateException("ViewPager2 does not support direct child views");
    }

    @Override // android.view.View
    public final boolean performAccessibilityAction(int i, Bundle bundle) {
        this.f2428O.getClass();
        if (i != 8192 && i != 4096) {
            return super.performAccessibilityAction(i, bundle);
        }
        C0767l c0767l = this.f2428O;
        c0767l.getClass();
        if (i != 8192 && i != 4096) {
            vf3.m19087b();
            return false;
        }
        ViewPager2 viewPager2 = (ViewPager2) c0767l.f25635A;
        int i2 = viewPager2.f2432z;
        int i3 = i == 8192 ? i2 - 1 : i2 + 1;
        if (viewPager2.f2426M) {
            viewPager2.m1638e(i3, true);
        }
        return true;
    }

    @Override // android.view.View
    public final void setLayoutDirection(int i) {
        super.setLayoutDirection(i);
        this.f2428O.m12543U();
    }

    public ViewPager2(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f2429e = new Rect();
        this.f2430i = new Rect();
        this.f2431y = new cdb();
        this.f2414A = false;
        this.f2415B = new bdb(this, 0);
        this.f2417D = -1;
        this.f2425L = false;
        this.f2426M = true;
        this.f2427N = -1;
        m1635b(context, attributeSet);
    }

    public ViewPager2(@NonNull Context context, @Nullable AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2429e = new Rect();
        this.f2430i = new Rect();
        this.f2431y = new cdb();
        this.f2414A = false;
        this.f2415B = new bdb(this, 0);
        this.f2417D = -1;
        this.f2425L = false;
        this.f2426M = true;
        this.f2427N = -1;
        m1635b(context, attributeSet);
    }

    public ViewPager2(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.f2429e = new Rect();
        this.f2430i = new Rect();
        this.f2431y = new cdb();
        this.f2414A = false;
        this.f2415B = new bdb(this, 0);
        this.f2417D = -1;
        this.f2425L = false;
        this.f2426M = true;
        this.f2427N = -1;
        m1635b(context, attributeSet);
    }
}
