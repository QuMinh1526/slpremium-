package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.annotation.RestrictTo;
import androidx.core.graphics.drawable.IconCompat;
import p000.kab;
import p000.lab;
import p000.mab;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@RestrictTo({RestrictTo.Scope.LIBRARY})
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(kab kabVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        mab mabVarM11955g = remoteActionCompat.f1617a;
        boolean z = true;
        if (kabVar.mo11953e(1)) {
            mabVarM11955g = kabVar.m11955g();
        }
        remoteActionCompat.f1617a = (IconCompat) mabVarM11955g;
        CharSequence charSequence = remoteActionCompat.f1618b;
        if (kabVar.mo11953e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((lab) kabVar).f26381e);
        }
        remoteActionCompat.f1618b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f1619c;
        if (kabVar.mo11953e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((lab) kabVar).f26381e);
        }
        remoteActionCompat.f1619c = charSequence2;
        remoteActionCompat.f1620d = (PendingIntent) kabVar.m11954f(remoteActionCompat.f1620d, 4);
        boolean z2 = remoteActionCompat.f1621e;
        if (kabVar.mo11953e(5)) {
            z2 = ((lab) kabVar).f26381e.readInt() != 0;
        }
        remoteActionCompat.f1621e = z2;
        boolean z3 = remoteActionCompat.f1622f;
        if (!kabVar.mo11953e(6)) {
            z = z3;
        } else if (((lab) kabVar).f26381e.readInt() == 0) {
            z = false;
        }
        remoteActionCompat.f1622f = z;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, kab kabVar) {
        kabVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f1617a;
        kabVar.mo11956h(1);
        kabVar.m11957i(iconCompat);
        CharSequence charSequence = remoteActionCompat.f1618b;
        kabVar.mo11956h(2);
        Parcel parcel = ((lab) kabVar).f26381e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f1619c;
        kabVar.mo11956h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f1620d;
        kabVar.mo11956h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z = remoteActionCompat.f1621e;
        kabVar.mo11956h(5);
        parcel.writeInt(z ? 1 : 0);
        boolean z2 = remoteActionCompat.f1622f;
        kabVar.mo11956h(6);
        parcel.writeInt(z2 ? 1 : 0);
    }
}
