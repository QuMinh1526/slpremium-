package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import p000.mab;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public final class RemoteActionCompat implements mab {

    /* JADX INFO: renamed from: a */
    public IconCompat f1617a;

    /* JADX INFO: renamed from: b */
    public CharSequence f1618b;

    /* JADX INFO: renamed from: c */
    public CharSequence f1619c;

    /* JADX INFO: renamed from: d */
    public PendingIntent f1620d;

    /* JADX INFO: renamed from: e */
    public boolean f1621e;

    /* JADX INFO: renamed from: f */
    public boolean f1622f;
}
