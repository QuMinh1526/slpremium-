package androidx.core.app;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.util.HashMap;
import p000.C1521v3;
import p000.xo5;
import p000.yo5;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Deprecated
public abstract class JobIntentService extends Service {

    /* JADX INFO: renamed from: i */
    public static final HashMap f1615i = new HashMap();

    /* JADX INFO: renamed from: e */
    public yo5 f1616e;

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        yo5 yo5Var = this.f1616e;
        if (yo5Var != null) {
            return yo5Var.getBinder();
        }
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        int i = Build.VERSION.SDK_INT;
        if (i >= 26) {
            this.f1616e = new yo5(this);
            return;
        }
        this.f1616e = null;
        ComponentName componentName = new ComponentName(this, getClass());
        HashMap map = f1615i;
        if (((xo5) map.get(componentName)) == null) {
            if (i >= 26) {
                C1521v3.m18903j("Can't be here without a job id");
                return;
            }
            xo5 xo5Var = new xo5();
            getApplicationContext();
            PowerManager powerManager = (PowerManager) getSystemService("power");
            powerManager.newWakeLock(1, componentName.getClassName() + ":launch").setReferenceCounted(false);
            powerManager.newWakeLock(1, componentName.getClassName() + ":run").setReferenceCounted(false);
            map.put(componentName, xo5Var);
        }
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        return 2;
    }
}
