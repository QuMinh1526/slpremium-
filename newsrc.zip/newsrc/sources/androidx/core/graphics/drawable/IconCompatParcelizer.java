package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.RestrictTo;
import java.nio.charset.Charset;
import p000.C1521v3;
import p000.kab;
import p000.lab;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@RestrictTo({RestrictTo.Scope.LIBRARY})
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(kab kabVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f1631a = -1;
        iconCompat.f1633c = null;
        iconCompat.f1634d = null;
        iconCompat.f1635e = 0;
        iconCompat.f1636f = 0;
        iconCompat.f1637g = null;
        iconCompat.f1638h = IconCompat.f1630k;
        iconCompat.f1639i = null;
        iconCompat.f1631a = !kabVar.mo11953e(1) ? -1 : ((lab) kabVar).f26381e.readInt();
        byte[] bArr = iconCompat.f1633c;
        if (kabVar.mo11953e(2)) {
            Parcel parcel = ((lab) kabVar).f26381e;
            int i = parcel.readInt();
            if (i < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[i];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f1633c = bArr;
        iconCompat.f1634d = kabVar.m11954f(iconCompat.f1634d, 3);
        int i2 = iconCompat.f1635e;
        if (kabVar.mo11953e(4)) {
            i2 = ((lab) kabVar).f26381e.readInt();
        }
        iconCompat.f1635e = i2;
        int i3 = iconCompat.f1636f;
        if (kabVar.mo11953e(5)) {
            i3 = ((lab) kabVar).f26381e.readInt();
        }
        iconCompat.f1636f = i3;
        iconCompat.f1637g = (ColorStateList) kabVar.m11954f(iconCompat.f1637g, 6);
        String string = iconCompat.f1639i;
        if (kabVar.mo11953e(7)) {
            string = ((lab) kabVar).f26381e.readString();
        }
        iconCompat.f1639i = string;
        String string2 = iconCompat.f1640j;
        if (kabVar.mo11953e(8)) {
            string2 = ((lab) kabVar).f26381e.readString();
        }
        iconCompat.f1640j = string2;
        iconCompat.f1638h = PorterDuff.Mode.valueOf(iconCompat.f1639i);
        switch (iconCompat.f1631a) {
            case -1:
                Parcelable parcelable = iconCompat.f1634d;
                if (parcelable != null) {
                    iconCompat.f1632b = parcelable;
                    return iconCompat;
                }
                C1521v3.m18903j("Invalid icon");
                return null;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f1634d;
                if (parcelable2 != null) {
                    iconCompat.f1632b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.f1633c;
                iconCompat.f1632b = bArr3;
                iconCompat.f1631a = 3;
                iconCompat.f1635e = 0;
                iconCompat.f1636f = bArr3.length;
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str = new String(iconCompat.f1633c, Charset.forName("UTF-16"));
                iconCompat.f1632b = str;
                if (iconCompat.f1631a == 2 && iconCompat.f1640j == null) {
                    iconCompat.f1640j = str.split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.f1632b = iconCompat.f1633c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, kab kabVar) {
        kabVar.getClass();
        iconCompat.f1639i = iconCompat.f1638h.name();
        switch (iconCompat.f1631a) {
            case -1:
                iconCompat.f1634d = (Parcelable) iconCompat.f1632b;
                break;
            case 1:
            case 5:
                iconCompat.f1634d = (Parcelable) iconCompat.f1632b;
                break;
            case 2:
                iconCompat.f1633c = ((String) iconCompat.f1632b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f1633c = (byte[]) iconCompat.f1632b;
                break;
            case 4:
            case 6:
                iconCompat.f1633c = iconCompat.f1632b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i = iconCompat.f1631a;
        if (-1 != i) {
            kabVar.mo11956h(1);
            ((lab) kabVar).f26381e.writeInt(i);
        }
        byte[] bArr = iconCompat.f1633c;
        if (bArr != null) {
            kabVar.mo11956h(2);
            Parcel parcel = ((lab) kabVar).f26381e;
            parcel.writeInt(bArr.length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f1634d;
        if (parcelable != null) {
            kabVar.mo11956h(3);
            ((lab) kabVar).f26381e.writeParcelable(parcelable, 0);
        }
        int i2 = iconCompat.f1635e;
        if (i2 != 0) {
            kabVar.mo11956h(4);
            ((lab) kabVar).f26381e.writeInt(i2);
        }
        int i3 = iconCompat.f1636f;
        if (i3 != 0) {
            kabVar.mo11956h(5);
            ((lab) kabVar).f26381e.writeInt(i3);
        }
        ColorStateList colorStateList = iconCompat.f1637g;
        if (colorStateList != null) {
            kabVar.mo11956h(6);
            ((lab) kabVar).f26381e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f1639i;
        if (str != null) {
            kabVar.mo11956h(7);
            ((lab) kabVar).f26381e.writeString(str);
        }
        String str2 = iconCompat.f1640j;
        if (str2 != null) {
            kabVar.mo11956h(8);
            ((lab) kabVar).f26381e.writeString(str2);
        }
    }
}
