package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import com.squareup.picasso.BuildConfig;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import p000.C1521v3;
import p000.b72;
import p000.nxa;
import p000.o40;
import p000.qh3;
import p000.vf3;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* JADX INFO: renamed from: k */
    public static final PorterDuff.Mode f1630k = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: a */
    public int f1631a;

    /* JADX INFO: renamed from: b */
    public Object f1632b;

    /* JADX INFO: renamed from: c */
    public byte[] f1633c = null;

    /* JADX INFO: renamed from: d */
    public Parcelable f1634d = null;

    /* JADX INFO: renamed from: e */
    public int f1635e = 0;

    /* JADX INFO: renamed from: f */
    public int f1636f = 0;

    /* JADX INFO: renamed from: g */
    public ColorStateList f1637g = null;

    /* JADX INFO: renamed from: h */
    public PorterDuff.Mode f1638h = f1630k;

    /* JADX INFO: renamed from: i */
    public String f1639i = null;

    /* JADX INFO: renamed from: j */
    public String f1640j;

    public IconCompat(int i) {
        this.f1631a = i;
    }

    /* JADX INFO: renamed from: a */
    public static Bitmap m996a(Bitmap bitmap, boolean z) {
        int iMin = (int) (Math.min(bitmap.getWidth(), bitmap.getHeight()) * 0.6666667f);
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(iMin, iMin, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        Paint paint = new Paint(3);
        float f = iMin;
        float f2 = 0.5f * f;
        float f3 = 0.9166667f * f2;
        if (z) {
            float f4 = 0.010416667f * f;
            paint.setColor(0);
            paint.setShadowLayer(f4, 0.0f, f * 0.020833334f, 1023410176);
            canvas.drawCircle(f2, f2, f3, paint);
            paint.setShadowLayer(f4, 0.0f, 0.0f, 503316480);
            canvas.drawCircle(f2, f2, f3, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
        Matrix matrix = new Matrix();
        matrix.setTranslate((-(bitmap.getWidth() - iMin)) / 2.0f, (-(bitmap.getHeight() - iMin)) / 2.0f);
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader(bitmapShader);
        canvas.drawCircle(f2, f2, f3, paint);
        canvas.setBitmap(null);
        return bitmapCreateBitmap;
    }

    /* JADX INFO: renamed from: b */
    public static IconCompat m997b(int i) {
        if (i == 0) {
            C1521v3.m18903j("Drawable resource ID must not be 0");
            return null;
        }
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.f1635e = i;
        iconCompat.f1632b = BuildConfig.VERSION_NAME;
        iconCompat.f1640j = BuildConfig.VERSION_NAME;
        return iconCompat;
    }

    /* JADX INFO: renamed from: c */
    public final int m998c() {
        int i = this.f1631a;
        if (i != -1) {
            if (i == 2) {
                return this.f1635e;
            }
            nxa.m14376a(this, "called getResId() on ");
            return 0;
        }
        Object obj = this.f1632b;
        if (Build.VERSION.SDK_INT >= 28) {
            return o40.m14469e(obj);
        }
        try {
            return ((Integer) obj.getClass().getMethod("getResId", null).invoke(obj, null)).intValue();
        } catch (IllegalAccessException e) {
            Log.e("IconCompat", "Unable to get icon resource", e);
            return 0;
        } catch (NoSuchMethodException e2) {
            Log.e("IconCompat", "Unable to get icon resource", e2);
            return 0;
        } catch (InvocationTargetException e3) {
            Log.e("IconCompat", "Unable to get icon resource", e3);
            return 0;
        }
    }

    /* JADX INFO: renamed from: d */
    public final int m999d() {
        int i = this.f1631a;
        if (i != -1) {
            return i;
        }
        Object obj = this.f1632b;
        if (Build.VERSION.SDK_INT >= 28) {
            return o40.m14473i(obj);
        }
        try {
            return ((Integer) obj.getClass().getMethod("getType", null).invoke(obj, null)).intValue();
        } catch (IllegalAccessException e) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e);
            return -1;
        } catch (NoSuchMethodException e2) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e2);
            return -1;
        } catch (InvocationTargetException e3) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e3);
            return -1;
        }
    }

    /* JADX INFO: renamed from: e */
    public final Uri m1000e() {
        int i = this.f1631a;
        if (i != -1) {
            if (i == 4 || i == 6) {
                return Uri.parse((String) this.f1632b);
            }
            nxa.m14376a(this, "called getUri() on ");
            return null;
        }
        Object obj = this.f1632b;
        if (Build.VERSION.SDK_INT >= 28) {
            return o40.m14474j(obj);
        }
        try {
            return (Uri) obj.getClass().getMethod("getUri", null).invoke(obj, null);
        } catch (IllegalAccessException e) {
            Log.e("IconCompat", "Unable to get icon uri", e);
            return null;
        } catch (NoSuchMethodException e2) {
            Log.e("IconCompat", "Unable to get icon uri", e2);
            return null;
        } catch (InvocationTargetException e3) {
            Log.e("IconCompat", "Unable to get icon uri", e3);
            return null;
        }
    }

    /* JADX INFO: renamed from: f */
    public final Icon m1001f(Context context) {
        Icon iconCreateWithBitmap;
        InputStream inputStreamOpenInputStream;
        int i = this.f1631a;
        String strM14470f = null;
        switch (i) {
            case -1:
                return (Icon) this.f1632b;
            case 0:
            default:
                C1521v3.m18903j("Unknown type");
                return null;
            case 1:
                iconCreateWithBitmap = Icon.createWithBitmap((Bitmap) this.f1632b);
                break;
            case 2:
                if (i == -1) {
                    Object obj = this.f1632b;
                    if (Build.VERSION.SDK_INT >= 28) {
                        strM14470f = o40.m14470f(obj);
                    } else {
                        try {
                            strM14470f = (String) obj.getClass().getMethod("getResPackage", null).invoke(obj, null);
                        } catch (IllegalAccessException e) {
                            Log.e("IconCompat", "Unable to get icon package", e);
                        } catch (NoSuchMethodException e2) {
                            Log.e("IconCompat", "Unable to get icon package", e2);
                        } catch (InvocationTargetException e3) {
                            Log.e("IconCompat", "Unable to get icon package", e3);
                        }
                    }
                } else {
                    if (i != 2) {
                        nxa.m14376a(this, "called getResPackage() on ");
                        return null;
                    }
                    String str = this.f1640j;
                    strM14470f = (str == null || TextUtils.isEmpty(str)) ? ((String) this.f1632b).split(":", -1)[0] : this.f1640j;
                }
                iconCreateWithBitmap = Icon.createWithResource(strM14470f, this.f1635e);
                break;
            case 3:
                iconCreateWithBitmap = Icon.createWithData((byte[]) this.f1632b, this.f1635e, this.f1636f);
                break;
            case 4:
                iconCreateWithBitmap = Icon.createWithContentUri((String) this.f1632b);
                break;
            case 5:
                int i2 = Build.VERSION.SDK_INT;
                Object obj2 = this.f1632b;
                iconCreateWithBitmap = i2 < 26 ? Icon.createWithBitmap(m996a((Bitmap) obj2, false)) : b72.m2122b((Bitmap) obj2);
                break;
            case 6:
                if (Build.VERSION.SDK_INT >= 30) {
                    iconCreateWithBitmap = qh3.m15952a(m1000e());
                } else {
                    if (context == null) {
                        C1521v3.m18907n(m1000e(), "Context is required to resolve the file uri of the icon: ");
                        return null;
                    }
                    Uri uriM1000e = m1000e();
                    String scheme = uriM1000e.getScheme();
                    if ("content".equals(scheme) || "file".equals(scheme)) {
                        try {
                            inputStreamOpenInputStream = context.getContentResolver().openInputStream(uriM1000e);
                        } catch (Exception e4) {
                            Log.w("IconCompat", "Unable to load image from URI: " + uriM1000e, e4);
                            inputStreamOpenInputStream = null;
                        }
                    } else {
                        try {
                            inputStreamOpenInputStream = new FileInputStream(new File((String) this.f1632b));
                        } catch (FileNotFoundException e5) {
                            Log.w("IconCompat", "Unable to load image from path: " + uriM1000e, e5);
                            inputStreamOpenInputStream = null;
                        }
                    }
                    if (inputStreamOpenInputStream == null) {
                        vf3.m19096n(m1000e(), "Cannot load adaptive icon from uri: ");
                        return null;
                    }
                    if (Build.VERSION.SDK_INT < 26) {
                        iconCreateWithBitmap = Icon.createWithBitmap(m996a(BitmapFactory.decodeStream(inputStreamOpenInputStream), false));
                    } else {
                        iconCreateWithBitmap = b72.m2122b(BitmapFactory.decodeStream(inputStreamOpenInputStream));
                    }
                }
                break;
        }
        ColorStateList colorStateList = this.f1637g;
        if (colorStateList != null) {
            iconCreateWithBitmap.setTintList(colorStateList);
        }
        PorterDuff.Mode mode = this.f1638h;
        if (mode != f1630k) {
            iconCreateWithBitmap.setTintMode(mode);
        }
        return iconCreateWithBitmap;
    }

    public final String toString() {
        String str;
        if (this.f1631a == -1) {
            return String.valueOf(this.f1632b);
        }
        StringBuilder sb = new StringBuilder("Icon(typ=");
        switch (this.f1631a) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case 3:
                str = "DATA";
                break;
            case 4:
                str = "URI";
                break;
            case 5:
                str = "BITMAP_MASKABLE";
                break;
            case 6:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        sb.append(str);
        switch (this.f1631a) {
            case 1:
            case 5:
                sb.append(" size=");
                sb.append(((Bitmap) this.f1632b).getWidth());
                sb.append("x");
                sb.append(((Bitmap) this.f1632b).getHeight());
                break;
            case 2:
                sb.append(" pkg=");
                sb.append(this.f1640j);
                sb.append(" id=");
                sb.append(String.format("0x%08x", Integer.valueOf(m998c())));
                break;
            case 3:
                sb.append(" len=");
                sb.append(this.f1635e);
                if (this.f1636f != 0) {
                    sb.append(" off=");
                    sb.append(this.f1636f);
                }
                break;
            case 4:
            case 6:
                sb.append(" uri=");
                sb.append(this.f1632b);
                break;
        }
        if (this.f1637g != null) {
            sb.append(" tint=");
            sb.append(this.f1637g);
        }
        if (this.f1638h != f1630k) {
            sb.append(" mode=");
            sb.append(this.f1638h);
        }
        sb.append(")");
        return sb.toString();
    }
}
