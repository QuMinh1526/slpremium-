package androidx.core.view.insets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.annotation.AttrRes;
import ginlemon.flowerfree.R;
import java.util.ArrayList;
import java.util.List;
import p000.C1521v3;
import p000.hi8;
import p000.ii8;
import p000.ija;
import p000.li5;
import p000.lja;
import p000.pq1;
import p000.z82;
import p000.zg8;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class ProtectionLayout extends FrameLayout {

    /* JADX INFO: renamed from: y */
    public static final Object f1641y = new Object();

    /* JADX INFO: renamed from: e */
    public final ArrayList f1642e;

    /* JADX INFO: renamed from: i */
    public ii8 f1643i;

    public ProtectionLayout(Context context, List list) {
        super(context);
        ArrayList arrayList = new ArrayList();
        this.f1642e = arrayList;
        arrayList.clear();
        arrayList.addAll(list);
        if (isAttachedToWindow()) {
            m1003b();
            m1002a();
            requestApplyInsets();
        }
    }

    /* JADX WARN: Code duplicated, block: B:27:0x00b2  */
    /* JADX WARN: Code duplicated, block: B:30:0x00c4 A[LOOP:0: B:10:0x003b->B:30:0x00c4, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:35:0x00cd A[SYNTHETIC] */
    /* JADX INFO: renamed from: a */
    public final void m1002a() {
        lja ljaVar;
        int i;
        int i2;
        int i3;
        FrameLayout.LayoutParams layoutParams;
        View view;
        zg8 zg8Var;
        ArrayList arrayList = this.f1642e;
        if (arrayList.isEmpty()) {
            return;
        }
        ViewGroup viewGroup = (ViewGroup) getRootView();
        Object tag = viewGroup.getTag(R.id.tag_system_bar_state_monitor);
        if (tag instanceof lja) {
            ljaVar = (lja) tag;
        } else {
            ljaVar = new lja(viewGroup);
            viewGroup.setTag(R.id.tag_system_bar_state_monitor, ljaVar);
        }
        this.f1643i = new ii8(ljaVar, arrayList);
        int childCount = getChildCount();
        int size = this.f1643i.f21428a.size();
        for (int i4 = 0; i4 < size; i4++) {
            pq1 pq1Var = (pq1) this.f1643i.f21428a.get(i4);
            Context context = getContext();
            int i5 = i4 + childCount;
            hi8 hi8Var = pq1Var.f33682b;
            int i6 = pq1Var.f33681a;
            int i7 = -1;
            if (i6 != 1) {
                if (i6 == 2) {
                    i3 = hi8Var.f19733b;
                    i2 = 48;
                } else if (i6 == 4) {
                    i = hi8Var.f19732a;
                    i2 = 5;
                } else if (i6 != 8) {
                    C1521v3.m18903j(z82.m21085r(i6, "Unexpected side: "));
                    return;
                } else {
                    i3 = hi8Var.f19733b;
                    i2 = 80;
                }
                layoutParams = new FrameLayout.LayoutParams(i7, i3, i2);
                li5 li5Var = hi8Var.f19734c;
                layoutParams.leftMargin = li5Var.f26704a;
                layoutParams.topMargin = li5Var.f26705b;
                layoutParams.rightMargin = li5Var.f26706c;
                layoutParams.bottomMargin = li5Var.f26707d;
                view = new View(context);
                view.setTag(f1641y);
                view.setTranslationX(hi8Var.f19737f);
                view.setTranslationY(hi8Var.f19738g);
                view.setAlpha(hi8Var.f19739h);
                view.setVisibility(hi8Var.f19735d ? 0 : 4);
                view.setBackground(hi8Var.f19736e);
                zg8Var = new zg8(1, layoutParams, view);
                if (hi8Var.f19740i == null) {
                    C1521v3.m18909p("Trying to overwrite the existing callback. Did you send one protection to multiple ProtectionLayouts?");
                    return;
                } else {
                    hi8Var.f19740i = zg8Var;
                    addView(view, i5, layoutParams);
                }
            } else {
                i = hi8Var.f19732a;
                i2 = 3;
            }
            i7 = i;
            i3 = -1;
            layoutParams = new FrameLayout.LayoutParams(i7, i3, i2);
            li5 li5Var2 = hi8Var.f19734c;
            layoutParams.leftMargin = li5Var2.f26704a;
            layoutParams.topMargin = li5Var2.f26705b;
            layoutParams.rightMargin = li5Var2.f26706c;
            layoutParams.bottomMargin = li5Var2.f26707d;
            view = new View(context);
            view.setTag(f1641y);
            view.setTranslationX(hi8Var.f19737f);
            view.setTranslationY(hi8Var.f19738g);
            view.setAlpha(hi8Var.f19739h);
            view.setVisibility(hi8Var.f19735d ? 0 : 4);
            view.setBackground(hi8Var.f19736e);
            zg8Var = new zg8(1, layoutParams, view);
            if (hi8Var.f19740i == null) {
                C1521v3.m18909p("Trying to overwrite the existing callback. Did you send one protection to multiple ProtectionLayouts?");
                return;
            } else {
                hi8Var.f19740i = zg8Var;
                addView(view, i5, layoutParams);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (view != null && view.getTag() != f1641y) {
            ii8 ii8Var = this.f1643i;
            int childCount = getChildCount() - (ii8Var != null ? ii8Var.f21428a.size() : 0);
            if (i > childCount || i < 0) {
                i = childCount;
            }
        }
        super.addView(view, i, layoutParams);
    }

    /* JADX INFO: renamed from: b */
    public final void m1003b() {
        ii8 ii8Var;
        if (this.f1643i != null) {
            removeViews(getChildCount() - this.f1643i.f21428a.size(), this.f1643i.f21428a.size());
            int size = this.f1643i.f21428a.size();
            int i = 0;
            while (true) {
                ii8Var = this.f1643i;
                if (i >= size) {
                    break;
                }
                ((pq1) ii8Var.f21428a.get(i)).f33682b.f19740i = null;
                i++;
            }
            ArrayList arrayList = ii8Var.f21428a;
            if (!ii8Var.f21433f) {
                ii8Var.f21433f = true;
                ii8Var.f21429b.f26775b.remove(ii8Var);
                for (int size2 = arrayList.size() - 1; size2 >= 0; size2--) {
                    ((pq1) arrayList.get(size2)).f33685e = null;
                }
                arrayList.clear();
            }
            this.f1643i = null;
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f1643i != null) {
            m1003b();
        }
        m1002a();
        requestApplyInsets();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        m1003b();
        ViewGroup viewGroup = (ViewGroup) getRootView();
        Object tag = viewGroup.getTag(R.id.tag_system_bar_state_monitor);
        if (tag instanceof lja) {
            lja ljaVar = (lja) tag;
            if (ljaVar.f26775b.isEmpty()) {
                ljaVar.f26774a.post(new ija(ljaVar, 0));
                viewGroup.setTag(R.id.tag_system_bar_state_monitor, null);
            }
        }
    }

    public ProtectionLayout(Context context, AttributeSet attributeSet, @AttrRes int i) {
        super(context, attributeSet, i, 0);
        this.f1642e = new ArrayList();
    }

    public ProtectionLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}
