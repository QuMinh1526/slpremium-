package androidx.core.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import androidx.core.widget.ContentLoadingProgressBar;
import p000.g62;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class ContentLoadingProgressBar extends ProgressBar {

    /* JADX INFO: renamed from: y */
    public static final /* synthetic */ int f1644y = 0;

    /* JADX INFO: renamed from: e */
    public final g62 f1645e;

    /* JADX INFO: renamed from: i */
    public final g62 f1646i;

    /* JADX WARN: Type inference failed for: r2v1, types: [g62] */
    /* JADX WARN: Type inference failed for: r2v2, types: [g62] */
    public ContentLoadingProgressBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        final int i = 0;
        this.f1645e = new Runnable(this) { // from class: g62

            /* JADX INFO: renamed from: i */
            public final /* synthetic */ ContentLoadingProgressBar f15311i;

            {
                this.f15311i = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                int i2 = i;
                ContentLoadingProgressBar contentLoadingProgressBar = this.f15311i;
                switch (i2) {
                    case 0:
                        int i3 = ContentLoadingProgressBar.f1644y;
                        contentLoadingProgressBar.setVisibility(8);
                        break;
                    default:
                        int i4 = ContentLoadingProgressBar.f1644y;
                        System.currentTimeMillis();
                        contentLoadingProgressBar.setVisibility(0);
                        break;
                }
            }
        };
        final int i2 = 1;
        this.f1646i = new Runnable(this) { // from class: g62

            /* JADX INFO: renamed from: i */
            public final /* synthetic */ ContentLoadingProgressBar f15311i;

            {
                this.f15311i = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                int i3 = i2;
                ContentLoadingProgressBar contentLoadingProgressBar = this.f15311i;
                switch (i3) {
                    case 0:
                        int i4 = ContentLoadingProgressBar.f1644y;
                        contentLoadingProgressBar.setVisibility(8);
                        break;
                    default:
                        int i5 = ContentLoadingProgressBar.f1644y;
                        System.currentTimeMillis();
                        contentLoadingProgressBar.setVisibility(0);
                        break;
                }
            }
        };
    }

    @Override // android.widget.ProgressBar, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(this.f1645e);
        removeCallbacks(this.f1646i);
    }

    @Override // android.widget.ProgressBar, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f1645e);
        removeCallbacks(this.f1646i);
    }
}
