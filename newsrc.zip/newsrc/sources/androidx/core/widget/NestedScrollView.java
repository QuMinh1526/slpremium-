package androidx.core.widget;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import androidx.appcompat.widget.RtlSpacingHelper;
import java.util.ArrayList;
import java.util.WeakHashMap;
import org.p003jf.dexlib2.dexbacked.raw.ItemType;
import p000.AbstractC0598hx;
import p000.C1477tx;
import p000.C1521v3;
import p000.fbb;
import p000.fu2;
import p000.hj4;
import p000.kw5;
import p000.n73;
import p000.obb;
import p000.rh3;
import p000.s47;
import p000.sd9;
import p000.u47;
import p000.ug3;
import p000.v47;
import p000.z23;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
public class NestedScrollView extends FrameLayout implements u47, s47 {

    /* JADX INFO: renamed from: b0 */
    public static final float f1647b0 = (float) (Math.log(0.78d) / Math.log(0.9d));

    /* JADX INFO: renamed from: c0 */
    public static final n73 f1648c0 = new n73(4);

    /* JADX INFO: renamed from: d0 */
    public static final int[] f1649d0 = {R.attr.fillViewport};

    /* JADX INFO: renamed from: A */
    public final EdgeEffect f1650A;

    /* JADX INFO: renamed from: B */
    public final EdgeEffect f1651B;

    /* JADX INFO: renamed from: C */
    public kw5 f1652C;

    /* JADX INFO: renamed from: D */
    public int f1653D;

    /* JADX INFO: renamed from: E */
    public boolean f1654E;

    /* JADX INFO: renamed from: F */
    public boolean f1655F;

    /* JADX INFO: renamed from: G */
    public View f1656G;

    /* JADX INFO: renamed from: H */
    public boolean f1657H;

    /* JADX INFO: renamed from: I */
    public VelocityTracker f1658I;

    /* JADX INFO: renamed from: J */
    public final boolean f1659J;

    /* JADX INFO: renamed from: K */
    public final boolean f1660K;

    /* JADX INFO: renamed from: L */
    public final int f1661L;

    /* JADX INFO: renamed from: M */
    public final int f1662M;

    /* JADX INFO: renamed from: N */
    public final int f1663N;

    /* JADX INFO: renamed from: O */
    public int f1664O;

    /* JADX INFO: renamed from: P */
    public final int[] f1665P;

    /* JADX INFO: renamed from: Q */
    public final int[] f1666Q;

    /* JADX INFO: renamed from: R */
    public int f1667R;

    /* JADX INFO: renamed from: S */
    public int f1668S;

    /* JADX INFO: renamed from: T */
    public SavedState f1669T;

    /* JADX INFO: renamed from: U */
    public final v47 f1670U;

    /* JADX INFO: renamed from: V */
    public final C1477tx f1671V;

    /* JADX INFO: renamed from: W */
    public float f1672W;

    /* JADX INFO: renamed from: a0 */
    public final fu2 f1673a0;

    /* JADX INFO: renamed from: e */
    public final float f1674e;

    /* JADX INFO: renamed from: i */
    public long f1675i;

    /* JADX INFO: renamed from: y */
    public final Rect f1676y;

    /* JADX INFO: renamed from: z */
    public final OverScroller f1677z;

    /* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
    public static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new C0137a();

        /* JADX INFO: renamed from: e */
        public int f1678e;

        public final String toString() {
            StringBuilder sb = new StringBuilder("HorizontalScrollView.SavedState{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" scrollPosition=");
            return z23.m20931m(this.f1678e, "}", sb);
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f1678e);
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1676y = new Rect();
        this.f1654E = true;
        this.f1655F = false;
        this.f1656G = null;
        this.f1657H = false;
        this.f1660K = true;
        this.f1664O = -1;
        this.f1665P = new int[2];
        this.f1666Q = new int[2];
        this.f1673a0 = new fu2(getContext(), new kw5(this, 12));
        int i2 = Build.VERSION.SDK_INT;
        this.f1650A = i2 >= 31 ? ug3.m18372a(context, attributeSet) : new EdgeEffect(context);
        this.f1651B = i2 >= 31 ? ug3.m18372a(context, attributeSet) : new EdgeEffect(context);
        this.f1674e = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.f1677z = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f1661L = viewConfiguration.getScaledTouchSlop();
        this.f1662M = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f1663N = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f1649d0, i, 0);
        boolean z = typedArrayObtainStyledAttributes.getBoolean(0, false);
        if (z != this.f1659J) {
            this.f1659J = z;
            requestLayout();
        }
        typedArrayObtainStyledAttributes.recycle();
        this.f1670U = new v47();
        this.f1671V = new C1477tx(this);
        setNestedScrollingEnabled(true);
        obb.m14621n(this, f1648c0);
    }

    /* JADX INFO: renamed from: h */
    public static boolean m1004h(View view, NestedScrollView nestedScrollView) {
        if (view == nestedScrollView) {
            return true;
        }
        Object parent = view.getParent();
        return (parent instanceof ViewGroup) && m1004h((View) parent, nestedScrollView);
    }

    /* JADX INFO: renamed from: a */
    public final boolean m1005a(int i) {
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
        }
        View view = viewFindFocus;
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, view, i);
        int height = (int) (getHeight() * 0.5f);
        if (viewFindNextFocus == null || !m1012i(viewFindNextFocus, height, getHeight())) {
            if (i == 33 && getScrollY() < height) {
                height = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                height = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), height);
            }
            if (height == 0) {
                return false;
            }
            if (i != 130) {
                height = -height;
            }
            m1018o(height, -1, null, 0, 1, true);
        } else {
            Rect rect = this.f1676y;
            viewFindNextFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(viewFindNextFocus, rect);
            m1018o(m1006b(rect), -1, null, 0, 1, true);
            viewFindNextFocus.requestFocus(i);
        }
        if (view != null && view.isFocused() && !m1012i(view, 0, getHeight())) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
        } else {
            C1521v3.m18909p("ScrollView can host only one direct child");
        }
    }

    /* JADX INFO: renamed from: b */
    public final int m1006b(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i2 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i - verticalFadingEdgeLength : i;
        int i3 = rect.bottom;
        if (i3 > i2 && rect.top > scrollY) {
            return Math.min(rect.height() > height ? rect.top - scrollY : rect.bottom - i2, (childAt.getBottom() + layoutParams.bottomMargin) - i);
        }
        if (rect.top >= scrollY || i3 >= i2) {
            return 0;
        }
        return Math.max(rect.height() > height ? 0 - (i2 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
    }

    /* JADX WARN: Code duplicated, block: B:48:0x0098  */
    /* JADX WARN: Code duplicated, block: B:54:0x00ab  */
    /* JADX INFO: renamed from: c */
    public final boolean m1007c(KeyEvent keyEvent) {
        View viewFindFocus;
        View viewFindNextFocus;
        this.f1676y.setEmpty();
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                if (keyEvent.getAction() == 0) {
                    int keyCode = keyEvent.getKeyCode();
                    if (keyCode == 19) {
                        return keyEvent.isAltPressed() ? m1009e(33) : m1005a(33);
                    }
                    if (keyCode == 20) {
                        return keyEvent.isAltPressed() ? m1009e(130) : m1005a(130);
                    }
                    if (keyCode == 62) {
                        m1016m(keyEvent.isShiftPressed() ? 33 : 130);
                        return false;
                    }
                    if (keyCode == 92) {
                        return m1009e(33);
                    }
                    if (keyCode == 93) {
                        return m1009e(130);
                    }
                    if (keyCode == 122) {
                        m1016m(33);
                        return false;
                    }
                    if (keyCode == 123) {
                        m1016m(130);
                        return false;
                    }
                }
            } else if (isFocused() && keyEvent.getKeyCode() != 4) {
                viewFindFocus = findFocus();
                if (viewFindFocus == this) {
                    viewFindFocus = null;
                }
                viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
                if (viewFindNextFocus == null && viewFindNextFocus != this && viewFindNextFocus.requestFocus(130)) {
                    return true;
                }
            }
        } else if (isFocused()) {
            viewFindFocus = findFocus();
            if (viewFindFocus == this) {
                viewFindFocus = null;
            }
            viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
            if (viewFindNextFocus == null) {
            }
        }
        return false;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0083  */
    /* JADX WARN: Code duplicated, block: B:24:0x0090  */
    /* JADX WARN: Code duplicated, block: B:26:0x00b6  */
    /* JADX WARN: Code duplicated, block: B:30:0x00c0 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:31:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:33:0x00c8  */
    /* JADX WARN: Code duplicated, block: B:34:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:36:0x00d7  */
    /* JADX WARN: Code duplicated, block: B:40:0x00eb  */
    /* JADX WARN: Code duplicated, block: B:42:0x00ef  */
    @Override // android.view.View
    public final void computeScroll() {
        int iRound;
        int[] iArr;
        int i;
        int iM1010f;
        int overScrollMode;
        OverScroller overScroller = this.f1677z;
        if (overScroller.isFinished()) {
            return;
        }
        overScroller.computeScrollOffset();
        int currY = overScroller.getCurrY();
        int i2 = currY - this.f1668S;
        int height = getHeight();
        EdgeEffect edgeEffect = this.f1650A;
        EdgeEffect edgeEffect2 = this.f1651B;
        if (i2 <= 0 || AbstractC0598hx.m10443z(edgeEffect) == 0.0f) {
            if (i2 < 0 && AbstractC0598hx.m10443z(edgeEffect2) != 0.0f) {
                float f = height;
                iRound = Math.round(AbstractC0598hx.m10410M(edgeEffect2, (i2 * 4.0f) / f, 0.5f) * (f / 4.0f));
                if (iRound != i2) {
                    edgeEffect2.finish();
                }
            }
            int i3 = i2;
            this.f1668S = currY;
            iArr = this.f1666Q;
            iArr[1] = 0;
            this.f1671V.m17959c(0, i3, 1, iArr, null);
            i = i3 - iArr[1];
            iM1010f = m1010f();
            if (Build.VERSION.SDK_INT >= 35) {
                rh3.m16526a(this, Math.abs(overScroller.getCurrVelocity()));
            }
            if (i != 0) {
                int scrollY = getScrollY();
                m1015l(i, getScrollX(), scrollY, iM1010f);
                int scrollY2 = getScrollY() - scrollY;
                int i4 = i - scrollY2;
                iArr[1] = 0;
                this.f1671V.m17960d(0, scrollY2, 0, i4, this.f1665P, 1, iArr);
                i = i4 - iArr[1];
            }
            if (i != 0) {
                overScrollMode = getOverScrollMode();
                if (overScrollMode != 0 || (overScrollMode == 1 && iM1010f > 0)) {
                    if (i < 0) {
                        if (edgeEffect.isFinished()) {
                            edgeEffect.onAbsorb((int) overScroller.getCurrVelocity());
                        }
                    } else if (edgeEffect2.isFinished()) {
                        edgeEffect2.onAbsorb((int) overScroller.getCurrVelocity());
                    }
                }
                overScroller.abortAnimation();
                m1022s(1);
            }
            if (overScroller.isFinished()) {
                m1022s(1);
            } else {
                postInvalidateOnAnimation();
            }
        }
        iRound = Math.round(AbstractC0598hx.m10410M(edgeEffect, ((-i2) * 4.0f) / height, 0.5f) * ((-height) / 4.0f));
        if (iRound != i2) {
            edgeEffect.finish();
        }
        i2 -= iRound;
        int i5 = i2;
        this.f1668S = currY;
        iArr = this.f1666Q;
        iArr[1] = 0;
        this.f1671V.m17959c(0, i5, 1, iArr, null);
        i = i5 - iArr[1];
        iM1010f = m1010f();
        if (Build.VERSION.SDK_INT >= 35) {
            rh3.m16526a(this, Math.abs(overScroller.getCurrVelocity()));
        }
        if (i != 0) {
            int scrollY3 = getScrollY();
            m1015l(i, getScrollX(), scrollY3, iM1010f);
            int scrollY4 = getScrollY() - scrollY3;
            int i6 = i - scrollY4;
            iArr[1] = 0;
            this.f1671V.m17960d(0, scrollY4, 0, i6, this.f1665P, 1, iArr);
            i = i6 - iArr[1];
        }
        if (i != 0) {
            overScrollMode = getOverScrollMode();
            if (overScrollMode != 0) {
                if (i < 0) {
                    if (edgeEffect.isFinished()) {
                        edgeEffect.onAbsorb((int) overScroller.getCurrVelocity());
                    }
                } else if (edgeEffect2.isFinished()) {
                    edgeEffect2.onAbsorb((int) overScroller.getCurrVelocity());
                }
            } else if (i < 0) {
                if (edgeEffect.isFinished()) {
                    edgeEffect.onAbsorb((int) overScroller.getCurrVelocity());
                }
            } else if (edgeEffect2.isFinished()) {
                edgeEffect2.onAbsorb((int) overScroller.getCurrVelocity());
            }
            overScroller.abortAnimation();
            m1022s(1);
        }
        if (overScroller.isFinished()) {
            postInvalidateOnAnimation();
        } else {
            m1022s(1);
        }
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int iMax = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        return scrollY > iMax ? (scrollY - iMax) + bottom : bottom;
    }

    /* JADX INFO: renamed from: d */
    public final void m1008d(int i) {
        if (getChildCount() > 0) {
            this.f1677z.fling(getScrollX(), getScrollY(), 0, i, 0, 0, RtlSpacingHelper.UNDEFINED, Integer.MAX_VALUE, 0, 0);
            this.f1671V.m17965i(2, 1);
            this.f1668S = getScrollY();
            postInvalidateOnAnimation();
            if (Build.VERSION.SDK_INT >= 35) {
                rh3.m16526a(this, Math.abs(this.f1677z.getCurrVelocity()));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || m1007c(keyEvent);
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.f1671V.m17957a(f, f2, z);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f2) {
        return this.f1671V.m17958b(f, f2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return this.f1671V.m17959c(i, i2, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.f1671V.m17960d(i, i2, i3, i4, iArr, 0, null);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int paddingLeft;
        super.draw(canvas);
        int scrollY = getScrollY();
        EdgeEffect edgeEffect = this.f1650A;
        int paddingLeft2 = 0;
        if (!edgeEffect.isFinished()) {
            int iSave = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int iMin = Math.min(0, scrollY);
            if (getClipToPadding()) {
                width -= getPaddingRight() + getPaddingLeft();
                paddingLeft = getPaddingLeft();
            } else {
                paddingLeft = 0;
            }
            if (getClipToPadding()) {
                height -= getPaddingBottom() + getPaddingTop();
                iMin += getPaddingTop();
            }
            canvas.translate(paddingLeft, iMin);
            edgeEffect.setSize(width, height);
            if (edgeEffect.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect2 = this.f1651B;
        if (edgeEffect2.isFinished()) {
            return;
        }
        int iSave2 = canvas.save();
        int width2 = getWidth();
        int height2 = getHeight();
        int iMax = Math.max(m1010f(), scrollY) + height2;
        if (getClipToPadding()) {
            width2 -= getPaddingRight() + getPaddingLeft();
            paddingLeft2 = getPaddingLeft();
        }
        if (getClipToPadding()) {
            height2 -= getPaddingBottom() + getPaddingTop();
            iMax -= getPaddingBottom();
        }
        canvas.translate(paddingLeft2 - width2, iMax);
        canvas.rotate(180.0f, width2, 0.0f);
        edgeEffect2.setSize(width2, height2);
        if (edgeEffect2.draw(canvas)) {
            postInvalidateOnAnimation();
        }
        canvas.restoreToCount(iSave2);
    }

    /* JADX INFO: renamed from: e */
    public final boolean m1009e(int i) {
        int childCount;
        boolean z = i == 130;
        int height = getHeight();
        Rect rect = this.f1676y;
        rect.top = 0;
        rect.bottom = height;
        if (z && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            rect.bottom = paddingBottom;
            rect.top = paddingBottom - height;
        }
        return m1017n(i, rect.top, rect.bottom);
    }

    /* JADX INFO: renamed from: f */
    public final int m1010f() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    /* JADX INFO: renamed from: g */
    public final float m1011g() {
        if (this.f1672W == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                C1521v3.m18909p("Expected theme to define listPreferredItemHeight.");
                return 0.0f;
            }
            this.f1672W = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.f1672W;
    }

    @Override // android.view.View
    public final float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    @Override // android.view.ViewGroup
    public final int getNestedScrollAxes() {
        return this.f1670U.m18919a();
    }

    @Override // android.view.View
    public final float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.f1671V.m17962f(0);
    }

    /* JADX INFO: renamed from: i */
    public final boolean m1012i(View view, int i, int i2) {
        Rect rect = this.f1676y;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        return rect.bottom + i >= getScrollY() && rect.top - i <= getScrollY() + i2;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.f1671V.f41017a;
    }

    /* JADX INFO: renamed from: j */
    public final void m1013j(int[] iArr, int i, int i2) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f1671V.m17960d(0, scrollY2, 0, i - scrollY2, null, i2, iArr);
    }

    /* JADX INFO: renamed from: k */
    public final void m1014k(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f1664O) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f1653D = (int) motionEvent.getY(i);
            this.f1664O = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.f1658I;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    /* JADX INFO: renamed from: l */
    public final boolean m1015l(int i, int i2, int i3, int i4) {
        int i5;
        boolean z;
        int i6;
        boolean z2;
        getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        int i7 = i3 + i;
        if (i2 <= 0 && i2 >= 0) {
            i5 = i2;
            z = false;
        } else {
            i5 = 0;
            z = true;
        }
        if (i7 <= i4) {
            if (i7 < 0) {
                i6 = 0;
            } else {
                i6 = i7;
                z2 = false;
            }
            if (z2 && !this.f1671V.m17962f(1)) {
                this.f1677z.springBack(i5, i6, 0, 0, 0, m1010f());
            }
            super.scrollTo(i5, i6);
            return !z || z2;
        }
        i6 = i4;
        z2 = true;
        if (z2) {
            this.f1677z.springBack(i5, i6, 0, 0, 0, m1010f());
        }
        super.scrollTo(i5, i6);
        if (z) {
        }
    }

    /* JADX INFO: renamed from: m */
    public final void m1016m(int i) {
        boolean z = i == 130;
        int height = getHeight();
        Rect rect = this.f1676y;
        if (z) {
            rect.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
                if (rect.top + height > paddingBottom) {
                    rect.top = paddingBottom - height;
                }
            }
        } else {
            int scrollY = getScrollY() - height;
            rect.top = scrollY;
            if (scrollY < 0) {
                rect.top = 0;
            }
        }
        int i2 = rect.top;
        int i3 = height + i2;
        rect.bottom = i3;
        m1017n(i, i2, i3);
    }

    @Override // android.view.ViewGroup
    public final void measureChild(View view, int i, int i2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    @Override // android.view.ViewGroup
    public final void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0068  */
    /* JADX INFO: renamed from: n */
    public final boolean m1017n(int i, int i2, int i3) {
        boolean z;
        int height = getHeight();
        int scrollY = getScrollY();
        int i4 = height + scrollY;
        boolean z2 = i == 33;
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z3 = false;
        for (int i5 = 0; i5 < size; i5++) {
            View view2 = focusables.get(i5);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i2 < bottom && top < i3) {
                boolean z4 = i2 < top && bottom < i3;
                if (view == null) {
                    view = view2;
                    z3 = z4;
                } else {
                    boolean z5 = (z2 && top < view.getTop()) || (!z2 && bottom > view.getBottom());
                    if (z3) {
                        if (z4 && z5) {
                            view = view2;
                        }
                    } else if (z4) {
                        view = view2;
                        z3 = true;
                    } else if (z5) {
                        view = view2;
                    }
                }
            }
        }
        View view3 = view == null ? this : view;
        if (i2 < scrollY || i3 > i4) {
            m1018o(z2 ? i2 - scrollY : i3 - i4, -1, null, 0, 1, true);
            z = true;
        } else {
            z = false;
        }
        if (view3 != findFocus()) {
            view3.requestFocus(i);
        }
        return z;
    }

    /* JADX WARN: Code duplicated, block: B:61:0x0139  */
    /* JADX WARN: Code duplicated, block: B:68:0x014a  */
    /* JADX INFO: renamed from: o */
    public final int m1018o(int i, int i2, MotionEvent motionEvent, int i3, int i4, boolean z) {
        int i5;
        int i6;
        boolean z2;
        boolean z3;
        VelocityTracker velocityTracker;
        C1477tx c1477tx = this.f1671V;
        if (i4 == 1) {
            c1477tx.m17965i(2, i4);
        }
        boolean zM17959c = this.f1671V.m17959c(0, i, i4, this.f1666Q, this.f1665P);
        int[] iArr = this.f1665P;
        int[] iArr2 = this.f1666Q;
        if (zM17959c) {
            i5 = i - iArr2[1];
            i6 = iArr[1];
        } else {
            i5 = i;
            i6 = 0;
        }
        int scrollY = getScrollY();
        int iM1010f = m1010f();
        int overScrollMode = getOverScrollMode();
        boolean z4 = (overScrollMode == 0 || (overScrollMode == 1 && m1010f() > 0)) && !z;
        boolean z5 = m1015l(i5, 0, scrollY, iM1010f) && !c1477tx.m17962f(i4);
        int scrollY2 = getScrollY() - scrollY;
        if (motionEvent != null && scrollY2 != 0) {
            if (this.f1652C == null) {
                this.f1652C = new kw5(this);
            }
            ((sd9) this.f1652C.f25469i).onScrollProgress(motionEvent.getDeviceId(), motionEvent.getSource(), i2, scrollY2);
        }
        iArr2[1] = 0;
        this.f1671V.m17960d(0, scrollY2, 0, i5 - scrollY2, this.f1665P, i4, iArr2);
        int i7 = i6 + iArr[1];
        int i8 = i5 - iArr2[1];
        int i9 = scrollY + i8;
        EdgeEffect edgeEffect = this.f1651B;
        EdgeEffect edgeEffect2 = this.f1650A;
        if (i9 >= 0) {
            if (i9 > iM1010f && z4) {
                AbstractC0598hx.m10410M(edgeEffect, i8 / getHeight(), 1.0f - (i3 / getWidth()));
                if (motionEvent != null) {
                    if (this.f1652C == null) {
                        this.f1652C = new kw5(this);
                    }
                    z2 = false;
                    ((sd9) this.f1652C.f25469i).onScrollLimit(motionEvent.getDeviceId(), motionEvent.getSource(), i2, false);
                } else {
                    z2 = false;
                }
                if (!edgeEffect2.isFinished()) {
                    edgeEffect2.onRelease();
                }
            }
            if (edgeEffect2.isFinished() || !edgeEffect.isFinished()) {
                postInvalidateOnAnimation();
                z3 = z2;
            } else {
                z3 = z5;
            }
            if (z3 && i4 == 0 && (velocityTracker = this.f1658I) != null) {
                velocityTracker.clear();
            }
            if (i4 == 1) {
                m1022s(i4);
                edgeEffect2.onRelease();
                edgeEffect.onRelease();
            }
            return i7;
        }
        if (z4) {
            AbstractC0598hx.m10410M(edgeEffect2, (-i8) / getHeight(), i3 / getWidth());
            if (motionEvent != null) {
                if (this.f1652C == null) {
                    this.f1652C = new kw5(this);
                }
                ((sd9) this.f1652C.f25469i).onScrollLimit(motionEvent.getDeviceId(), motionEvent.getSource(), i2, true);
            }
            if (!edgeEffect.isFinished()) {
                edgeEffect.onRelease();
            }
        }
        z2 = false;
        if (edgeEffect2.isFinished()) {
            postInvalidateOnAnimation();
            z3 = z2;
        } else {
            postInvalidateOnAnimation();
            z3 = z2;
        }
        if (z3) {
            velocityTracker.clear();
        }
        if (i4 == 1) {
            m1022s(i4);
            edgeEffect2.onRelease();
            edgeEffect.onRelease();
        }
        return i7;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1655F = false;
    }

    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        int i;
        int width;
        float axisValue;
        if (motionEvent.getAction() == 8 && !this.f1657H) {
            if (hj4.m10175V(motionEvent, 2)) {
                axisValue = motionEvent.getAxisValue(9);
                i = 9;
                width = (int) motionEvent.getX();
            } else if (hj4.m10175V(motionEvent, 4194304)) {
                float axisValue2 = motionEvent.getAxisValue(26);
                width = getWidth() / 2;
                i = 26;
                axisValue = axisValue2;
            } else {
                i = 0;
                width = 0;
                axisValue = 0.0f;
            }
            if (axisValue != 0.0f) {
                m1018o(-((int) (m1011g() * axisValue)), i, motionEvent, width, 1, hj4.m10175V(motionEvent, ItemType.STRING_DATA_ITEM));
                if (i == 0) {
                    return true;
                }
                this.f1673a0.m8298a(motionEvent, i);
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0085  */
    /* JADX WARN: Code duplicated, block: B:36:0x008d  */
    /* JADX WARN: Code duplicated, block: B:39:0x00a9  */
    /* JADX WARN: Code duplicated, block: B:62:0x0119  */
    /* JADX WARN: Code duplicated, block: B:70:0x012d  */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        VelocityTracker velocityTracker;
        VelocityTracker velocityTracker2;
        int action = motionEvent.getAction();
        boolean z = true;
        if (action == 2 && this.f1657H) {
            return true;
        }
        int i = action & 255;
        if (i == 0) {
            int y = (int) motionEvent.getY();
            int x = (int) motionEvent.getX();
            int childCount = getChildCount();
            OverScroller overScroller = this.f1677z;
            if (childCount > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y < childAt.getTop() - scrollY || y >= childAt.getBottom() - scrollY || x < childAt.getLeft() || x >= childAt.getRight()) {
                    if (!m1021r(motionEvent) && overScroller.isFinished()) {
                        z = false;
                    }
                    this.f1657H = z;
                    velocityTracker = this.f1658I;
                    if (velocityTracker != null) {
                        velocityTracker.recycle();
                        this.f1658I = null;
                    }
                } else {
                    this.f1653D = y;
                    this.f1664O = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker3 = this.f1658I;
                    if (velocityTracker3 == null) {
                        this.f1658I = VelocityTracker.obtain();
                    } else {
                        velocityTracker3.clear();
                    }
                    this.f1658I.addMovement(motionEvent);
                    overScroller.computeScrollOffset();
                    if (!m1021r(motionEvent) && overScroller.isFinished()) {
                        z = false;
                    }
                    this.f1657H = z;
                    this.f1671V.m17965i(2, 0);
                }
            } else {
                if (!m1021r(motionEvent)) {
                    z = false;
                }
                this.f1657H = z;
                velocityTracker = this.f1658I;
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    this.f1658I = null;
                }
            }
        } else if (i == 1) {
            this.f1657H = false;
            this.f1664O = -1;
            velocityTracker2 = this.f1658I;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f1658I = null;
            }
            if (this.f1677z.springBack(getScrollX(), getScrollY(), 0, 0, 0, m1010f())) {
                postInvalidateOnAnimation();
            }
            m1022s(0);
        } else if (i == 2) {
            int i2 = this.f1664O;
            if (i2 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i2);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + i2 + " in onInterceptTouchEvent");
                } else {
                    int y2 = (int) motionEvent.getY(iFindPointerIndex);
                    if (Math.abs(y2 - this.f1653D) > this.f1661L && (2 & this.f1670U.m18919a()) == 0) {
                        this.f1657H = true;
                        this.f1653D = y2;
                        if (this.f1658I == null) {
                            this.f1658I = VelocityTracker.obtain();
                        }
                        this.f1658I.addMovement(motionEvent);
                        this.f1667R = 0;
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
            }
        } else if (i == 3) {
            this.f1657H = false;
            this.f1664O = -1;
            velocityTracker2 = this.f1658I;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f1658I = null;
            }
            if (this.f1677z.springBack(getScrollX(), getScrollY(), 0, 0, 0, m1010f())) {
                postInvalidateOnAnimation();
            }
            m1022s(0);
        } else if (i == 6) {
            m1014k(motionEvent);
        }
        return this.f1657H;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int measuredHeight;
        super.onLayout(z, i, i2, i3, i4);
        int i5 = 0;
        this.f1654E = false;
        View view = this.f1656G;
        if (view != null && m1004h(view, this)) {
            View view2 = this.f1656G;
            Rect rect = this.f1676y;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iM1006b = m1006b(rect);
            if (iM1006b != 0) {
                scrollBy(0, iM1006b);
            }
        }
        this.f1656G = null;
        if (!this.f1655F) {
            if (this.f1669T != null) {
                scrollTo(getScrollX(), this.f1669T.f1678e);
                this.f1669T = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                measuredHeight = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                measuredHeight = 0;
            }
            int paddingTop = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < measuredHeight && scrollY >= 0) {
                i5 = paddingTop + scrollY > measuredHeight ? measuredHeight - paddingTop : scrollY;
            }
            if (i5 != scrollY) {
                scrollTo(getScrollX(), i5);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f1655F = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f1659J && View.MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (z) {
            return false;
        }
        dispatchNestedFling(0.0f, f2, true);
        m1008d((int) f2);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        return this.f1671V.m17958b(f, f2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        this.f1671V.m17959c(i, i2, 0, iArr, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        m1013j(null, i4, 0);
    }

    @Override // p000.t47
    public final void onNestedScrollAccepted(View view, View view2, int i, int i2) {
        this.f1670U.m18920b(i, i2);
        this.f1671V.m17965i(2, i2);
    }

    @Override // android.view.View
    public final void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        View viewFindNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i);
        if (viewFindNextFocus != null && m1012i(viewFindNextFocus, 0, getHeight())) {
            return viewFindNextFocus.requestFocus(i, rect);
        }
        return false;
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f1669T = savedState;
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f1678e = getScrollY();
        return savedState;
    }

    @Override // android.view.View
    public final void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View viewFindFocus = findFocus();
        if (viewFindFocus == null || this == viewFindFocus || !m1012i(viewFindFocus, 0, i4)) {
            return;
        }
        Rect rect = this.f1676y;
        viewFindFocus.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(viewFindFocus, rect);
        int iM1006b = m1006b(rect);
        if (iM1006b != 0) {
            if (this.f1660K) {
                m1020q(0, iM1006b, false);
            } else {
                scrollBy(0, iM1006b);
            }
        }
    }

    @Override // p000.t47
    public final boolean onStartNestedScroll(View view, View view2, int i, int i2) {
        return (i & 2) != 0;
    }

    @Override // p000.t47
    public final void onStopNestedScroll(View view, int i) {
        this.f1670U.m18921c(i);
        m1022s(i);
    }

    /* JADX WARN: Code duplicated, block: B:49:0x0120  */
    /* JADX WARN: Code duplicated, block: B:52:0x0128  */
    /* JADX WARN: Code duplicated, block: B:54:0x0130  */
    /* JADX WARN: Code duplicated, block: B:56:0x0136  */
    /* JADX WARN: Code duplicated, block: B:59:0x013d  */
    /* JADX WARN: Code duplicated, block: B:60:0x013f  */
    /* JADX WARN: Code duplicated, block: B:63:0x0144  */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        float fM10410M;
        int iRound;
        int i;
        int iAbs;
        int i2;
        ViewParent parent2;
        if (this.f1658I == null) {
            this.f1658I = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1667R = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        float f = 0.0f;
        motionEventObtain.offsetLocation(0.0f, this.f1667R);
        C1477tx c1477tx = this.f1671V;
        if (actionMasked != 0) {
            EdgeEffect edgeEffect = this.f1650A;
            EdgeEffect edgeEffect2 = this.f1651B;
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.f1658I;
                velocityTracker.computeCurrentVelocity(1000, this.f1663N);
                int yVelocity = (int) velocityTracker.getYVelocity(this.f1664O);
                if (Math.abs(yVelocity) >= this.f1662M) {
                    if (AbstractC0598hx.m10443z(edgeEffect) != 0.0f) {
                        if (m1019p(edgeEffect, yVelocity)) {
                            edgeEffect.onAbsorb(yVelocity);
                        } else {
                            m1008d(-yVelocity);
                        }
                    } else if (AbstractC0598hx.m10443z(edgeEffect2) != 0.0f) {
                        int i3 = -yVelocity;
                        if (m1019p(edgeEffect2, i3)) {
                            edgeEffect2.onAbsorb(i3);
                        } else {
                            m1008d(i3);
                        }
                    } else {
                        int i4 = -yVelocity;
                        float f2 = i4;
                        if (!c1477tx.m17958b(0.0f, f2)) {
                            dispatchNestedFling(0.0f, f2, true);
                            m1008d(i4);
                        }
                    }
                } else if (this.f1677z.springBack(getScrollX(), getScrollY(), 0, 0, 0, m1010f())) {
                    postInvalidateOnAnimation();
                }
                this.f1664O = -1;
                this.f1657H = false;
                VelocityTracker velocityTracker2 = this.f1658I;
                if (velocityTracker2 != null) {
                    velocityTracker2.recycle();
                    this.f1658I = null;
                }
                m1022s(0);
                edgeEffect.onRelease();
                edgeEffect2.onRelease();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f1664O);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.f1664O + " in onTouchEvent");
                } else {
                    int y = (int) motionEvent.getY(iFindPointerIndex);
                    int i5 = this.f1653D - y;
                    float x = motionEvent.getX(iFindPointerIndex) / getWidth();
                    float height = i5 / getHeight();
                    if (AbstractC0598hx.m10443z(edgeEffect) != 0.0f) {
                        fM10410M = -AbstractC0598hx.m10410M(edgeEffect, -height, x);
                        if (AbstractC0598hx.m10443z(edgeEffect) == 0.0f) {
                            edgeEffect.onRelease();
                        }
                    } else if (AbstractC0598hx.m10443z(edgeEffect2) != 0.0f) {
                        fM10410M = AbstractC0598hx.m10410M(edgeEffect2, height, 1.0f - x);
                        if (AbstractC0598hx.m10443z(edgeEffect2) == 0.0f) {
                            edgeEffect2.onRelease();
                        }
                    } else {
                        iRound = Math.round(f * getHeight());
                        if (iRound != 0) {
                            invalidate();
                        }
                        i = i5 - iRound;
                        if (!this.f1657H) {
                            iAbs = Math.abs(i);
                            i2 = this.f1661L;
                            if (iAbs > i2) {
                                parent2 = getParent();
                                if (parent2 != null) {
                                    parent2.requestDisallowInterceptTouchEvent(true);
                                }
                                this.f1657H = true;
                                if (i > 0) {
                                    i -= i2;
                                } else {
                                    i += i2;
                                }
                            }
                        }
                        if (this.f1657H) {
                            int iM1018o = m1018o(i, 1, motionEvent, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                            this.f1653D = y - iM1018o;
                            this.f1667R += iM1018o;
                        }
                    }
                    f = fM10410M;
                    iRound = Math.round(f * getHeight());
                    if (iRound != 0) {
                        invalidate();
                    }
                    i = i5 - iRound;
                    if (!this.f1657H) {
                        iAbs = Math.abs(i);
                        i2 = this.f1661L;
                        if (iAbs > i2) {
                            parent2 = getParent();
                            if (parent2 != null) {
                                parent2.requestDisallowInterceptTouchEvent(true);
                            }
                            this.f1657H = true;
                            if (i > 0) {
                                i -= i2;
                            } else {
                                i += i2;
                            }
                        }
                    }
                    if (this.f1657H) {
                        int iM1018o2 = m1018o(i, 1, motionEvent, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                        this.f1653D = y - iM1018o2;
                        this.f1667R += iM1018o2;
                    }
                }
            } else if (actionMasked == 3) {
                if (this.f1657H && getChildCount() > 0) {
                    if (this.f1677z.springBack(getScrollX(), getScrollY(), 0, 0, 0, m1010f())) {
                        postInvalidateOnAnimation();
                    }
                }
                this.f1664O = -1;
                this.f1657H = false;
                VelocityTracker velocityTracker3 = this.f1658I;
                if (velocityTracker3 != null) {
                    velocityTracker3.recycle();
                    this.f1658I = null;
                }
                m1022s(0);
                edgeEffect.onRelease();
                edgeEffect2.onRelease();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                this.f1653D = (int) motionEvent.getY(actionIndex);
                this.f1664O = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                m1014k(motionEvent);
                this.f1653D = (int) motionEvent.getY(motionEvent.findPointerIndex(this.f1664O));
            }
        } else {
            if (getChildCount() == 0) {
                return false;
            }
            if (this.f1657H && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            OverScroller overScroller = this.f1677z;
            if (!overScroller.isFinished()) {
                overScroller.abortAnimation();
                m1022s(1);
            }
            int y2 = (int) motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            this.f1653D = y2;
            this.f1664O = pointerId;
            c1477tx.m17965i(2, 0);
        }
        VelocityTracker velocityTracker4 = this.f1658I;
        if (velocityTracker4 != null) {
            velocityTracker4.addMovement(motionEventObtain);
        }
        motionEventObtain.recycle();
        return true;
    }

    /* JADX INFO: renamed from: p */
    public final boolean m1019p(EdgeEffect edgeEffect, int i) {
        if (i > 0) {
            return true;
        }
        float fM10443z = AbstractC0598hx.m10443z(edgeEffect) * getHeight();
        float fAbs = Math.abs(-i) * 0.35f;
        float f = this.f1674e * 0.015f;
        double dLog = Math.log(fAbs / f);
        double d = f1647b0;
        return ((float) (Math.exp((d / (d - 1.0d)) * dLog) * ((double) f))) < fM10443z;
    }

    /* JADX INFO: renamed from: q */
    public final void m1020q(int i, int i2, boolean z) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.f1675i > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int iMax = Math.max(0, Math.min(i2 + scrollY, Math.max(0, height - height2))) - scrollY;
            this.f1677z.startScroll(getScrollX(), scrollY, 0, iMax, 250);
            if (z) {
                this.f1671V.m17965i(2, 1);
            } else {
                m1022s(1);
            }
            this.f1668S = getScrollY();
            postInvalidateOnAnimation();
        } else {
            OverScroller overScroller = this.f1677z;
            if (!overScroller.isFinished()) {
                overScroller.abortAnimation();
                m1022s(1);
            }
            scrollBy(i, i2);
        }
        this.f1675i = AnimationUtils.currentAnimationTimeMillis();
    }

    /* JADX INFO: renamed from: r */
    public final boolean m1021r(MotionEvent motionEvent) {
        boolean z;
        EdgeEffect edgeEffect = this.f1650A;
        if (AbstractC0598hx.m10443z(edgeEffect) != 0.0f) {
            AbstractC0598hx.m10410M(edgeEffect, 0.0f, motionEvent.getX() / getWidth());
            z = true;
        } else {
            z = false;
        }
        EdgeEffect edgeEffect2 = this.f1651B;
        if (AbstractC0598hx.m10443z(edgeEffect2) == 0.0f) {
            return z;
        }
        AbstractC0598hx.m10410M(edgeEffect2, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        if (this.f1654E) {
            this.f1656G = view2;
        } else {
            Rect rect = this.f1676y;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iM1006b = m1006b(rect);
            if (iM1006b != 0) {
                scrollBy(0, iM1006b);
            }
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int iM1006b = m1006b(rect);
        boolean z2 = iM1006b != 0;
        if (z2) {
            if (z) {
                scrollBy(0, iM1006b);
                return z2;
            }
            m1020q(0, iM1006b, false);
        }
        return z2;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z) {
        VelocityTracker velocityTracker;
        if (z && (velocityTracker = this.f1658I) != null) {
            velocityTracker.recycle();
            this.f1658I = null;
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.f1654E = true;
        super.requestLayout();
    }

    /* JADX INFO: renamed from: s */
    public final void m1022s(int i) {
        this.f1671V.m17966j(i);
    }

    @Override // android.view.View
    public final void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width >= width2 || i < 0) {
                i = 0;
            } else if (width + i > width2) {
                i = width2 - width;
            }
            if (height >= height2 || i2 < 0) {
                i2 = 0;
            } else if (height + i2 > height2) {
                i2 = height2 - height;
            }
            if (i == getScrollX() && i2 == getScrollY()) {
                return;
            }
            super.scrollTo(i, i2);
        }
    }

    @Override // android.view.View
    public final void setNestedScrollingEnabled(boolean z) {
        C1477tx c1477tx = this.f1671V;
        if (c1477tx.f41017a) {
            ViewGroup viewGroup = (ViewGroup) c1477tx.f41020d;
            WeakHashMap weakHashMap = obb.f31348a;
            fbb.m8068o(viewGroup);
        }
        c1477tx.f41017a = z;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        return this.f1671V.m17965i(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        m1022s(0);
    }

    @Override // p000.t47
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5) {
        m1013j(null, i4, i5);
    }

    @Override // p000.u47
    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        m1013j(iArr, i4, i5);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        return onStartNestedScroll(view, view2, i, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        onStopNestedScroll(view, 0);
    }

    @Override // p000.t47
    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr, int i3) {
        this.f1671V.m17959c(i, i2, i3, iArr, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        onNestedScrollAccepted(view, view2, i, 0);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i) {
        if (getChildCount() <= 0) {
            super.addView(view, i);
        } else {
            C1521v3.m18909p("ScrollView can host only one direct child");
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
        } else {
            C1521v3.m18909p("ScrollView can host only one direct child");
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i, layoutParams);
        } else {
            C1521v3.m18909p("ScrollView can host only one direct child");
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ginlemon.flowerfree.R.attr.nestedScrollViewStyle);
    }

    public NestedScrollView(Context context) {
        this(context, null);
    }
}
