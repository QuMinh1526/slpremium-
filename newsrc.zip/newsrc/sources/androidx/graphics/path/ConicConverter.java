package androidx.graphics.path;

import com.squareup.picasso.BuildConfig;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-66749cc189612c5a5f573ec6aca0f2f180ef66dbef5b1580d9b163a9c2a91ff2 */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m12197d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0014\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0005\b\u0000\u0018\u00002\u00020\u0001J8\u0010\n\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00022\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u0007H\u0082 ¢\u0006\u0004\b\n\u0010\u000b¨\u0006\f"}, m12198d2 = {"Landroidx/graphics/path/ConicConverter;", BuildConfig.VERSION_NAME, BuildConfig.VERSION_NAME, "conicPoints", BuildConfig.VERSION_NAME, "offset", "quadraticPoints", BuildConfig.VERSION_NAME, "weight", "tolerance", "internalConicToQuadratics", "([FI[FFF)I", "graphics-path_release"}, m12199k = 1, m12200mv = {1, 8, 0}, m12202xi = 48)
public final class ConicConverter {
    private final native int internalConicToQuadratics(float[] conicPoints, int offset, float[] quadraticPoints, float weight, float tolerance);
}
